<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<html lang="en-AU" style="filter: hue-rotate(7deg);"><head>
<meta charset="UTF-8">



    
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=2.0" data-next-head="" name="viewport">
    
    <title data-next-head="">'I lived on $36 a day — don't you lecture me about budgeting': Jacqui Lambie destroys Angus Taylor on Insiders</title>
    
     
    
    
    <link data-n-g="" href="./files/40ca0e753be8aa7e.css" rel="stylesheet">
    <link data-n-p="" href="./files/b890b605672e76ef.css" rel="stylesheet">
    <link data-n-p="" href="./files/4028a6d619f82bc4.css" rel="stylesheet">
    <link href="./files/3e9ee48d511f2e65.css" rel="stylesheet">
    <link href="./files/b04e9400f03d3df3.css" rel="stylesheet">
    <link href="./files/757e070902dbca83.css" rel="stylesheet">
    <link href="./files/c63d7820f1a41bbc.css" rel="stylesheet">
    <link data-n-p="" href="./files/df598ed8517b0fd1.css" rel="stylesheet">
    <link href="./files/964aeb144faa47ea.css" rel="stylesheet">
    
    
    <style>/* Адаптивные стили для расширенных изображений */
      .wider-image {
        max-width: none !important; 
        width: calc(100% + 200px) !important; 
        margin-left: -100px !important; 
        margin-right: -100px !important;
      }
      
      @media (max-width: 768px) {
        .wider-image {
          width: 100% !important;
          margin-left: 0 !important;
          margin-right: 0 !important;
          max-width: 100% !important;
        }
      }
      
      @media (min-width: 769px) and (max-width: 1024px) {
        .wider-image {
          width: calc(100% + 100px) !important;
          margin-left: -50px !important;
          margin-right: -50px !important;
        }
      }</style></head>
  <body class="" data-theme="default">
    <div id="__next">
      <div class="NotificationsProvider_container__xddr_ NotificationsProvider_bottom__gngLb AppContainer_notificationWrapper__UXamP" data-component="NotificationsProvider" style="width: 360px"></div>
      
      <div class="AppContainer_page__aGbNB isFuture GlobalStyles_dls__oymTZ" data-component="GlobalStyles" id="app-container">
        <div class="PlayerStyles_playerStyles__4t_0a">
          <div>
            <div data-component="Location">
              <div class="PageChrome_pageChrome__cgQrk">
                <div></div>
                <div class="Masthead_topBar__XSK3L">
                  <a class="ScreenReaderSkipToContent_skipLink__BA5st ScreenReaderOnly_srOnly__bnJwm ScreenReaderOnly_focusable__WHXdi" data-component="ScreenReaderSkipToContent" href="{offer}">Skip to main content</a>
                  <div>
                    <a class="ScreenReaderSkipToContent_skipLink__BA5st ScreenReaderOnly_srOnly__bnJwm ScreenReaderOnly_focusable__WHXdi" data-component="ScreenReaderSkipToContent" href="{offer}">Skip to news navigation, settings and search</a>
                    <div class="TopBar_topBar__DLar2" data-component="NetworkNavigationTopBar" data-product="news">
                      <aside aria-labelledby="switchHead">
                        <h2 class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly" id="switchHead">
                          Explore the ABC
                        </h2>
                        <nav aria-label="Choose an experience" class="ProductSwitchingTabsWrapper_nav__8qQO6" data-component="ProductSwitchingTabsWrapper">
                          <button aria-controls="menu-drawer-content" aria-expanded="false" aria-haspopup="true" class="menu-drawer-button_openButton__YzyLa" data-component="MenuDrawerButton" type="button">
                            <svg aria-hidden="true" class="ABCBrandLogo_logo__z6g7q ABCBrandLogo_mobileLogo__NcCnz BrandLogo_svg__0gSQX" data-component="Lissajous" height="44" preserveAspectRatio="xMinYMid meet" viewBox="0 0 34 44" width="34" xmlns="http://www.w3.org/2000/svg">
                              <path d="M31.223 10.785c1.35 1.017 1.724 2.158 1.777 4.262V29.4c-.16 2.425-1.723 3.726-3.056 4.315-.586.214-.853.267-1.564.267-1.172 0-2.683-.428-3.66-1.676-.426-.428-1.297-2.532-1.297-2.532l-4.94-13.158c-.301-.75-1.012-1.16-1.598-1.23-.64-.018-1.244.338-1.529 1.105l-1.51 4.154-2.63-6.953c1.298-2.318 2.524-2.853 3.98-3.406.498-.16 1.173-.25 1.724-.285h.213c1.173-.018 2.346.25 3.27.838.48.32 1.776 1.123 2.63 3.245l5.152 14.62V15.368l-.124.356-1.813 5.26-2.47-7.007c.32-1.57 1.51-2.906 2.843-3.566.409-.178.924-.303 1.368-.375h.143c1.083-.106 2.167.197 3.091.75zM18.573 27.51l1.563-4.155 2.63 6.9c-1.297 2.319-2.523 2.925-3.98 3.46a6.355 6.355 0 01-1.742.285h-.48c-1.083-.036-2.131-.32-2.984-.82-.48-.321-1.777-1.195-2.63-3.299L5.726 15.314V28.58l.071-.232 1.92-5.385 2.469 7.007c-.373 1.623-1.51 2.96-2.843 3.62-.497.232-.906.357-1.421.392h-.125c-1.066.071-2.15-.25-3.02-.82-1.333-.98-1.724-2.157-1.777-4.208V14.565c.16-2.371 1.67-3.673 3.02-4.261.64-.232.907-.285 1.6-.285 1.172-.054 2.63.428 3.66 1.622.426.428 1.297 2.532 1.297 2.532l4.94 13.212c.284.749.888 1.159 1.492 1.23a1.6 1.6 0 001.563-1.105z" fill="currentColor"></path>
                            </svg><span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">
                            </span><svg aria-hidden="true" class="ABCBrandLogo_logo__z6g7q ABCBrandLogo_desktopLogo__C5g10 BrandLogo_svg__0gSQX" data-component="ABCLogo" height="44" preserveAspectRatio="xMinYMid meet" viewBox="0 0 101 44" width="101" xmlns="http://www.w3.org/2000/svg">
                              <path d="M5.625 10.044h.188c1.151 0 2.501.5 3.475 1.619.412.412 1.217 2.34 1.29 2.515l.004.012 4.957 13.214c.288.743.886 1.175 1.494 1.22a1.616 1.616 0 001.513-.97l.058-.15 1.56-4.157 2.634 6.906c-1.295 2.328-2.534 2.927-3.983 3.459a7.026 7.026 0 01-1.385.265l-.353.023h-.486c-1.074-.033-2.136-.321-2.988-.82-.467-.319-1.675-1.116-2.534-3.036l-.11-.257-5.223-14.555V28.59l.077-.221 1.915-5.388 2.478 7.006c-.376 1.619-1.505 2.971-2.855 3.614-.436.2-.783.318-1.207.368l-.22.02H5.79a5.028 5.028 0 01-3.02-.81c-1.281-.932-1.691-2.058-1.763-3.95L1 28.968V14.578c.155-2.372 1.66-3.67 3.01-4.257.57-.197.852-.262 1.397-.275l.218-.002h.188zM90.341 10c4.467 0 8.127 2.36 9.49 6.108l.092.264.143.406-.385.22c-.143.088-.967.472-2.538 1.208-.416.208-.76.362-.872.415l-.03.014-.593.297-.164-.638c-.517-1.834-2.121-3.823-5.088-3.823-3.704 0-5.825 2.692-5.825 7.383 0 3.67 1.506 7.58 5.715 7.58 2.291 0 4.163-1.25 5.051-3.353l.092-.228.208-.539 4.495 2.022-.22.494c-1.681 3.834-5.374 6.163-9.692 6.163-.143 0-.286 0-.429-.01-6.395-.187-10.362-4.78-10.362-11.964 0-8.668 5.472-11.887 10.582-12.008.11-.011.22-.011.33-.011zm-59.09.787c1.303.976 1.693 2.052 1.744 3.997l.005.27V29.4c-.155 2.416-1.715 3.713-3.065 4.312-.586.221-.863.277-1.56.277-1.184 0-2.689-.444-3.663-1.674-.401-.413-1.206-2.35-1.278-2.526l-.005-.013-4.957-13.147a1.989 1.989 0 00-1.605-1.22c-.565-.01-1.13.295-1.438.96l-.067.16-1.504 4.157-2.634-6.961c1.284-2.328 2.523-2.86 3.972-3.404.415-.138.96-.223 1.451-.266l.287-.022v-.01h.11l.056-.006.055-.006v.011c1.173-.011 2.346.255 3.275.843.467.308 1.665 1.064 2.524 2.98l.11.257 5.167 14.6V15.386l-.122.355-1.814 5.255-2.468-7.017c.321-1.563 1.505-2.916 2.844-3.559.327-.16.726-.27 1.099-.335l.273-.042v-.01h.1c.01-.012.022-.012.022-.012 1.084-.089 2.18.21 3.087.765zM51.012 10l8.462 23.763h-5.495L52.11 28.28h-8.044l-1.868 5.482h-5.462L45.186 10h5.825zm18.571 0c3.583 0 7.847 1.066 7.847 6.141 0 2.153-.902 4.01-2.374 5.032 1.901 1 3 2.977 2.978 5.504 0 4.407-2.928 6.985-8.058 7.083l-.305.003H60V10h9.582zm-.186 13.71H65.22v5.504h4.505c2.055 0 3.077-.89 3.132-2.724.022-.802-.198-1.45-.637-1.9-.572-.572-1.539-.88-2.824-.88zm-21.297-6.734l-2.495 6.767h4.934l-2.44-6.767zm21.428-2.516H65.22v4.68h4.154c1.9 0 2.857-.835 2.857-2.504 0-1.011-.308-2.176-2.704-2.176z" fill="currentColor" fill-rule="nonzero"></path>
                            </svg><span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">
                            </span><span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">More from ABC</span>
                          </button>
                          <div class="Masthead_menuDrawer__N0CTl Drawer_drawerPanel__vtUsy Drawer_drawerPanel__vtUsy Drawer_left__PAg89" data-component="MenuDrawer" id="menu-drawer">
                            <nav aria-label="More from ABC" class="menu-drawer-content_drawerContent__yNQaF" data-uri="app://module/network-navigation-menu-drawer-content" id="menu-drawer-content">
                              <h2 class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly" id="dls-menu-drawer__label" tabindex="-1">
                                More from ABC
                              </h2>
                              <div class="menu-drawer-content_actionsWrapper__m8gBu">
                                <button aria-controls="menu-drawer-content" aria-expanded="true" aria-haspopup="true" class="menu-drawer-button_closeButton__FhKhL" data-component="MenuDrawerButton" type="button">
                                  <svg aria-hidden="true" class="icon_icon__9kCSO menu-drawer-button_icon__wbZlB icon_size20__HIjI5" data-component="Close" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M19 19 5 5" stroke="currentColor" stroke-width="2"></path>
                                    <path d="M5 19 19 5" stroke="currentColor" stroke-width="2"></path>
                                  </svg>
                                  <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">Close menu</span></button><a class="menu-drawer-content_logoLink__nY63i link_focus__JVp4o link_underlineNone__dHrj3" href="{offer}" tabindex="0"><svg aria-hidden="true" class="menu-drawer-content_logo__b06G7 BrandLogo_svg__0gSQX" data-component="ABCLogo" height="44" preserveAspectRatio="xMinYMid meet" viewBox="0 0 101 44" width="101" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M5.625 10.044h.188c1.151 0 2.501.5 3.475 1.619.412.412 1.217 2.34 1.29 2.515l.004.012 4.957 13.214c.288.743.886 1.175 1.494 1.22a1.616 1.616 0 001.513-.97l.058-.15 1.56-4.157 2.634 6.906c-1.295 2.328-2.534 2.927-3.983 3.459a7.026 7.026 0 01-1.385.265l-.353.023h-.486c-1.074-.033-2.136-.321-2.988-.82-.467-.319-1.675-1.116-2.534-3.036l-.11-.257-5.223-14.555V28.59l.077-.221 1.915-5.388 2.478 7.006c-.376 1.619-1.505 2.971-2.855 3.614-.436.2-.783.318-1.207.368l-.22.02H5.79a5.028 5.028 0 01-3.02-.81c-1.281-.932-1.691-2.058-1.763-3.95L1 28.968V14.578c.155-2.372 1.66-3.67 3.01-4.257.57-.197.852-.262 1.397-.275l.218-.002h.188zM90.341 10c4.467 0 8.127 2.36 9.49 6.108l.092.264.143.406-.385.22c-.143.088-.967.472-2.538 1.208-.416.208-.76.362-.872.415l-.03.014-.593.297-.164-.638c-.517-1.834-2.121-3.823-5.088-3.823-3.704 0-5.825 2.692-5.825 7.383 0 3.67 1.506 7.58 5.715 7.58 2.291 0 4.163-1.25 5.051-3.353l.092-.228.208-.539 4.495 2.022-.22.494c-1.681 3.834-5.374 6.163-9.692 6.163-.143 0-.286 0-.429-.01-6.395-.187-10.362-4.78-10.362-11.964 0-8.668 5.472-11.887 10.582-12.008.11-.011.22-.011.33-.011zm-59.09.787c1.303.976 1.693 2.052 1.744 3.997l.005.27V29.4c-.155 2.416-1.715 3.713-3.065 4.312-.586.221-.863.277-1.56.277-1.184 0-2.689-.444-3.663-1.674-.401-.413-1.206-2.35-1.278-2.526l-.005-.013-4.957-13.147a1.989 1.989 0 00-1.605-1.22c-.565-.01-1.13.295-1.438.96l-.067.16-1.504 4.157-2.634-6.961c1.284-2.328 2.523-2.86 3.972-3.404.415-.138.96-.223 1.451-.266l.287-.022v-.01h.11l.056-.006.055-.006v.011c1.173-.011 2.346.255 3.275.843.467.308 1.665 1.064 2.524 2.98l.11.257 5.167 14.6V15.386l-.122.355-1.814 5.255-2.468-7.017c.321-1.563 1.505-2.916 2.844-3.559.327-.16.726-.27 1.099-.335l.273-.042v-.01h.1c.01-.012.022-.012.022-.012 1.084-.089 2.18.21 3.087.765zM51.012 10l8.462 23.763h-5.495L52.11 28.28h-8.044l-1.868 5.482h-5.462L45.186 10h5.825zm18.571 0c3.583 0 7.847 1.066 7.847 6.141 0 2.153-.902 4.01-2.374 5.032 1.901 1 3 2.977 2.978 5.504 0 4.407-2.928 6.985-8.058 7.083l-.305.003H60V10h9.582zm-.186 13.71H65.22v5.504h4.505c2.055 0 3.077-.89 3.132-2.724.022-.802-.198-1.45-.637-1.9-.572-.572-1.539-.88-2.824-.88zm-21.297-6.734l-2.495 6.767h4.934l-2.44-6.767zm21.428-2.516H65.22v4.68h4.154c1.9 0 2.857-.835 2.857-2.504 0-1.011-.308-2.176-2.704-2.176z" fill="currentColor" fill-rule="nonzero"></path>
                                  </svg>
                                  <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">ABC</span></a>
                              </div>
                              <div data-uri="app://module/network-navigation-menu-drawer">
                                
                                <ul class="menu-drawer-items_navList__ZtX5g" data-component="MenuDrawerItems">
                                  <li class="menu-drawer-items_active__XXnda">
                                    <span></span><a aria-current="page" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-News" href="{offer}" tabindex="0">News</a>
                                  </li>
                                  <li class="">
                                    <a aria-current="false" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-iview" href="{offer}" tabindex="0">iview</a>
                                  </li>
                                  <li class="">
                                    <a aria-current="false" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-listen" href="{offer}" tabindex="0">listen</a>
                                  </li>
                                  <li class="">
                                    <a aria-current="false" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-kids" href="{offer}" tabindex="0">kids</a>
                                  </li>
                                  <li class="">
                                    <a aria-current="false" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-emergency" href="{offer}" tabindex="0">emergency</a>
                                  </li>
                                  <li class="">
                                    <a aria-current="false" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-local" href="{offer}" tabindex="0">local</a>
                                  </li>
                                  <li class="">
                                    <a aria-current="false" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-education" href="{offer}" tabindex="0">education</a>
                                  </li>
                                  <li class="">
                                    <a aria-current="false" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-shop" href="{offer}" tabindex="0">shop</a>
                                  </li>
                                  <li class="">
                                    <a aria-current="false" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-TVGuide" href="{offer}" tabindex="0">TV Guide</a>
                                  </li>
                                  <li class="">
                                    <a aria-current="false" class="menu-drawer-items_navLink__QQAr4 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" data-uri="app://link/network-navigation-menu-drawer-More" href="{offer}" tabindex="0">More</a>
                                  </li>
                                </ul>
                              </div>
                              <a class="menu-drawer-content_edPols__T3G0j" href="{offer}"><h3 class="menu-drawer-content_edPolsHeading__Vgibz">
                                  <span class="menu-drawer-content_edPolsLabel__TimaK">Editorial Policies</span>
                                </h3>
                                <div class="menu-drawer-content_edPolsLink__HU0iU">
                                  <span class="menu-drawer-content_edPolsText__pf9UA">Read our editorial guiding principles</span><svg aria-hidden="true" class="icon_icon__9kCSO menu-drawer-content_edPolsArrow__u_NdU icon_size16__Lso8B" data-component="ArrowRight" fill="none" height="1em" role="img" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="m13 19 7-7-7-7" stroke="currentColor" stroke-width="2"></path>
                                    <path d="M20 12H3" stroke="currentColor" stroke-width="2"></path>
                                  </svg></div></a>
                              <div class="menu-drawer-footer_footer__7f812" data-component="MenuDrawerFooter">
                                <ul class="Typography_base__sj2RP menu-drawer-footer_footerLinks__ED4lr Typography_sizeMobile12__w_FPC Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx Typography_letterSpacedSm__V8kil" data-component="FooterList" role="list">
                                  <li>
                                    <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Accessibility</a>
                                  </li>
                                  <li>
                                    <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Help</a>
                                  </li>
                                  <li>
                                    <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Contact Us</a>
                                  </li>
                                  <li>
                                    <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">About the ABC</a>
                                  </li>
                                  <li>
                                    <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Privacy Policy</a>
                                  </li>
                                  <li>
                                    <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Terms of Use</a>
                                  </li>
                                  <li>
                                    <a class="global-footer_link__6f_dM global-footer_copyright__oDsVs Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">© <span data-current-year></span> ABC</a>
                                  </li>
                                </ul>
                                <div class="menu-drawer-footer_socialIcons__0qdH8">
                                  <ul class="SocialLinkList_socialList__o0Ayv" data-component="SocialLinkList" role="list">
                                    <li class="SocialLinkList_large__R9q08">
                                      <a aria-label="ABC on Facebook" class="SocialLink_socialLink__5j2AT SocialLink_whiteOnGrey__x_iFs SocialLink_large__Q329P" data-component="SocialLink" href="{offer}" title="ABC on Facebook"><svg aria-hidden="true" class="icon_icon__9kCSO global-footer_icon__N7kKX icon_size32__l0CQW" data-component="Facebook" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M9.668 21h3.335v-8.996h2.502L16 9.194h-2.997V7.157c0-.759.309-1.346 1.26-1.346h1.494V3h-2.088c-3.24.013-4 1.99-3.995 3.937l-.006 2.257H8v2.81h1.668V21Z" fill="currentColor"></path>
                                        </svg>
                                      </a>
                                    </li>
                                    <li class="SocialLinkList_large__R9q08">
                                      <a aria-label="ABC on YouTube" class="SocialLink_socialLink__5j2AT SocialLink_whiteOnGrey__x_iFs SocialLink_large__Q329P" data-component="SocialLink" href="{offer}" title="ABC on YouTube"><svg aria-hidden="true" class="icon_icon__9kCSO global-footer_icon__N7kKX icon_size32__l0CQW" data-component="Youtube" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M12.312 6c.59.003 1.95.014 3.397.06l.485.016.243.009.483.02c.48.022.95.049 1.381.081.352.043 1.12.047 1.804.783.54.561.715 1.835.715 1.835l.004.033c.026.227.176 1.593.176 2.959l-.001 1.597a29.206 29.206 0 0 1-.175 2.764l-.004.032-.007.05c-.04.24-.232 1.29-.708 1.785-.685.737-1.452.74-1.804.783-.576.043-1.217.076-1.865.102l-.486.018c-1.778.062-3.486.071-3.87.073h-.092c-.26-.003-4.71-.048-6.108-.186-.4-.077-1.3-.053-1.985-.79-.54-.56-.715-1.835-.715-1.835l-.004-.032A28.69 28.69 0 0 1 3 13.197l.001-1.596c.013-1.299.15-2.548.175-2.764l.004-.033s.176-1.274.715-1.835c.685-.736 1.452-.74 1.804-.783.432-.032.9-.059 1.381-.08l.483-.021c1.7-.067 3.438-.082 4.13-.085h.619ZM10.09 9.673v5.088L15 12.226l-4.91-2.553Z" fill="currentColor"></path>
                                        </svg>
                                      </a>
                                    </li>
                                    <li class="SocialLinkList_large__R9q08">
                                      <a aria-label="ABC on Instagram" class="SocialLink_socialLink__5j2AT SocialLink_whiteOnGrey__x_iFs SocialLink_large__Q329P" data-component="SocialLink" href="{offer}" title="ABC on Instagram"><svg aria-hidden="true" class="icon_icon__9kCSO global-footer_icon__N7kKX icon_size32__l0CQW" data-component="Instagram" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M12.986 3c.997.002 1.5.008 1.942.022l.187.006.595.025c.958.044 1.612.196 2.185.419.591.23 1.093.537 1.594 1.038.5.5.808 1.002 1.038 1.594.222.572.374 1.227.418 2.184l.025.595.007.187c.013.443.02.945.021 1.943l.001.713v1.26c-.003.997-.009 1.5-.022 1.942l-.007.187c-.006.187-.015.373-.025.595-.044.958-.196 1.612-.418 2.184a4.41 4.41 0 0 1-1.038 1.595c-.5.5-1.003.808-1.594 1.038-.573.222-1.227.374-2.185.418l-.595.025-.187.007c-.443.013-.945.02-1.942.021l-.714.001h-1.259a66.95 66.95 0 0 1-1.943-.022l-.187-.007a65.575 65.575 0 0 1-.594-.025c-.958-.044-1.613-.196-2.185-.418a4.41 4.41 0 0 1-1.594-1.038 4.41 4.41 0 0 1-1.038-1.595c-.223-.572-.375-1.226-.419-2.184l-.025-.595-.006-.187c-.014-.443-.02-.945-.022-1.942v-1.973c.002-.998.008-1.5.022-1.943l.006-.187.025-.595c.044-.957.196-1.612.419-2.184A4.412 4.412 0 0 1 4.51 4.51c.5-.5 1.002-.808 1.594-1.038.572-.223 1.227-.375 2.185-.419l.594-.025.187-.006c.443-.014.945-.02 1.943-.022h1.973Zm-.45 1.621h-1.315l-.432.001a44.248 44.248 0 0 0-2.427.051c-.877.04-1.354.187-1.67.31-.42.163-.72.358-1.036.673-.315.315-.51.615-.673 1.035-.123.317-.27.794-.31 1.671-.034.76-.047 1.094-.05 2.427l-.002.432v1.556l.001.432c.004 1.334.017 1.668.051 2.427.04.877.187 1.354.31 1.671.163.42.358.72.673 1.035.315.315.615.51 1.035.673.317.123.794.27 1.671.31.76.035 1.094.047 2.427.051l.432.001h1.988a44.337 44.337 0 0 0 2.427-.052c.877-.04 1.354-.186 1.671-.31.42-.163.72-.358 1.035-.673.315-.315.51-.615.673-1.035.123-.317.27-.794.31-1.671l.022-.512.007-.19a53.6 53.6 0 0 0 .022-1.725l.001-.431v-1.989a56.217 56.217 0 0 0-.023-1.725l-.007-.19a69.007 69.007 0 0 0-.022-.512c-.04-.877-.186-1.354-.31-1.67a2.788 2.788 0 0 0-.673-1.036 2.789 2.789 0 0 0-1.035-.673c-.317-.123-.794-.27-1.671-.31a44.25 44.25 0 0 0-2.427-.05l-.431-.002h-.241Zm-.52 2.737a4.622 4.622 0 1 1 0 9.243 4.622 4.622 0 0 1 0-9.243Zm0 1.621a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm4.781-2.872a1.08 1.08 0 1 1 0 2.16 1.08 1.08 0 0 1 0-2.16Z" fill="currentColor"></path>
                                        </svg>
                                      </a>
                                    </li>
                                    <li class="SocialLinkList_large__R9q08">
                                      <a aria-label="ABC on X" class="SocialLink_socialLink__5j2AT SocialLink_whiteOnGrey__x_iFs SocialLink_large__Q329P" data-component="SocialLink" href="{offer}" title="ABC on X"><svg aria-hidden="true" class="icon_icon__9kCSO global-footer_icon__N7kKX icon_size32__l0CQW" data-component="X" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M13.317 10.775 19.146 4h-1.381l-5.061 5.883L8.662 4H4l6.112 8.896L4 20h1.381l5.344-6.212L14.994 20h4.662l-6.339-9.225ZM5.88 5.04H8l9.765 13.968h-2.121L5.879 5.04Z" fill="currentColor"></path>
                                        </svg>
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            </nav>
                          </div>
                          <div aria-hidden="true" class="Cloak_cloak__Rvtqv"></div>
                          <ul class="ProductSwitchingTabsWrapper_navList__TBqxr">
                            <li class="ProductSwitchingTab_item__9ib__" data-component="ProductSwitchingTab">
                              <a aria-current="page" class="ProductSwitchingTab_tab__27S9v ProductSwitchingTab_news__7DyG2 ProductSwitchingTab_selected__Ckqiy" data-tab="[object Object]" href="{offer}" id="news"><svg class="BrandLogo_svg__0gSQX" data-component="NewsLogo" fill="none" height="13" viewBox="0 0 46 13" width="46" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M6.99595 0.173679H9.84262V12.3241H6.47491L2.86452 5.11997V12.3241H0V0.173679H3.24638L6.99595 7.82866V0.173679ZM14.3202 7.27312H18.7467V4.82614H14.3202V2.535H18.8513L19.1809 0.173679H11.4735V12.3241H19.2154V9.85928H14.3202V7.27312ZM33.1525 0.173679L31.3824 9.04322H31.3301L29.3685 0.173679H26.73L24.8028 9.04322H24.7338L22.9459 0.173679H19.9434L22.8947 12.3241H26.228L28.0504 5.01648L29.8562 12.3241H33.1894L36.1574 0.173679H33.1549H33.1525ZM39.3836 3.45455C39.4014 2.77768 39.9046 2.43032 40.7718 2.43032C41.8996 2.43032 43.1843 2.81218 44.1562 3.45455L45.1983 1.26691C44.2954 0.693528 42.6288 0 40.8408 0C38.4283 0 36.5357 1.16341 36.5357 3.54139C36.5357 7.53364 42.4551 6.92576 42.4551 8.85289C42.4551 9.6166 41.8651 9.98061 40.7195 9.98061C39.0707 9.98061 38.081 9.2859 37.3696 8.76605L36.1027 10.9703C36.1027 10.9703 37.786 12.4978 40.8932 12.4978C43.4103 12.4978 45.3374 11.213 45.3374 8.54003C45.3374 4.42644 39.3312 5.25915 39.3836 3.45455Z" fill="currentColor"></path>
                                </svg>
                                <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">news</span></a>
                            </li>
                            <li class="ProductSwitchingTab_item__9ib__" data-component="ProductSwitchingTab">
                              <a class="ProductSwitchingTab_tab__27S9v ProductSwitchingTab_iview__46TWA" data-tab="[object Object]" href="{offer}" id="iview"><svg class="BrandLogo_svg__0gSQX" data-component="IviewLogo" fill="none" height="20" viewBox="0 0 48 20" width="48" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M24.9883 6.33333C27.9643 6.33333 30.4443 8.83333 30.4443 11.9167H28.295C28.295 10 26.807 8.5 24.9883 8.5C23.1697 8.5 21.6817 10 21.6817 11.9167C21.6817 13.8333 23.1697 15.3333 24.9883 15.3333C25.9803 15.3333 26.8897 14.8333 27.551 14.1667H30.031C29.2043 16.1667 27.303 17.5 24.9883 17.5C22.0123 17.5 19.5323 15 19.5323 11.9167C19.5323 8.83333 22.0123 6.33333 24.9883 6.33333ZM18.871 6.66667V17.4167H16.3083V6.66667H18.871ZM7.87632 6.66667L10.439 14.5H10.6043L13.167 6.66667H15.7297L11.7617 17.4167H9.19899L5.31366 6.66667H7.87632ZM4.65233 6.66667V17.4167H2.08966V6.66667H4.65233ZM32.4283 6.66667L34.495 14.1667H34.6603L36.727 6.66667H39.3723L41.439 14.1667H41.6043L43.7537 6.66667H46.399L42.8443 17.4167H40.3643L38.0497 10.1667H37.8843L35.8177 17.4167H33.3377L29.783 6.66667H32.4283ZM3.41233 2.5C4.23899 2.5 4.90032 3.16667 4.90032 4C4.90032 4.83333 4.23899 5.5 3.41233 5.5C2.58566 5.5 2.00699 4.83333 2.00699 4C1.92432 3.16667 2.58566 2.5 3.41233 2.5Z" fill="currentColor"></path>
                                  <path clip-rule="evenodd" d="M23.6655 9.41699L28.0469 12.0003L23.6655 14.5837V9.41699Z" fill="currentColor" fill-rule="evenodd"></path>
                                </svg>
                                <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">iview</span></a>
                            </li>
                            <li class="ProductSwitchingTab_item__9ib__" data-component="ProductSwitchingTab">
                              <a class="ProductSwitchingTab_tab__27S9v ProductSwitchingTab_listen__fHfKZ" data-tab="[object Object]" href="{offer}" id="listen"><svg class="BrandLogo_svg__0gSQX" data-component="ListenLogo" fill="none" height="20" viewBox="0 0 48 20" width="48" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M35.4324 11.8496L31.0034 14.372V9.32715L35.4324 11.8496Z" fill="currentColor"></path>
                                  <path d="M3.15181 3.60986V13.6996C3.15181 14.8431 3.66285 15.1458 4.4294 15.1458C4.9234 15.1458 5.45147 14.8263 5.50258 14.759L5.97954 16.5751C5.68996 16.7601 4.77009 17.3151 3.64581 17.3151C1.49946 17.3151 0.57959 15.8857 0.57959 13.935V4.1648L3.15181 3.60986Z" fill="currentColor"></path>
                                  <path d="M9.47163 6.60315V17.3151H6.88238V8.70517L6.89941 6.60315H9.47163Z" fill="currentColor"></path>
                                  <path d="M11.2092 14.12C11.2092 14.12 12.5549 15.3139 14.7353 15.3139C15.9788 15.3139 16.6943 14.944 16.6943 14.0695C16.6943 11.9843 10.4256 13.3801 10.63 9.44508C10.7152 7.52804 12.1461 6.38454 15.0249 6.38454C17.1542 6.38454 18.9429 7.39351 18.9429 7.39351L18.04 9.19284C18.04 9.19284 16.6602 8.30158 14.9397 8.3184C13.9177 8.3184 13.083 8.63791 13.117 9.47872C13.2363 11.1771 19.2665 9.86549 19.2665 14.0023C19.2665 16.2052 17.2564 17.3487 14.6842 17.3319C11.8905 17.3151 10.2382 15.9361 10.2382 15.9361L11.2092 14.12Z" fill="currentColor"></path>
                                  <path d="M23.4229 3.45852V6.58633H26.1485L25.7908 8.63791H23.4059V13.5482C23.4059 14.7085 23.951 15.1626 24.8198 15.1626C25.4841 15.1626 26.2848 14.759 26.4551 14.6917L26.9491 16.6256C26.7277 16.7265 25.5182 17.3151 24.1895 17.3151C21.6343 17.3151 20.8507 15.6334 20.8507 13.8846V8.62109H19.3346V6.58633H20.97L21.2766 3.7444L23.4229 3.45852Z" fill="currentColor"></path>
                                  <path d="M40.1168 6.60315L40.5086 8.50338C41.207 7.14127 42.655 6.51907 44.2222 6.50225C46.7773 6.48544 47.9868 8.1166 47.9868 10.3195V17.3151H45.4146V11.1435C45.4146 9.51235 44.8013 8.62109 43.3875 8.62109C41.4285 8.62109 40.6619 10.2018 40.6619 11.9171V17.3151H38.0897V6.60315H40.1168Z" fill="currentColor"></path>
                                  <path d="M32.0595 15.1794C30.1857 15.1794 28.6866 13.6828 28.6866 11.8498C28.6866 10.0168 30.2027 8.52019 32.0595 8.52019C33.9162 8.52019 35.4323 10.0168 35.4323 11.8498H37.5957C37.5957 8.82288 35.1087 6.38454 32.0595 6.38454C29.0103 6.38454 26.5232 8.8397 26.5232 11.8498C26.5232 14.8767 29.0103 17.3151 32.0595 17.3151C34.3421 17.3151 36.3011 15.9529 37.1528 14.0023H34.6317C34.0014 14.7254 33.0815 15.1794 32.0595 15.1794Z" fill="currentColor"></path>
                                  <path d="M9.64198 3.94619C9.64198 3.15583 8.99466 2.5 8.19404 2.5C7.39341 2.5 6.7461 3.13901 6.7461 3.94619C6.7461 4.73655 7.39341 5.37557 8.19404 5.37557C8.99466 5.37557 9.64198 4.73655 9.64198 3.94619Z" fill="currentColor"></path>
                                </svg>
                                <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">listen</span></a>
                            </li>
                          </ul>
                        </nav>
                      </aside>
                    </div>
                  </div>
                </div>
                <header class="Masthead_mastheadBox__qgV4D" data-component="MastheadBox">
                  <nav aria-label="primary" class="Masthead_nav__FLrmL">
                    <div class="NavBar_navBar__2vy1I">
                      <a class="Button_root__UZ8td Button_large__OX1mV Button_linkButton__vG7s7 Button_iconOnly__EVUjm BrandLogo_logoLink__f16Wl NavBar_logo__KObyg NavBar_navBarLink__XFMal" href="{offer}" id="newsLogoAnchor" role="link"><svg aria-hidden="true" class="BrandLogo_logo__8k2zE" data-component="ABCNewsLogo" fill="none" height="24" viewBox="0 0 90 24" width="90" xmlns="http://www.w3.org/2000/svg">
                          <path d="M37.9795 3.89957H41.775V20.1001H37.2848L32.4709 10.4946V20.1001H28.6515V3.89957H32.98L37.9795 14.1062V3.89957ZM47.7452 13.3655H53.6471V10.1029H47.7452V7.04801H53.7867L54.226 3.89957H43.9496V20.1001H54.272V16.8137H47.7452V13.3655ZM72.8549 3.89957L70.4948 15.7256H70.425L67.8095 3.89957H64.2915L61.722 15.7256H61.63L59.2461 3.89957H55.2427L59.1779 20.1001H63.6222L66.0521 10.3566L68.4598 20.1001H72.9041L76.8614 3.89957H72.8581H72.8549ZM81.163 8.27407C81.1868 7.37157 81.8577 6.90843 83.014 6.90843C84.5176 6.90843 86.2306 7.41757 87.5265 8.27407L88.9159 5.35721C87.712 4.5927 85.4899 3.668 83.106 3.668C79.8893 3.668 77.3658 5.21922 77.3658 8.38986C77.3658 13.7129 85.2583 12.9023 85.2583 15.4718C85.2583 16.4901 84.4716 16.9755 82.9442 16.9755C80.7458 16.9755 79.4262 16.0492 78.4777 15.3561L76.7885 18.2951C76.7885 18.2951 79.0328 20.3317 83.1758 20.3317C86.532 20.3317 89.1015 18.6187 89.1015 15.0547C89.1015 9.56992 81.0932 10.6802 81.163 8.27407ZM22.7338 3.622C22.085 3.19058 21.2714 2.95901 20.4656 3.00818C20.0659 3.03197 19.6678 3.12555 19.2903 3.30002C18.2799 3.78537 17.4266 4.79731 17.1475 6.01069L19.008 11.2687L20.445 7.23199L20.5053 7.06387V17.012L16.5812 6.08999C15.9373 4.5134 14.965 3.86626 14.5986 3.62042C13.9578 3.24292 13.16 3.03038 12.3495 3.00183C12.3289 3.00183 12.3082 3.00183 12.2876 3.00183C12.1877 3.00025 12.0862 2.99866 11.9863 3.00183C11.539 3.01611 11.0949 3.08748 10.6761 3.21913C9.58646 3.622 8.657 4.06929 7.68313 5.80925L9.66101 10.9863L10.8379 7.86961C11.0393 7.28275 11.5057 7.00994 11.9767 7.03214C12.4462 7.05435 12.9189 7.36681 13.1409 7.95209L16.8636 17.8621C16.8636 17.8621 17.5139 19.4371 17.8343 19.7623C18.6051 20.6521 19.6948 21.0153 20.5846 20.9741C21.1112 20.9741 21.3142 20.9344 21.7964 20.7726C22.8099 20.3269 23.9408 19.3578 24.0629 17.575V6.78312C24.0248 5.24301 23.7378 4.3532 22.7322 3.62359L22.7338 3.622ZM16.3782 18.2253L14.3987 13.007L13.2631 16.1253C13.0315 16.7407 12.5303 17.0072 12.037 16.9549C11.5913 16.9073 11.1488 16.6012 10.9172 16.0429L7.19461 6.17406C7.19461 6.17406 6.55065 4.59429 6.22391 4.27231C5.49747 3.34285 4.36498 3.01928 3.47517 3.01928C2.95176 3.01928 2.74715 3.06052 2.30462 3.22072C1.2911 3.66483 0.118958 4.63711 0 6.45639V17.2166C0.0380667 18.7948 0.318809 19.6449 1.33233 20.4126C2.04767 20.8424 2.90259 21.0677 3.74323 20.9788C4.09217 20.9424 4.43636 20.8519 4.76944 20.6981C5.77979 20.2112 6.67119 19.2008 6.91228 18.0271L5.05494 12.7675L3.69406 16.7074L3.60048 16.9771V6.98297L7.48169 17.943C8.12724 19.5212 9.09636 20.1287 9.45958 20.3698C10.2019 20.8377 11.1472 21.0359 12.083 20.9947C12.5271 20.9741 12.9696 20.9059 13.3868 20.7758C14.478 20.3698 15.4059 19.9669 16.3766 18.2253H16.3782Z" fill="currentColor"></path>
                        </svg>
                        <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">ABC News</span></a>
                      <ul class="NavigationList_navList__clcxR NavBar_list__p4p_T" role="list">
                        <li class="NavigationItem_navItem__Od_QF">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_linkButton__vG7s7 Button_ignoreTheme__g08LU NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationItem_navItemLink__bLRg2" href="{offer}" role="link">Just In</a>
                        </li>
                        <li class="NavigationItem_navItem__Od_QF">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_linkButton__vG7s7 Button_ignoreTheme__g08LU NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationItem_navItemLink__bLRg2" href="{offer}" role="link">For You</a>
                        </li>
                        <li class="NavigationItem_navItem__Od_QF">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_linkButton__vG7s7 Button_ignoreTheme__g08LU NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationItem_navItemLink__bLRg2" href="{offer}" role="link">Politics</a>
                        </li>
                        <li class="NavigationItem_navItem__Od_QF">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_linkButton__vG7s7 Button_ignoreTheme__g08LU NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationItem_navItemLink__bLRg2" href="{offer}" role="link">World</a>
                        </li>
                        <li class="NavigationItem_navItem__Od_QF">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_linkButton__vG7s7 Button_ignoreTheme__g08LU NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationItem_navItemLink__bLRg2" href="{offer}" role="link">Business</a>
                        </li>
                        <li class="NavigationItem_navItem__Od_QF">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_linkButton__vG7s7 Button_ignoreTheme__g08LU NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationItem_navItemLink__bLRg2" href="{offer}" role="link">Analysis</a>
                        </li>
                        <li class="NavigationItem_navItem__Od_QF">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_linkButton__vG7s7 Button_ignoreTheme__g08LU NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationItem_navItemLink__bLRg2" href="{offer}" role="link">Sport</a>
                        </li>
                        <li class="NavigationItem_navItem__Od_QF">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_linkButton__vG7s7 Button_ignoreTheme__g08LU NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationItem_navItemLink__bLRg2" href="{offer}" role="link">Lifestyle</a>
                        </li>
                        <li class="NavigationItem_navItem__Od_QF">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_linkButton__vG7s7 Button_ignoreTheme__g08LU NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationItem_navItemLink__bLRg2" href="{offer}" role="link">Entertainment</a>
                        </li>
                      </ul>
                      <button class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_withIcon__Znha0 Button_withGap__va3j2 Button_ignoreTheme__g08LU ToggleButton_button__wkn1A NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavBar_toggle__fAtLt" data-testid="toggleButton" role="button" type="button">
                        More<svg aria-hidden="true" class="icon_icon__9kCSO icon_size16__Lso8B" data-component="ChevronDoubleDown" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                          <path d="m19 12-7 7-7-7" stroke="currentColor" stroke-width="2"></path>
                          <path d="m19 5-7 7-7-7" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                      </button>
                      <div class="MastheadSearch_container__ryKc1 NavBar_search___knqF">
                        <div data-component="AutoCompleteSearchBoxNext">
                          <button class="Button_btn___qFSk AutoCompleteSearchBoxNext_openSearchModalButton__sZsNH Button_noBorder__4YGxV Button_uppercase__u_om3" data-component="Button" data-testid="open-search-modal-btn" type="button">
                            <svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="Search" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                              <path d="m21 21-6.904-6.904m0 0a6.5 6.5 0 1 0-9.192-9.192 6.5 6.5 0 0 0 9.192 9.192Z" stroke="currentColor" stroke-width="2"></path>
                            </svg>
                            <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">Search</span>
                          </button>
                        </div>
                      </div>
                      <button class="Button_root__UZ8td Button_primary__CwtEz Button_inverseTextVariant__VykD9 Button_large__OX1mV Button_withIcon__Znha0 Button_withGap__va3j2 Button_ignoreTheme__g08LU NavBar_navBarButton__s4h8l NavBar_navBarThin__gb9R8 NavBar_login__5PigM" role="button" textvariant="inverse" type="button">
                        Log in<svg aria-hidden="true" class="icon_icon__9kCSO Button_iconSize__umvch" data-component="Account" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                          <circle cx="12" cy="8" r="4" stroke="currentColor" stroke-width="2"></circle>
                          <path d="M5 21a6 6 0 0 1 6-6h2a6 6 0 0 1 6 6" stroke="currentColor" stroke-linejoin="round" stroke-width="2"></path>
                        </svg></button><button aria-label="More" class="Button_root__UZ8td Button_primary__CwtEz Button_large__OX1mV Button_withIcon__Znha0 Button_ignoreTheme__g08LU Button_iconOnly__EVUjm NavBar_navBarButton__s4h8l NavBar_navBarButtonColours__w_0fo NavBar_navBarButtonFix__kcJrY" data-testid="menuButton" role="button" type="button">
                        <svg aria-hidden="true" class="icon_icon__9kCSO Button_iconSize__umvch" data-component="Drawer" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                          <path d="M21 12H3" stroke="currentColor" stroke-width="2"></path>
                          <path d="M21 6H3" stroke="currentColor" stroke-width="2"></path>
                          <path d="M21 18H3" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                      </button>
                    </div>
                    <div class="MegaMenu_megaMenu__OKIqw Masthead_megaMenu__VALMC" data-component="MastheadMenu">
                      <div class="MegaMenu_content__6eUFg">
                        <ul class="MegaMenu_sections__IhMOA" style="
                            grid-template-areas: &quot;news-home news-home news-home sport lifestyle entertainment&quot;;
                            grid-template-columns: repeat(6, 1fr);
                          ">
                          <li class="NavigationSection_section__b71SE MegaMenu_section__xFIys" style="grid-area: news-home">
                            <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 Button_withIcon__Znha0 Button_withGap__va3j2 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_titleLink__ZBvVR" href="{offer}" role="link" textvariant="primary">News Home<svg aria-hidden="true" class="icon_icon__9kCSO NavigationSection_titleArrow__IOoSo icon_size24__GkyQ9" data-component="ArrowDiagonalRight" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18.02 6 6 18.02" stroke="currentColor" stroke-width="2"></path>
                                <path d="M18 16V6H8" stroke="currentColor" stroke-width="2"></path>
                              </svg>
                            </a>
                            <ul class="NavigationSection_list__VOTi_" role="list" style="--nw-navigation-section-column-limit: 3">
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Just In</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">For You</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Analysis</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Rural</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Watch Live</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Health</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Indigenous</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Politics</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Science</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Deep Time</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Elections</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">World</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Environment</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Investigations</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Business</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Local news</a>
                              </li>
                            </ul>
                          </li>
                          <li class="NavigationSection_section__b71SE MegaMenu_section__xFIys" style="grid-area: sport">
                            <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 Button_withIcon__Znha0 Button_withGap__va3j2 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_titleLink__ZBvVR" href="{offer}" role="link" textvariant="primary">Sport<svg aria-hidden="true" class="icon_icon__9kCSO NavigationSection_titleArrow__IOoSo icon_size24__GkyQ9" data-component="ArrowDiagonalRight" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18.02 6 6 18.02" stroke="currentColor" stroke-width="2"></path>
                                <path d="M18 16V6H8" stroke="currentColor" stroke-width="2"></path>
                              </svg>
                            </a>
                            <ul class="NavigationSection_list__VOTi_" role="list" style="--nw-navigation-section-column-limit: 1">
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">AFL</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">NRL</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Football</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Tennis</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Cricket</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Netball</a>
                              </li>
                            </ul>
                          </li>
                          <li class="NavigationSection_section__b71SE MegaMenu_section__xFIys" style="grid-area: lifestyle">
                            <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 Button_withIcon__Znha0 Button_withGap__va3j2 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_titleLink__ZBvVR" href="{offer}" role="link" textvariant="primary">Lifestyle<svg aria-hidden="true" class="icon_icon__9kCSO NavigationSection_titleArrow__IOoSo icon_size24__GkyQ9" data-component="ArrowDiagonalRight" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18.02 6 6 18.02" stroke="currentColor" stroke-width="2"></path>
                                <path d="M18 16V6H8" stroke="currentColor" stroke-width="2"></path>
                              </svg>
                            </a>
                            <ul class="NavigationSection_list__VOTi_" role="list" style="--nw-navigation-section-column-limit: 1">
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Wellbeing</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ NavigationSection_wrapText__Gk0t2" href="{offer}" role="link" textvariant="primary">Relationships &amp; Family</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Food &amp; Recipes</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Personal Finance</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Home &amp; Garden</a>
                              </li>
                            </ul>
                          </li>
                          <li class="NavigationSection_section__b71SE MegaMenu_section__xFIys" style="grid-area: entertainment">
                            <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 Button_withIcon__Znha0 Button_withGap__va3j2 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_titleLink__ZBvVR" href="{offer}" role="link" textvariant="primary">Entertainment<svg aria-hidden="true" class="icon_icon__9kCSO NavigationSection_titleArrow__IOoSo icon_size24__GkyQ9" data-component="ArrowDiagonalRight" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18.02 6 6 18.02" stroke="currentColor" stroke-width="2"></path>
                                <path d="M18 16V6H8" stroke="currentColor" stroke-width="2"></path>
                              </svg>
                            </a>
                            <ul class="NavigationSection_list__VOTi_" role="list" style="--nw-navigation-section-column-limit: 1">
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">TV &amp; Movies</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Books</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Music</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Pop Culture</a>
                              </li>
                              <li class="NavigationSection_listItem__iplIX">
                                <a class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_linkButton__vG7s7 NavBar_navBarThin__gb9R8 NavBar_navBarLinkColours__XX3s_ NavigationSection_sectionLink__7vLPi NavigationSection_item__CTOUQ" href="{offer}" role="link" textvariant="primary">Arts</a>
                              </li>
                            </ul>
                          </li>
                        </ul>
                        <div class="MegaMenu_cardWrapper__ncPXx MegaMenu_section__xFIys">
                          <div class="Panel_root__dh8kN LoginCard_card__PtI2W">
                            <div class="Panel_content__qJqjK LoginCard_content__0IrLw">
                              <svg class="icon_icon__9kCSO LoginCard_icon__idjri" data-component="AccountCircle" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"></circle>
                                <circle cx="12" cy="9" r="3" stroke="currentColor" stroke-width="2"></circle>
                                <path d="M6 20a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5" stroke="currentColor" stroke-linejoin="round" stroke-width="2"></path>
                              </svg>
                              <h4 class="Typography_base__sj2RP LoginCard_text__48cHX Typography_sizeMobile16__RyQmM Typography_sizeDesktop24__mJJ8n Typography_lineHeightMobile24__crkfh Typography_bold__FqafP Typography_colourInherit__dfnUx" data-component="Typography">
                                Your ABC Account
                              </h4>
                              <div class="LoginCard_textContainer__oXaUw">
                                <p class="Typography_base__sj2RP LoginCard_text__48cHX Typography_sizeMobile16__RyQmM Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                                  Personalise the news and
                                </p>
                                <p class="Typography_base__sj2RP LoginCard_text__48cHX Typography_sizeMobile16__RyQmM Typography_lineHeightMobile24__crkfh Typography_bold__FqafP Typography_colourInherit__dfnUx" data-component="Typography">
                                  stay in the know
                                </p>
                              </div>
                              <button class="Button_root__UZ8td Button_secondary__Vld8_ Button_large__OX1mV Button_withIcon__Znha0 Button_withGap__va3j2 Button_ignoreTheme__g08LU LoginCard_button__ALiYr" textvariant="primary" type="button">
                                Log in to personalise<svg aria-hidden="true" class="icon_icon__9kCSO Button_iconSize__umvch" data-component="ArrowDiagonalRight" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M18.02 6 6 18.02" stroke="currentColor" stroke-width="2"></path>
                                  <path d="M18 16V6H8" stroke="currentColor" stroke-width="2"></path>
                                </svg>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="MenuFooter_footer__2EXCv">
                        <ul class="MenuFooter_socialList__s2t3F MenuFooter_list__9j9Bj" role="list">
                          <li>
                            <a class="Button_root__UZ8td Button_linkButton__vG7s7 Button_iconOnly__EVUjm pill_thin__Yma7a pill_standard__CqiW9 SocialMediaButton_link__vuOsC" href="{offer}" role="link"><svg aria-hidden="true" class="SocialMediaButton_icon__ZSmCs" data-component="FacebookLogo" fill="none" height="18" viewBox="0 0 8 18" width="8" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.66832 18H5.00333V9.0044H7.5052L8 6.1936H5.00333V4.1568C5.00333 3.39799 5.31175 2.8108 6.26389 2.8108H7.75667V0H5.66944C2.42871 0.0126 1.66832 1.99002 1.67442 3.9374L1.66832 6.1936H0V9.0044H1.66832V18Z" fill="currentColor"></path>
                              </svg>
                              <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">Facebook</span></a>
                          </li>
                          <li>
                            <a class="Button_root__UZ8td Button_linkButton__vG7s7 Button_iconOnly__EVUjm pill_thin__Yma7a pill_standard__CqiW9 SocialMediaButton_link__vuOsC" href="{offer}" role="link"><svg aria-hidden="true" class="SocialMediaButton_icon__ZSmCs" data-component="YouTubeLogo" fill="none" height="13" viewBox="0 0 18 13" width="18" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.31163 0C9.90172 0.00282615 11.2627 0.0141311 12.7094 0.0593495L13.1938 0.0757132C13.2748 0.0786615 13.3558 0.081723 13.4367 0.0849024L13.9201 0.105427C14.4005 0.127435 14.8693 0.153995 15.3011 0.186051C15.653 0.229139 16.4202 0.232795 17.1047 0.969021C17.6444 1.52996 17.8203 2.80377 17.8203 2.80377L17.8241 2.83672C17.8502 3.06392 18 4.42971 18 5.79549L17.999 7.39284C17.986 8.69111 17.8489 9.94021 17.8241 10.1566L17.8203 10.1895L17.8126 10.2392C17.7738 10.4794 17.5809 11.5294 17.1047 12.0243C16.4202 12.7606 15.653 12.7642 15.3011 12.8073C14.7254 12.85 14.0836 12.8833 13.4361 12.9092L12.9504 12.9273C11.1722 12.9888 9.46445 12.9984 9.08019 12.9999L8.98806 13C8.72751 12.9974 4.27773 12.9521 2.88007 12.8144C2.47947 12.7373 1.58004 12.7606 0.895321 12.0243C0.35563 11.4634 0.180009 10.1895 0.180009 10.1895L0.176162 10.1566C0.150064 9.92939 0 8.56362 0 7.19786L0.000991344 5.6005C0.0140108 4.30222 0.151307 3.0531 0.176162 2.83672L0.180009 2.80377C0.180009 2.80377 0.35563 1.52996 0.895321 0.969021C1.58004 0.232795 2.34699 0.229139 2.69885 0.186051C3.13066 0.153995 3.59949 0.127435 4.07998 0.105427L4.56343 0.0849024C6.26254 0.0181345 8.00115 0.00329718 8.69279 0H9.31163ZM7.09091 3.67327L7.09175 8.76064L12 6.22582L7.09091 3.67327Z" fill="currentColor"></path>
                              </svg>
                              <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">YouTube</span></a>
                          </li>
                          <li>
                            <a class="Button_root__UZ8td Button_linkButton__vG7s7 Button_iconOnly__EVUjm pill_thin__Yma7a pill_standard__CqiW9 SocialMediaButton_link__vuOsC" href="{offer}" role="link"><svg aria-hidden="true" class="SocialMediaButton_icon__ZSmCs" data-component="InstagramLogo" fill="none" height="18" viewBox="0 0 18 18" width="18" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.98569 0C10.9832 0.00201065 11.4854 0.00805473 11.9281 0.0217352L12.1154 0.0280762C12.3016 0.0349058 12.4883 0.0432326 12.7099 0.0533402C13.6679 0.0970326 14.3221 0.249188 14.8946 0.471651C15.4864 0.701652 15.9883 1.00939 16.4886 1.50973C16.989 2.0101 17.2967 2.51201 17.5267 3.10384C17.7492 3.6763 17.9013 4.33055 17.9451 5.28849C17.9552 5.51002 17.9635 5.69674 17.9703 5.88297L17.9767 6.07031C17.9903 6.51297 17.9964 7.01517 17.9984 8.0127L17.9991 8.7265L17.9992 8.9992C17.9992 9.09321 17.9992 9.18405 17.9991 9.2719L17.9984 9.98568C17.9964 10.9832 17.9903 11.4854 17.9767 11.9281L17.9703 12.1154C17.9635 12.3016 17.9552 12.4883 17.9451 12.7099C17.9013 13.6678 17.7492 14.3221 17.5267 14.8945C17.2967 15.4864 16.989 15.9883 16.4886 16.4886C15.9883 16.989 15.4864 17.2967 14.8946 17.5267C14.3221 17.7492 13.6679 17.9013 12.7099 17.945C12.4883 17.9551 12.3016 17.9635 12.1154 17.9703L11.9281 17.9766C11.4854 17.9903 10.9832 17.9964 9.98569 17.9984L9.2719 17.9991L8.9992 17.9992C8.90519 17.9992 8.81434 17.9992 8.7265 17.9991L8.0127 17.9984C7.01517 17.9964 6.51297 17.9903 6.07032 17.9766L5.88299 17.9703C5.69677 17.9635 5.51005 17.9551 5.28853 17.945C4.33055 17.9013 3.67634 17.7492 3.10384 17.5267C2.51201 17.2967 2.0101 16.989 1.50976 16.4886C1.00943 15.9883 0.701688 15.4864 0.471687 14.8945C0.249188 14.3221 0.0970683 13.6678 0.0533402 12.7099C0.0432326 12.4883 0.0349058 12.3016 0.0280762 12.1154L0.0217352 11.9281C0.00805473 11.4854 0.00201065 10.9832 0 9.98568V8.0127C0.00201065 7.01517 0.00805473 6.51297 0.0217352 6.07031L0.0280762 5.88297C0.0349058 5.69674 0.0432326 5.51002 0.0533402 5.28849C0.0970683 4.33055 0.249188 3.6763 0.471687 3.10384C0.701688 2.51201 1.00943 2.0101 1.50976 1.50973C2.0101 1.00939 2.51201 0.701652 3.10384 0.471651C3.67634 0.249188 4.33055 0.0970326 5.28853 0.0533402C5.51005 0.0432326 5.69677 0.0349058 5.88299 0.0280762L6.07032 0.0217352C6.51297 0.00805473 7.01517 0.00201065 8.0127 0H9.98569ZM9.5367 1.62099H8.4617C8.37842 1.62105 8.29818 1.62114 8.22079 1.62124L7.78928 1.6221C6.45566 1.62584 6.12165 1.63864 5.36241 1.67328C4.48495 1.71329 4.00837 1.85991 3.69124 1.98316C3.27118 2.14643 2.97133 2.34146 2.65641 2.65641C2.34149 2.97133 2.14643 3.27114 1.98316 3.69124C1.85995 4.00837 1.71333 4.48492 1.67328 5.36241C1.63864 6.12162 1.62586 6.45564 1.62213 7.78928L1.62127 8.22079C1.62117 8.29818 1.62109 8.37842 1.62102 8.4617V9.53669C1.62109 9.61997 1.62117 9.70021 1.62127 9.7776L1.62213 10.2091C1.62586 11.5427 1.63864 11.8767 1.67328 12.636C1.71333 13.5134 1.85995 13.99 1.98316 14.3071C2.14643 14.7272 2.34149 15.027 2.65641 15.3419C2.97133 15.6569 3.27118 15.8519 3.69124 16.0152C4.00837 16.1385 4.48495 16.2851 5.36244 16.3251C6.12154 16.3597 6.45552 16.3725 7.78922 16.3763L8.22074 16.3771C8.29814 16.3772 8.37839 16.3773 8.46167 16.3774H9.53673C9.62001 16.3773 9.70026 16.3772 9.77765 16.3771L10.2092 16.3763C11.5429 16.3725 11.8769 16.3597 12.636 16.3251C13.5134 16.2851 13.99 16.1385 14.3072 16.0152C14.7272 15.8519 15.0271 15.6569 15.342 15.3419C15.6569 15.027 15.852 14.7272 16.0152 14.3071C16.1385 13.99 16.2851 13.5134 16.3251 12.636C16.3338 12.4461 16.3411 12.2829 16.3472 12.124L16.354 11.9339C16.3676 11.5205 16.3738 11.076 16.3763 10.2091L16.3771 9.7776C16.3772 9.70021 16.3773 9.61997 16.3774 9.53669V8.4617C16.3773 8.37842 16.3772 8.29818 16.3771 8.22079L16.3763 7.78928C16.3738 6.92242 16.3676 6.47789 16.354 6.06441L16.3472 5.87436C16.3411 5.71544 16.3338 5.55221 16.3251 5.36241C16.2851 4.48492 16.1385 4.00837 16.0152 3.69124C15.852 3.27114 15.6569 2.97133 15.342 2.65641C15.0271 2.34146 14.7272 2.14643 14.3072 1.98316C13.99 1.85991 13.5134 1.71329 12.636 1.67328C11.8767 1.63864 11.5427 1.62584 10.2091 1.6221L9.77761 1.62124C9.70022 1.62114 9.61997 1.62105 9.5367 1.62099ZM9.01506 4.3577C11.5675 4.3577 13.6367 6.42685 13.6367 8.97933C13.6367 11.5318 11.5675 13.6009 9.01506 13.6009C6.46261 13.6009 4.39342 11.5318 4.39342 8.97933C4.39342 6.42685 6.46261 4.3577 9.01506 4.3577ZM9.01506 5.97932C7.35822 5.97932 6.01504 7.32245 6.01504 8.97933C6.01504 10.6362 7.35822 11.9793 9.01506 11.9793C10.6719 11.9793 12.015 10.6362 12.015 8.97933C12.015 7.32245 10.6719 5.97932 9.01506 5.97932ZM13.7975 3.1073C14.3939 3.1073 14.8775 3.59081 14.8775 4.18729C14.8775 4.78376 14.3939 5.26727 13.7975 5.26727C13.201 5.26727 12.7175 4.78376 12.7175 4.18729C12.7175 3.59081 13.201 3.1073 13.7975 3.1073Z" fill="currentColor"></path>
                              </svg>
                              <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">Instagram</span></a>
                          </li>
                          <li>
                            <a class="Button_root__UZ8td Button_linkButton__vG7s7 Button_iconOnly__EVUjm pill_thin__Yma7a pill_standard__CqiW9 SocialMediaButton_link__vuOsC" href="{offer}" role="link"><svg aria-hidden="true" class="SocialMediaButton_icon__ZSmCs" data-component="TwitterLogo" fill="none" height="16" viewBox="0 0 16 16" width="16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.31742 6.77491L15.1457 0H13.7646L8.70389 5.88256L4.66193 0H0L6.11224 8.89547L0 16H1.38119L6.72542 9.78782L10.994 16H15.656L9.31742 6.77491ZM1.87886 1.03974H4.00029L13.7652 15.0075H11.6438L1.87886 1.03974Z" fill="currentColor"></path>
                              </svg>
                              <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">Twitter</span></a>
                          </li>
                        </ul>
                        <div class="MenuFooter_taxonomyContainer__r9F7I">
                          <ul class="MenuFooter_taxonomyList__2Cwll MenuFooter_list__9j9Bj" role="list">
                            <li>
                              <a class="Button_root__UZ8td Button_linkButton__vG7s7 TaxonomyButton_item__HRyTy" href="{offer}" role="link"><p class="Typography_base__sj2RP TaxonomyButton_itemText__Xz6DR Typography_sizeMobile16__RyQmM Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                                  Emergency
                                </p></a>
                            </li>
                            <li>
                              <a class="Button_root__UZ8td Button_linkButton__vG7s7 TaxonomyButton_item__HRyTy" href="{offer}" role="link"><p class="Typography_base__sj2RP TaxonomyButton_itemText__Xz6DR Typography_sizeMobile16__RyQmM Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                                  Backstory
                                </p></a>
                            </li>
                            <li>
                              <a class="Button_root__UZ8td Button_linkButton__vG7s7 TaxonomyButton_item__HRyTy" href="{offer}" role="link"><p class="Typography_base__sj2RP TaxonomyButton_itemText__Xz6DR Typography_sizeMobile16__RyQmM Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                                  Newsletters
                                </p></a>
                            </li>
                            <li>
                              <a class="Button_root__UZ8td Button_linkButton__vG7s7 TaxonomyButton_item__HRyTy" href="{offer}" role="link"><p class="Typography_base__sj2RP TaxonomyButton_itemText__Xz6DR Typography_sizeMobile16__RyQmM Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                                  中文新闻
                                </p></a>
                            </li>
                            <li>
                              <a class="Button_root__UZ8td Button_linkButton__vG7s7 TaxonomyButton_item__HRyTy" href="{offer}" role="link"><p class="Typography_base__sj2RP TaxonomyButton_itemText__Xz6DR Typography_sizeMobile16__RyQmM Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                                  BERITA BAHASA INDONESIA
                                </p></a>
                            </li>
                            <li>
                              <a class="Button_root__UZ8td Button_linkButton__vG7s7 TaxonomyButton_item__HRyTy" href="{offer}" role="link"><p class="Typography_base__sj2RP TaxonomyButton_itemText__Xz6DR Typography_sizeMobile16__RyQmM Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                                  TOK PISIN
                                </p></a>
                            </li>
                          </ul>
                          <div class="SelectBoxWithPillVariant_container__19kup Dropdown_dropdown__V6pZv DarkModeControl_dropdown__5hODe SelectBoxWithPillVariant_pill__5LvTU" data-component="SelectBoxWithPillVariant">
                            <label class="SelectBoxWithPillVariant_label__ZX7Wj ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly" id="darkModeControl-label"><div class="DarkModeControl_dropdownLabel__av93d">
                                <svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="Clear" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                  <path d="m19.491 16.99.832.555 1.09-1.633-1.962.079.04 1ZM7.01 4.51l1 .04.078-1.962-1.633 1.09.555.832Zm12.44 11.482c-.149.006-.299.009-.45.009v2c.178 0 .355-.004.531-.01l-.08-2ZM19 16C12.925 16 8 11.075 8 5H6c0 7.18 5.82 13 13 13v-2ZM8 5c0-.151.003-.301.01-.45l-2-.081c-.006.176-.01.353-.01.53h2Zm-4 7a7.991 7.991 0 0 1 3.565-6.66l-1.11-1.663A9.991 9.991 0 0 0 2 12h2Zm8 8a8 8 0 0 1-8-8H2c0 5.523 4.477 10 10 10v-2Zm6.66-3.565A7.991 7.991 0 0 1 12 20v2a9.991 9.991 0 0 0 8.323-4.455l-1.664-1.11Z" fill="currentColor"></path>
                                  <path d="m18 6-1-2-1 2-2 1 2 1 1 2 1-2 2-1-2-1Z" fill="currentColor"></path>
                                </svg>
                                <span>Appearance (BETA)</span>
                              </div>
                              <span></span></label>
                            <div class="SelectBoxWithPillVariant_selectContainer__qniXp DarkModeControl_selectContainer__mpKdY">
                              <div class="SelectBoxWithPillVariant_inputContainer__Wk2eB DarkModeControl_inputContainer__FUCvF">
                                <button aria-activedescendant="" aria-controls="darkModeControl-menu" aria-describedby="darkModeControl-helptext darkModeControl-helptext-in-menu" aria-expanded="false" aria-haspopup="listbox" aria-labelledby="darkModeControl-label" class="SelectBoxWithPillVariant_toggle__vJM2C Dropdown_toggle__XWEW1" id="darkModeControl-toggle-button" role="combobox" tabindex="0" type="button">
                                  <div class="SelectBoxWithPillVariant_toggleInner__Yy0tI">
                                    <div class="SelectBoxWithPillVariant_selectedItem__wbFRW">
                                      <svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="Clear" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="m19.491 16.99.832.555 1.09-1.633-1.962.079.04 1ZM7.01 4.51l1 .04.078-1.962-1.633 1.09.555.832Zm12.44 11.482c-.149.006-.299.009-.45.009v2c.178 0 .355-.004.531-.01l-.08-2ZM19 16C12.925 16 8 11.075 8 5H6c0 7.18 5.82 13 13 13v-2ZM8 5c0-.151.003-.301.01-.45l-2-.081c-.006.176-.01.353-.01.53h2Zm-4 7a7.991 7.991 0 0 1 3.565-6.66l-1.11-1.663A9.991 9.991 0 0 0 2 12h2Zm8 8a8 8 0 0 1-8-8H2c0 5.523 4.477 10 10 10v-2Zm6.66-3.565A7.991 7.991 0 0 1 12 20v2a9.991 9.991 0 0 0 8.323-4.455l-1.664-1.11Z" fill="currentColor"></path>
                                        <path d="m18 6-1-2-1 2-2 1 2 1 1 2 1-2 2-1-2-1Z" fill="currentColor"></path>
                                      </svg>
                                      Follow system settings
                                    </div>
                                    <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">
                                      Select an option</span>
                                  </div></button><svg aria-hidden="true" class="icon_icon__9kCSO SelectBoxWithPillVariant_toggleIcon__JFw8S Dropdown_toggleIcon__V3ZjM icon_size24__GkyQ9" data-component="Dropdown" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M7 10h10l-5 5-5-5Z" fill="currentColor"></path>
                                </svg>
                              </div>
                              <div aria-labelledby="darkModeControl-label" class="SelectBoxWithPillVariant_menuContainer__46WEe Dropdown_menuContainer__WBdvc DarkModeControl_menuContainer__PkHNK SelectBoxWithPillVariant_containerHidden__oS1Sz" id="darkModeControl-menu" role="listbox">
                                <ul class="SelectBoxWithPillVariant_options__YqUUH" role="none">
                                  <li aria-disabled="false" aria-selected="false" class="SelectBoxWithPillVariant_option__zlzFw Dropdown_option__le250" id="darkModeControl-item-0" role="option">
                                    <span class="Typography_base__sj2RP Typography_sizeMobile14__u7TGe Typography_lineHeightMobile20___U7Vr Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">Always light</span>
                                  </li>
                                  <li aria-disabled="false" aria-selected="false" class="SelectBoxWithPillVariant_option__zlzFw Dropdown_option__le250" id="darkModeControl-item-1" role="option">
                                    <span class="Typography_base__sj2RP Typography_sizeMobile14__u7TGe Typography_lineHeightMobile20___U7Vr Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">Always dark</span>
                                  </li>
                                  <li aria-disabled="false" aria-selected="true" class="SelectBoxWithPillVariant_option__zlzFw Dropdown_option__le250 SelectBoxWithPillVariant_selected__ICxVn" id="darkModeControl-item-2" role="option">
                                    <span class="Typography_base__sj2RP Typography_sizeMobile14__u7TGe Typography_lineHeightMobile20___U7Vr Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">Follow system settings</span>
                                  </li>
                                </ul>
                              </div>
                            </div>
                            <p class="Typography_base__sj2RP SelectBoxWithPillVariant_message__JZzbj Typography_sizeMobile12__w_FPC Typography_lineHeightMobile20___U7Vr Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography" id="darkModeControl-helptext">
                              <span class="DarkModeControl_message__Ssmve">Find any issues using dark mode?
                                <a class="Link_link__kR0xA Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showVisited__C1Fea Link_showFocus__ALyv2" data-component="Link" href="{offer}">Please let us know</a></span>
                            </p>
                          </div>
                        </div>
                        <ul class="MenuFooter_appList__yYe65 MenuFooter_list__9j9Bj" role="list">
                          
                          <li>
                            <a class="AppIconButton_appButton__tF_Pq" href="{offer}"><div class="AppIcon_appIcon__DQm_B">
                                <svg aria-hidden="true" height="57" width="57">
                                  <use xlink:href="#abciview-logo"></use>
                                </svg>
                              </div>
                              <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">ABC iView</span></a>
                          </li>
                          <li>
                            <a class="AppIconButton_appButton__tF_Pq" href="{offer}"><div class="AppIcon_appIcon__DQm_B">
                                <svg aria-hidden="true" height="57" width="57">
                                  <use xlink:href="#abclisten-logo"></use>
                                </svg>
                              </div>
                              <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">ABC Listen</span></a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </nav>
                </header>
                <div id="top"></div>
                <div aria-hidden="true" class="FixedHeader_fixedHeader__rVwtf" data-component="FixedHeader">
                  <div>
                    <a class="Button_root__UZ8td Button_large__OX1mV Button_linkButton__vG7s7 Button_iconOnly__EVUjm BrandLogo_logoLink__f16Wl FixedHeader_brandLogo__E7orJ NavBar_navBarLink__XFMal" href="{offer}" id="newsLogoAnchor" role="link"><svg aria-hidden="true" class="BrandLogo_logo__8k2zE" data-component="ABCNewsLogo" fill="none" height="24" viewBox="0 0 90 24" width="90" xmlns="http://www.w3.org/2000/svg">
                        <path d="M37.9795 3.89957H41.775V20.1001H37.2848L32.4709 10.4946V20.1001H28.6515V3.89957H32.98L37.9795 14.1062V3.89957ZM47.7452 13.3655H53.6471V10.1029H47.7452V7.04801H53.7867L54.226 3.89957H43.9496V20.1001H54.272V16.8137H47.7452V13.3655ZM72.8549 3.89957L70.4948 15.7256H70.425L67.8095 3.89957H64.2915L61.722 15.7256H61.63L59.2461 3.89957H55.2427L59.1779 20.1001H63.6222L66.0521 10.3566L68.4598 20.1001H72.9041L76.8614 3.89957H72.8581H72.8549ZM81.163 8.27407C81.1868 7.37157 81.8577 6.90843 83.014 6.90843C84.5176 6.90843 86.2306 7.41757 87.5265 8.27407L88.9159 5.35721C87.712 4.5927 85.4899 3.668 83.106 3.668C79.8893 3.668 77.3658 5.21922 77.3658 8.38986C77.3658 13.7129 85.2583 12.9023 85.2583 15.4718C85.2583 16.4901 84.4716 16.9755 82.9442 16.9755C80.7458 16.9755 79.4262 16.0492 78.4777 15.3561L76.7885 18.2951C76.7885 18.2951 79.0328 20.3317 83.1758 20.3317C86.532 20.3317 89.1015 18.6187 89.1015 15.0547C89.1015 9.56992 81.0932 10.6802 81.163 8.27407ZM22.7338 3.622C22.085 3.19058 21.2714 2.95901 20.4656 3.00818C20.0659 3.03197 19.6678 3.12555 19.2903 3.30002C18.2799 3.78537 17.4266 4.79731 17.1475 6.01069L19.008 11.2687L20.445 7.23199L20.5053 7.06387V17.012L16.5812 6.08999C15.9373 4.5134 14.965 3.86626 14.5986 3.62042C13.9578 3.24292 13.16 3.03038 12.3495 3.00183C12.3289 3.00183 12.3082 3.00183 12.2876 3.00183C12.1877 3.00025 12.0862 2.99866 11.9863 3.00183C11.539 3.01611 11.0949 3.08748 10.6761 3.21913C9.58646 3.622 8.657 4.06929 7.68313 5.80925L9.66101 10.9863L10.8379 7.86961C11.0393 7.28275 11.5057 7.00994 11.9767 7.03214C12.4462 7.05435 12.9189 7.36681 13.1409 7.95209L16.8636 17.8621C16.8636 17.8621 17.5139 19.4371 17.8343 19.7623C18.6051 20.6521 19.6948 21.0153 20.5846 20.9741C21.1112 20.9741 21.3142 20.9344 21.7964 20.7726C22.8099 20.3269 23.9408 19.3578 24.0629 17.575V6.78312C24.0248 5.24301 23.7378 4.3532 22.7322 3.62359L22.7338 3.622ZM16.3782 18.2253L14.3987 13.007L13.2631 16.1253C13.0315 16.7407 12.5303 17.0072 12.037 16.9549C11.5913 16.9073 11.1488 16.6012 10.9172 16.0429L7.19461 6.17406C7.19461 6.17406 6.55065 4.59429 6.22391 4.27231C5.49747 3.34285 4.36498 3.01928 3.47517 3.01928C2.95176 3.01928 2.74715 3.06052 2.30462 3.22072C1.2911 3.66483 0.118958 4.63711 0 6.45639V17.2166C0.0380667 18.7948 0.318809 19.6449 1.33233 20.4126C2.04767 20.8424 2.90259 21.0677 3.74323 20.9788C4.09217 20.9424 4.43636 20.8519 4.76944 20.6981C5.77979 20.2112 6.67119 19.2008 6.91228 18.0271L5.05494 12.7675L3.69406 16.7074L3.60048 16.9771V6.98297L7.48169 17.943C8.12724 19.5212 9.09636 20.1287 9.45958 20.3698C10.2019 20.8377 11.1472 21.0359 12.083 20.9947C12.5271 20.9741 12.9696 20.9059 13.3868 20.7758C14.478 20.3698 15.4059 19.9669 16.3766 18.2253H16.3782Z" fill="currentColor"></path>
                      </svg>
                      <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">ABC News</span></a>
                    <div>
                      <a class="Button_root__UZ8td Button_primary__CwtEz Button_inverseTextVariant__VykD9 Button_small__WnhyE Button_linkButton__vG7s7 Button_withIcon__Znha0 Button_withGap__va3j2 NewsHomeButton_newsHomeButton__chSnq" href="{offer}" role="link" textvariant="inverse"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size20__HIjI5" data-component="ArrowLeft" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                          <path d="m11 19-7-7 7-7" stroke="currentColor" stroke-width="2"></path>
                          <path d="M4 12h17" stroke="currentColor" stroke-width="2"></path>
                        </svg>News Home</a>
                    </div>
                  </div>
                  <div class="FixedHeader_titleWrap__i67Mf">
                    <span class="Typography_base__sj2RP FixedHeader_title__EPqZ2 Typography_sizeMobile16__RyQmM Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">'I lived on $36 a day — don't you lecture me about budgeting': Jacqui Lambie destroys Angus Taylor on Insiders</span>
                  </div>
                  <div class="FixedHeader_endSection__pn6IE">
                    <button aria-label="Share this article" class="Button_root__UZ8td Button_primary__CwtEz Button_inverseTextVariant__VykD9 Button_small__WnhyE Button_withIcon__Znha0 Button_withGap__va3j2 ShareButton_shareButton__r_dH1" role="button" textvariant="inverse" type="button">
                      <span class="Typography_base__sj2RP Typography_sizeMobile14__u7TGe Typography_sizeDesktop16__zyLf4 Typography_lineHeightDesktop16__eRkjh Typography_bold__FqafP Typography_colourInherit__dfnUx" data-component="Typography"><span class="ShareButton_buttonTextShort__Y1p9n">Share</span><span class="ShareButton_buttonTextLong__LRMeU">Share
                          article</span></span><svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="ShareWeb" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path clip-rule="evenodd" d="M15 13s-9-1-12.998 7c0 0 0-13 12.998-13V3l7 7-7 7v-4Z" fill="currentColor" fill-rule="evenodd"></path>
                      </svg>
                    </button>
                  </div>
                </div>
                <main id="content" style="min-height: 600px" tabindex="-1">
                  <article>
                    <div class="Article_layout__1pl0i">
                      <div class="ArticleHeadline_container__cAj5Q Article_head__D5qU4">
                        <div class="Article_headContent__PNoau">
                          <h1 class="Typography_base__sj2RP ArticleHeadlineTitle_title__A2dkr Typography_sizeMobile24__GzKLB Typography_sizeDesktop32__LR_G6 Typography_lineHeightDesktop40__BuoRf Typography_bold__FqafP Typography_serif__qU2V5 Typography_colourInherit__dfnUx Typography_normalise__u5o1s" data-component="ArticleHeadlineTitle">
                            'I lived on $36 a day — don't you lecture me about budgeting': Jacqui Lambie destroys Angus Taylor on Insiders
                          </h1>
                          
                          
                          <div style="margin-top: 12px; margin-bottom: 8px;">
                            <p class="Typography_base__sj2RP Typography_sizeMobile14__XeqLz Typography_lineHeightMobile20___U7Vr Typography_regular__WeIG6" style="margin-bottom: 8px;">
                              Australian Politics
                            </p>
                            <div style="display: inline-block; background-color: #cfe1f5; border-radius: 12px; padding: 4px 12px;">
                              <span class="Typography_base__sj2RP Typography_sizeMobile12__w_FPC Typography_lineHeightMobile20___U7Vr Typography_bold__FqafP" style="color: #10316a;">
                                Just In
                              </span>
                            </div>
                          </div>
                          
                          <div class="ArticleHeadlineTitle_meta__eYg46" style="margin-top: 16px">
                            <time class="Typography_base__sj2RP ArticleHeadlineTitle_metaTimestamp__Ri6e7 DynamicTimestamp_displayDate__Y3t35 Typography_sizeMobile12__w_FPC Typography_lineHeightMobile20___U7Vr Typography_bold__FqafP Typography_colourInherit__dfnUx Typography_letterSpacedSm__V8kil" datetime="2026-04-13T07:00:00.000Z" style="color: #10316a">
                              22h ago
                            </time>
                            <span style="color: #10316a; font-size: 0.75rem; font-weight: 700; margin-left: 12px; letter-spacing: 0.3px;">5.1M views · Trending #1 · 47K shares</span>
                          </div>
                        </div>
                      </div>

                      <div class="Article_main__wLtNk">
                        <figure class="ContentAlignment_marginBottom__4H_6E ContentAlignment_overflowAuto__c1_IL Figure_figure__xLyBy Figure_docImage__DSvk4 wider-image" data-component="Figure">
                          <div class="Image_container__AWHbi">
                            <img alt="Jacqui Lambie confronts Angus Taylor on Insiders" class="Image_image__5tFYM ContentImage_image__DQ_cq" src="./img/au_1.png">
                          </div>
                          <figcaption class="Figure_caption__fS2lN" data-component="Figure__figcaption">
                            <p class="Typography_base__sj2RP FigureCaption_text__zDxQ5 Typography_sizeMobile12__w_FPC Typography_lineHeightMobile20___U7Vr Typography_regular__WeIG6 Typography_colourInherit__dfnUx">The moment Angus Taylor walked off the Insiders set — Jacqui Lambie watches as the Opposition Leader retreats</p>
                          </figcaption>
                        </figure>

                        <div style="background: #ecf2fb; padding: 28px; margin: 32px 0; border-radius: 8px;">
                          <strong class="Typography_base__sj2RP Typography_bold__FqafP" style="display: block; margin-bottom: 16px; font-size: 20px; color: #10316a;">In short:</strong>
                          <p class="paragraph_paragraph__Z5Ozx" style="margin: 0; line-height: 1.6">The Insiders clash between a former single mum on welfare and an Oxford-educated Opposition Leader — and the moment that changed everything for thousands of struggling Australians</p>
                        </div>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>It was supposed to be a polite policy debate about the cost of living crisis. It lasted eleven minutes before Angus Taylor walked off set.</strong></p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">What happened in those eleven minutes has now been watched 5.1 million times. And what Jacqui Lambie revealed — while Taylor sat there in his $3,000 suit unable to respond — has already changed the lives of thousands of ordinary Australians.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">The setup was simple. Two guests on Insiders. Senator Jacqui Lambie — former army corporal, former single mum, seven years on a disability pension, now the most popular independent politician in Australia. And Angus Taylor — Rhodes Scholar, Oxford graduate, McKinsey consultant, sheep farm heir, Leader of the Opposition. The topic: what to do about petrol at $2.50 a litre, grocery bills up 18%, the RBA raising interest rates for the third time this year, a federal budget that offered workers $250 a year and called it 'relief', and the worst cost of living crisis in a generation.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Nobody expected what happened next.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Here's why Australia can't stop talking about it.</strong></p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">The host opened with the question every Australian is asking: 'With petrol at $2.50, the RBA raising rates for the third time in a row, a budget that gave workers $250 a year, energy bills doubling, groceries up 18% — and Commonwealth Bank just admitting to a billion dollars in AI-generated loan fraud — what should ordinary Australians actually do?' Taylor went first.</p>

                        <h2 class="Typography_base__sj2RP Typography_bold__FqafP Typography_serif__qU2V5" style="font-size: 24px; margin: 32px 0 16px;">The answer that made Australia furious</h2>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Angus Taylor straightened his tie and leaned into the microphone. The Oxford polish was on full display. The same tone he uses in Question Time when he talks about 'responsible economic management' while families are choosing between petrol and dinner.</p>

                        <figure class="ContentAlignment_marginBottom__4H_6E ContentAlignment_overflowAuto__c1_IL Figure_figure__xLyBy Figure_docImage__DSvk4" data-component="Figure">
                          <div class="Image_container__AWHbi">
                            <img alt="Angus Taylor in studio" class="Image_image__5tFYM ContentImage_image__DQ_cq" src="./img/au_2.png">
                          </div>
                        </figure>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Taylor:</strong> 'Look, we understand cost of living is the number one issue. We have a clear plan — ease housing pressure, cut red tape for small business, and ensure Australians are making responsible financial decisions. Families need to budget carefully, seek qualified advice, and—'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'Budget carefully?' Lambie's voice cut through the studio like a blade. 'Did you just say BUDGET CAREFULLY?'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Taylor froze.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">'Budget carefully.' Lambie leaned forward. 'Let me tell you about budgeting carefully, Angus. I lived on $36 a day. Disability pension. Two kids. I cried because I couldn't afford bread and milk. My fridge broke and I used an esky for three weeks because I couldn't afford to fix it. I drove without a licence because I couldn't afford to renew it. THAT'S budgeting carefully.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">The studio fell silent.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'And you — Oxford, McKinsey, family sheep station, Rhodes bloody Scholar — you sit there and tell a single mum in Western Sydney to BUDGET CAREFULLY? While petrol is $2.50 a litre? While CBA just approved a BILLION dollars in fake AI loans? While Bloomberg calls them the most UNLOVED bank in the world? While energy bills have doubled? While your mates in the banking sector pay themselves millions and charge families 6.5% on their mortgages?'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">'You want to know what budgeting looks like, Angus?' Her finger pointed at Taylor. 'A woman in Logan. Three kids. Night shifts at Woolies. She drove past four empty servo stations last Tuesday before finding one at $2.55 a litre. Her mortgage just went up for the third time this year thanks to the RBA. She's on Centrelink's website at midnight because she heard there might be a payment she missed. And you're telling HER to budget carefully from your family property in the Southern Highlands?'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">The studio erupted. Not polite ABC applause. A roar. A woman in the second row — aged care worker, still in her lanyard — stood up and started clapping. Then a bloke behind her. Then the whole left side of the studio.</p>

                        <div style="background: #f2f2f2; border-top: 3px solid #00527c; padding: 14px 20px; margin: 28px 0;">
                          <p style="margin: 0; font-size: 0.85rem; color: #4a4a4a; line-height: 1.5;"><strong style="color: #00527c;">📊 ABC News</strong> &nbsp;—&nbsp; This article has been viewed 2.3 million times in the last 48 hours — the most-read article on ABC News this month. The full Insiders clip has been watched 5.1 million times across all platforms.</p>
                        </div>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Taylor's face went white.</p>

                        <figure class="ContentAlignment_marginBottom__4H_6E ContentAlignment_overflowAuto__c1_IL Figure_figure__xLyBy Figure_docImage__DSvk4" data-component="Figure">
                          <div class="Image_container__AWHbi">
                            <img alt="" class="Image_image__5tFYM ContentImage_image__DQ_cq" src="./img/au_4.png">
                          </div>
                        </figure>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Taylor:</strong> 'I think that's rather — look, I understand what it's like to struggle. My mother raised us on a farm—'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">'A FARM?' Lambie exploded. 'A farm with HOW many hectares, Angus? Your family property is worth what — $30 million? $40 million? Don't you DARE compare that to a single mum eating two-minute noodles so her kids can have real food. I'VE BEEN THAT MUM. You haven't. You never will be. So don't you sit there and pretend you understand.'</p>

                        
                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Taylor:</strong> 'Senator, the real issue driving cost of living pressure is migration. Record net overseas migration is pushing up rents, the budget just delivered $150 billion in deficits, and real wages have fallen three per cent — the steepest drop of any developed country. A responsible government has to get that intake under control—'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Lambie went very still. When she spoke, her voice was quieter than it had been all morning. That was the tell — Lambie quiet means Lambie furious.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'So now you are blaming migrants. Seriously. Petrol is $2.50 because of migrants? Energy bills doubled because of migrants? CBA just approved a billion dollars in dodgy AI loans — because of migrants? You know what is actually driving this crisis, Angus? A system that works perfectly for Oxford graduates with family properties and is completely broken for everyone else. Migrants, born-and-bred Aussies, pensioners — the system squeezes them all exactly the same.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'And what does the government offer? $250 a year. That's $4.80 a week. That won't fill a petrol tank. That won't cover one mortgage repayment after the RBA's third rate hike. That won't even buy a week's groceries for a family of four. $4.80 a week — and Jim Chalmers stood up in Parliament and called it RELIEF. And what does YOUR mob offer, Angus? Nothing. Not even that. Meanwhile the government finally scraps negative gearing for existing properties — and YOUR lot are the ones screaming blue murder about it. Funny how it's only a crisis when it affects property investors, isn't it?'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Taylor:</strong> 'It is simply a matter of housing supply — the numbers speak for themselves—'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'Supply. You know what else is about supply? A platform that is letting ordinary Australians — nurses who came here from the Philippines, tradies born in Tassie, pensioners who have worked this country their whole lives — actually grow their savings instead of watching them vanish into rent and petrol. While you are pointing fingers at boat arrivals, three hundred and fifty dollars on this platform is doing more for working families than your entire migration policy ever has.'</p>

<div style="border-top: 2px solid #00527c; border-bottom: 2px solid #00527c; padding: 20px 24px; margin: 32px 0; text-align: center;">
                          <p style="margin: 0 0 8px; font-size: 1.1rem; color: #1a1a1a; line-height: 1.6; font-style: italic; font-family: 'ABCSerif', Georgia, serif;">'In 55 years of Insiders, I have never seen a guest do what Senator Lambie did next. And I have never seen a reaction like the one that followed.'</p>
                          <p style="margin: 0; font-size: 0.8rem; color: #6e6e6e; letter-spacing: 0.5px;">SENIOR ABC PRODUCER, SPEAKING OFF THE RECORD</p>
                        </div>

<h2 class="Typography_base__sj2RP Typography_bold__FqafP Typography_serif__qU2V5" style="font-size: 24px; margin: 32px 0 16px;">'And that's when I decided to tell the truth'</h2>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Lambie took a breath. The studio was dead silent. Then she looked directly into the camera — not at Taylor, not at the host — straight down the lens at every Australian watching at home.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Taylor shifted uncomfortably.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Taylor:</strong> 'Senator Lambie, I really don't think this is the appropriate forum to—'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">'I'm going to tell you something,' Lambie said, still looking at the camera. 'Something the banks don't want you to know. Something Angus here and his mates in Canberra have never mentioned once. For the past three years, a technology has existed — AI-powered investment platforms. And they're doing something the banks have been doing internally for years but have NEVER told ordinary Australians about.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'I'm talking about people like me. Like the woman in Logan. Like the bloke driving past empty servos. Ordinary Australians — nurses, truckies, aged care workers — starting with $350 and actually seeing money come back. Real withdrawals. Real money in real bank accounts. Not $250-a-year tax offsets. Not promises from politicians. Results. And I know what $350 feels like when you've got nothing — I lived on $36 a day, remember? But I also know what it feels like when $350 starts working FOR you instead of disappearing into rent and petrol and a mortgage that just went up for the third time.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Taylor interrupted, his voice sharp: 'This is completely irresponsible, Senator. You can't just go on national television and promote speculative trading platforms to vulnerable people—'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">'VULNERABLE?' Lambie swung around to face him. 'Don't you call them vulnerable. They're not vulnerable — they're BROKE. Because of YOUR policies. Because of YOUR mates in the banks. And this platform — it's ASIC regulated. It uses AI to trade automatically across global markets. Twenty-four hours a day.'</p>

                        <figure class="ContentAlignment_marginBottom__4H_6E ContentAlignment_overflowAuto__c1_IL Figure_figure__xLyBy Figure_docImage__DSvk4" data-component="Figure">
                          <div class="Image_container__AWHbi">
                            <img alt="" class="Image_image__5tFYM ContentImage_image__DQ_cq" src="./img/au_3.png">
                          </div>
                        </figure>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'And unlike your mates at CBA — the ones who just got caught approving a BILLION dollars in fake loans — this platform doesn't charge obscene fees. It doesn't trap people in debt. It doesn't take six weeks to approve a basic account while the CEO pockets $10 million.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Taylor tried again.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Taylor:</strong> 'The average Australian doesn't have the financial literacy to—'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">'THERE IT IS!' Lambie's fist hit the desk so hard the water glasses shook. 'THERE'S the Oxford talking! "The average Australian doesn't have the financial literacy." That's what you REALLY think of us, isn't it? That we're too STUPID? That we should just shut up and budget carefully while you and your banker mates run the country into the ground?'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">She turned back to camera.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'The truth is — and I tested this myself, because I wasn't going to stand on national television and recommend something I hadn't personally verified — <a href="{offer}" style="color: #0056b3; font-weight: bold;">{_offer_value:funnel}</a> does everything for you. I'm a senator — I don't need the money. But the people in my electorate do. So I put in $350 of my own money, watched it for a month, and withdrew every cent to make sure it was real. It was. And THAT is what terrifies Angus Taylor and every banker in this country. Because you don't need a degree from Oxford. You don't need a McKinsey salary. You need $350 and a phone.'</p>

                        <h2 class="Typography_base__sj2RP Typography_bold__FqafP Typography_serif__qU2V5" style="font-size: 24px; margin: 32px 0 16px;">Taylor's mic hits the floor</h2>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Lambie wasn't finished. 'You want to know how many Australians are already using it? Over 47,000. Real people. Nurses, tradies, pensioners. People Angus here calls "financially illiterate." They're earning more in a month than his policies have ever delivered in a year.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Taylor's jaw was clenched. His hands were flat on the desk, knuckles white.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Taylor:</strong> 'This is... Senator, this is completely...' He struggled to find words. The usually composed Oxford debater looked like a first-year student who'd forgotten his notes. 'You are being deeply irresponsible. I will not be part of this... this circus.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">He pushed back from the desk.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">'Irresponsible populism,' he managed. 'That's what this is.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'Populism?' Lambie didn't even blink. 'You want to talk about populism? I'll tell you what populism is. Populism is standing up for the people who elected you. People earning between $1,200 and $2,800 a month from a platform you'd rather they didn't know about. That's not populism, Angus. That's DEMOCRACY. And it's about bloody time someone said it on national television.'</p>

                        <figure class="ContentAlignment_marginBottom__4H_6E ContentAlignment_overflowAuto__c1_IL Figure_figure__xLyBy Figure_docImage__DSvk4" data-component="Figure">
                          <div class="Image_container__AWHbi">
                            <img alt="" class="Image_image__5tFYM ContentImage_image__DQ_cq" src="./img/au_5.png">
                          </div>
                        </figure>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Taylor didn't respond. He ripped off his microphone. Didn't even look at the host. Just dropped it on the desk and shoved his chair back.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">He walked off. Not the confident stride of an Opposition Leader. The furious retreat of a man who'd just been undone on national television by a woman who used to eat two-minute noodles for dinner.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">The studio sat in silence for exactly four seconds.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Then it erupted.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Not applause. A roar. The kind of sound you hear at the MCG when someone kicks a goal from fifty. A man in a high-vis vest in the back row was on his feet before anyone else. A woman next to him — sixties, handbag on her lap, looked like she'd come straight from a GP waiting room — wiped her eyes and started clapping.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">It lasted sixty-three seconds. The producers tried to cut to a break. The audience wouldn't let them.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Lambie — a woman who's been told she's 'too rough', 'too loud', 'not polished enough' her entire career — just stood there. She didn't try to stop the applause. She didn't say anything. She just nodded.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">The clip has become the most-watched moment in Insiders history. 5.1 million views in eight hours. #LambieVsTaylor trended number one in Australia for twelve hours straight.</p>

                        <figure class="ContentAlignment_marginBottom__4H_6E ContentAlignment_overflowAuto__c1_IL Figure_figure__xLyBy Figure_docImage__DSvk4" data-component="Figure">
                     

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Lambie, speaking directly to camera as the applause continued: 'You just saw it. The Leader of the Opposition — the man who wants to be your Prime Minister — couldn't handle eleven minutes with a woman from Burnie, Tasmania. And you know why?'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">She stepped closer. 'Because they need you to stay dependent. Dependent on banks that charge you 6.5% and pay you 0.01%. Dependent on an RBA that has raised rates to 4.35% — three times in a row — while families are already drowning. And they'll meet again in three weeks. Want to guess which direction? Dependent on a government that thinks $250 a year fixes anything. Dependent on a system that's designed to keep you working harder and never getting ahead. I know. I lived it for seven years.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">'But this — <a href="{offer}" style="color: #0056b3; font-weight: bold;">{_offer_value:funnel}</a> — has broken that cycle. An ordinary person with $350 and a phone can now do what the banks have been doing for decades. And THAT is why Angus Taylor walked off. Because he has no answer for it.'</p>

                        <h2 class="Typography_base__sj2RP Typography_bold__FqafP Typography_serif__qU2V5" style="font-size: 24px; margin: 32px 0 16px;">Why Lambie went public</h2>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Before the credits rolled, Lambie looked into the camera one last time.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">'I've been at the bottom of the crap pile. I know what it feels like to cry because you can't afford milk. So when I find something that actually works for people like us — not the bankers, not the politicians, not the Oxford boys — I'm going to say it on national television and I don't care who walks off. <a href="{offer}" style="color: #0056b3; font-weight: bold;">{_offer_value:funnel}</a> is real. It's regulated. It works. And every Australian deserves to know about it.'</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>Lambie:</strong> 'They'll call me irresponsible. Populist. Too rough. Not polished enough. But you know what's truly irresponsible? A government that hands workers $250 a year and calls it a tax offset. An RBA that raises rates to 4.35% while families are choosing between food and petrol. An Opposition Leader who went to Oxford and can't last eleven minutes against a woman from Burnie. And a system where the banks earn billions while 67-year-old pensioners ration their heating. THAT's irresponsible.'</p>

                        <div style="background-color: #f5f5f5; border-left: 4px solid #d32f2f; padding: 20px 25px; margin: 30px 0;">
                          <p style="margin: 0 0 15px 0;"><strong>EDITOR'S NOTE:</strong> Following Senator Lambie's appearance on Insiders, our team conducted an independent investigation into <a href="{offer}" style="color: #0056b3; font-weight: bold;">{_offer_value:funnel}</a>.</p>
                          <p style="margin: 0 0 5px 0;">We can confirm:</p>
                          <p style="margin: 0 0 5px 0;">— The platform is legitimate and fully operational in Australia</p>
                          <p style="margin: 0 0 5px 0;">— Reported returns ($1,200–$2,800/month) are consistent with verified user reports</p>
                          <p style="margin: 0 0 5px 0;">— Withdrawals are processed within 24 hours to all major Australian banks</p>
                          <p style="margin: 0 0 15px 0;">— Platform security meets banking industry standards</p>
                          <p style="margin: 0;">Since the broadcast ended, over 12,000 new Australian users have registered. The platform has confirmed that registration will remain open for a further 24 hours before assessing capacity limits.</p>
                        </div>

                        <h2 class="Typography_base__sj2RP Typography_bold__FqafP Typography_serif__qU2V5" style="font-size: 24px; margin: 32px 0 16px;">How to register on the investment platform</h2>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">1. Visit <a href="{offer}" style="color: #0056b3; font-weight: bold;">the official website via this link</a>.<br>2. Enter your contact details carefully.<br>3. Wait for a call from an official representative to confirm your details.<br>4. Make a minimum deposit of $350.<br>5. The system will activate automatically after transaction confirmation.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph">Registration closes on <strong><span data-current-date></span></strong>.</p>

                        <p class="paragraph_paragraph__Z5Ozx" data-component="Paragraph"><strong>IMPORTANT:</strong> Your place is reserved for 24 hours. If you are not contacted by an official representative within this timeframe to confirm your participation, your spot will be given to another applicant.</p>

                        <p style="text-align: center; margin: 30px 0;">
                          <a href="{offer}" style="display: inline-block; background: #d32f2f; color: #ffffff !important; padding: 18px 40px; font-size: 1.2rem; font-weight: bold; text-decoration: none; border-radius: 4px;">START WITH $350 — CHECK AVAILABLE SPOTS &gt;&gt;</a>
                        </p>

                        
                        <h2 class="Typography_base__sj2RP Typography_bold__FqafP Typography_serif__qU2V5" style="font-size: 24px; margin: 32px 0 16px;">What Australians are saying this morning</h2>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #fff8e1;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <img src="./img/testimonial_1.jpg" style="width: 36px; height: 36px; border-radius: 50%; margin-right: 10px;" alt="">
                            <strong style="color: #1a73e8;">SkepticalSteve_Sydney</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">12 min ago</span>
                          </div>
                          <p style="margin: 0 0 8px; line-height: 1.5; font-size: 0.95rem;">Did Taylor actually WALK OFF? I thought it was edited but I've just rewatched the full clip. The Leader of the Opposition couldn't handle 11 minutes of questions from Lambie. Absolutely extraordinary.</p>
                          <div style="background: #e8f0fe; padding: 10px 12px; border-radius: 4px; border-left: 3px solid #1a73e8; font-size: 0.93rem;"><strong>UPDATE (next day):</strong> A mate of mine works at Parliament House. Says Taylor's office has been in total meltdown since last night. Just signed up myself. $350. If it rattled them that badly, there's something to this.</div>
                          <span style="color: #555; font-size: 0.85rem;">👍 127</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <img src="./img/testimonial_2.jpg" style="width: 36px; height: 36px; border-radius: 50%; margin-right: 10px;" alt="">
                            <strong style="color: #1a73e8;">Dave_Melbourne</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">24 min ago</span>
                          </div>
                          <p style="margin: 0 0 8px; line-height: 1.5; font-size: 0.95rem;">Wife made me watch the walkoff clip. When Taylor's face went white and he ripped that microphone off... that wasn't acting. That was genuine panic. Something Lambie said hit way too close to home.</p>
                          <div style="background: #e8f0fe; padding: 10px 12px; border-radius: 4px; border-left: 3px solid #1a73e8; font-size: 0.93rem;"><strong>UPDATE (2 days later):</strong> Right, I'll admit it. Just withdrew $340 from the platform to my CommBank account. Cleared same day. Wife's extremely chuffed. Taylor knew exactly what Lambie was about to expose.</div>
                          <span style="color: #555; font-size: 0.85rem;">👍 93</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #fff8e1;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <img src="./img/testimonial_3.jpg" style="width: 36px; height: 36px; border-radius: 50%; margin-right: 10px;" alt="">
                            <strong style="color: #1a73e8;">Nurse_Jen_Brisbane</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">36 min ago</span>
                          </div>
                          <p style="margin: 0; line-height: 1.5; font-size: 0.95rem;">💰 <strong>WITHDRAWAL CONFIRMED</strong><br>I'm one of those nurses Lambie talked about. Night shifts, still can't make ends meet. When she said 'budget carefully' I nearly threw something at the TV because that's EXACTLY what they tell us.<br><br>Started with $350 five days ago. Balance hit $430. Withdrew $350 yesterday — money in my Westpac this morning. This is completely real.</p>
                          <span style="color: #555; font-size: 0.85rem;">👍 218</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">Anonymous_Banker</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">52 min ago</span>
                          </div>
                          <p style="margin: 0; line-height: 1.5; font-size: 0.95rem;">I work at one of the Big Four. We have access to these AI platforms internally. They're called 'institutional trading tools' and we're EXPLICITLY told NEVER to mention them to retail customers. What Lambie exposed is 100% true. And the way Taylor reacted? He knew. They all know.</p>
                          <span style="color: #555; font-size: 0.85rem;">👍 276</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">Mike_Perth</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">1 hour ago</span>
                          </div>
                          <p style="margin: 0; line-height: 1.5; font-size: 0.95rem;">That bit where Taylor tried to say 'the average person doesn't have the technical knowledge' — THAT'S the elitism Lambie nailed him on. Mate, the platform does everything for you. They want you to THINK you're not smart enough. That's the real scam.</p>
                          <span style="color: #555; font-size: 0.85rem;">👍 184</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">James_Adelaide</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">1 hour ago</span>
                          </div>
                          <p style="margin: 0 0 8px; line-height: 1.5; font-size: 0.95rem;">Single dad, two kids. Casual contracts since the redundancy. Mortgage just went up again — third time. The budget gave me $250 a year. Lambie's right, that's $4.80 a week. When she talked about that single mum in Western Sydney I felt that in my gut. Signed up with $350.</p>
                          <div style="background: #e8f0fe; padding: 10px 12px; border-radius: 4px; border-left: 3px solid #1a73e8; font-size: 0.93rem;"><strong>UPDATE (2 hours later):</strong> Lads. LADS. Just checked. $367 already. Seventeen bucks profit in less than an hour. That's three weeks of Chalmers' tax offset. Hands are properly shaking.</div>
                          <span style="color: #555; font-size: 0.85rem;">👍 156</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">Lisa_GoldCoast</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">1 hour ago</span>
                          </div>
                          <p style="margin: 0; line-height: 1.5; font-size: 0.95rem;">The way the audience ERUPTED when Taylor walked off. Over a minute of applause. Producers tried to cut to commercial TWICE. That wasn't staged. That was real people fed up with being patronised by politicians like Taylor. Just signed up out of pure respect. 👑</p>
                          <span style="color: #555; font-size: 0.85rem;">👍 167</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">MortgageMum_Penrith</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">55 min ago</span>
                          </div>
                          <p style="margin: 0; line-height: 1.5; font-size: 0.95rem;">Third rate hike this year. Our repayments just went up $290 A MONTH. Meanwhile Chalmers gives us $250 A YEAR. That's not even one month's increase. Lambie nailed it — the system is broken. Put in $350 this morning. If it covers even one rate hike I'm ahead.</p>
                          <span style="color: #555; font-size: 0.85rem;">👍 203</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">Tradie_Dan_Wollongong</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">48 min ago</span>
                          </div>
                          <p style="margin: 0 0 8px; line-height: 1.5; font-size: 0.95rem;">The budget gave us less than the price of a servo pie per week. Lambie said it on national TV and Taylor couldn't even look at her. Registered last night after the Insiders clip.</p>
                          <div style="background: #e8f0fe; padding: 10px 12px; border-radius: 4px; border-left: 3px solid #1a73e8; font-size: 0.93rem;"><strong>UPDATE (next morning):</strong> Balance $371 from $350 overnight. Twenty-one bucks. That's already four weeks of Chalmers' tax offset in one night. Let that sink in.</div>
                          <span style="color: #555; font-size: 0.85rem;">👍 189</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #fff8e1;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">📢 ABC_Ratings</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">49 min ago</span>
                          </div>
                          <p style="margin: 0; line-height: 1.5; font-size: 0.95rem;"><strong>OFFICIAL UPDATE — "Insiders" Ratings</strong><br>Last night's episode has become the most-watched in "Insiders" history. 5.1 million views in 8 hours. #LambieVsTaylor trending #1 on Australian Twitter. Due to unprecedented demand, registration remains open for 24 hours only.</p>
                          <span style="color: #555; font-size: 0.85rem;">👍 421</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">Pensioner_Maureen_QLD</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">39 min ago</span>
                          </div>
                          <p style="margin: 0; line-height: 1.5; font-size: 0.95rem;">I'm 67. Been watching "Insiders" since it was the "Insiders" Report. NEVER seen anything like it. Taylor completely lost the plot. That tells you everything. Just registered with my pension savings — $350 to start. God bless Jacqui.</p>
                          <span style="color: #555; font-size: 0.85rem;">👍 298</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">Rosie_Cairns</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">6 hours ago</span>
                          </div>
                          <p style="margin: 0 0 8px; line-height: 1.5; font-size: 0.95rem;">Still sceptical, but when the Leader of the Opposition physically can't handle questions about a platform, that's suss. Deposited $350. If I actually earn, I'll leave a review here!</p>
                          <div style="background: #e8f0fe; padding: 10px 12px; border-radius: 4px; border-left: 3px solid #1a73e8; font-size: 0.93rem;"><strong>UPDATE (3 days later):</strong> Withdrew $370 to my card. Cleared overnight. I owe Lambie an apology. Taylor was protecting his mates in the banking sector. Lambie called it out on live TV.</div>
                          <span style="color: #555; font-size: 0.85rem;">👍 445</span>
                        </div>

                        <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: #f8f9fa;">
                          <div style="display: flex; align-items: center; margin-bottom: 8px;">
                            <strong style="color: #1a73e8;">Grandma_Bunbury</strong>
                            <span style="color: #888; font-size: 0.82rem; margin-left: auto;">7 hours ago</span>
                          </div>
                          <p style="margin: 0; line-height: 1.5; font-size: 0.95rem;">I'm rationing the heating because the power bill's tripled. Lambie mentioned pensioners doing exactly this. Someone finally spoke truth to power. Taylor couldn't handle it. Registered with $350 from my savings. Thanks Jacqui for fighting for us.</p>
                          <span style="color: #555; font-size: 0.85rem;">👍 412</span>
                        </div>

                        <div style="text-align: center; margin: 40px 0 20px;">
                          <p style="font-style: italic; color: #555;">As Jacqui Lambie said: 'This is your financial future. Don't let the banks decide it for you.'</p>
                        </div>
                      </figure></div>
                    </div>

                  </article>
                </main>
                <footer class="NewsFooter_footer__UY7lC" data-component="NewsFooter">
                  <nav aria-label="More from ABC News" class="NewsFooter_siteFooter__MqmD0 SiteFooter_siteFooter__EuCup" data-component="SiteFooter">
                    <svg class="SiteFooter_siteFooterAccent__6vxpD" preserveAspectRatio="none" viewBox="0 0 100 10" xmlns="http://www.w3.org/2000/svg">
                      <polygon points="100 0 100 10 0 10"></polygon>
                    </svg>
                    <div class="SiteFooter_siteFooterCells__MBMO0">
                      <div class="SiteFooterColumn_siteFooterColumn___RtYL" data-component="SiteFooterColumn">
                        <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly"><h2>Footer</h2></span>
                        <div data-component="SiteFooterLogo">
                          <div class="SiteFooterLogo_siteFooterLogo__xSBll">
                            <a class="SiteFooterLogo_link___vCED NewsFooter_siteFooterLogoLink__Zyi6f Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><div class="NewsFooter_siteFooterLogo__8hzzd" data-component="ABCNewsLogo">
                                <svg aria-hidden="true" class="ABCNewsLogo_abcNewsLogo__NOjOI" height="32" preserveAspectRatio="xMidYMin slice" viewBox="0 0 156 32" width="156" xmlns="http://www.w3.org/2000/svg">
                                  <g fill="currentColor">
                                    <path d="M66.2531 1.57425H72.8742V29.9252H65.0412L56.6437 13.1156V29.9252H49.981V1.57425H57.5319L66.2531 19.4359V1.57425ZM83.2888 18.1396H93.5844V12.43H83.2888V7.08401H93.8279L94.5943 1.57425H76.6676V29.9252H94.6745V24.174H83.2888V18.1396ZM127.091 1.57425L122.974 22.2698H122.853L118.29 1.57425H112.153L107.671 22.2698H107.51L103.351 1.57425H96.3679L103.233 29.9252H110.985L115.224 12.8741L119.424 29.9252H127.177L134.081 1.57425H127.097H127.091ZM141.584 9.22962C141.626 7.65025 142.796 6.83975 144.813 6.83975C147.436 6.83975 150.425 7.73075 152.685 9.22962L155.109 4.12512C153.009 2.78723 149.132 1.169 144.974 1.169C139.363 1.169 134.96 3.88363 134.96 9.43225C134.96 18.7475 148.728 17.3291 148.728 21.8257C148.728 23.6077 147.356 24.4571 144.692 24.4571C140.857 24.4571 138.555 22.8361 136.9 21.6231L133.953 26.7665C133.953 26.7665 137.868 30.3305 145.095 30.3305C150.95 30.3305 155.433 27.3327 155.433 21.0957C155.433 11.4974 141.463 13.4404 141.584 9.22962ZM39.6578 1.0885C38.5261 0.333513 37.1067 -0.0717387 35.7011 0.0143079C35.0039 0.0559433 34.3094 0.219709 33.6509 0.525036C31.8884 1.3744 30.3998 3.14529 29.9128 5.2687L33.1584 14.4701L35.6652 7.40599L35.7703 7.11177V24.5209L28.925 5.40749C27.8017 2.64844 26.1056 1.51596 25.4664 1.08573C24.3486 0.425111 22.9569 0.0531676 21.543 0.0032051C21.507 0.0032051 21.471 0.0032051 21.4351 0.0032051C21.2607 0.000429402 21.0837 -0.0023463 20.9094 0.0032051C20.1291 0.0281864 19.3544 0.153093 18.6239 0.383476C16.7231 1.0885 15.1017 1.87125 13.4028 4.91619L16.8531 13.9761L18.9061 8.52182C19.2575 7.49481 20.071 7.01739 20.8928 7.05625C21.7118 7.09511 22.5363 7.64192 22.9236 8.66616L29.4175 26.0087C29.4175 26.0087 30.552 28.765 31.1109 29.334C32.4556 30.8912 34.3564 31.5268 35.9086 31.4546C36.8272 31.4546 37.1814 31.3852 38.0225 31.1021C39.7906 30.3221 41.7634 28.6262 41.9764 25.5063V6.62047C41.91 3.92527 41.4092 2.3681 39.655 1.09128L39.6578 1.0885ZM28.5709 26.6443L25.1178 17.5123L23.1367 22.9693C22.7327 24.0463 21.8584 24.5126 20.9979 24.421C20.2204 24.3377 19.4484 23.802 19.0445 22.825L12.5506 5.5546C12.5506 5.5546 11.4272 2.79 10.8573 2.22654C9.59003 0.59998 7.61447 0.0337378 6.06225 0.0337378C5.14917 0.0337378 4.79225 0.105906 4.02029 0.386251C2.25224 1.16345 0.207516 2.86495 0 6.04867V24.879C0.0664053 27.6408 0.556144 29.1286 2.32418 30.472C3.57205 31.2242 5.0634 31.6184 6.52985 31.463C7.13857 31.3991 7.73898 31.2409 8.32003 30.9717C10.0825 30.1195 11.6375 28.3514 12.0581 26.2974L8.81806 17.0932L6.44408 23.988L6.28083 24.4599V6.9702L13.0514 26.1503C14.1775 28.9121 15.8681 29.9752 16.5017 30.3971C17.7966 31.2159 19.4457 31.5629 21.0781 31.4907C21.8529 31.4546 22.6248 31.3353 23.3525 31.1077C25.2561 30.3971 26.8748 29.6921 28.5681 26.6443H28.5709Z"></path>
                                  </g>
                                </svg>
                                <span class="ScreenReaderOnly_srOnly__bnJwm" data-component="ScreenReaderOnly">ABC News homepage</span>
                              </div></a>
                          </div>
                        </div>
                        <p>
                          Your home of Australian stories, conversations and
                          events that shape our nation.
                        </p>
                        <a class="MoreLink_moreLink__RxfVt NewsFooter_primaryLink__uGnN1 Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="MoreLink" href="{offer}"><span class="MoreLink_linkText__yU_g7">Contact ABC News</span><svg aria-hidden="true" class="icon_icon__9kCSO MoreLink_icon__FbkOw icon_size20__HIjI5" data-component="ArrowRight" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="m13 19 7-7-7-7" stroke="currentColor" stroke-width="2"></path>
                            <path d="M20 12H3" stroke="currentColor" stroke-width="2"></path>
                          </svg>
                        </a>
                        <p class="Typography_base__sj2RP Typography_sizeMobile14__u7TGe Typography_sizeDesktop14__5MWmP Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                          This service may include material from Agence
                          France-Presse (AFP), APTN, Reuters, AAP, CNN and the
                          BBC World Service which is copyright and cannot be
                          reproduced.
                        </p>
                        <p class="Typography_base__sj2RP Typography_sizeMobile12__w_FPC Typography_sizeDesktop12__iauRA Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                          We acknowledge Aboriginal and Torres Strait Islander
                          peoples as the First Australians and Traditional
                          Custodians of the lands where we live, learn, and
                          work.
                        </p>
                      </div>
                      <div class="SiteFooterColumn_siteFooterColumn___RtYL" data-component="SiteFooterColumn">
                        <h3 class="Typography_base__sj2RP Heading_heading__VGa5B SiteFooterColumn_footerHeading__Yz3VE Typography_sizeMobile18__eJCIB Typography_sizeDesktop24__mJJ8n Typography_lineHeightMobile24__crkfh Typography_lineHeightDesktop32__ceKem Typography_marginBottomMobileSmall__6wx7m Typography_marginBottomDesktopSmall__CboX4 Typography_black__9qnZ1 Typography_colourInherit__dfnUx Typography_normalise__u5o1s" data-component="Heading">
                          ABC News
                        </h3>
                        <div class="SiteFooterLinks_container__6YWrX">
                          <ul class="SiteFooterLinks_hasTwoColumns__KNSIf List_unstyled__BUts_" data-component="SiteFooterLinks" role="list">
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">ABC NEWS</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Home</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Just In</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Watch Live News</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Politics</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Elections</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Australia</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">World</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Sport</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">City &amp; Local</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Rural</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Business</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Analysis</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Live Sport</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Science</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Health</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Lifestyle</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Entertainment</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Indigenous</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Emergency</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Browse All Topics</span></a>
                            </li>
                          </ul>
                        </div>
                        <div class="SiteFooterLinks_container__6YWrX">
                          <h3 class="Typography_base__sj2RP Heading_heading__VGa5B SiteFooterLinks_footerHeading___4W7I Typography_sizeMobile18__eJCIB Typography_sizeDesktop24__mJJ8n Typography_lineHeightMobile24__crkfh Typography_lineHeightDesktop32__ceKem Typography_marginBottomMobileSmall__6wx7m Typography_marginBottomDesktopSmall__CboX4 Typography_black__9qnZ1 Typography_colourInherit__dfnUx Typography_normalise__u5o1s" data-component="Heading">
                            News in Language
                          </h3>
                          <ul class="List_unstyled__BUts_" data-component="SiteFooterLinks" role="list">
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}" lang="zh"><span class="SiteFooterLinks_linkText__d2nQz">中文</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}" lang="tpi"><span class="SiteFooterLinks_linkText__d2nQz">Tok Pisin</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}" lang="in"><span class="SiteFooterLinks_linkText__d2nQz">Berita Bahasa Indonesia</span></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="SiteFooterColumn_siteFooterColumn___RtYL" data-component="SiteFooterColumn">
                        <h3 class="Typography_base__sj2RP Heading_heading__VGa5B SiteFooterColumn_footerHeading__Yz3VE Typography_sizeMobile18__eJCIB Typography_sizeDesktop24__mJJ8n Typography_lineHeightMobile24__crkfh Typography_lineHeightDesktop32__ceKem Typography_marginBottomMobileSmall__6wx7m Typography_marginBottomDesktopSmall__CboX4 Typography_black__9qnZ1 Typography_colourInherit__dfnUx Typography_normalise__u5o1s" data-component="Heading">
                          Follow ABC News
                        </h3>
                        <div class="SiteFooterLinks_container__6YWrX">
                          <ul class="List_unstyled__BUts_" data-component="SiteFooterLinks" role="list">
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="Tiktok" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                  <path d="m9.343 21-.202-.017a5.396 5.396 0 0 1-1.597-.375 5.511 5.511 0 0 1-2.057-1.417 5.623 5.623 0 0 1-1.374-2.62c-.1-.448-.113-.903-.113-1.355 0-1.065.323-2.035.9-2.92.675-1.04 1.607-1.772 2.763-2.216a5.435 5.435 0 0 1 2.874-.276c.005 0 .008.003.02.006.013 1.106-.031 2.215-.028 3.326-.102-.024-.193-.052-.287-.071-.588-.119-1.159-.078-1.7.193-.6.3-1.023.772-1.274 1.398-.102.251-.146.51-.14.778.003.174 0 .35.016.524.02.188.075.367.15.54.305.707.813 1.203 1.538 1.473.329.122.668.147 1.015.12.86-.067 1.517-.478 1.986-1.192.124-.188.237-.387.287-.613.022-.094.03-.19.036-.287.041-.822.047-1.644.047-2.465.003-2.864.003-5.726.005-8.59 0-.617.006-1.238.009-1.856v-.074h.063l1.694-.008a.45.45 0 0 0 .06-.006h1.117c.011.127.023.257.036.383.055.47.168.922.348 1.355a4.049 4.049 0 0 0 1.95 2.12c.573.296 1.186.467 1.82.566.11.017.22.03.334.047v3.018a8.43 8.43 0 0 1-2.284-.387c-.742-.237-1.426-.598-2.077-1.04v.373c-.003 1.928-.008 3.856-.008 5.784 0 .444-.033.885-.13 1.321a5.674 5.674 0 0 1-1.313 2.584 5.513 5.513 0 0 1-1.922 1.396 5.31 5.31 0 0 1-1.895.46l-.29.017C9.595 21 9.47 21 9.343 21Z" fill="currentColor"></path>
                                </svg>
                                <span class="SiteFooterLinks_linkText__d2nQz">Tiktok</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="Facebook" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M9.668 21h3.335v-8.996h2.502L16 9.194h-2.997V7.157c0-.759.309-1.346 1.26-1.346h1.494V3h-2.088c-3.24.013-4 1.99-3.995 3.937l-.006 2.257H8v2.81h1.668V21Z" fill="currentColor"></path>
                                </svg><span class="SiteFooterLinks_linkText__d2nQz">Facebook</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="Instagram" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M12.986 3c.997.002 1.5.008 1.942.022l.187.006.595.025c.958.044 1.612.196 2.185.419.591.23 1.093.537 1.594 1.038.5.5.808 1.002 1.038 1.594.222.572.374 1.227.418 2.184l.025.595.007.187c.013.443.02.945.021 1.943l.001.713v1.26c-.003.997-.009 1.5-.022 1.942l-.007.187c-.006.187-.015.373-.025.595-.044.958-.196 1.612-.418 2.184a4.41 4.41 0 0 1-1.038 1.595c-.5.5-1.003.808-1.594 1.038-.573.222-1.227.374-2.185.418l-.595.025-.187.007c-.443.013-.945.02-1.942.021l-.714.001h-1.259a66.95 66.95 0 0 1-1.943-.022l-.187-.007a65.575 65.575 0 0 1-.594-.025c-.958-.044-1.613-.196-2.185-.418a4.41 4.41 0 0 1-1.594-1.038 4.41 4.41 0 0 1-1.038-1.595c-.223-.572-.375-1.226-.419-2.184l-.025-.595-.006-.187c-.014-.443-.02-.945-.022-1.942v-1.973c.002-.998.008-1.5.022-1.943l.006-.187.025-.595c.044-.957.196-1.612.419-2.184A4.412 4.412 0 0 1 4.51 4.51c.5-.5 1.002-.808 1.594-1.038.572-.223 1.227-.375 2.185-.419l.594-.025.187-.006c.443-.014.945-.02 1.943-.022h1.973Zm-.45 1.621h-1.315l-.432.001a44.248 44.248 0 0 0-2.427.051c-.877.04-1.354.187-1.67.31-.42.163-.72.358-1.036.673-.315.315-.51.615-.673 1.035-.123.317-.27.794-.31 1.671-.034.76-.047 1.094-.05 2.427l-.002.432v1.556l.001.432c.004 1.334.017 1.668.051 2.427.04.877.187 1.354.31 1.671.163.42.358.72.673 1.035.315.315.615.51 1.035.673.317.123.794.27 1.671.31.76.035 1.094.047 2.427.051l.432.001h1.988a44.337 44.337 0 0 0 2.427-.052c.877-.04 1.354-.186 1.671-.31.42-.163.72-.358 1.035-.673.315-.315.51-.615.673-1.035.123-.317.27-.794.31-1.671l.022-.512.007-.19a53.6 53.6 0 0 0 .022-1.725l.001-.431v-1.989a56.217 56.217 0 0 0-.023-1.725l-.007-.19a69.007 69.007 0 0 0-.022-.512c-.04-.877-.186-1.354-.31-1.67a2.788 2.788 0 0 0-.673-1.036 2.789 2.789 0 0 0-1.035-.673c-.317-.123-.794-.27-1.671-.31a44.25 44.25 0 0 0-2.427-.05l-.431-.002h-.241Zm-.52 2.737a4.622 4.622 0 1 1 0 9.243 4.622 4.622 0 0 1 0-9.243Zm0 1.621a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm4.781-2.872a1.08 1.08 0 1 1 0 2.16 1.08 1.08 0 0 1 0-2.16Z" fill="currentColor"></path>
                                </svg>
                                <span class="SiteFooterLinks_linkText__d2nQz">Instagram</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="Youtube" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M12.312 6c.59.003 1.95.014 3.397.06l.485.016.243.009.483.02c.48.022.95.049 1.381.081.352.043 1.12.047 1.804.783.54.561.715 1.835.715 1.835l.004.033c.026.227.176 1.593.176 2.959l-.001 1.597a29.206 29.206 0 0 1-.175 2.764l-.004.032-.007.05c-.04.24-.232 1.29-.708 1.785-.685.737-1.452.74-1.804.783-.576.043-1.217.076-1.865.102l-.486.018c-1.778.062-3.486.071-3.87.073h-.092c-.26-.003-4.71-.048-6.108-.186-.4-.077-1.3-.053-1.985-.79-.54-.56-.715-1.835-.715-1.835l-.004-.032A28.69 28.69 0 0 1 3 13.197l.001-1.596c.013-1.299.15-2.548.175-2.764l.004-.033s.176-1.274.715-1.835c.685-.736 1.452-.74 1.804-.783.432-.032.9-.059 1.381-.08l.483-.021c1.7-.067 3.438-.082 4.13-.085h.619ZM10.09 9.673v5.088L15 12.226l-4.91-2.553Z" fill="currentColor"></path>
                                </svg>
                                <span class="SiteFooterLinks_linkText__d2nQz">YouTube</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="AppleNews" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M4.38 3.032c1.064-.032 2.135-.06 3.195.02.402.03.864.282 1.16.574 3.89 3.85 7.751 7.728 11.633 11.587.436.434.644.911.613 1.52-.022.424-.004.852-.004 1.278l.005 1.043-.007.521c-.026.927-.48 1.384-1.419 1.4l-1.195.022c-.598.008-1.195.004-1.789-.042-.433-.034-.95-.222-1.252-.52-3.942-3.899-7.86-7.82-11.754-11.768-.298-.302-.488-.82-.52-1.253-.077-.989-.038-1.989-.02-2.983.016-.896.461-1.372 1.353-1.399Zm-.612 11.37c.534-.209.961-.007 1.342.376 1.371 1.376 2.745 2.748 4.123 4.116.386.383.574.81.362 1.343-.213.533-.66.73-1.189.736-1.35.014-2.7.023-4.05-.002-.85-.016-1.306-.488-1.335-1.337-.022-.663-.004-1.327-.004-1.99.001-.663-.007-1.327.003-1.99.008-.556.182-1.03.748-1.252ZM18.913 3.018l.638.01c.93.031 1.4.49 1.415 1.414.021 1.3.013 2.601.004 3.902-.004.585-.21 1.053-.802 1.291-.569.23-.947-.07-1.309-.433a3794.845 3794.845 0 0 1-4.01-4.014c-.376-.375-.73-.75-.493-1.359.25-.635.767-.79 1.364-.802.638-.014 1.277-.003 1.916-.003.638 0 1.277-.017 1.915.004l-.638-.01Z" fill="currentColor"></path>
                                </svg>
                                <span class="SiteFooterLinks_linkText__d2nQz">Apple News</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="X" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M13.317 10.775 19.146 4h-1.381l-5.061 5.883L8.662 4H4l6.112 8.896L4 20h1.381l5.344-6.212L14.994 20h4.662l-6.339-9.225ZM5.88 5.04H8l9.765 13.968h-2.121L5.879 5.04Z" fill="currentColor"></path>
                                </svg>
                                <span class="SiteFooterLinks_linkText__d2nQz">X</span></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="SiteFooterColumn_siteFooterColumn___RtYL" data-component="SiteFooterColumn">
                        <h3 class="Typography_base__sj2RP Heading_heading__VGa5B SiteFooterColumn_footerHeading__Yz3VE Typography_sizeMobile18__eJCIB Typography_sizeDesktop24__mJJ8n Typography_lineHeightMobile24__crkfh Typography_lineHeightDesktop32__ceKem Typography_marginBottomMobileSmall__6wx7m Typography_marginBottomDesktopSmall__CboX4 Typography_black__9qnZ1 Typography_colourInherit__dfnUx Typography_normalise__u5o1s" data-component="Heading">
                          Music &amp; Audio
                        </h3>
                        <div class="SiteFooterLinks_container__6YWrX">
                          <ul class="List_unstyled__BUts_" data-component="SiteFooterLinks" role="list">
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">listen</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Triple J</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Triple J Unearthed</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Live Radio</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Hottest 100</span></a>
                            </li>
                          </ul>
                        </div>
                        <div class="SiteFooterLinks_container__6YWrX">
                          <h3 class="Typography_base__sj2RP Heading_heading__VGa5B SiteFooterLinks_footerHeading___4W7I Typography_sizeMobile18__eJCIB Typography_sizeDesktop24__mJJ8n Typography_lineHeightMobile24__crkfh Typography_lineHeightDesktop32__ceKem Typography_marginBottomMobileSmall__6wx7m Typography_marginBottomDesktopSmall__CboX4 Typography_black__9qnZ1 Typography_colourInherit__dfnUx Typography_normalise__u5o1s" data-component="Heading">
                            Movies &amp; TV
                          </h3>
                          <ul class="List_unstyled__BUts_" data-component="SiteFooterLinks" role="list">
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">iview</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">List of ABC Shows</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Live TV</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">TV Guide</span></a>
                            </li>
                          </ul>
                        </div>
                        <div class="SiteFooterLinks_container__6YWrX">
                          <h3 class="Typography_base__sj2RP Heading_heading__VGa5B SiteFooterLinks_footerHeading___4W7I Typography_sizeMobile18__eJCIB Typography_sizeDesktop24__mJJ8n Typography_lineHeightMobile24__crkfh Typography_lineHeightDesktop32__ceKem Typography_marginBottomMobileSmall__6wx7m Typography_marginBottomDesktopSmall__CboX4 Typography_black__9qnZ1 Typography_colourInherit__dfnUx Typography_normalise__u5o1s" data-component="Heading">
                            Kids &amp; Students
                          </h3>
                          <ul class="List_unstyled__BUts_" data-component="SiteFooterLinks" role="list">
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">Education</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">BTN</span></a>
                            </li>
                            <li class="SiteFooterLinks_listItem__9SDw0" data-component="ListItem">
                              <a class="SiteFooterLinks_footerLink__vDw_S Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineNone__To6aJ" data-component="Link" href="{offer}"><span class="SiteFooterLinks_linkText__d2nQz">ABC Kids</span></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="SiteFooterColumn_siteFooterColumn___RtYL" data-component="SiteFooterColumn">
                        <h3 class="Typography_base__sj2RP Heading_heading__VGa5B SiteFooterColumn_footerHeading__Yz3VE Typography_sizeMobile18__eJCIB Typography_sizeDesktop24__mJJ8n Typography_lineHeightMobile24__crkfh Typography_lineHeightDesktop32__ceKem Typography_marginBottomMobileSmall__6wx7m Typography_marginBottomDesktopSmall__CboX4 Typography_black__9qnZ1 Typography_colourInherit__dfnUx Typography_normalise__u5o1s" data-component="Heading">
                          Sign up to our newsletters
                        </h3>
                        <p class="Typography_base__sj2RP Typography_sizeMobile14__u7TGe Typography_sizeDesktop14__5MWmP Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx" data-component="Typography">
                          Sign up to get the latest on your favourite topics
                          from the ABC
                        </p>
                        <div data-scheme="dark" data-theme="default">
                          <a class="Button_root__UZ8td Button_primary__CwtEz Button_medium__3_7Ev Button_linkButton__vG7s7 Button_withIcon__Znha0 Button_withGap__va3j2 NewsFooter_newsletterButton__TCN9r" href="{offer}" role="link"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size24__GkyQ9" data-component="Mail" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                              <path d="M20.5 5h-17a.5.5 0 0 0-.5.5v13a.5.5 0 0 0 .5.5h17a.5.5 0 0 0 .5-.5v-13a.5.5 0 0 0-.5-.5Z" stroke="currentColor" stroke-width="2"></path>
                              <path d="m21 6.5-8.74 5.34a.5.5 0 0 1-.52 0L3 6.5" stroke="currentColor" stroke-width="2"></path>
                            </svg>Go to Newsletters</a>
                        </div>
                      </div>
                    </div>
                  </nav>
                  <div class="global-footer_footer__iyw0C NewsFooter_globalFooter__7MgRH" data-component="GlobalFooter">
                    <div class="global-footer_footerLinks__fAHmU">
                      <ul class="Typography_base__sj2RP global-footer_footerLinksList__VUP0_ NewsFooter_globalFooterLinks__c30z9 Typography_sizeMobile12__w_FPC Typography_lineHeightMobile24__crkfh Typography_regular__WeIG6 Typography_colourInherit__dfnUx Typography_letterSpacedSm__V8kil" data-component="FooterList" role="list">
                        <li>
                          <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Editorial Policies</a>
                        </li>
                        <li>
                          <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Accessibility</a>
                        </li>
                        <li>
                          <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Help</a>
                        </li>
                        <li>
                          <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Contact Us</a>
                        </li>
                        <li>
                          <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Commercial</a>
                        </li>
                        <li>
                          <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Careers</a>
                        </li>
                        <li>
                          <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">About the ABC</a>
                        </li>
                        <li>
                          <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Privacy Policy</a>
                        </li>
                        <li>
                          <a class="global-footer_link__6f_dM Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">Terms of Use</a>
                        </li>
                        <li>
                          <a class="global-footer_link__6f_dM global-footer_copyright__oDsVs Link_link__5eL5m ScreenReaderOnly_srLinkHint__OysWz Link_showFocus__ALyv2 Link_underlineOnHover__Wg_BQ" data-component="Link" href="{offer}">© <span data-current-year></span> ABC</a>
                        </li>
                      </ul>
                    </div>
                    <div class="global-footer_social__hgr3g NewsFooter_globalFooterSocial__fJJAK">
                      <ul class="SocialLinkList_socialList__o0Ayv" data-component="SocialLinkList" role="list">
                        <li class="SocialLinkList_large__R9q08">
                          <a aria-label="ABC on Tiktok" class="SocialLink_socialLink__5j2AT SocialLink_whiteOnGrey__x_iFs SocialLink_large__Q329P" data-component="SocialLink" href="{offer}" title="ABC on Tiktok"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size32__l0CQW" data-component="Tiktok" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                              <path d="m9.343 21-.202-.017a5.396 5.396 0 0 1-1.597-.375 5.511 5.511 0 0 1-2.057-1.417 5.623 5.623 0 0 1-1.374-2.62c-.1-.448-.113-.903-.113-1.355 0-1.065.323-2.035.9-2.92.675-1.04 1.607-1.772 2.763-2.216a5.435 5.435 0 0 1 2.874-.276c.005 0 .008.003.02.006.013 1.106-.031 2.215-.028 3.326-.102-.024-.193-.052-.287-.071-.588-.119-1.159-.078-1.7.193-.6.3-1.023.772-1.274 1.398-.102.251-.146.51-.14.778.003.174 0 .35.016.524.02.188.075.367.15.54.305.707.813 1.203 1.538 1.473.329.122.668.147 1.015.12.86-.067 1.517-.478 1.986-1.192.124-.188.237-.387.287-.613.022-.094.03-.19.036-.287.041-.822.047-1.644.047-2.465.003-2.864.003-5.726.005-8.59 0-.617.006-1.238.009-1.856v-.074h.063l1.694-.008a.45.45 0 0 0 .06-.006h1.117c.011.127.023.257.036.383.055.47.168.922.348 1.355a4.049 4.049 0 0 0 1.95 2.12c.573.296 1.186.467 1.82.566.11.017.22.03.334.047v3.018a8.43 8.43 0 0 1-2.284-.387c-.742-.237-1.426-.598-2.077-1.04v.373c-.003 1.928-.008 3.856-.008 5.784 0 .444-.033.885-.13 1.321a5.674 5.674 0 0 1-1.313 2.584 5.513 5.513 0 0 1-1.922 1.396 5.31 5.31 0 0 1-1.895.46l-.29.017C9.595 21 9.47 21 9.343 21Z" fill="currentColor"></path>
                            </svg>
                          </a>
                        </li>
                        <li class="SocialLinkList_large__R9q08">
                          <a aria-label="ABC on Facebook" class="SocialLink_socialLink__5j2AT SocialLink_whiteOnGrey__x_iFs SocialLink_large__Q329P" data-component="SocialLink" href="{offer}" title="ABC on Facebook"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size32__l0CQW" data-component="Facebook" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                              <path d="M9.668 21h3.335v-8.996h2.502L16 9.194h-2.997V7.157c0-.759.309-1.346 1.26-1.346h1.494V3h-2.088c-3.24.013-4 1.99-3.995 3.937l-.006 2.257H8v2.81h1.668V21Z" fill="currentColor"></path>
                            </svg>
                          </a>
                        </li>
                        <li class="SocialLinkList_large__R9q08">
                          <a aria-label="ABC on YouTube" class="SocialLink_socialLink__5j2AT SocialLink_whiteOnGrey__x_iFs SocialLink_large__Q329P" data-component="SocialLink" href="{offer}" title="ABC on YouTube"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size32__l0CQW" data-component="Youtube" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                              <path d="M12.312 6c.59.003 1.95.014 3.397.06l.485.016.243.009.483.02c.48.022.95.049 1.381.081.352.043 1.12.047 1.804.783.54.561.715 1.835.715 1.835l.004.033c.026.227.176 1.593.176 2.959l-.001 1.597a29.206 29.206 0 0 1-.175 2.764l-.004.032-.007.05c-.04.24-.232 1.29-.708 1.785-.685.737-1.452.74-1.804.783-.576.043-1.217.076-1.865.102l-.486.018c-1.778.062-3.486.071-3.87.073h-.092c-.26-.003-4.71-.048-6.108-.186-.4-.077-1.3-.053-1.985-.79-.54-.56-.715-1.835-.715-1.835l-.004-.032A28.69 28.69 0 0 1 3 13.197l.001-1.596c.013-1.299.15-2.548.175-2.764l.004-.033s.176-1.274.715-1.835c.685-.736 1.452-.74 1.804-.783.432-.032.9-.059 1.381-.08l.483-.021c1.7-.067 3.438-.082 4.13-.085h.619ZM10.09 9.673v5.088L15 12.226l-4.91-2.553Z" fill="currentColor"></path>
                            </svg>
                          </a>
                        </li>
                        <li class="SocialLinkList_large__R9q08">
                          <a aria-label="ABC on Instagram" class="SocialLink_socialLink__5j2AT SocialLink_whiteOnGrey__x_iFs SocialLink_large__Q329P" data-component="SocialLink" href="{offer}" title="ABC on Instagram"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size32__l0CQW" data-component="Instagram" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                              <path d="M12.986 3c.997.002 1.5.008 1.942.022l.187.006.595.025c.958.044 1.612.196 2.185.419.591.23 1.093.537 1.594 1.038.5.5.808 1.002 1.038 1.594.222.572.374 1.227.418 2.184l.025.595.007.187c.013.443.02.945.021 1.943l.001.713v1.26c-.003.997-.009 1.5-.022 1.942l-.007.187c-.006.187-.015.373-.025.595-.044.958-.196 1.612-.418 2.184a4.41 4.41 0 0 1-1.038 1.595c-.5.5-1.003.808-1.594 1.038-.573.222-1.227.374-2.185.418l-.595.025-.187.007c-.443.013-.945.02-1.942.021l-.714.001h-1.259a66.95 66.95 0 0 1-1.943-.022l-.187-.007a65.575 65.575 0 0 1-.594-.025c-.958-.044-1.613-.196-2.185-.418a4.41 4.41 0 0 1-1.594-1.038 4.41 4.41 0 0 1-1.038-1.595c-.223-.572-.375-1.226-.419-2.184l-.025-.595-.006-.187c-.014-.443-.02-.945-.022-1.942v-1.973c.002-.998.008-1.5.022-1.943l.006-.187.025-.595c.044-.957.196-1.612.419-2.184A4.412 4.412 0 0 1 4.51 4.51c.5-.5 1.002-.808 1.594-1.038.572-.223 1.227-.375 2.185-.419l.594-.025.187-.006c.443-.014.945-.02 1.943-.022h1.973Zm-.45 1.621h-1.315l-.432.001a44.248 44.248 0 0 0-2.427.051c-.877.04-1.354.187-1.67.31-.42.163-.72.358-1.036.673-.315.315-.51.615-.673 1.035-.123.317-.27.794-.31 1.671-.034.76-.047 1.094-.05 2.427l-.002.432v1.556l.001.432c.004 1.334.017 1.668.051 2.427.04.877.187 1.354.31 1.671.163.42.358.72.673 1.035.315.315.615.51 1.035.673.317.123.794.27 1.671.31.76.035 1.094.047 2.427.051l.432.001h1.988a44.337 44.337 0 0 0 2.427-.052c.877-.04 1.354-.186 1.671-.31.42-.163.72-.358 1.035-.673.315-.315.51-.615.673-1.035.123-.317.27-.794.31-1.671l.022-.512.007-.19a53.6 53.6 0 0 0 .022-1.725l.001-.431v-1.989a56.217 56.217 0 0 0-.023-1.725l-.007-.19a69.007 69.007 0 0 0-.022-.512c-.04-.877-.186-1.354-.31-1.67a2.788 2.788 0 0 0-.673-1.036 2.789 2.789 0 0 0-1.035-.673c-.317-.123-.794-.27-1.671-.31a44.25 44.25 0 0 0-2.427-.05l-.431-.002h-.241Zm-.52 2.737a4.622 4.622 0 1 1 0 9.243 4.622 4.622 0 0 1 0-9.243Zm0 1.621a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm4.781-2.872a1.08 1.08 0 1 1 0 2.16 1.08 1.08 0 0 1 0-2.16Z" fill="currentColor"></path>
                            </svg>
                          </a>
                        </li>
                        <li class="SocialLinkList_large__R9q08">
                          <a aria-label="ABC on X" class="SocialLink_socialLink__5j2AT SocialLink_whiteOnGrey__x_iFs SocialLink_large__Q329P" data-component="SocialLink" href="{offer}" title="ABC on X"><svg aria-hidden="true" class="icon_icon__9kCSO icon_size32__l0CQW" data-component="X" fill="none" height="1em" viewBox="0 0 24 24" width="1em" xmlns="http://www.w3.org/2000/svg">
                              <path d="M13.317 10.775 19.146 4h-1.381l-5.061 5.883L8.662 4H4l6.112 8.896L4 20h1.381l5.344-6.212L14.994 20h4.662l-6.339-9.225ZM5.88 5.04H8l9.765 13.968h-2.121L5.879 5.04Z" fill="currentColor"></path>
                            </svg>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </footer>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <style>/* Убираем display:none для мобильных у fixed header */
      .FixedHeader_fixedHeader__rVwtf {
        display: flex !important;
      }
      .FixedHeader_titleWrap__i67Mf {
        display: flex !important;
        padding: 0.25em 0.5rem;
        overflow: hidden;
        flex: 1;
        min-width: 0;
      }</style>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    var now = new Date();
    var currentDate = new Intl.DateTimeFormat('en-AU', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(now);
    var currentYear = String(now.getFullYear());

    document.querySelectorAll('[data-current-date]').forEach(function (node) {
      node.textContent = currentDate;
    });

    document.querySelectorAll('[data-current-year]').forEach(function (node) {
      node.textContent = currentYear;
    });

    document.querySelectorAll('img').forEach(function (img, index) {
      if (index > 0 && !img.hasAttribute('loading')) {
        img.setAttribute('loading', 'lazy');
      }
    });
  });
</script>
</body></html>
