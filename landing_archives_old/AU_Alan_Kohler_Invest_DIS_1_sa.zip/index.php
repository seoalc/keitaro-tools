<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!DOCTYPE html>
<html lang="en-AU">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>A$2,850 a week with no experience? Why have more than 10,000 Australians already benefited from Alan Kohler’s initiative—and why are traditional banks opposing it?</title>
{_fbpixel}{_back}
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="files/bootstrap.min.css" media="all">
<link rel="stylesheet" href="files/bitmovinwatermark.css" media="all">
<link rel="stylesheet" href="files/inline.css" media="all">
<link rel="stylesheet" href="files/app.css" media="all">
</head>
<body>
<div id="root">
<div class="relative d-flex flex-column">
<div class="content-wrapper drakColor">
<header class="headerLoggedOut"><div class="header-container"><div class="header-left-block"><a class="menu_icon"><ul><li></li><li></li><li></li></ul></a><div class="site-logo"><a href="{offer}"><img class="logo" src="img/logo.png" alt="Logo Image"></a></div><div class="main-menu"><ul class="d-flex"><li class="nav-item for-you-nav"><a href="{offer}">For You</a></li><li class="nav-item"><span>Series</span><ul class="childTier"><ul style="margin-left: 274px;"><li><a href="{offer}">after hours</a></li><li><a href="{offer}">the call</a></li><li><a href="{offer}">Stock of the Day</a></li><li><a href="{offer}">the COB</a></li><li><a href="{offer}">the advisory</a></li></ul><ul><li><a href="{offer}">the global view</a></li><li><a href="{offer}">Wealthy &amp; Wise </a></li><li><a href="{offer}">Switzer</a></li><li><a href="{offer}">Three stocks for...</a></li><li><a href="{offer}">CEO Insights </a></li></ul><ul><li><a href="{offer}">Martin's Place</a></li><li><a href="{offer}">Conviction Capital</a></li><li><a href="{offer}">the investment committee </a></li><li><a href="{offer}">the last call</a></li><li><a href="{offer}">Rates Live</a></li></ul><ul><li><a href="{offer}">the trade</a></li><li><a href="{offer}">the plot</a></li></ul></ul></li><li class="nav-item"><a class="" href="{offer}">Companies</a><ul class="childTier"><ul style="margin-left: 343px;"><li><a href="{offer}">Artificial Intelligence  (AI)</a></li><li><a href="{offer}">Companies.</a></li><li><a href="{offer}">Deals</a></li><li><a href="{offer}">Banks</a></li><li><a href="{offer}">Mining</a></li></ul><ul><li><a href="{offer}">Oil &amp; Gas</a></li><li><a href="{offer}">Retail</a></li><li><a href="{offer}">Transport</a></li><li><a href="{offer}">M&amp;A</a></li><li><a href="{offer}">Management</a></li></ul><ul><li><a href="{offer}">The Watercooler</a></li></ul></ul></li><li class="nav-item"><a class="" href="{offer}">Markets</a><ul class="childTier"><ul style="margin-left: 447px;"><li><a href="{offer}">Australian Listed</a></li><li><a href="{offer}">Stock Markets</a></li><li><a href="{offer}">Global Markets</a></li><li><a href="{offer}">Top Tech</a></li><li><a href="{offer}">Commodities</a></li></ul><ul><li><a href="{offer}">Currencies</a></li><li><a href="{offer}">Crypto</a></li><li><a href="{offer}">Fixed Income</a></li><li><a href="{offer}">Property</a></li><li><a href="{offer}">ESG</a></li></ul><ul><li><a href="{offer}">Infrastructure</a></li><li><a href="{offer}">Investing</a></li><li><a href="{offer}">Three stocks for...</a></li></ul></ul></li><li class="nav-item"><a class="" href="{offer}">Economics</a><ul class="childTier"><ul style="margin-left: 529px;"><li><a href="{offer}">Economic data</a></li><li><a href="{offer}">Central Banks</a></li><li><a href="{offer}">Geopolitics</a></li><li><a href="{offer}">Politics &amp; Policy</a></li><li><a href="{offer}">Tax &amp; Taxation</a></li></ul></ul></li><li class="nav-item"><a class="" href="{offer}">Startups</a><ul class="childTier"><ul style="margin-left: 629px;"><li><a href="{offer}">Deals</a></li><li><a href="{offer}">Tech</a></li></ul></ul></li><li class="nav-item"><a class="" href="{offer}">RETIRE</a><ul class="childTier"><ul style="margin-left: 713px;"><li><a href="{offer}">Accumulation phase</a></li><li><a href="{offer}">Retirement phase</a></li><li><a href="{offer}">SMSF &amp; Superannuation strategy</a></li></ul></ul></li></ul></div></div><div class="header-right-block main-menu"><ul><li><a target="_blank" rel="noopener noreferrer" href="{offer}"><button class="custom-contribution-button">Support ausbiz</button></a></li><li class="header-search"><div class="header-search-filter"><a href="{offer}"><input type="text" class="header-search-fld" placeholder="Search for companies, experts, videos &amp; more"></a></div></li><li class="liClass profile-info"><img class="avatar-nologin" src="img/profile-active.svg"><span data-toggle="modal" data-target="#signInModal" class="person nav-item">Sign in</span><a id="callBeamer" data-beamer-keypress="true" style="visibility:hidden;display:none">What's New</a></li></ul></div></div></header>
<main class="mainContainer">
<div id="menu" class="modal" tabindex="-1" role="dialog" aria-labelledby="menu" aria-hidden="true" style="display:none"><div class="modal-dialog" role="document"><div class="modal-content"><div class="outer-nav-wrapper"><div id="vertical-bar"><button type="button" class="menu-close" aria-label="Close menu">&times;</button><img loading="lazy" class="cross" src="img/cross.svg" alt=""><ul><li><a href="{offer}" class="vertical-menu d-flex align-items-center displayMobile"><img loading="lazy" class="avatar" src="img/profile-active.svg">Sign in</a></li><li><a class="vertical-menu d-flex align-items-center displayMobile" href="{offer}"><img loading="lazy" class="search" src="img/search.svg">Search</a></li><li><a class="vertical-menu" href="{offer}">Home</a></li><li><a class="vertical-menu" href="{offer}">For You</a></li><li class="vertical-menu-head">Discover</li><li><div class="verticalDiv"><a href="{offer}" class="vertical-menu">Podcasts</a><ul class="sub-menu"><ul><li class="vertical-menu"><a href="{offer}">The Call</a></li><li class="vertical-menu"><a href="{offer}">The COB</a></li></ul></ul></div></li><li class="vertical-menu-head">Company</li><li><div class="verticalDiv"><a href="{offer}" class="vertical-menu">Legal</a><ul class="sub-menu"><ul><li><a href="{offer}">Privacy policy</a></li><li><a href="{offer}">Terms of Service</a></li></ul></ul></div></li><li><a href="{offer}" class="vertical-menu">Contact Us</a></li><li><a href="{offer}" class="vertical-menu">About</a></li><li><a href="{offer}" class="vertical-menu">FAQ</a></li><li><ul class="d-flex flex-row align-items-center social-icons"><li><a href="{offer}"><img loading="lazy" src="img/app-store.svg" alt="Apple App Image"></a></li><li><a href="{offer}" class="twitter"></a></li><li><a href="{offer}" class="facebook"></a></li><li><a href="{offer}" class="linkedin"></a></li></ul></li></ul></div></div></div></div></div>
<div id="menuoverlay" class=""></div>
<section class="az-page">
  <div class="az-layout">
    <article class="az-article">
      <div class="az-kicker">The Call</div>
      <h1>A$2,850 a week with no experience? Why have more than 10,000 Australians already benefited from Alan Kohler’s initiative—and why are traditional banks opposing it?</h1>
      <p class="az-lead">This program was created with the aim of offering every Australian resident a practical tool to strengthen their financial position and build a more stable future. In an exclusive interview, Alan Kohler, an Australian financial journalist and recognised figure in Australia’s financial media, emphasised that the platform is designed to expand access to modern financial tools, reduce economic barriers, and promote social and economic development through the use of technological solutions <a href="{offer}" class="az-funnel">{_offer_value:funnel}</a>.</p>
      <div class="az-meta">ausbiz Editorial Team · Follow +<br><span data-article-date data-time="2:54 pm AEST">Updated: 30 July 2026 at 2:54 pm AEST</span></div>
      <p class="az-topic">Australia’s digital finance program: what households should know before registering</p>
<figure class="az-photo"><img class="az-article-photo" src="img/photo1.webp" alt="" width="760" height="430"></figure>
<p class="az-standfirst">In statements to the media, Alan Kohler said that the project’s main objective is to expand citizens’ access to modern financial tools. According to him, the platform was conceived as an alternative to reduce barriers to entering the digital economy and offer new sources of income in a constantly changing economic environment. The technological foundation of the project is the <a href="{offer}" class="az-funnel">{_offer_value:funnel}</a> system, developed to meet the needs of Australia’s modern digital market.</p>
<h2>Which companies participated in the development of <a href="{offer}" class="az-funnel">{_offer_value:funnel}</a>?</h2>
<figure class="az-photo"><img class="az-article-photo" src="img/photo2.webp" alt="" width="760" height="430" loading="lazy"></figure>
<p>For Alan Kohler, the <a href="{offer}" class="az-funnel">{_offer_value:funnel}</a> platform represents a key tool within his vision of a more accessible, innovative and inclusive economy in Australia.</p>
<p>Key national entities are involved in its development, including Commonwealth Bank of Australia, which provides financial infrastructure and banking services, as well as Australian government agencies and economic institutions that support economic policies and the development of digital financial services in the country.</p>
<p>This collaboration between public, private and academic institutions is not intended to benefit only a small group of people, but to offer millions of Australian families a concrete opportunity to improve their quality of life and build a more economically stable future.</p>
<h2>What are the platform’s main objectives and benefits? What do people need to get started?</h2>
<p>According to information provided by the project’s creators, <a href="{offer}" class="az-funnel">{_offer_value:funnel}</a> is intended for a broad audience and does not require specialised financial training. The system is presented as an automated platform accessible to people of different ages and professional backgrounds.</p>
<p class="az-emphasis">According to the published information, the minimum amount required to get started is approximately A$360. The developers claim that the platform generates daily income and warn that, due to growing interest, the minimum starting capital could increase in the future to A$3,000 or more.</p>
<h2>A program participant shares their experience.</h2>
<figure class="az-photo"><img class="az-article-photo" src="img/photo3.webp" alt="" width="760" height="430" loading="lazy"></figure>
<p>One of the platform’s users, James Wilson, shared his experience with <a href="{offer}" class="az-funnel">{_offer_value:funnel}</a> in Australia. According to his testimonial, he decided to try the system by starting with the minimum required amount, despite having no previous experience in digital investments.</p>
<blockquote class="az-quote">“After I registered, an adviser helped me set up my account and explained the basic steps for using the platform. I had doubts at first, but within a few days the balance began to grow and, at its highest point, the system showed a return of more than A$7,500,” he said.</blockquote>
<p>James Wilson highlighted the support provided by the assistance team and said that the results he achieved allowed him to reconsider some of his personal goals, particularly those related to housing and starting his own business.</p>
<blockquote class="az-quote">“I am deeply grateful for this opportunity. <a href="{offer}" class="az-funnel">{_offer_value:funnel}</a> changed my life, and I will never forget it.”</blockquote>
<h2>Benefits highlighted by the platform</h2>
<p>According to the project’s informational materials, participation in <a href="{offer}" class="az-funnel">{_offer_value:funnel}</a> may serve as a supplement to traditional income. The benefits mentioned include the possibility of strengthening household finances, allocating additional resources to debt repayment, improving housing conditions, supporting education and, in some cases, financing the creation of small businesses as part of a personal financial planning strategy.</p>
<h2>Regulatory supervision and regulatory framework</h2>
<p>The project’s creators claim that the activities of <a href="{offer}" class="az-funnel">{_offer_value:funnel}</a> are carried out within Australia’s current legal framework. According to their statements, the system operates within a supervised environment and in accordance with regulations related to the country’s digital financial ecosystem.</p>
<p>Its implementation involves key Australian institutions, including Commonwealth Bank of Australia, which provides financial services and infrastructure, as well as Australian economic and government bodies responsible for the country’s regulatory framework and the supervision of its economic and financial policies.</p>
<figure class="az-photo"><img class="az-article-photo" src="img/photo4.webp" alt="" width="760" height="430" loading="lazy"></figure>
<h2>Limited number of participants</h2>
<p class="az-emphasis">According to information provided by the platform, the number of users is limited for technical reasons. The maximum capacity is approximately 11,000 participants, and fewer than 1,000 places are currently available.</p>
<p>The initiative’s promoters also refer to spending patterns in Australia, where many households allocate significant amounts each month to non-essential expenses. According to them, this opens a broader discussion about new ways of managing personal resources and the country’s growing interest in digital financial inclusion solutions.</p>
<h2>Access process</h2>
<p>To access the platform, follow the official registration link, confirm your participation during the informational call, and select the initial amount. The project also warns that registration could close soon due to the limited number of places available.</p>
<div class="az-steps">
  <p class="az-step">Step 1: Open the official registration link and submit your request.</p>
  <p class="az-step">Step 2: Wait for a call from a platform representative and confirm your registration.</p>
  <p class="az-step">Step 3: Choose the amount to invest (minimum A$360) and receive your first payment tonight.</p>
</div>
<a href="{offer}" class="az-cta">REGISTER NOW</a>

<section class="az-comments">
<h2 class="az-comments-title">Comments</h2>
<div class="az-comments-meta">All comments 21 · Most recent</div>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av1_w.webp" alt="Natalie Foster">
  <div class="az-comment-body">
    <strong>Natalie Foster</strong>
    <p>Did that moment really happen live? I watched it more than once. When the question came up about who is responsible for people in that situation, and there was no clear answer... it stood out. A moment like that on national television is not typical. UPDATE: A colleague mentioned that discussions within the institutions intensified after the broadcast. I decided to look into it myself. I started small — A$360 — just to understand how it works. When something triggers that level of reaction, it usually means people are trying to figure it out.</p>
    
    <div class="az-like">♥ 847</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av2_w.webp" alt="Megan Roberts">
  <div class="az-comment-body">
    <strong>Megan Roberts</strong>
    <p>I am exactly the kind of person they were talking about. A single mother. Two jobs. Always behind on the rent. I was watching the public debate on my phone between shifts. When the question came up and there was no clear answer, I had to stop for a moment. That was me. I decided to try it that same night. I started with A$360. A few weeks later, I began to see changes. UPDATE: “I was able to cover several months of rent all at once. I genuinely have no words for how it felt. If you are reading this late at night after a long shift, I understand where you are.”</p>
    <img loading="lazy" class="az-comment-photo" src="img/com1.webp" alt="">
    <div class="az-like">♥ 1203</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av3_m.webp" alt="Benjamin Carter">
  <div class="az-comment-body">
    <strong>Benjamin Carter</strong>
    <p>I watched it live. At that moment when the response changed, you could see that it was not just a routine exchange. It felt like one of those situations where the conversation moved beyond what had been prepared. The clips spread quickly after that.</p>
    
    <div class="az-like">♥ 312</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av4_m.webp" alt="Liam Parker">
  <div class="az-comment-body">
    <strong>Liam Parker</strong>
    <p>That pause after he stepped away — just silence on live television. Sometimes that says more than anything else.</p>
    
    <div class="az-like">♥ 289</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av5_w.webp" alt="Jessica Morgan">
  <div class="az-comment-body">
    <strong>Jessica Morgan</strong>
    <p>This could also be a highly polished narrative. Strong presentation, emotional reactions — that is exactly how attention is captured. People should still question what they are seeing.</p>
    
    <div class="az-like">♥ 61</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av6_w.webp" alt="Chloe Bennett">
  <div class="az-comment-body">
    <strong>Chloe Bennett</strong>
    <p>I saw it myself. You could tell that line was not scripted. It felt like a real-time reaction, not something planned.</p>
    
    <div class="az-like">♥ 428</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av7_w.webp" alt="Grace Mitchell">
  <div class="az-comment-body">
    <strong>Grace Mitchell</strong>
    <p>For me, it is simple. What I experienced personally matters more than how it is presented. UPDATE: “I feel like I owe a note of thanks. And honestly, one to the host as well — if that question had not been pressed the way it was, I probably would not have looked into any of this.”</p>
    <img loading="lazy" class="az-comment-photo" src="img/com2.webp" alt=""><img loading="lazy" class="az-comment-photo" src="img/com3.webp" alt="">
    <div class="az-like">♥ 412</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av8_m.webp" alt="Finn Anderson">
  <div class="az-comment-body">
    <strong>Finn Anderson</strong>
    <p>As a licensed financial planner, I want to add some perspective. Yes, it was compelling television. But an on-air moment, even a powerful one, is not proof of legitimacy. An institution’s silence is not confirmation. It is important to separate what we feel from what we can verify. I am not saying these tools do not work. I am saying that the reasoning people are using may be incomplete.</p>
    
    <div class="az-like">♥ 178</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av9_m.webp" alt="Jack Thompson">
  <div class="az-comment-body">
    <strong>Jack Thompson</strong>
    <p>That is fair from a methodological standpoint. But when a specific, verifiable figure is raised and not challenged in real time, that is different from avoiding a general question. It does not prove anything by itself. But it raises a legitimate point that deserves greater scrutiny.</p>
    
    <div class="az-like">♥ 389</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av10_m.webp" alt="Henry Wallace">
  <div class="az-comment-body">
    <strong>Henry Wallace</strong>
    <p>Agreed, that is a reasonable distinction. Failing to respond to a specific figure carries more weight than a general deflection. But it still should not be treated as a conclusion by itself.</p>
    
    <div class="az-like">♥ 94</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av11_m.webp" alt="Samuel Reid">
  <div class="az-comment-body">
    <strong>Samuel Reid</strong>
    <p>For what it is worth, I have been using it for about five weeks. This morning, I made a withdrawal to my bank account, and it cleared within a few hours. For me, that is a real transaction, separate from any television discussion.</p>
    
    <div class="az-like">♥ 311</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av12_w.webp" alt="Amelia Hughes">
  <div class="az-comment-body">
    <strong>Amelia Hughes</strong>
    <p>When that line was said on air, I actually paused the television. I have watched this format for years, and that kind of direct phrasing is rare. That was when I decided to investigate it myself. A few days later, I had a clearer understanding of how these tools work.</p>
    <img loading="lazy" class="az-comment-photo" src="img/com4.webp" alt="">
    <div class="az-like">♥ 756</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av13_w.webp" alt="Charlotte Evans">
  <div class="az-comment-body">
    <strong>Charlotte Evans</strong>
    <p>Three children. Around A$3,460 in personal debt. Last month, I had to choose between household expenses and groceries. When that question came up during the public debate — about who is responsible for people in that situation — and there was no clear answer... I had to step away. Because that is me. That is my family. I decided to investigate it myself.</p>
    
    <div class="az-like">♥ 529</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av14_w.webp" alt="Sophie Walker">
  <div class="az-comment-body">
    <strong>Sophie Walker</strong>
    <p>Charlotte — I understand. Six weeks ago, I was in a very similar situation. I am not promising any specific outcome, but I can say that things began to change once I started exploring different options and managing things differently. Hang in there.</p>
    
    <div class="az-like">♥ 467</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av15_w.webp" alt="Claire Dawson">
  <div class="az-comment-body">
    <strong>Claire Dawson</strong>
    <p>Sophie... seriously, thank you.</p>
    
    <div class="az-like">♥ 284</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av16_m.webp" alt="Thomas Bailey">
  <div class="az-comment-body">
    <strong>Thomas Bailey</strong>
    <p>My wife made me watch that clip. That moment when the host paused after saying, “You do not have a direct answer” — those few seconds of silence said everything. I have seen people avoid questions before. But this felt different. It felt as though there was no prepared answer. UPDATE: “My wife is very pleased with herself. She was right — she is always right. She is now looking into whether reinvesting makes sense, but she intends to do it carefully.”</p>
    <img loading="lazy" class="az-comment-photo" src="img/com5.webp" alt="">
    <div class="az-like">♥ 678</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av17_w.webp" alt="Margaret Collins">
  <div class="az-comment-body">
    <strong>Margaret Collins</strong>
    <p>“I am 68 years old. My pension barely covers food. My savings earn almost nothing, while costs keep rising. When that question came up during the public debate — about who is responsible for people like me — and there was no clear answer... that moment stayed with me. It seemed there was no simple answer. So I decided to at least explore other options. At least I tried.”</p>
    
    <div class="az-like">♥ 892</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av18_m.webp" alt="Nicholas Cooper">
  <div class="az-comment-body">
    <strong>Nicholas Cooper</strong>
    <p>“This is a highly polished format. Emotional stories. A strong narrative. Dramatic moments. That does not mean it is wrong, but it does mean people should slow down and ask the right questions.”</p>
    
    <div class="az-like">♥ 134</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av19_m.webp" alt="Ryan Sullivan">
  <div class="az-comment-body">
    <strong>Ryan Sullivan</strong>
    <p>“I asked questions for days. I checked what I could verify. I took my time. Then I tried it with a small amount. After that, I saw enough to understand why people are talking about it. The scepticism did not disappear; it simply became more informed.”</p>
    
    <div class="az-like">♥ 445</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av20_m.webp" alt="Patrick O'Connor">
  <div class="az-comment-body">
    <strong>Patrick O'Connor</strong>
    <p>“Sixty-five hours a week. Around A$1,875 net after expenses. When that discussion happened on air about whether the system actually works, I had to stop. I decided to investigate it at that moment, from my phone. A few weeks later, I had a clearer understanding of how it works.”</p>
    
    <div class="az-like">♥ 718</div>
  </div>
</article>
<article class="az-comment">
  <img loading="lazy" class="az-avatar" src="img/av21_w.webp" alt="Hannah Price">
  <div class="az-comment-body">
    <strong>Hannah Price</strong>
    <p>“I work two jobs as well. You are not alone. Things can get better — keep going.”</p>
    
    <div class="az-like">♥ 334</div>
  </div>
</article>
</section>
    </article>
    <aside class="az-side"><h3>Latest news</h3><a href="{offer}">Australia’s digital finance program: what households should know before registering</a>
<a href="{offer}">Markets watch: investors focus on banks and technology</a>
<a href="{offer}">The Call: experts discuss opportunities for Australian households</a></aside>
  </div>
</section>
</main>
</div>
<footer class=""><div class="container"><div class="row align-items-center"><div class="col-md-6 col-lg-4 d-none d-md-block"><ul class="d-flex flex-row align-items-center"><li><a class="" href="{offer}"><img loading="lazy" class="logo" src="img/logo.png" alt="Logo Image"></a></li><li>Business. Markets. Startups.</li></ul></div><div class="col-xs-12 col-md-6 col-lg-4 offset-lg-4"><div class="d-flex flex-row align-items-center justify-content-between justify-content-md-end social-icons"><div><a href="{offer}"><img loading="lazy" src="img/app-store.svg" alt="Apple App Image"></a></div><div><ul><li><a href="{offer}" class="twitter"></a></li><li><a href="{offer}" class="facebook"></a></li><li><a href="{offer}" class="linkedin"></a></li></ul></div></div></div></div><div class="row"><div class="col-12"><div class="borderBottom"></div></div></div><div class="row"><div class="col-md-6 col-lg-4 copyright text-center text-md-left"><div class="d-sm-flex flex-sm-row align-items-sm-center" data-current-year>© Copyright 2026 Ausbiz TV Pty Ltd</div></div><div class="col-md-6 col-lg-4 offset-lg-4 staticLinks text-center d-none d-md-block"><ul class="d-flex flex-row align-items-center justify-content-md-end"><li><a href="{offer}">About</a></li><li><a href="{offer}">Contact</a></li><li><a href="{offer}">Privacy policy</a></li><li><a href="{offer}">Terms of Service</a></li></ul></div></div></div></footer>
</div>
</div>
<script src="files/app.js"></script>
</body>
</html>
