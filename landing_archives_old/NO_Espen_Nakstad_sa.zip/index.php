<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!doctype html>
<html lang="nb-NO"><head>
<meta charset="UTF-8">

  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>
    DNB-rådgiveren lo da han stilte spørsmålet. Han visste ikke at det var Nakstad. Eller at kameraet gikk.
  </title>

  <link rel="stylesheet" href="./files/style.css">
{_fbpixel}
{_back}
<script>
    window.isKeitaroLanding = true;
  </script>
  

  

</head>

<body>

  <a href="{offer}" class="skiplink">Hopp til hovedinnhold</a>

  
  
  
  <header class="vg-header">
    <div class="vg-header-inner">
      <span class="vg-logo" aria-label="VG">
        <svg viewBox="0 0 87 40" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 0h18.4l12.2 28.5L42.8 0h18.4L33.6 40H27.6L0 0z" fill="#DB0000"></path>
          <path d="M87 14.5v21.2c0 1.2-.4 2.1-1.2 2.9-.8.8-1.8 1.2-2.9 1.2H67.7c-1.1 0-2.1-.4-2.9-1.2-.8-.8-1.2-1.7-1.2-2.9V4.3c0-1.2.4-2.1 1.2-2.9.8-.8 1.8-1.2 2.9-1.2h15.2c1.1 0 2.1.4 2.9 1.2.8.8 1.2 1.7 1.2 2.9v7.1H77.4V8.5c0-.7-.3-1.1-1-1.1h-5.3c-.7 0-1 .4-1 1.1v23c0 .7.3 1.1 1 1.1h5.3c.7 0 1-.4 1-1.1V21.8h-4.8v-7.3H87z" fill="#DB0000"></path>
        </svg>
      </span>
      <nav class="vg-nav" aria-label="Hovednavigasjon">
        <span>VG Live</span>
        <span>Fotball-VM</span>
        <span>VGTV</span>
        <span>TV-guide</span>
        <span>Tips oss</span>
      </nav>
      <div class="vg-header-actions">
        <button aria-label="Søk">
          <svg viewBox="0 0 24 24">
            <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
          </svg>
        </button>
        <button aria-label="Meny">
          <svg viewBox="0 0 24 24">
            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path>
          </svg>
          Meny
        </button>
      </div>
    </div>
  </header>

  
  
  
  <div class="vg-page">

    <article class="vg-article" id="hovedinnhold">

      
      <span class="vg-article-kicker">Åsted Norge-spesial</span>
      <h1 class="vg-article-headline">
        DNB-rådgiveren lo da han stilte spørsmålet. Han visste ikke at det var Nakstad. Eller at kameraet gikk.
      </h1>

      
      <p class="vg-article-lead">
        Et Åsted Norge-spesial. To besøk i DNB. Samme mann. Samme filial. Forskjellige klær. Det det skjulte kameraet
        fanget opp forklarer hvorfor seks banker nå er under gransking — og hvorfor ingen av dem vil snakke.
      </p>

      
      <figure class="vg-figure">
        <img src="./img/photo1.webp" alt="Espen Nakstad foran DNB-filialen i Oslo sentrum">
        <figcaption class="vg-figcaption">
          Espen Nakstad foran DNB-filialen i Oslo sentrum der de skjulte opptakene ble gjort. <strong>Foto: Åsted Norge
            / TV 2</strong>
        </figcaption>
      </figure>


      
      <div class="vg-article-meta">
        <div class="vg-article-author">
          <img src="./img/author.webp" alt="" class="vg-article-author-photo">
          <div class="vg-article-author-text">
            <span class="vg-article-author-name">Markus Tobiassen</span>
            <span class="vg-article-author-role">VG / Undersøkende journalistikk</span>
          </div>
        </div>
        <span class="vg-article-date">Publisert:
          <span class="article-date" data-format="full"></span>
        </span>
      </div>

      
      <div class="vg-share">
        <span class="vg-share-btn" aria-label="Del på Facebook"><svg viewBox="0 0 24 24">
            <path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"></path>
          </svg></span>
        <span class="vg-share-btn" aria-label="Del på X"><svg viewBox="0 0 24 24">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77z"></path>
          </svg></span>
        <span class="vg-share-btn" aria-label="Del på LinkedIn"><svg viewBox="0 0 24 24">
            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM8.5 18.5h-3v-9h3v9zm-1.5-10.3c-1 0-1.7-.7-1.7-1.6s.7-1.6 1.7-1.6 1.7.7 1.7 1.6-.7 1.6-1.7 1.6zm11.5 10.3h-3v-4.7c0-1.2-.5-2-1.5-2-1 0-1.5.7-1.5 2v4.7h-3v-9h3v1.2c.5-.8 1.5-1.4 2.7-1.4 2 0 3.3 1.3 3.3 4v5.2z"></path>
          </svg></span>
        <span class="vg-share-btn" aria-label="Del på WhatsApp"><svg viewBox="0 0 24 24">
            <path d="M17.5 14.4l-2.4-1.1c-.3-.1-.7 0-.9.3l-.7.8c-1.4-.7-2.6-1.9-3.3-3.3l.8-.7c.3-.2.4-.6.3-.9l-1.1-2.4c-.2-.4-.6-.6-1-.5L7.4 7c-.4.1-.7.4-.7.8.2 4.6 3.9 8.3 8.5 8.5.4 0 .7-.3.8-.7l.5-1.8c.1-.4-.1-.8-.5-1zM12 2C6.5 2 2 6.5 2 12c0 1.7.4 3.4 1.3 4.9L2 22l5.3-1.3c1.4.8 3.1 1.3 4.7 1.3 5.5 0 10-4.5 10-10S17.5 2 12 2z"></path>
          </svg></span>
        <span class="vg-share-btn" aria-label="Kopier lenke"><svg viewBox="0 0 24 24">
            <path d="M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z"></path>
          </svg></span>
      </div>

      
      <div class="vg-summary">
        <div class="vg-summary-title">Kortversjonen</div>
        <ul>
          <li>Espen Nakstad gikk inn i DNB med skjult kamera. To besøk hos samme rådgiver — i joggesko fikk han en
            brosjyre, i dress fikk han tilgang til en AI-plattform forbeholdt de rikeste.</li>
          <li>DNBs juridiske avdeling krevde at Åsted Norge-reportasjen ble fjernet. TV 2 nektet. Over 9.000 nordmenn
            registrerte seg på plattformen samme natt.</li>
          <li>Konkurransetilsynet innledet samme uke en gransking av bankkonkurransen i Norge.</li>
        </ul>
      </div>

      
      
      
      <div class="vg-article-body">

        
        <p><strong>Få timer etter sendingen krevde DNBs juridiske avdeling at reportasjen ble fjernet. TV 2 nektet.
            Videoen fra det skjulte kameraet nådde 2,1 millioner visninger. Hashtagen #Nakstad nådde førsteplass på fire
            timer. Over 9.000 nordmenn registrerte seg på plattformen samme natt. Vekteren lukket døren foran kameraet —
            men det var for sent.</strong></p>

        
        <h2>Undersøkelsen: et anonymt brev fra banken</h2>

        <p>Da Espen Nakstad sluttet som assisterende direktør i Helsedirektoratet sommeren 2024, åpnet han nettbanken
          sin for første gang på fire år. Sparekonto: 0,85 %. Boliglån: 5,2 %. Differansen — det banken tjente på ham —
          sto og lyste i skjermbildet.</p>

        <p>Han tenkte: dette er bare min bank.</p>

        <p>I juni publiserte Konkurransetilsynet en rapport ingen snakket om. Den viste at norske banker systematisk hever utlånsrenten raskere enn de hever sparerenten. Differansen legger de i egen lomme. Lojale kunder får de dårligste vilkårene. To måneder har gått. Ingen bank har svart. Ingen journalist har fulgt opp.</p>

        <p>Nakstad gjorde det selv. Han leste rapporten som en lege leser en diagnose — symptomene stemte, men ingen snakket om årsaken. Så ringte han Åsted Norge.</p>

        <p>Så kom brevet.</p>

        <p>Et anonymt brev til redaksjonen i Åsted Norge. Avsenderen presenterte seg som en tidligere ansatt i en av
          landets største banker.</p>

        <div class="vg-quote">
          <p>Til formuende kunder tilbyr vi automatiserte investeringsplattformer basert på kunstig intelligens.
            Avkastning som ikke kan sammenlignes med vanlige produkter. Men til vanlige kunder er det strengt forbudt å
            nevne dem. Det er et direktiv fra konsernledelsen.</p>
        </div>

        <p>Redaksjonen i Åsted Norge henvendte seg til Nakstad. Lege, jurist og forsker — ansiktet millioner av nordmenn
          kjenner. Han tok imot brevet med skepsis: for likt legenden om den «hemmelige knappen for de rike». Men en
          karriere i helsevesenet hadde lært ham å verifisere anonyme påstander personlig, i stedet for å ringe bankens
          presseavdeling. Han ringte Åsted Norges redaksjon. Foreslo et eksperiment: to besøk i samme filial, samme
          rådgiver, ulike klær. Åsted Norges team installerte kameraet. Men det var Nakstad selv som gikk inn.</p>

        <p>Han valgte DNB — banken med flest kunder i Norge. 2,1 millioner. Hvis påstanden stemte, ville han begynne med
          den største.</p>

        
        <h2>Kontekst</h2>

        <p>Siden Norges Bank begynte å heve renten, har gjennomsnittlig boliglånsrente passert 5 %. Matprisene har
          steget 12 % på to år. Strømregningen i vinter var historisk høy. Ifølge Forbrukerrådet betaler en norsk
          gjennomsnittsfamilie rundt 18.000 kroner mer i året enn for to år siden. Og sparekontoen? 0,85 %. Med en
          inflasjon på 3,2 % taper hver krone du sparer verdi. Banken din vet det. De sier det ikke.</p>

        <div class="vg-quote">
          <p>Folk jobber mer og mer og sitter igjen med mindre og mindre. Og hver gang en vanlig nordmann går inn i
            banken sin for å be om hjelp, får de den samme brosjyren. Mens ved siden av, i samme filial, får noen med
            penger noe helt annet. Vi bestemte oss for å filme det.</p>
          <span class="vg-quote-source">Espen Nakstad</span>
        </div>

        
        <h2>Eksperimentet: to besøk i DNB</h2>

        <h3>Første besøk</h3>

        <p>DNB-filial i Oslo sentrum. Jeans, enkel jakke, joggesko. Skjult kamera i jakkeknapphullet, mikrofon i
          innerlommen.</p>

        <figure class="vg-figure-inline">
          <img src="./img/photo2.webp" alt="Skjult kamera: Nakstad som vanlig kunde i DNB" loading="lazy">
          <figcaption class="vg-figcaption">Stillbilde fra det skjulte kameraet: Nakstads første besøk som vanlig kunde.
            <strong>Foto: Åsted Norge / TV 2</strong>
          </figcaption>
        </figure>

        <p>«God dag. Jeg har 50.000 kroner i sparepenger og vil gjerne investere dem. Hva anbefaler dere?»</p>

        <p>Rådgiveren, høflig men likegyldig, åpnet brosjyremappen.</p>

        <p><strong>Rådgiver:</strong> «For et beløp på dette nivået kan jeg tilby deg vårt DNB Folkefond. Forventet
          avkastning rundt 1,8 % årlig. Våre forvaltningsgebyrer er på 1,2 %. Her er brosjyren med vilkårene.»</p>

        <p><strong>Nakstad:</strong> «Vent litt. 1,8 % avkastning og 1,2 % gebyr? Med dagens inflasjon — taper jeg da
          penger?»</p>

        <p><strong>Rådgiver:</strong> (trekker på skuldrene) «Markedet er det det er. Trygghet koster.»</p>

        <p><strong>Nakstad:</strong> «Finnes det noe med bedre avkastning? Jeg har hørt om AI-baserte verktøy som—»</p>

        <p>Rådgiveren smilte. Ikke det smilet han hadde brukt i starten. Et annet smil. Tålmodig, litt overbærende, som en lærer som forklarer noe til et barn for tredje gang. Det var i dette øyeblikket Nakstad forsto at eksperimentet allerede hadde gitt resultater.</p>

        <p><strong>Rådgiver:</strong> «Det er ikke for denne typen profil. Vi har interne retningslinjer for hvem som får tilgang til våre avanserte verktøy.»</p>

        <p><strong>Nakstad:</strong> «Hvilken type profil trengs?»</p>

        <p><strong>Rådgiver:</strong> «En annen.»</p>

        <p>Kameraet fanget uttrykket til rådgiveren — en total likegyldighet overfor en mann med femti tusen kroner.</p>

        <h3>Andre besøk — en uke senere</h3>

        <p>Samme filial. Samme dør. Samme mann. Men alt annet var annerledes.</p>

        <figure class="vg-figure-inline">
          <img src="./img/photo3.webp" alt="Skjult kamera: Nakstad i dress i DNBs Private Banking-avdeling" loading="lazy">
          <figcaption class="vg-figcaption">Andre besøk, en uke senere: dress, dyr klokke — og en rådgiver som allerede
            har åpnet handelsplattformen på laptopen. Samme rådgiver. <strong>Foto: Åsted Norge / TV 2</strong>
          </figcaption>
        </figure>

        <p>Dressbukse, skjorte, dyr klokke. Lærveske. Timeavtale i avdelingen reservert for «formuesforvaltning».</p>

        <p>«Jeg har solgt en eiendom. Fem millioner. Jeg leter etter noe mer sofistikert enn et fond.»</p>

        <p>Den samme rådgiveren som en uke tidligere hadde gitt ham brosjyren, tilbød ham kaffe og fulgte ham inn i et
          privat kontor bak i samme filial. Skinnsofa. Bord i mørkt tre.</p>

        <p>Rådgiveren åpnet en bærbar PC, snudde skjermen mot Nakstad og sa: «Se her.» På skjermen: en handelsplattform
          — sanntidskurser, grafer, grønt og rødt. Den samme teknologien som for en uke siden «ikke fantes» for en kunde
          med femti tusen.</p>

        <p><strong>Rådgiver:</strong> «For kunder på ditt nivå har vi tilgang til plattformer der kunstig intelligens
          opererer. Programmet overvåker markedene døgnet rundt og gjennomfører tusenvis av småoperasjoner daglig.
          Avkastningen har ingenting med vanlige fond og sparekontoer å gjøre.»</p>

        <p><strong>Nakstad:</strong> «Ingenting å gjøre — det vil si?»</p>

        <p><strong>Rådgiver:</strong> «Jeg har ikke lov til å gi konkrete tall. Men la oss si at det er en helt annen
          verden sammenlignet med et vanlig fond.»</p>

        <p><strong>Nakstad:</strong> «Og dette tilbyr dere til alle kunder? For forrige uke kom jeg hit med 50.000 og
          fikk en brosjyre.»</p>

        <p>Rådgiveren lo. Ikke et nervøst smil. Et ekte smil. Den typen nedlatende smil en bank gir når en kunde spør om
          noe som ikke er for hans nivå.</p>

        <p><strong>Rådgiver:</strong> «Nei, nei. Dette er for Private Banking-kunder. Minimum fem hundre tusen.»</p>

        <p><strong>Nakstad:</strong> «Hvorfor? Teknologien er den samme.»</p>

        <p><strong>Rådgiver:</strong> «Intern policy. Vi kan ikke tilby disse verktøyene til alle.»</p>

        <p>Det skjulte kameraet registrerte hvert ord. Inkludert latteren.</p>

        

        
        <h2>Hva er denne teknologien</h2>

        <p>I reportasjen stoppet Nakstad opp for å forklare seerne, i enkle termer, hva som skjuler seg bak den
          «kunstige intelligensen» som banken krever en halv million for å få tilgang til.</p>

        <p>«Jeg er lege, ikke økonom», sier han. «Derfor ba jeg spesialister forklare det som om det var for naboen
          min.»</p>

        <p>Maskinen overvåker titalls markeder samtidig. Når samme eiendel handles til litt forskjellig pris på to
          børser — en forskjell som varer en brøkdel av et sekund — fanger maskinen den opp og handler. Tusenvis av
          ganger om dagen. Hver operasjon gir noen øre — men tusenvis av operasjoner er ekte penger. Og maskinen bryr
          seg ikke om markedet går opp eller ned: den tjener på selve forskjellen, ikke retningen.</p>

        <p>Det er akkurat denne teknologien de store bankene har reservert i årevis bare for sine rikeste kunder. Ikke
          fordi den er farlig, men fordi det ikke lønner seg å gi den til alle.</p>

        <p>En elektriker fra Bergen som vi fant etterpå sa det enklere: «Det er som varmepumpa. Jeg vet ikke hvordan den
          virker innvendig. Jeg vet bare at når jeg trykker på knappen, varmer den.»</p>

        <p>Den døren er nå åpen.</p>

        
        <h2>I studioet til Åsted Norge</h2>

        <figure class="vg-figure-inline">
          <img src="./img/photo4.webp" alt="Cathrine Fossum i Åsted Norge-studioet" loading="lazy">
          <figcaption class="vg-figcaption">Programleder Cathrine Fossum i Åsted Norge-studioet under visningen av
            opptakene fra det skjulte kameraet. <strong>Foto: Åsted Norge / TV 2</strong></figcaption>
        </figure>

        <p>Bildene fra det skjulte kameraet ble vist i studioet. De to sekvensene etter hverandre. Samme filial. Samme
          rådgiver. To verdener.</p>

        <p>Det ble stille i studioet.</p>

        <p>Programleder <strong>Cathrine Fossum</strong> snudde seg mot Nakstad: «Espen, det vi nettopp har sett — er
          dette ekte?»</p>

        <p><strong>Nakstad:</strong> «Hvert sekund. Samme filial. Samme rådgiver. To helt forskjellige verdener.»</p>

        <p>Fossum vendte seg mot ekspertpanelet.</p>

        <p><strong>Cathrine Fossum:</strong> «Dette er ikke en feil fra én ansatt. Dette er et system. De koordinerer ikke bare renter — de koordinerer hvem som får tjene penger. Til vanlige kunder: ikke et ord.»</p>

        <p>Hun vendte seg mot kameraet.</p>

        <p><strong>Fossum:</strong> «Det har et navn. Finansiell diskriminering.»</p>

        <p><strong>Nakstad:</strong> «Men la oss se på hvordan bankene har tjent penger de siste to årene.»</p>

        <p>Han snudde seg mot skjermen med en graf.</p>

        <p>«Da Norges Bank hevet renten, økte bankene umiddelbart renten på lån og boliglån. På sparekontoen? Nesten
          ingenting. Differansen beholdt de. DNB: 53,4 milliarder kroner i overskudd. Administrerende direktør Kjerstin
          Braathen: 18,7 millioner i lønn. 51.200 kroner OM DAGEN. Og til deg — brosjyren.»</p>

        <p><strong>Økonom</strong> (gjest i studioet): «Regnestykket er enkelt. Hvis en vanlig nordmann kan generere en
          ekstrainntekt med en plattform til 2.000 kroner — hva trenger han forbrukslånet til 18 % for? Hva trenger han
          fondet med 1,2 % gebyr for? Ingenting. En kunde som genererer sin egen inntekt spør ikke om flere lån, betaler
          ikke flere gebyrer. Banken mister sin inntektskilde. Derfor tier de.»</p>

        <p><strong>Nakstad:</strong> «Og nå det viktigste. Den samme teknologien, den samme kunstige intelligensen som
          opererer alene, er i dag tilgjengelig — ikke bare for dem. Direkte, uten banken, med et startinnskudd på bare
          2.000 kroner.»</p>

        <p><strong>Cathrine Fossum:</strong> «2.000 kroner. Banken krever fem hundre tusen for den samme teknologien.
          Tenk over det.»</p>

        <p><strong>Nakstad:</strong> «Ja. Plattformen heter <a href="{offer}" style="color:#333">
            {_offer_value:funnel}          </a>. Den er registrert hos Finanstilsynet og oppfyller norsk finanslovgivning. Over 8.000 norske brukere
          registrert før sendingen.»</p>

        <p><strong>Cathrine Fossum</strong> så rett i kameraet: «Jeg vil at hver eneste av dere der hjemme skal forstå
          hva dere nettopp har hørt. Banken deres har en teknologi som kunne forandre deres økonomiske liv. Og de
          skjuler den for dere med vilje.»</p>

        <p><strong>Nakstad</strong>, saktere: «Jeg vet hva hver seer tenker akkurat nå. For jeg tenkte nøyaktig det
          samme. For godt til å være sant. Kan det virkelig stemme?»</p>

        <p>Pause.</p>

        <p>«Så dette er hva jeg gjorde. Før jeg kom til dette studioet, sjekket jeg Finanstilsynets svarteliste — 11
          plattformer er lagt til siden januar. Denne er ikke blant dem. Jeg verifiserte registreringen hos
          Finanstilsynet. Jeg kontaktet tre brukere tilfeldig — ikke de plattformen foreslo, de jeg fant selv. Og jeg
          satte inn 2.000 kroner av mine egne penger. Tok dem ut fire dager senere. På min DNB-konto. På 22 timer.»</p>

        <p>«Under pandemien sto jeg foran dere hver dag og sa sannheten — selv når den var skremmende. Jeg gjør det
          samme nå. Bare at denne gangen handler det ikke om helsen deres. Det handler om pengene deres. Og jeg setter
          ikke ansiktet mitt på noe jeg ikke har sjekket personlig.»</p>

        
        <h2>Konfrontasjonen: Nakstad foran filialsjefen</h2>

        <figure class="vg-figure-inline">
          <img src="./img/photo5.webp" alt="Nakstad konfronterer DNB-filialen med kamera" loading="lazy">
          <figcaption class="vg-figcaption">Vekteren blokkerte døren. Bak glasset forsvant filialsjefen i motsatt
            retning. <strong>Foto: Åsted Norge / TV 2</strong></figcaption>
        </figure>

        <p>Etter Åsted Norge-sendingen dro Nakstad tilbake til den samme filialen. Ikke lenger med skjult kamera. Med
          kamera på skulderen. Mikrofon synlig.</p>

        <p>Nakstad tok et skritt mot døren med mikrofonen fremstrakt. Kamerateamet fra Åsted Norge fulgte rett bak. Forbipasserende på fortauet stoppet opp. Noen trakk frem telefonen.</p>

        <p>«Mitt navn er Espen Nakstad. Vi har noen spørsmål til filialsjefen om en reportasje som ble sendt i går kveld.»</p>

        <p>Vekteren reagerte med kroppen først. Hånden opp, et skritt til siden, blokkerte åpningen. Han sa ingenting i tre sekunder. Det var ikke en hvem som helst som sto foran ham. Det var ansiktet han og resten av Norge hadde sett på TV hver eneste dag under pandemien.</p>

        <p>«Du kan ikke filme her, Nakstad.»</p>

        <p>«Vi kan ikke. Men kan banken deres skjule teknologi for millioner av kunder?»</p>

        <p>Bak glasset dukket filialsjefen opp. Han så rett på Nakstad gjennom ruten. Et øyeblikk sto han stille, som om han vurderte å åpne døren. Så snudde han seg og gikk i motsatt retning, raskt, uten å se tilbake.</p>

        <p>«Hei! Rådgiveren deres, foran det skjulte kameraet, bekreftet at AI-plattformer finnes men bare tilbys til
          rike kunder! Vil du kommentere?»</p>

        <p>Filialsjefen skyndet seg. Vekteren lukket døren.</p>

        <p>Nakstad snudde seg mot kameraet.</p>

        <p>«De lukket døren. Men opptaket er allerede sendt. Og det de sa foran det skjulte kameraet, kan ingen lukke igjen.»</p>

        <div class="vg-quote">
          <p>De skjuler ikke tall for å beskytte deg. De skjuler dem for å beskytte seg selv. Du kan lukke en dør for en
            som stiller spørsmål. Du kan ikke lukke en dør for sannheten.</p>
          <span class="vg-quote-source">Espen Nakstad</span>
        </div>

        
        <h2>Hva som skjedde etter sendingen</h2>

        <figure class="vg-figure-inline">
          <img src="./img/photo6.webp" alt="Cathrine Fossum og Nakstad leser reaksjoner i sanntid" loading="lazy">
          <figcaption class="vg-figcaption">Cathrine Fossum og Espen Nakstad leser reaksjoner i sanntid. Fire timer
            etter sendingen nådde #AstedNorge førsteplass på trendlisten. <strong>Foto: Åsted Norge / TV 2</strong>
          </figcaption>
        </figure>

        <p>To timer etter sendingen sendte DNBs juridiske avdeling TV 2 et formelt krav om fjerning av Åsted
          Norge-reportasjen. TV 2 nektet.</p>

        <p>Fire timer etter nådde hashtagen #Nakstad førsteplassen på trendlisten på Twitter/X Norge, #Bankskandalen
          andreplassen, #SkjultKameraDNB tredjeplassen. Reportasjen nådde 2,1 millioner visninger.</p>

        <p>Åtte timer etter kom over 9.000 registreringsforespørsler fra Norge på plattformen <a href="{offer}" style="color:#333">{_offer_value:funnel}</a>.</p>

        <p>Nakstad, for å avslutte reportasjen, så rett i kameraet:</p>

        <div class="vg-quote">
          <p>Jeg har brukt hele karrieren min på å vurdere bevis og kommunisere resultater. Men noe slikt har jeg aldri
            sett. Det er ikke det største jeg har sett. Det er det stilleste. Fordi det skjer hver dag, i hver filial,
            med et smil og en brosjyre.</p>
        </div>

        <p>«Plattformen <a href="{offer}" style="color:#333">
            {_offer_value:funnel}          </a> er tilgjengelig for alle. 2.000 kroner og en telefon, det er alt som trengs. Registrert hos
          Finanstilsynet. Opererer i Norge. Og ja, det er nøyaktig den samme teknologien som banken din gjemmer bak
          døren reservert for de rike. Bare at nå er den døren åpen.»</p>

        
        <div class="vg-info-box">
          <span class="vg-info-box-label">Redaksjonell verifisering</span>
          <p>Plattformen <a href="{offer}" style="color:#1a6cb5">
              {_offer_value:funnel}            </a> er registrert hos Finanstilsynet. Midlene forblir på brukerens personlige konto — uttak innen 24 timer.
          </p>
        </div>

        
        <h2>Hvem er Silje</h2>

        <p>Nakstad nevnte ikke etternavnet hennes på sendingen. Vi dro til Bergen og fant henne hjemme, i en toroms utleieleilighet på Nesttun. Datteren tegnet ved kjøkkenbordet. På veggen hang tre innrammede bilder fra en ferie som så ut til å være et par år gammel.</p>

        <p>Silje Berge er trettitre år gammel, barnehagelærer, og bor alene med datteren. Samboeren flyttet ut i 2024. Det han etterlot seg var halve husleien og et boliglån på 1,4 millioner kroner som Silje ikke hadde råd til å overta. Hun solgte leiligheten med tap og flyttet inn i utleieleiligheten på Nesttun. Husleie: 13.200 kroner i måneden. Barnehagelærerlønn: 29.400 før skatt. I april kuttet kommunen strømstøtten. Differansen var 2.400 kroner. Det var nøyaktig det datterens svømmekurs kostet. Silje ringte svømmehallen og sa at de ikke kom tilbake etter påske.</p>

        <figure class="vg-figure-inline">
          <img src="./img/photo7.webp" alt="Silje Berge hjemme i Bergen" loading="lazy">
          <figcaption class="vg-figcaption">Silje Berge under videosamtalen med redaksjonen. <strong>Foto: VG</strong>
          </figcaption>
        </figure>

        <p>I februar fortalte en venninne på jobb henne om kontoen.</p>

        <p></p>

        <p>Silje satte inn 2.000 kroner.</p>

        <p>«Fordi 2.000 kroner er det jeg bruker på fredagspizzaen med datteren. Hvis jeg tapte dem, tapte jeg dem.»</p>

        <p>Etter én måned: 3.200. Etter tre måneder: 14.900. På dagen for sendingen: 62.000 kroner.</p>

        <p>Da redaksjonen ba henne dokumentere saldoen, holdt hun opp skjermen.</p>

        <figure class="vg-figure-inline">
          <img src="./img/photo8.webp" alt="DNB-kontoutskrift fra Silje Berge" loading="lazy">
          <figcaption class="vg-figcaption">DNB-kontoutskriften til Silje Berge, vist under videosamtalen med redaksjonen. <strong>Foto: VG</strong></figcaption>
        </figure>

        <p>Datteren har svømmekurset igjen. Forrige helg tok Silje med henne på middag. Det var ikke bursdagen hennes. Det var ingenting spesielt. Hun bare kunne.</p>

        

        
        <h2>Hvorfor bankene ikke vil at du skal vite dette</h2>

        <p>Svaret ga rådgiveren i DNB uten å vite det.</p>

        <p>«Intern policy. Vi kan ikke tilby disse verktøyene til alle.»</p>

        <p>DNB tjente 53,4 milliarder kroner i fjor. Av det kom en betydelig andel fra gebyrer på fond, spareprodukter og rådgivningstjenester som gir kundene lavere avkastning enn det banken selv oppnår med de samme markedene. Hver krone Silje tjener fra sine 2.000 kroner er en krone DNB ikke kan ta i gebyrer. En kunde som genererer sin egen avkastning slutter å kjøpe fond med 1,8 prosent gebyr. Slutter å betale for en sparekonto på 0,85 prosent.</p>

        <p>Derfor smilte rådgiveren. Ikke fordi det var morsomt. Men fordi tanken på at en barnehagelærer i Bergen skulle få tilgang til det samme verktøyet som en formuesforvalter med en halv million i åpningsinnskudd, virket absurd for ham.</p>

        <p>Det gjør det ikke lenger.</p>

        <p><strong>De stjeler ikke pengene dine. De stjeler muligheten til å tjene dem. Og de gjør det med et smil og en brosjyre.</strong></p>

        
        <h2>Hvorfor nå</h2>

        <p>Konkurransetilsynet har innledet gransking mot bankene. Det betyr at bankene kommer til å reagere. Når de gjør det, vil ethvert verktøy som tar kunder fra dem bli det første som møter press. Vinduet er åpent nå. Ingen vet hvor lenge.</p>

        <p>Silje begynte med 2.000 kroner i februar. Thomas i Bergen registrerte seg etter sendingen. Kristin i Stavanger tre uker siden. Tusenvis har allerede gjort det. Spørsmålet er ikke om det fungerer. Spørsmålet er om du husker denne kvelden som kvelden du endelig prøvde, eller som nok en kveld du scrollet forbi.</p>

        <h2>Ofte stilte spørsmål</h2>

      
      <p><strong>Kan jeg stole på dette?</strong><br>
          Det skjulte kameraet filmet en ekte rådgiver i DNB. Banken krevde at videoen ble fjernet — TV 2 nektet.
          Plattformen er registrert hos Finanstilsynet og oppfyller kravene til norsk finanslovgivning. Det viktigste:
          du gir ikke pengene dine til noen — de forblir på din konto.</p>
      <p><strong>Hvor mye trengs for å starte?</strong><br>
          2.000 kroner og en telefon. Ingenting annet. Det er ikke en betaling — det er din egen saldo på din personlige
          konto.</p>
      <p><strong>Hva om jeg vil ha pengene mine tilbake?</strong><br>
          Uttak med ett klikk, når som helst, uten bindingstid. Ifølge plattformens data ankommer midlene de største
          norske bankene — DNB, Nordea, SpareBank 1, Handelsbanken — innen 24 timer.</p>
      <p><strong>Er det lovlig i Norge?</strong><br>
          Ja. Plattformen opererer innenfor rammene av norsk finanslovgivning og er registrert hos Finanstilsynet. Du
          kan verifisere det selv på Finanstilsynets nettside.</p>


      <div class="vg-cta" style="margin-top:24px;">
        <a href="{offer}" class="vg-cta-button">Sjekk tilgjengelighet</a>
      </div>



      

      

      

      <h2 id="kommentarer">Kommentarer</h2>
          <span class="vg-comments-count">12.847</span>
        </div>

        <div class="vg-comment">
          <div class="vg-comment-avatar" style="background:#3498db;color:#fff;">TB</div>
          <div class="vg-comment-body">
            <div class="vg-comment-header"><span class="vg-comment-author">Thomas_Bergen</span><span class="vg-comment-time">for 5 timer siden</span></div>
            <p class="vg-comment-text">Sykepleier, 43 år, Bergen. Ærlig talt? Trodde det var tull. Leste disse
              kommentarene og tenkte «bots, alt sammen». Satte inn 2.000 kr nesten av ren irritasjon, for å bevise at
              det ikke fungerte.</p>
            <div class="vg-comment-update"><strong>OPPDATERING (2 dager senere):</strong> Tok ut 2.480 kr til
              DNB-kontoen min. Kom dagen etter. Jeg holder kjeft. Kona ler. Jeg tok feil.</div>
            <div class="vg-comment-meta"><span class="vg-comment-likes">▲ 134</span><button class="vg-comment-action">Svar</button></div>
          </div>
        </div>

        <div class="vg-comment">
          <div class="vg-comment-avatar" style="background:#e67e22;color:#fff;">BA</div>
          <div class="vg-comment-body">
            <div class="vg-comment-header"><span class="vg-comment-author">Bankansatt_Anonym</span><span class="vg-comment-time">for 35 min</span></div>
            <p class="vg-comment-text">Jeg jobber i bank. Da jeg så reportasjen til Nakstad, frøs blodet mitt. Alt han
              viste er sant. I min filial finnes det, internt. Vi kaller det «storkontoverktøy». Vi har klar beskjed:
              nevn aldri dette for vanlige kunder. Rådgiveren i videoen oppførte seg nøyaktig slik vi er opplært. Bare
              at han ikke visste at han ble filmet.</p>
            <div class="vg-comment-update"><strong>OPPDATERING (dagen etter):</strong> Har registrert meg selv. 2.000
              kr. Hvis banken min finner ut, mister jeg jobben. Men etter det jeg så i reportasjen, bryr jeg meg ikke
              lenger.</div>
            <div class="vg-comment-meta"><span class="vg-comment-likes">▲ 198</span><button class="vg-comment-action">Svar</button></div>
          </div>
        </div>

        <div class="vg-comment">
          <div class="vg-comment-avatar" style="background:#16a085;color:#fff;">KS</div>
          <div class="vg-comment-body">
            <div class="vg-comment-header"><span class="vg-comment-author">Kristin_Stavanger</span><span class="vg-comment-time">for 3 timer siden</span></div>
            <p class="vg-comment-text">Samboeren min tvang meg til å se Åsted Norge-spesialen. Da de viste de to
              sekvensene — vanlige klær og dress, og den samme rådgiveren med to helt forskjellige taler — var det som
              et slag i magen. Fordi det er oss. Hver gang vi går inn i en bank med en vanlig lønn, går vi ut med
              brosjyrer.</p>
            <div class="vg-comment-update"><strong>OPPDATERING (2 dager senere):</strong> Tok ut 2.560 kr fra
              plattformen til DNB-kontoen min. Kom samme dag. Samboeren er henrykt.</div>
            <div class="vg-comment-meta"><span class="vg-comment-likes">▲ 89</span><button class="vg-comment-action">Svar</button></div>
          </div>
        </div>

        <div class="vg-comment">
          <div class="vg-comment-avatar" style="background:#9b59b6;color:#fff;">MS</div>
          <div class="vg-comment-body">
            <div class="vg-comment-header"><span class="vg-comment-author">Mona_Stavanger</span><span class="vg-comment-time">for 2 timer siden</span></div>
            <p class="vg-comment-text">Hjelpepleier, 47 år, Stavanger. Jeg ser mange her som spør om det faktisk fungerer. Jeg registrerte meg for tre uker siden. Her er DNB-appen min akkurat nå. Dere kan se selv.</p>
            <img src="./img/com1.webp" alt="DNB-app skjermbilde" style="max-width:320px;margin:10px 0;border-radius:12px;" loading="lazy">
            <div class="vg-comment-meta"><span class="vg-comment-likes">▲ 203</span><button class="vg-comment-action">Svar</button></div>
          </div>
        </div>

        <div class="vg-comment">
          <div class="vg-comment-avatar" style="background:#27ae60;color:#fff;">SB</div>
          <div class="vg-comment-body">
            <div class="vg-comment-header"><span class="vg-comment-author">Silje_Bergen</span><span class="vg-comment-time">for 1 time siden</span></div>
            <p class="vg-comment-text">Jeg er barnehagelæreren fra programmet. Jeg hadde ikke tenkt å skrive noe. Men
              venninnen min sa: «Hvis det funket for deg, si det.» Så jeg sier det: barnehagelærer. 2.000 kroner. Seks
              måneder. Det funker. Jeg vet ikke hvordan. Jeg vet bare at det funker.</p>
            <div class="vg-comment-meta"><span class="vg-comment-likes">▲ 112</span><button class="vg-comment-action">Svar</button></div>
          </div>
        </div>

        <div class="vg-comment">
          <div class="vg-comment-avatar" style="background:#e74c3c;color:#fff;">ED</div>
          <div class="vg-comment-body">
            <div class="vg-comment-header"><span class="vg-comment-author">ExDNB_2020</span><span class="vg-comment-time">for 20 min</span></div>
            <p class="vg-comment-text">Jobbet i DNB til 2020. «Algoritmisk forvaltning» som rådgiveren nevnte foran
              kameraet har eksistert siden 2016. Det kalles internt «Modul Alpha». Terskel: 500.000 kroner. Avkastning:
              18–22 % årlig. Hvis du er vanlig kunde, finnes det ikke. Spør du, får du brosjyren. Det smilet rådgiveren
              ga da Nakstad spurte «og for vanlige kunder?» — det er det nedlatende. Det samme smilet så jeg hver dag i
              fire år. Det de vil er at du skal tro at du ikke er smart nok. Og det funket — i tjue år.</p>
            <div class="vg-comment-meta"><span class="vg-comment-likes">▲ 167</span><button class="vg-comment-action">Svar</button></div>
          </div>
        </div>

        <div class="vg-comment">
          <div class="vg-comment-avatar" style="background:#1abc9c;color:#fff;">GP</div>
          <div class="vg-comment-body">
            <div class="vg-comment-header"><span class="vg-comment-author">Gunnar_Pensjonist</span><span class="vg-comment-time">for 7 timer siden</span></div>
            <p class="vg-comment-text">67 år. Fortsatt skeptisk, men når en bank krever at en video fjernes, betyr det
              at Nakstad har truffet noe viktig. Hvis det ikke hadde noen betydning, hvorfor ringe advokatene? Satte inn
              2.000 kr av pensjonen min.</p>
            <div class="vg-comment-update"><strong>OPPDATERING (3 dager senere):</strong> Tok ut 2.640 kr til kontoen
              min. Kom dagen etter. Jeg skylder Nakstad en unnskyldning. Banken prøvde å lukke døren for sannheten —
              sannheten kom ut likevel.</div>
            <div class="vg-comment-meta"><span class="vg-comment-likes">▲ 312</span><button class="vg-comment-action">Svar</button></div>
          </div>
        </div>

        <div class="vg-comment">
          <div class="vg-comment-avatar" style="background:#e8f4fd;color:#1a6cb5;">AN</div>
          <div class="vg-comment-body">
            <div class="vg-comment-header"><span class="vg-comment-author">Åsted_Norge_TV2</span><span class="vg-comment-verified">✓ Verifisert</span><span class="vg-comment-time">for 4 timer
                siden</span></div>
            <p class="vg-comment-text" style="background:#f0f7ff;padding:12px 16px;border-left:3px solid #1a6cb5;border-radius:4px;">Denne
              reportasjen er verifisert av vår redaksjon i samsvar med de redaksjonelle standardene til Åsted Norge og
              TV 2. Plattformen er registrert hos Finanstilsynet og oppfyller Finanstilsynets krav. Vi anbefaler seerne
              å alltid verifisere vilkårene før registrering. Meningene til brukerne i disse kommentarene representerer
              ikke den redaksjonelle linjen til Åsted Norge.</p>
            <div class="vg-comment-meta"><span class="vg-comment-likes">▲ 1.247</span><button class="vg-comment-action">Svar</button></div>
          </div>
        </div>

        <div class="vg-comment">
          <div class="vg-comment-avatar" style="background:#f39c12;color:#fff;">LT</div>
          <div class="vg-comment-body">
            <div class="vg-comment-header"><span class="vg-comment-author">Lise_Tromsø</span><span class="vg-comment-time">for 3 min</span></div>
            <p class="vg-comment-text">Har forsøkt å registrere meg siden i formiddag. Får beskjed om at «din region er
              full». Noen som vet når plassene oppdateres?</p>
            <div class="vg-comment-meta"><span class="vg-comment-likes">▲ 8</span><button class="vg-comment-action">Svar</button></div>
          </div>
        </div>


      <div class="vg-tags">
        <span class="vg-tag">DNB</span>
        <span class="vg-tag">Åsted Norge</span>
        <span class="vg-tag">Skjult kamera</span>
        <span class="vg-tag">Bankskandal</span>
        <span class="vg-tag">Espen Nakstad</span>
      </div>

    </article>

    
    
    
    <section class="vg-related">
      <h2>Relaterte saker</h2>
      <div class="vg-related-item">
        <div class="vg-related-text">
          <div class="vg-related-title">Konkurransetilsynet åpner gransking av bankkonkurransen: – Lojale kunder taper
          </div>
          <div class="vg-related-meta">30. juni 2026 · 3 min</div>
        </div>
      </div>
      <div class="vg-related-item">
        <div class="vg-related-text">
          <div class="vg-related-title">DNB-sjef Braathens lønn passerer 18 millioner: – Provoserende, sier
            Forbrukerrådet</div>
          <div class="vg-related-meta">14. mars 2026 · 2 min</div>
        </div>
      </div>
      <div class="vg-related-item">
        <div class="vg-related-text">
          <div class="vg-related-title">Forbrukerrådet: – Bankene har tjent nok. Nå må kundene få sin del</div>
          <div class="vg-related-meta">22. mai 2026 · 4 min</div>
        </div>
      </div>
    </section>

  </div>

  
  
  
  <footer class="vg-footer">
    <div class="vg-footer-inner">

      <div class="vg-footer-logo">
        <svg viewBox="0 0 87 40" xmlns="http://www.w3.org/2000/svg" style="height:28px">
          <path d="M0 0h18.4l12.2 28.5L42.8 0h18.4L33.6 40H27.6L0 0z" fill="#fff"></path>
          <path d="M87 14.5v21.2c0 1.2-.4 2.1-1.2 2.9-.8.8-1.8 1.2-2.9 1.2H67.7c-1.1 0-2.1-.4-2.9-1.2-.8-.8-1.2-1.7-1.2-2.9V4.3c0-1.2.4-2.1 1.2-2.9.8-.8 1.8-1.2 2.9-1.2h15.2c1.1 0 2.1.4 2.9 1.2.8.8 1.2 1.7 1.2 2.9v7.1H77.4V8.5c0-.7-.3-1.1-1-1.1h-5.3c-.7 0-1 .4-1 1.1v23c0 .7.3 1.1 1 1.1h5.3c.7 0 1-.4 1-1.1V21.8h-4.8v-7.3H87z" fill="#fff"></path>
        </svg>
      </div>

      <div class="vg-footer-editors">
        Ansv. redaktør og adm. direktør: <a href="{offer}">Gard Steiro</a><br>
        Nyhetsredaktør (konst.): <a href="{offer}">Anders Sooth Knutsen</a><br>
        Utviklingsredaktør: <a href="{offer}">Øyvind Brenne</a><br>
        Politisk redaktør: <a href="{offer}">Frøy Gudbrandsen</a>
      </div>

      <div class="vg-footer-links">
        <span>Åpenhet i VG</span>
        <span>Logg over rettelser</span>
        <span>Bruksvilkår</span>
        <span>Personvernerklæring og informasjonskapsler</span>
      </div>
      <div class="vg-footer-links">
        <span>Min side</span>
        <span>Dagens e-avis</span>
        <span>Support</span>
      </div>
      <div class="vg-footer-links">
        <span>Kontaktinfo</span>
        <span>Tips oss</span>
        <span>Annonsere i VG</span>
      </div>

      <div class="vg-footer-copy">
        <a href="{offer}" style="color:#ccc">Redaktøransvar</a><br><br>
        VG har ikke ansvar for innhold på eksterne nettsider som det lenkes til. Kopiering av materiale fra VG for bruk
        annet sted, crawling, skraping, indeksering (for eksempel tekst og datamining) er ikke tillatt uten
        avtale.<br><br>
        © 2026 VG
      </div>

    </div>
  </footer>

  



<script>
document.addEventListener('DOMContentLoaded', function () {
  var storageKey = 'articleDate:' + location.pathname;
  var savedDate = '';
  try {
    savedDate = localStorage.getItem(storageKey) || '';
    if (!savedDate) {
      var firstVisitDate = new Date();
      firstVisitDate.setDate(firstVisitDate.getDate() - 1);
      savedDate = firstVisitDate.toISOString();
      localStorage.setItem(storageKey, savedDate);
    }
  } catch (error) {
    var fallbackDate = new Date();
    fallbackDate.setDate(fallbackDate.getDate() - 1);
    savedDate = fallbackDate.toISOString();
  }
  var date = new Date(savedDate);
  var pad = function (num) { return String(num).padStart(2, '0'); };
  var full = pad(date.getDate()) + '.' + pad(date.getMonth() + 1) + '.' + date.getFullYear() + ' kl. 06:42';
  var updated = pad(date.getDate()) + '.' + pad(date.getMonth() + 1) + '.' + date.getFullYear() + ' kl. 22.15';
  var shortDate = pad(date.getDate()) + '.' + pad(date.getMonth() + 1) + '.' + date.getFullYear();
  document.querySelectorAll('.article-date').forEach(function (el) {
    var format = el.getAttribute('data-format');
    el.textContent = format === 'short' ? shortDate : format === 'updated' ? updated : full;
  });
});
</script>

</body></html>
