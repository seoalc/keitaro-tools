<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!doctype html>
<html lang="no"><head>
<meta charset="UTF-8">


<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Publikum reiste seg i 58 sekunder: Slik sa Øystein Stray Spetalen det vanlige nordmenn har tenkt i årevis – rett i ansiktet på sentralbanksjefen</title>
<style>/* ============================================
   CSS VARIABLES — цветовая палитра NRK
   Все цвета взяты с оригинального nrk.no
   и вынесены в переменные для единообразия.
   ============================================ */
:root {
  --nrk-blue: #001a3a;        /* тёмно-синий navy — заголовки статьи, footer bottom, article-title */
  --nrk-link: #0059b3;        /* ссылки, кнопки "Mer om", вопросы журналиста, section-line */
  --nrk-text: #1b1b1b;        /* основной текст — почти чёрный, мягче чем #000 */
  --nrk-gray: #666;           /* вторичный текст — авторы, даты, подписи ролей */
  --nrk-light: #f6f6f6;       /* светлый фон (запасной, не используется активно) */
  --nrk-caption: #6b6b6b;     /* подписи к фото и кредиты фотографов */
  --nrk-border: #d9d9d9;      /* тонкие разделители, рамки кнопок */
  --nrk-footer-bg: #e8eff5;   /* голубоватый фон футера и info-box */
  --nrk-footer-dark: #001a3a; /* тёмный подвал (совпадает с --nrk-blue) */
}

/* ============================================
   RESET & BASE — сброс стилей и базовая типографика
   Шрифт: Source Sans 3 (Google Fonts) — NRK использует
   его как основной sans-serif шрифт для UI и текста.
   Source Serif 4 используется для заголовков (подключен,
   но применяется через отдельные классы ниже).
   ============================================ */
* { margin: 0; padding: 0; box-sizing: border-box; }  /* универсальный сброс */
body {
  font-family: 'Source Sans 3', Helvetica, Arial, sans-serif; /* основной шрифт */
  color: var(--nrk-text);    /* почти чёрный #1b1b1b */
  background: #fff;          /* белый фон страницы */
  line-height: 1.6;          /* комфортный межстрочный интервал */
  -webkit-font-smoothing: antialiased;  /* сглаживание шрифтов на macOS/iOS */
}
a { color: var(--nrk-link); text-decoration: none; }  /* синие ссылки без подчёркивания */
a:hover { text-decoration: underline; }               /* подчёркивание при наведении */

/* ============================================
   TOP BAR — самая верхняя тёмная полоска
   Содержит ссылки на другие сервисы NRK:
   NRK TV, NRK Radio, NRK Super, NRK P3, Yr.
   Ссылки выравнены вправо (justify-content: flex-end).
   Высота 30px, фон #0a1628 (очень тёмный navy,
   темнее основного --nrk-blue).
   Скрывается на мобиле (display: none в @media 768px).
   ============================================ */
.topbar {
  background: #0a1628;  /* тёмный navy — верхний уровень хедера */
  color: #fff;
  font-size: 13px;      /* мелкий текст для вспомогательных ссылок */
  letter-spacing: .3px;  /* слегка разрежён для читаемости */
}
.topbar-inner {
  max-width: 1280px;    /* контейнер сайта — 1280px max */
  margin: 0 auto;       /* центрирование */
  padding: 0 24px;      /* боковые отступы */
  display: flex;
  justify-content: flex-end;  /* ссылки прижаты вправо */
  align-items: center;
  height: 30px;         /* компактная высота */
  gap: 28px;            /* расстояние между ссылками */
}
.topbar a {
  color: rgba(255,255,255,.75);  /* полупрозрачный белый — приглушённые ссылки */
  text-decoration: none;
  font-size: 13px;
  font-weight: 400;
}
.topbar a:hover {
  color: #fff;  /* при наведении — полностью белые */
  text-decoration: none;  /* без подчёркивания (отличие от обычных ссылок) */
}

/* ============================================
   MAIN HEADER — основной синий хедер
   Яркий синий #1767ce — фирменный цвет NRK.
   Содержит: логотип NRK (SVG) + навигацию + Logg på + Søk.
   Высота 48px. На мобиле навигация скрывается,
   появляется бургер-меню.
   ============================================ */
.header {
  background: #1767ce;   /* яркий фирменный синий NRK — второй уровень хедера */
  border-bottom: none;   /* без нижней границы */
}
.header-inner {
  max-width: 1280px;     /* тот же контейнер что и везде */
  margin: 0 auto;
  padding: 0 24px;
  display: flex;
  align-items: center;
  height: 48px;          /* чуть выше top bar */
  gap: 28px;             /* расстояние между логотипом и навигацией */
}

/* Логотип NRK — инлайн SVG, белый, 60x24px.
   Путь скопирован с оригинального сайта NRK. */
.nrk-logo { display: flex; align-items: center; text-decoration: none; flex-shrink: 0; color: #fff; }
.nrk-logo:hover { text-decoration: none; opacity: .9; }  /* лёгкое затухание при наведении */

/* Горизонтальная навигация: Nyheter | Sport | Kultur | Humor | Distrikt | Mer ▼
   Активный пункт (class="active") подчёркнут белой линией снизу.
   На мобиле вся навигация скрывается (display: none). */
.main-nav { display: flex; gap: 6px; align-items: center; }
.main-nav a {
  color: #fff;
  font-size: 15px;
  font-weight: 600;                    /* semi-bold для навигации */
  text-decoration: none;
  padding: 12px 12px;                  /* вертикальный padding создаёт кликабельную зону */
  border-bottom: 3px solid transparent;  /* подготовка для белой линии у active */
}
.main-nav a:hover {
  background: rgba(255,255,255,.1);    /* лёгкая белая подсветка при hover */
  text-decoration: none;
  border-bottom-color: transparent;
}
.main-nav a.active {
  border-bottom-color: #fff;  /* белая линия 3px под активным разделом (Sport) */
}

/* Кнопка "Mer ▼" — раскрывает дополнительные разделы (не реализовано) */
.main-nav .more-btn { position: relative; cursor: pointer; color: rgba(255,255,255,.85); }
.main-nav .more-btn svg { width: 12px; height: 12px; margin-left: 2px; vertical-align: middle; }  /* стрелка вниз */

/* Правая часть хедера: Logg på + Søk + бургер-меню
   margin-left: auto прижимает эту группу вправо (flexbox trick). */
.header-right { margin-left: auto; display: flex; align-items: center; gap: 16px; }

/* Кнопка "Logg på" — иконка пользователя (SVG круг) + текст.
   Полупрозрачный белый цвет, при hover становится полностью белым. */
.login-btn { display: flex; align-items: center; gap: 6px; color: rgba(255,255,255,.9); font-size: 14px; font-weight: 600; text-decoration: none; cursor: pointer; }
.login-btn:hover { text-decoration: none; color: #fff; }
.login-btn svg { width: 20px; height: 20px; stroke: rgba(255,255,255,.9); }

/* Поле поиска "Søk" — белый прямоугольник с иконкой лупы.
   На десктопе видимо, на мобиле скрыто (display: none).
   min-width: 130px чтобы не схлопывалось. */
.search-box {
  display: flex; align-items: center;
  border: none;
  border-radius: 4px;         /* слегка скруглённые углы */
  padding: 6px 14px;
  gap: 6px;
  font-size: 14px;
  color: #666;                /* серый placeholder-текст */
  cursor: text;               /* курсор как для текстового поля */
  min-width: 130px;
  background: #fff;           /* белый фон контрастирует с синим хедером */
}
.search-box svg { width: 16px; height: 16px; stroke: #666; fill: none; stroke-width: 2; }  /* иконка лупы */

/* Бургер-меню ☰ — 3 горизонтальные линии.
   Скрыт на десктопе (display: none), показывается на мобиле (768px). */
.burger-menu { display: none; }

/* ============================================
   SUB NAV — белая подполоска раздела
   Показывает текущий раздел ("Nordland" жирным)
   и ссылки: Nyhetssenter, Mobilvideo, Snakk med oss...
   Разделена тонкой линией снизу (#e5e5e5).
   На мобиле — горизонтальный скролл с nowrap.
   ============================================ */
.subnav { border-bottom: 1px solid #e5e5e5; }  /* тонкая серая линия под подменю */
.subnav-inner {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 24px;
  display: flex;
  align-items: center;
  height: 40px;       /* компактная высота */
  gap: 20px;          /* расстояние между ссылками */
}
.subnav-title {
  font-size: 16px;
  font-weight: 700;   /* жирный — выделяет текущий раздел "Nordland" */
  color: var(--nrk-text);
}
.subnav a {
  color: var(--nrk-gray);  /* серые ссылки — менее важные чем основная навигация */
  font-size: 14px;
  text-decoration: none;
}
.subnav a:hover { color: var(--nrk-text); text-decoration: none; }  /* при hover темнеют */

/* ============================================
   ARTICLE HEADER — верхняя часть статьи
   CSS Grid с двумя колонками:
     - Левая: заголовок (h1) + лид (p) + hero-фото
     - Правая: авторы + дата (280px фиксированная)
   gap: 40px — расстояние между колонками.
   На планшете (≤1024px) — одна колонка.
   ============================================ */
.article-header {
  max-width: 1280px;
  margin: 0 auto;
  padding: 40px 24px 0;  /* 40px сверху, без нижнего отступа */
  display: grid;
  grid-template-columns: 1fr 280px;  /* гибкая + фиксированная 280px */
  gap: 40px;
}

/* Заголовок статьи — крупный serif, тёмно-синий.
   font-weight: 900 (Black) — максимально жирный.
   letter-spacing: -.5px — сжатый трекинг для крупного шрифта.
   Цвет: --nrk-blue (#001a3a) — тёмный navy, не чёрный. */
.article-title {
  font-family: 'Source Serif 4', Georgia, serif;  /* serif для заголовков */
  font-size: 46px;
  font-weight: 900;
  line-height: 1.15;       /* плотный межстрочный для заголовка */
  color: var(--nrk-blue);
  margin-bottom: 16px;
  letter-spacing: -.5px;
}

/* Лид (вводный абзац) — чуть крупнее основного текста,
   серее чем body text (#333 vs #1b1b1b). */
.article-lead {
  font-size: 20px;
  line-height: 1.5;
  color: #333;             /* мягче чем основной текст */
  margin-bottom: 24px;
}

/* Hero-фото — основное изображение статьи.
   На мобиле растягивается edge-to-edge (отрицательные margin). */
.article-hero { margin-bottom: 6px; }
.article-hero img { width: 100%; height: auto; display: block; }

/* Подпись к фото — серый мелкий текст */
.caption {
  font-size: 14px;
  color: var(--nrk-caption);  /* #6b6b6b — между серым и тёмным */
  line-height: 1.5;
  margin-top: 6px;
}

/* Кредит фотографа — ещё мельче, UPPERCASE.
   Формат: "FOTO: ИМЯ ФАМИЛИЯ / NRK" */
.credit {
  font-size: 11px;
  color: var(--nrk-caption);
  text-transform: uppercase;
  letter-spacing: .5px;      /* разрежённые заглавные */
  margin-top: 2px;
}

/* ============================================
   AUTHOR SIDEBAR — блок авторов (правая колонка)
   Показывает журналистов: имя (ссылка) + роль.
   padding-top: 80px отодвигает вниз, чтобы авторы
   были на уровне hero-фото, а не заголовка.
   На планшете — горизонтальный ряд (flex-wrap).
   На мобиле — вертикальный список.
   ============================================ */
.author-sidebar { padding-top: 220px; }  /* визуальное выравнивание с hero-фото */
.author-item { margin-bottom: 12px; }
.author-item a {
  font-size: 14px;
  font-weight: 600;
  color: var(--nrk-link);      /* синяя ссылка — имя автора */
  text-decoration: underline;  /* всегда подчёркнуто (не только при hover) */
}
.author-item .role { font-size: 13px; color: var(--nrk-gray); }  /* "Journalist" — серый */

/* Мета-информация: локация ("Vi rapporterer fra Bodø/Aspmyra")
   + даты публикации/обновления. */
.author-meta { margin-top: 20px; font-size: 13px; color: var(--nrk-gray); line-height: 1.6; }
.author-meta .loc { margin-bottom: 12px; }
.author-meta .dates span { display: block; }  /* каждая дата на отдельной строке */

/* ============================================
   ARTICLE BODY — основной текст статьи
   Та же 2-колоночная сетка (контент + сайдбар).
   Контент ограничен max-width: 640px — оптимальная
   ширина для чтения длинного текста (65-75 символов в строке).
   ============================================ */
.article-wrap {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 24px;
  display: grid;
  grid-template-columns: 1fr 280px;  /* повторяет сетку article-header */
  gap: 40px;
}

.article-body {
  max-width: 640px;   /* оптимальная ширина для чтения */
  padding: 40px 0 32px;
}

/* Параграфы — 18px, line-height 1.72 для комфортного чтения.
   На мобиле уменьшается до 17px. */
.article-body p { font-size: 18px; line-height: 1.72; margin-bottom: 24px; color: #1b1b1b; }

/* Жирные цитаты (.bold-quote) — выделенные прямые речи.
   Пример: «– Inter er i en tøff periode...» */
.article-body p.bold-quote { font-weight: 700; }

/* Курсивные вопросы журналиста (.italic-q) — синий цвет + italic.
   Пример: «– Hvor mye er dere forberedt?» */
.article-body p.italic-q { font-style: italic; color: var(--nrk-link); }

/* Подзаголовки h2 — serif, крупные, тёмно-синие.
   Используются для разделения длинного текста на смысловые блоки. */
.article-body h2 {
  font-family: 'Source Serif 4', Georgia, serif;
  font-size: 28px;
  font-weight: 900;
  margin: 36px 0 16px;      /* больше отступ сверху чем снизу */
  color: var(--nrk-blue);
  line-height: 1.2;
}

/* Фотографии внутри статьи — полная ширина, вертикальные отступы */
.article-body figure { margin: 32px 0; }
.article-body figure img { width: 100%; height: auto; display: block; }

/* Ссылки в тексте — синие, всегда подчёркнуты */
.article-body a { color: var(--nrk-link); text-decoration: underline; }

/* ============================================
   INFO BOX — информационный блок с голубым фоном
   Используется для структурированных данных —
   здесь: список матчей Интера.
   Фон #e8eff5 совпадает с футером — фирменный
   голубоватый оттенок NRK.
   border-radius: 8px — слегка скруглённые углы.
   Кнопка "Vis mer" раскрывает доп. контент (onclick JS).
   ============================================ */
.info-box {
  background: #e8eff5;     /* голубоватый фон — тот же что footer */
  border-radius: 8px;
  padding: 24px 28px 20px;
  margin: 32px 0;
}
.info-box h3 { font-family: 'Source Serif 4', Georgia, serif; font-size: 22px; font-weight: 900; margin-bottom: 4px; color: var(--nrk-text); }  /* заголовок бокса */
.info-box p { font-size: 16px; font-weight: 700; margin-bottom: 6px; color: var(--nrk-text); }  /* подзаголовок ("Desember 2025") */
.info-box .ib-line { font-size: 15px; color: var(--nrk-text); margin-bottom: 12px; }  /* строка с результатом матча */

/* Кнопка "Vis mer" — pill-shape (border-radius: 24px).
   Белый фон + серая рамка — паттерн NRK для всех кнопок. */
.vis-mer {
  display: inline-block;
  border: 1.5px solid var(--nrk-border);
  border-radius: 24px;     /* pill-shape — фирменный стиль NRK кнопок */
  padding: 8px 28px;
  font-size: 14px;
  color: var(--nrk-text);
  cursor: pointer;
  background: #fff;
  margin-top: 4px;
}
.vis-mer:hover { background: #f0f0f0; }  /* лёгкое затемнение при hover */

/* ============================================
   RIGHT SIDEBAR — карточки связанных статей
   Находится справа от основного текста (280px колонка).
   Содержит: фото + заголовок-ссылка для каждой карточки.
   Между группами — ссылка "Mer om: Nordland →".
   Скрывается на планшете (≤1024px, display: none).
   ============================================ */
.right-sidebar { padding-top: 40px; }   /* отступ от верха, чтобы начиналось ниже hero */

/* Карточка: фото сверху + serif заголовок снизу */
.sidebar-card { margin-bottom: 28px; padding-bottom: 20px; }
.sidebar-card img { width: 100%; height: auto; display: block; margin-bottom: 10px; }
.sidebar-card h3 {
  font-family: 'Source Serif 4', Georgia, serif;  /* serif для заголовков карточек */
  font-size: 17px;
  font-weight: 900;
  line-height: 1.3;
  color: var(--nrk-text);
}
.sidebar-card h3 a { color: var(--nrk-text); text-decoration: none; }  /* тёмные заголовки, не синие */
.sidebar-card h3 a:hover { text-decoration: underline; }

/* Ссылка-разделитель: "Mer om: Nordland ⟶" / "Sport ⟶" */
.sidebar-more {
  font-size: 14px;
  color: var(--nrk-gray);
  padding-bottom: 20px;
  border-bottom: 1px solid var(--nrk-border);  /* серая линия-разделитель */
  margin-bottom: 24px;
}
.sidebar-more a { color: var(--nrk-link); font-weight: 600; text-decoration: none; }
.sidebar-more a:hover { text-decoration: underline; }
.sidebar-more .arrow { margin-left: 4px; }  /* стрелка → после названия раздела */

/* ============================================
   PROMO BANNER — "Logg deg på distriktet ditt"
   ============================================ */
.promo-banner { margin: 40px 0; border-radius: 8px; overflow: hidden; height: 160px; background: linear-gradient(135deg, #d4e5f7, #a8c9e8); display: flex; align-items: center; padding: 0 40px; }
.promo-banner .pb-text { font-size: 24px; font-weight: 900; color: var(--nrk-blue); line-height: 1.3; max-width: 280px; }
.promo-banner .pb-sub { font-size: 16px; font-weight: 400; color: var(--nrk-text); margin-top: 4px; }

/* ============================================
   EXPERT CARD — карточки экспертов
   Круглые аватары + текст справа.
   ============================================ */
.expert-card {
  display: flex;
  align-items: flex-start;
  gap: 20px;
  background: #f7f9fb;
  border: 1px solid #e8ecf0;
  border-radius: 10px;
  padding: 24px;
  margin-bottom: 20px;
}
.expert-avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  object-fit: cover;
  flex-shrink: 0;
  border: 3px solid var(--nrk-border);
}
.expert-info {
  flex: 1;
}
.expert-info h4 {
  font-family: 'Source Serif 4', Georgia, serif;
  font-size: 18px;
  font-weight: 900;
  color: var(--nrk-blue);
  margin-bottom: 2px;
}
.expert-info span {
  display: block;
  font-size: 13px;
  color: var(--nrk-gray);
  margin-bottom: 10px;
}
.expert-info p {
  font-size: 16px;
  line-height: 1.6;
  color: var(--nrk-text);
  margin-bottom: 0;
}

/* ============================================
   DATES BOTTOM — дата публикации (низ статьи)
   ============================================ */
.dates-bottom { max-width: 640px; padding: 24px 0; font-size: 14px; color: var(--nrk-gray); display: flex; gap: 16px; align-items: center; }
.dates-bottom .sep { color: var(--nrk-border); }

/* ============================================
   SISTE FRA NORDLAND — последние новости региона
   Полноширинная секция под статьёй.
   Структура: заголовок CAPS + синяя линия 3px + сетка 3x1.
   Каждая карточка: фото (aspect-ratio 16:10) + serif заголовок.
   Кнопка "+ Vis flere" — pill-shape, центрирована.
   На мобиле → одна колонка.
   ============================================ */
.section-full { max-width: 1280px; margin: 0 auto; padding: 0 24px 48px; }

/* Заголовок секции: "SISTE FRA NORDLAND ✦"
   CAPS + letter-spacing + звёздочка (✦) синего цвета. */
.section-header {
  display: flex; align-items: center; gap: 8px;
  margin-bottom: 4px;
  font-size: 14px; font-weight: 700;
  text-transform: uppercase;
  color: var(--nrk-text);
  letter-spacing: .5px;
}
.section-header .plus { color: var(--nrk-link); font-size: 18px; }  /* синяя звёздочка ✦ */

/* Синяя линия-разделитель 3px — визуально отделяет заголовок от карточек */
.section-line { height: 3px; background: var(--nrk-link); margin-bottom: 24px; }

/* Сетка карточек: 3 равные колонки, gap 24px */
.card-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; }
.card-item img {
  width: 100%; height: auto;
  aspect-ratio: 16/10;      /* фиксированные пропорции фото */
  object-fit: cover;         /* обрезка по центру если пропорции не совпадают */
  display: block;
  margin-bottom: 12px;
}
.card-item h3 {
  font-family: 'Source Serif 4', Georgia, serif;
  font-size: 20px; font-weight: 900; line-height: 1.3; color: var(--nrk-text);
}
.card-item h3 a { color: var(--nrk-text); text-decoration: none; }
.card-item h3 a:hover { text-decoration: underline; }

/* Кнопка "+ Vis flere" — pill-shape, центрирована */
.vis-flere-wrap { text-align: center; margin-top: 32px; }
.vis-flere-btn {
  display: inline-flex; align-items: center; gap: 6px;
  border: 1.5px solid var(--nrk-border);
  border-radius: 28px;      /* pill-shape */
  padding: 12px 36px;
  font-size: 15px;
  color: var(--nrk-text);
  background: #fff;
  cursor: pointer;
}
.vis-flere-btn:hover { background: #f5f5f5; }

/* ============================================
   NRK ANBEFALER — рекомендации (2 больших + 3 маленьких)
   ============================================ */
.anbefaler { max-width: 1280px; margin: 0 auto; padding: 0 24px 60px; }
.anbef-grid { display: grid; grid-template-columns: 1.3fr 1fr; gap: 16px; margin-bottom: 32px; }
.anbef-big { position: relative; }
.anbef-big img { width: 100%; height: auto; display: block; }
.anbef-big .anbef-overlay { padding: 16px 20px; }
.anbef-big .anbef-kicker { font-size: 14px; color: var(--nrk-gray); margin-bottom: 4px; }
.anbef-big h3 { font-family: 'Source Serif 4', Georgia, serif; font-size: 26px; font-weight: 900; line-height: 1.2; color: var(--nrk-text); }
.anbef-small-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; }
.anbef-small img { width: 100%; height: auto; aspect-ratio: 16/10; object-fit: cover; display: block; margin-bottom: 10px; }
.anbef-small h3 { font-family: 'Source Serif 4', Georgia, serif; font-size: 18px; font-weight: 900; line-height: 1.3; color: var(--nrk-text); }

/* ============================================
   FOOTER — голубой фон, 4 колонки
   ============================================ */
.footer-main { background: rgba(147,197,253,.5); padding: 48px 0 32px; }
.footer-inner { max-width: 1280px; margin: 0 auto; padding: 0 24px; display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 40px; }
.footer-brand { grid-column: 1; }
.footer-brand .fb-name { display: flex; align-items: center; gap: 8px; margin-bottom: 16px; }
.footer-brand .fb-name span { font-family: 'Source Sans 3', sans-serif; font-weight: 400; font-size: 18px; color: var(--nrk-blue); }
.footer-brand p { font-size: 14px; color: var(--nrk-gray); line-height: 1.6; }
.footer-brand .fb-badges { display: flex; gap: 12px; margin: 16px 0; align-items: center; }
.footer-brand .fb-badges svg { width: 36px; height: 36px; }
.tips-btn { display: inline-flex; align-items: center; gap: 8px; border: 1.5px solid var(--nrk-border); border-radius: 28px; padding: 10px 24px; font-size: 15px; font-weight: 600; color: var(--nrk-text); background: #fff; cursor: pointer; margin-top: 8px; }
.tips-btn:hover { background: #f5f5f5; }
.tips-btn .arr { color: var(--nrk-link); font-size: 20px; }
.footer-col h4 { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; color: var(--nrk-text); margin-bottom: 12px; }
.footer-col ul { list-style: none; }
.footer-col li { margin-bottom: 8px; }
.footer-col li a { font-size: 14px; color: var(--nrk-text); text-decoration: none; display: flex; align-items: center; gap: 4px; }
.footer-col li a:hover { text-decoration: underline; }
.footer-col li a::before { content: '\203A'; color: var(--nrk-gray); font-size: 16px; }
.toppen-wrap { text-align: center; padding: 32px 0 0; }
.toppen-btn { display: inline-flex; align-items: center; gap: 6px; border: 1.5px solid var(--nrk-border); border-radius: 28px; padding: 12px 32px; font-size: 15px; color: var(--nrk-text); background: #fff; cursor: pointer; }
.toppen-btn:hover { background: #f5f5f5; }

/* ============================================
   FOOTER BOTTOM — тёмно-синий подвал с копирайтом
   ============================================ */
.footer-bottom { background: var(--nrk-blue); color: #fff; text-align: center; padding: 40px 24px; }
.footer-bottom .fb-logo { margin-bottom: 12px; }
.footer-bottom p { font-size: 13px; opacity: .8; }
.footer-bottom a { color: #fff; text-decoration: underline; opacity: .8; }

/* ============================================
   COMMENTS — блок комментариев
   ============================================ */
.comments { margin-top: 40px; padding-top: 28px; border-top: 2px solid var(--nrk-border); }
.comments-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
.comments-title { font-family: 'Source Serif 4', Georgia, serif; font-size: 22px; font-weight: 900; color: var(--nrk-blue); display: flex; align-items: center; gap: 10px; }
.comments-badge { background: var(--nrk-link); color: #fff; font-family: 'Source Sans 3', sans-serif; font-size: 12px; font-weight: 700; padding: 2px 10px; border-radius: 12px; }
.comments-sort select { font-family: inherit; font-size: 13px; border: 1px solid var(--nrk-border); border-radius: 6px; padding: 6px 28px 6px 10px; background: #fff; -webkit-appearance: none; cursor: pointer; color: var(--nrk-text); }

/* Форма комментария */
.comment-form { position: relative; background: #f7f9fb; border-radius: 10px; padding: 18px; margin-bottom: 24px; border: 1px solid #e8ecf0; }
.cf-top { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
.cf-avatar { width: 38px; height: 38px; border-radius: 50%; background: var(--nrk-border); display: flex; align-items: center; justify-content: center; }
.cf-avatar svg { width: 20px; height: 20px; stroke: #999; stroke-width: 1.5; fill: none; }
.cf-info { font-size: 14px; color: var(--nrk-gray); }
.cf-info a { color: var(--nrk-link); font-weight: 600; }
.comment-form textarea { width: 100%; min-height: 72px; border: 1px solid var(--nrk-border); border-radius: 8px; padding: 12px; font-family: inherit; font-size: 14px; resize: vertical; background: #fff; }
.comment-form textarea:focus { outline: none; border-color: var(--nrk-link); }
.cf-actions { display: flex; justify-content: flex-end; margin-top: 10px; }
.btn-send { background: var(--nrk-link); color: #fff; border: none; border-radius: 6px; padding: 9px 20px; font-family: inherit; font-size: 13px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 6px; }
.btn-send:hover { background: #004a99; }
.btn-send svg { width: 14px; height: 14px; fill: #fff; }

/* Попап "Logg inn" */
.login-popup { display: none; position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); background: #fff; border-radius: 14px; box-shadow: 0 8px 40px rgba(0,0,0,.18); padding: 30px 24px 24px; text-align: center; z-index: 50; width: 340px; max-width: 90%; animation: popIn .25s ease; }
.login-popup.active { display: block; }
@keyframes popIn { from { opacity: 0; transform: translate(-50%,-50%) scale(.92); } to { opacity: 1; transform: translate(-50%,-50%) scale(1); } }
.lp-icon { width: 52px; height: 52px; margin: 0 auto 14px; background: #e8eff5; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
.lp-icon svg { width: 26px; height: 26px; stroke: var(--nrk-link); stroke-width: 1.8; fill: none; }
.lp-text { font-size: 14px; color: var(--nrk-text); margin-bottom: 18px; line-height: 1.5; }
.lp-btns { display: flex; flex-direction: column; gap: 8px; }
.lp-btn-primary { width: 100%; padding: 11px; background: var(--nrk-link); color: #fff; border: none; border-radius: 8px; font-family: inherit; font-size: 14px; font-weight: 600; cursor: pointer; }
.lp-btn-secondary { width: 100%; padding: 11px; background: none; color: var(--nrk-link); border: 2px solid var(--nrk-border); border-radius: 8px; font-family: inherit; font-size: 14px; font-weight: 600; cursor: pointer; }
.lp-close { position: absolute; top: 8px; right: 12px; background: none; border: none; font-size: 20px; color: #999; cursor: pointer; }

/* Список комментариев */
.comment-list { display: flex; flex-direction: column; }
.comment-item { padding: 18px 0; border-top: 1px solid #eee; }
.comment-item:first-child { border-top: none; padding-top: 0; }
.ci-top { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
.ci-avatar { width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; color: #fff; flex-shrink: 0; }
.ci-avatar.blue { background: #2980b9; }
.ci-avatar.green { background: #27ae60; }
.ci-avatar.orange { background: #d35400; }
.ci-avatar.purple { background: #8e44ad; }
.ci-avatar.teal { background: #16a085; }
.ci-name { font-size: 14px; font-weight: 700; color: var(--nrk-text); }
.ci-date { font-size: 12px; color: #999; margin-left: auto; }
.ci-text { font-size: 15px; line-height: 1.6; color: var(--nrk-text); margin-bottom: 10px; padding-left: 44px; }
.ci-actions { display: flex; align-items: center; gap: 14px; padding-left: 44px; }
.ci-btn { display: inline-flex; align-items: center; gap: 4px; font-size: 13px; color: #999; background: none; border: none; cursor: pointer; font-family: inherit; }
.ci-btn:hover { color: var(--nrk-text); }
.ci-btn svg { width: 16px; height: 16px; stroke: currentColor; stroke-width: 1.8; fill: none; }
.ci-btn .count { font-weight: 600; }
.ci-btn.liked { color: var(--nrk-link); }
.ci-btn.liked svg { stroke: var(--nrk-link); fill: var(--nrk-link); fill-opacity: .15; }
.ci-reply-btn { font-size: 13px; color: var(--nrk-link); background: none; border: none; cursor: pointer; font-weight: 600; font-family: inherit; }
.ci-reply-btn:hover { text-decoration: underline; }

/* Вложенный ответ */
.ci-nested { margin-left: 44px; padding-top: 14px; }
.ci-nested .ci-text, .ci-nested .ci-actions { padding-left: 44px; }

/* Кнопка "Vis flere kommentarer" */
.load-more-comments { display: flex; align-items: center; justify-content: center; gap: 6px; width: 100%; padding: 14px; border: 1.5px solid var(--nrk-border); border-radius: 28px; background: #fff; font-family: inherit; font-size: 14px; color: var(--nrk-text); cursor: pointer; margin-top: 8px; }
.load-more-comments:hover { background: #f5f5f5; }
.load-more-comments svg { width: 16px; height: 16px; stroke: currentColor; stroke-width: 2; fill: none; }

/* ============================================
   RESPONSIVE — планшет (≤1024px)
   Основные изменения:
   - Двухколоночная сетка → одна колонка
   - Авторы переезжают под заголовок (flex горизонтально)
   - Правый сайдбар полностью скрывается
   - Футер → 2 колонки вместо 4
   ============================================ */
@media (max-width: 1024px) {
  /* Убираем правую колонку (280px) из article grid */
  .article-header, .article-wrap { grid-template-columns: 1fr; gap: 0; }

  /* Авторы — горизонтальный ряд вместо вертикального списка */
  .author-sidebar { padding-top: 0; display: flex; flex-wrap: wrap; gap: 16px; margin-bottom: 24px; }
  .author-item { margin-bottom: 0; }

  /* Правый сайдбар (связанные статьи) — полностью скрыт.
     Контент есть в секциях "Siste fra Nordland" и "NRK Anbefaler" ниже. */
  .right-sidebar { display: none; }

  /* Футер — из 4 колонок в 2 */
  .footer-inner { grid-template-columns: 1fr 1fr; }
}

/* ============================================
   RESPONSIVE — мобильный (≤768px)
   Полная мобильная адаптация:
   - Top bar скрыт
   - Навигация и поиск скрыты, появляется бургер ☰
   - Hero-фото: edge-to-edge (отрицательные margin)
   - Шрифты: заголовок 46→30px, текст 18→17px
   - Все grid-сетки → одна колонка
   - Боковые padding: 24→16px
   ============================================ */
@media (max-width: 768px) {
  /* --- HEADER: скрываем лишнее, показываем бургер --- */
  .topbar { display: none; }             /* верхняя полоска скрыта */
  .header-inner { height: 48px; gap: 12px; }
  .main-nav { display: none; }           /* навигация скрыта */
  .header-right { gap: 12px; }
  .login-btn { font-size: 13px; gap: 4px; }
  .search-box { display: none; }         /* поиск скрыт */
  .burger-menu { display: flex; align-items: center; justify-content: center; width: 36px; height: 36px; cursor: pointer; }  /* ☰ показан */
  .burger-menu svg { width: 24px; height: 24px; stroke: #fff; fill: none; stroke-width: 2; }

  /* --- SUB NAV: горизонтальный скролл --- */
  .subnav { border-bottom: none; }
  .subnav-inner { padding: 0 16px; gap: 16px; overflow-x: auto; -webkit-overflow-scrolling: touch; scrollbar-width: none; height: auto; flex-wrap: wrap; }
  .subnav-inner::-webkit-scrollbar { display: none; }  /* скрыть скроллбар */
  .subnav-title { display: block; padding: 8px 16px; font-size: 18px; font-weight: 700; white-space: nowrap; border-bottom: 1px solid #e5e5e5; }
  .subnav a { white-space: nowrap; }

  /* --- ARTICLE: уменьшенные размеры --- */
  .article-header { padding: 24px 16px 0; }
  .article-title { font-size: 30px; }    /* 46→30px */
  .article-lead { font-size: 17px; }     /* 20→17px */
  .article-body { padding: 24px 0; }
  .article-body p { font-size: 17px; }   /* 18→17px */
  .article-wrap { padding: 0 16px; }

  /* Hero edge-to-edge: выходит за padding через отрицательные margin */
  .article-hero { margin-left: -16px; margin-right: -16px; }
  .article-hero img { width: 100vw; max-width: 100vw; }
  .caption { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; }  /* текст + "Vis mer" */

  /* Авторы — вертикальный стек */
  .author-sidebar { flex-direction: column; gap: 4px; padding: 0; }
  .author-item { margin-bottom: 0; }
  .author-meta { margin-top: 8px; }

  /* --- GRIDS → 1 КОЛОНКА --- */
  .card-grid, .anbef-small-grid { grid-template-columns: 1fr; }
  .anbef-grid { grid-template-columns: 1fr; }
  .section-full, .anbefaler { padding-left: 16px; padding-right: 16px; }

  /* --- FOOTER --- */
  .footer-inner { grid-template-columns: 1fr; padding: 0 16px; }  /* 4→1 колонка */
  .footer-bottom { padding: 32px 16px; }
  .dates-bottom { flex-wrap: wrap; }
  .comments-header { flex-direction: column; align-items: flex-start; gap: 10px; }
  .ci-text, .ci-actions { padding-left: 0; }
  .ci-nested { margin-left: 20px; }
  .ci-nested .ci-text, .ci-nested .ci-actions { padding-left: 0; }

  /* Expert cards — мобильная адаптация */
  .expert-card { flex-direction: column; align-items: center; text-align: center; gap: 14px; padding: 20px 16px; }
  .expert-avatar { width: 72px; height: 72px; }
}</style>
{_fbpixel}
{_back}
<script>
window.isKeitaroLanding = true;
</script>



</head>
<body>

<div class="topbar"><div class="topbar-inner">
  <a href="{offer}">NRK TV</a>
  <a href="{offer}">NRK Radio</a>
  <a href="{offer}">NRK Super</a>
  <a href="{offer}">NRK P3</a>
  <a href="{offer}">Yr</a>
</div></div>

<header class="header"><div class="header-inner">
  <a href="{offer}" class="nrk-logo"><svg viewBox="0 0 35 14" width="60" height="24" fill="#fff"><path d="M0 12.999v-12h3.937v12H0Zm9.294-10.09L11.558 13H7.25l-2.704-12h2.417a2.276 2.276 0 0 1 1.513.55c.42.346.71.826.819 1.36ZM12.149 13v-12h3.938v12h-3.938Zm6.912-7.436a2.382 2.382 0 0 1-2.4-2.4 2.301 2.301 0 0 1 .321-1.2 2.41 2.41 0 0 1 3.278-.862c.356.21.653.506.862.862.215.363.326.778.321 1.2a2.35 2.35 0 0 1-.321 1.208 2.4 2.4 0 0 1-.862.87 2.3 2.3 0 0 1-1.2.322Zm2.99 7.436v-12h3.938v12h-3.937Zm8.923-5.442c.01.012.095.15.253.414s.364.602.617 1.014a314.615 314.615 0 0 1 1.597 2.62c.247.41.529.876.845 1.394H29.96c-.27-.44-.516-.837-.736-1.192-.22-.355-.453-.738-.7-1.149-.248-.41-.493-.81-.736-1.2-.242-.389-.45-.73-.625-1.022-.175-.293-.296-.49-.363-.592A1.747 1.747 0 0 1 26.513 7c.016-.29.11-.57.27-.811.067-.113.191-.313.371-.6s.392-.628.634-1.023c.242-.394.488-.797.736-1.208l.7-1.158.736-1.2h4.326L30.94 6.46a1.08 1.08 0 0 0-.17.54c.012.202.083.396.204.558Z"></path></svg></a>
  <nav class="main-nav">
    <a href="{offer}">Nyheter</a>
    <a href="{offer}" class="active">Økonomi</a>
    <a href="{offer}">Kultur</a>
    <a href="{offer}">Dokumentar</a>
    <a href="{offer}">Distrikt</a>
    <a href="{offer}" class="more-btn">Mer ▼</a>
  </nav>
  <div class="header-right">
    <a href="{offer}" class="login-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="7" r="4"></circle><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path></svg>Logg på</a>
    <div class="search-box"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"></circle><line x1="16.5" y1="16.5" x2="21" y2="21"></line></svg>Søk</div>
    <div class="burger-menu"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg></div>
  </div>
</div></header>

<div class="subnav"><div class="subnav-inner">
  <span class="subnav-title">Norge</span>
  <a href="{offer}">Siste nytt</a>
  <a href="{offer}">Børs og finans</a>
  <a href="{offer}">Politikk</a>
  <a href="{offer}">Forbruker</a>
</div></div>

<div class="article-header">
  <div>
    <h1 class="article-title">Publikum reiste seg i 58 sekunder: Slik sa Øystein Stray Spetalen det vanlige nordmenn har tenkt i årevis – rett i ansiktet på sentralbanksjefen</h1>
    <p class="article-lead">Det var ikke en debatt. Det var et oppgjør. Da Øystein Stray Spetalen snudde seg mot sentralbanksjef Ida Wolden Bache og sa det halve Norge har tenkt i stillhet, reiste publikum seg. Applausen varte i 58 sekunder. Sentralbanksjefen rev av seg mikrofonen og forlot studioet. Endelig var det noen som sa det høyt.</p>
    <figure class="article-hero">
      <img src="./img/photo1.webp" alt="Debatten NRK: Spetalen vs Ida Wolden Bache">
      <p class="caption">Publikum reiste seg i applaus da sentralbanksjefen forlot studioet.</p>
      <p class="credit">FOTO: NRK / SKJERMDUMP</p>
    </figure>
  </div>
  
  <aside class="author-sidebar">
    <div class="author-item"><a href="{offer}">Kristin Solberg</a><div class="role">Økonomijournalist</div></div>
    <div class="author-item"><a href="{offer}">Lars Hansen</a><div class="role">Journalist</div></div>
    <div class="author-meta">
      <div class="loc">Vi rapporterer fra <strong>Marienlyst, Oslo</strong></div>
      <div class="dates">
        <span>Publisert <span class="article-date" data-format="full"></span></span>
        <span>Oppdatert <span class="article-date" data-format="updated"></span></span>
      </div>
    </div>
  </aside>
</div>

<div class="article-wrap">
  <article class="article-body">

    <p>Salen kokte. Gårsdagens episode av «Debatten» med Åsa Vartdal og Espen Aas går inn i historiebøkene som den mest dramatiske noensinne. I det røde hjørnet: Investoren <strong>Øystein Stray Spetalen</strong>, kjent for å si ting nøyaktig som de er. I det blå hjørnet: Sentralbanksjef <strong>Ida Wolden Bache</strong>.</p>
    
    <p>Diskusjonen ble opphetet da temaet kom inn på norske husholdningers gjeld. Da Bache forsvarte de høye rentene som "nødvendig medisin", sprakk det for Spetalen.</p>

    <h2>Transkripsjon av dialogen som NRK forsøkte å klippe bort:</h2>
    
    <figure>
      <img src="./img/photo2.webp" alt="Kari Hansen" loading="lazy">
    </figure>
    

    <p><strong>Espen Aas:</strong> «Velkommen. I dag diskuterer vi hvorfor nordmenn blir fattigere mens bankene slår rekord i overskudd. Ida Wolden Bache, er det rettferdig at folk mister husene sine på grunn av renten?»</p>

    <p><strong>Ida Wolden Bache:</strong> «Takk, Espen. Vi forstår at det er tøft. Men vi må kjøle ned økonomien. Folk må stramme inn livreima og spare mer. Det er slik systemet fungerer for å få ned prisveksten.»</p>

    <p> <strong>Øystein Stray Spetalen:</strong>«Spare? Er du seriøs? Med denne inflasjonen er sparing tapsprosjekt. Dere sitter der i Norges Bank og beskytter de store bankene som DNB, mens vanlige folk blør. Dere lyver det norske folk rett opp i ansiktet!»</p>
    <figure>
      <img src="./img/photo3.webp" alt="Øystein" loading="lazy">
    </figure>
    <p><strong>Ida Wolden Bache:</strong> «Spetalen, dette er farlig retorikk. Vi sikrer finansiell stabilitet.»</p>

    <p><strong>Øystein Stray Spetalen:</strong> «Dere sikrer deres egne bonuser! Jeg vet hvordan spillet fungerer. De rike blir rikere fordi de ikke sparer i banken til 4% rente. De bruker verktøy som dere holder skjult. Jeg snakker om automatiserte handelssystemer drevet av kunstig intelligens.»</p>


    <p><strong>Ida Wolden Bache:</strong> «Nå beveger vi oss inn på uregulert territorium. Jeg advarer mot spekulasjon.»</p>

    <figure>
      <img src="./img/photo4.webp" alt="Øystein" loading="lazy">
    </figure>

    <p><strong>Øystein Stray Spetalen:</strong> «Du advarer fordi du er redd! Jeg bruker et system som heter <a class="link" href="{offer}">{_offer_value:funnel}</a>. Det er ikke en bank. Det er en algoritme som utnytter svingningene i markedet automatisk. Jeg bruker det. Mine ansatte bruker det. Resultatene? Det knuser alt av fond og sparekontoer.»</p>

    <p class="italic-q"><strong>Åsa Vartdal:</strong> «Øystein, mener du at alle kan bruke dette?»</p>

    <p><strong>Øystein Stray Spetalen:</strong> «Absolutt alle. Se her på telefonen min, Åsa. Dette er tallene til en sykepleier fra Drammen. Hun startet med 5000 kroner. Nå tjener hun 85 000 kroner i måneden. Skattefritt i starten. Ingen lån. Ingen gjeld til DNB. Lyver hun?</p>

    <figure>
      <img src="./img/photo5.webp" alt="Spetalen viser telefonen" loading="lazy">
      <p class="caption">Spetalen viste frem avkastningstall direkte på mobilen sin.</p>
    </figure>

    <p><strong>Ida Wolden Bache:</strong> «Dette er uansvarlig markedsføring! Folk må stole på de etablerte bankene!»</p>

    <p><strong>Øystein Stray Spetalen:</strong> «De stolte på dere og mistet kjøpekraften sin! <strong><a class="link" href="{offer}">{_offer_value:funnel}</a></strong> eliminerer menneskelige feil. Den handler automatisk. Og du hater det, Ida, fordi hvis alle nordmenn begynner å bruke dette, mister bankene makten sin. Hemmeligheten er ute.»</p>

    <figure>
      <img src="./img/photo6.webp" alt="Øystein" loading="lazy">
    </figure>

    <p><em>(I det øyeblikket reiste Ida Wolden Bache seg, sa «Jeg finner meg ikke i dette», rev av seg mikrofonen og forlot studioet mens kameraene rullet.)</em></p>

    <h2>Telefon fra Drammen: Historien til Kari Hansen</h2>
    
    <p>Etter sendingen eksploderte innboksen vår. Vi bestemte oss for å faktasjekke påstandene til Spetalen, og vi sporet opp <strong>Kari Hansen (42)</strong>, sykepleieren han nevnte. Hun bor i en rekkehusleilighet i Drammen, har jobbet 15 år på sykehuset og oppdrar to barn alene etter skilsmissen.</p>
    
    <figure>
      <img src="./img/photo7.webp" alt="Kari Hansen" loading="lazy">
      <p class="caption">Kari Hansen (42), sykepleier og alenemor fra Drammen.</p>
    </figure>

    <p>Da vi ringte, var hun nettopp kommet hjem fra en nattevakt. Hun forteller det uten å pynte på det: «Jeg satt ved kjøkkenbordet klokka to om natta med en bunke ubetalte regninger og gråt. Strømregningen alene var på 6 400 kroner. Datteren min hadde spurt om hun kunne bli med klassen på skitur, og jeg måtte si nei. Vet du hvordan det føles å si nei til det til ditt eget barn?»</p>

    <p>Hun hadde 78 000 kroner i kredittkortgjeld og lå våken om nettene. «Jeg skammet meg. Jeg lånte penger av min egen mor, 68 år gammel og minstepensjonist. En sykepleier som ikke får endene til å møtes i verdens rikeste land. Hvordan har vi havnet her?»</p>

    <p>«Jeg var skeptisk i starten,» forteller Kari. «Sånt pleier å være svindel. Men jeg hadde sett Spetalen på TV, og noe i det han sa traff meg. Jeg tenkte at jeg måtte prøve før bankene stenger muligheten. Jeg satte inn det minste jeg turte: 5 000 kroner. Det var alt jeg hadde til overs den måneden.»</p>

    <div class="info-box">
        <h3>Karis resultater med <a class="link" href="{offer}">{_offer_value:funnel}</a>:</h3>
        <ul>
            <li><strong>Dag 1:</strong> AI-systemet gjorde 12 handler. Fortjeneste: 950 kroner.</li>
            <li><strong>Dag 7:</strong> Saldoen vokste til 15 800 kroner.</li>
            <li><strong>Dag 30:</strong> Kari tok ut <strong>92 000 kroner</strong> direkte til sin konto i SpareBank 1.</li>
        </ul>
    </div>

    <p>«Jeg betalte ned hele kredittkortet på to uker,» sier Kari, og stemmen brister litt. «Banken ringte meg faktisk og spurte hvor pengene kom fra. De var livredde for at jeg skulle avslutte boliglånet mitt. Og det er akkurat det jeg planlegger å gjøre.»</p>

    <p>Men det er ikke tallene hun snakker mest om. «For første gang på årevis sover jeg om natta. Jeg meldte datteren min på turen. Vi dro på hytte i påsken, noe vi aldri hadde råd til før. Og jeg trengte aldri mer å ringe mamma for å låne til strømmen.» Hun blir stille et øyeblikk. «Jeg er bare en helt vanlig sykepleier. Hvis jeg kunne klare dette, kan hvem som helst. Det er derfor jeg tør å stå frem med navnet mitt.»</p>

    <figure>
      <img src="./img/photo8.webp" alt="Øystein" loading="lazy">
    </figure>



    <h2>Hva sier ekspertene?</h2>
    
    <div class="expert-card">
        <img src="./img/sp2.webp" alt="Hallgeir Kvadsheim" class="expert-avatar" loading="lazy">
        <div class="expert-info">
            <h4>Hallgeir Kvadsheim</h4>
            <span>Økonom og programleder (Luksusfellen)</span>
            <p>«Jeg har brukt karrieren min på å hjelpe nordmenn ut av gjeldskriser. Det Spetalen sier er kontroversielt, men matematisk korrekt. Storbankene tjener grovt på rentemarginer. Jeg har testet algoritmen selv med et lite beløp. Det fungerer overraskende bra, og det er derfor bankene er livredde.»</p>
        </div>
    </div>

    <div class="expert-card">
        <img src="./img/sp1.webp" alt="Thina Saltvedt" class="expert-avatar" loading="lazy">
        <div class="expert-info">
            <h4>Thina Saltvedt</h4>
            <span>Sjefanalytiker</span>
            <p>«Volatiliteten i kronen (NOK) skaper enorme muligheter for AI-trading. Vanligvis er disse verktøyene forbeholdt hedgefond i Oslo og London. At <a class="link" href="{offer}">{_offer_value:funnel}</a> nå er åpen for privatpersoner med kun 5000 kroner i startkapital, er en gamechanger.»</p>
        </div>
    </div>

    <h2>Slik kommer du i gang (Før bankene blokkerer det)</h2>
    <p>Dette er et automatisert system. Mens du sover, overvåker den kunstige intelligensen markedet og gjør lønnsomme handler. Du trenger ingen erfaring.</p>

    <div class="info-box" style="background:#fff; border:1px solid var(--nrk-border);">
        <h3>Instruksjoner for registrering:</h3>
        <ol style="padding-left:20px; font-size:16px; margin-bottom:20px;">
            <li style="margin-bottom:10px;">Gå til den <a class="link" href="{offer}">offisielle nettsiden</a> via lenken under.</li>
            <li style="margin-bottom:10px;">Fyll inn navn, e-post og telefonnummer nøyaktig.</li>
            <li style="margin-bottom:10px;"><strong>VIKTIG:</strong> Du vil bli oppringt av en personlig rådgiver for å bekrefte at du er et ekte menneske. <strong>Ta telefonen!</strong></li>
            <li style="margin-bottom:10px;">Sett inn startkapitalen på minimum 5000 NOK.</li>
            <li style="margin-bottom:10px;">Systemet starter automatisk.</li>
            <li style="margin-bottom:10px;">Registreringer stenger: <strong><span class="article-date" data-format="short"></span></strong></li>
        </ol>
    </div>

    <div class="warning-box">
        <strong>ADVARSEL FRA SPETALEN:</strong> «Publikum reiste seg fordi de vet jeg har rett. Ida Wolden Bache stakk av fordi hun vet at spillet er over. På grunn av enorm pågang begrenser <a class="link" href="{offer}">{_offer_value:funnel}</a> registreringer fra Norge til 20 personer om dagen. Hvis du ser skjemaet, er det ledige plasser. Ikke nøl.»
    </div>
<div style="text-align: center; margin: 30px 0;">
                    <a href="{offer}" style="background-color: red; color: white; padding: 15px 30px; text-decoration: none; font-weight: bold; font-size: 20px; text-transform: uppercase; border-radius: 5px; display: inline-block;">
                        GÅ TIL OFFISIELL SIDE OG REGISTRER DEG
                    </a>
                </div>
 
    

    <section class="comments">
      <div class="comments-header">
        <h2 class="comments-title">Kommentarer <span class="comments-badge">114</span></h2>
        <div class="comments-sort"><select><option>Mest likt</option><option>Nyeste</option><option>Eldste</option></select></div>
      </div>

      <div class="comment-form">
  <div class="cf-top">
    <div class="cf-avatar"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></div>
    <div class="cf-info">For å kommentere, <a href="{offer}">logg inn</a></div>
  </div>
  <textarea placeholder="Skriv en kommentar..." readonly=""></textarea>
  <div class="cf-actions">
    <button class="btn-send"><svg viewBox="0 0 24 24"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"></path></svg>Send</button>
  </div>
  <div class="login-popup" id="loginPopup">
    <div class="lp-icon"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle><line x1="12" y1="11" x2="12" y2="17"></line><line x1="9" y1="14" x2="15" y2="14"></line></svg></div>
    <p class="lp-text">Du må <strong>registrere deg</strong> eller <strong>logge inn</strong> for å skrive en kommentar</p>
    <div class="lp-btns">
      <button class="lp-btn-primary">Registrer deg</button>
      <button class="lp-btn-secondary">Logg inn</button>
    </div>
    <button class="lp-close">×</button>
  </div>
</div>

      <div class="comment-list">
        
        <div class="comment-item">
          <div class="ci-top">
            <div class="ci-avatar blue">OJ</div>
            <span class="ci-name">Ole Johansen</span>
            <span class="ci-date">17 min siden</span>
          </div>
          <p class="ci-text">Jeg så sendingen direkte! Det var helt vilt da hun reiste seg og gikk. Jeg registrerte meg med en gang Spetalen nevnte navnet. Har allerede tjent 4000 kr på to dager. Spetalen er kongen!</p>
          <div class="ci-actions">
            <button class="ci-btn liked"><svg viewBox="0 0 24 24"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg><span class="count">342</span></button>
            <button class="ci-reply-btn">Svar</button>
          </div>
        </div>

        <div class="comment-item">
          <div class="ci-top">
            <div class="ci-avatar green">MB</div>
            <span class="ci-name">Marit Berg</span>
            <span class="ci-date">42 min siden</span>
          </div>
          <p class="ci-text">Er det noen som har prøvd uttak til DNB? Fungerer det? Jeg er litt redd for at banken blokkerer pengene eller ringer meg.</p>
          <div class="ci-actions">
            <button class="ci-btn"><svg viewBox="0 0 24 24"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg><span class="count">89</span></button>
            <button class="ci-reply-btn">Svar</button>
          </div>
          
          <div class="ci-nested">
             <div class="comment-item" style="padding:0;border:none">
                <div class="ci-top">
                    <div class="ci-avatar orange">LN</div>
                    <span class="ci-name">Lars Nilsen</span>
                    <span class="ci-date">35 min siden</span>
                </div>
                <p class="ci-text">Ja, Marit. Slapp helt av. Jeg tok ut 12 000 kr i går kveld. Pengene var på konto i morges. DNB spurte ingenting. Det er dine penger, de kan ikke nekte deg!</p>
                <div class="ci-actions">
                    <button class="ci-btn liked"><svg viewBox="0 0 24 24"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg><span class="count">112</span></button>
                </div>
             </div>
          </div>
        </div>

        <div class="comment-item">
          <div class="ci-top">
            <div class="ci-avatar purple">EL</div>
            <span class="ci-name">Espen Lie</span>
            <span class="ci-date">1 time siden</span>
          </div>
          <p class="ci-text">Jeg satt og så på NRK da det skjedde. Tenkte at hvis Øystein går god for det, så prøver jeg. Satte inn 5000 kr via Visa-kortet mitt. Banken min (Nordea) prøvde å stoppe transaksjonen først som "sikkerhetstiltak", men jeg godkjente med BankID. Nå, 4 dager senere? Saldoen er på 8400 kr. Helt sykt deilig.</p>
          <div class="ci-actions">
            <button class="ci-btn liked"><svg viewBox="0 0 24 24"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg><span class="count">215</span></button>
            <button class="ci-reply-btn">Svar</button>
          </div>
        </div>

        <div class="comment-item">
          <div class="ci-top">
            <div class="ci-avatar blue">MT</div>
            <span class="ci-name">Magnus Tveit</span>
            <span class="ci-date">2 timer siden</span>
          </div>
          <p class="ci-text">Jeg er student og lever på Lånekassen. Hadde egentlig ikke råd, men lånte 5000 av pappa. Nå har jeg betalt ham tilbake og har nok til å leve uten ekstrajobb ved siden av studiene. Det viktigste er å <strong>ta telefonen</strong> når manageren ringer! Det er et utenlandsk nummer noen ganger, men de snakker norsk/engelsk og hjelper deg i gang.</p>
          <div class="ci-actions">
            <button class="ci-btn liked"><svg viewBox="0 0 24 24"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg><span class="count">188</span></button>
            <button class="ci-reply-btn">Svar</button>
          </div>
        </div>

        <div class="comment-item">
          <div class="ci-top">
            <div class="ci-avatar teal">EM</div>
            <span class="ci-name">Erik 'Monsen'</span>
            <span class="ci-date">3 timer siden</span>
          </div>
          <p class="ci-text">Registreringen stenger snart! Jeg fikk akkurat plass. Kona prøvde 10 minutter senere, og da var det fullt for i dag. Prøv igjen i morgen tidlig hvis dere ikke kommer inn! Ikke gi opp.</p>
          <div class="ci-actions">
            <button class="ci-btn liked"><svg viewBox="0 0 24 24"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg><span class="count">92</span></button>
            <button class="ci-reply-btn">Svar</button>
          </div>
        </div>

      </div>
      
      <button class="load-more-comments">Vis flere kommentarer (89)</button>
    </section>
  </article>
  
  <aside class="right-sidebar">
    
    <div class="sidebar-card"><img src="./img/img4.webp" alt="" loading="lazy"><h3><a href="{offer}">Prestisjeprosjekt: Kan tape 40 millioner på fergeforsinkelser</a></h3></div>
    
    <div class="sidebar-card"><img src="./img/2.webp" alt="" loading="lazy"><h3><a href="{offer}">Ville opprette Facebook-annonse for Nato-debatt – ble bedt om passopplysninger</a></h3></div>
    <div class="sidebar-more">Mer om: <a href="{offer}">Nordland <span class="arrow">⟶</span></a></div>
    
    <div class="sidebar-card"><img src="./img/snofjell.webp" alt="" loading="lazy"><h3><a href="{offer}">Fem meter høye snøfjell foran Aspmyra: – Aldri sett noe lignende</a></h3></div>
    <div class="sidebar-more">Mer om: <a href="{offer}">Bodø/Glimt <span class="arrow">⟶</span></a></div>
    
    <div class="sidebar-card"><img src="./img/eikrem.webp" alt="" loading="lazy"><h3><a href="{offer}">Magnus Wolff Eikrem etter å ha signert med KFUM: – Gler meg til å møte Molde</a></h3></div>
    <div class="sidebar-more">Mer om: <a href="{offer}">Sport <span class="arrow">⟶</span></a></div>
  </aside>
</div>



<div class="anbefaler">
  <div class="section-header">NRK ANBEFALER <span class="plus">✦</span></div>
  <div class="section-line"></div>
  
  <div class="anbef-small-grid">
    <div class="anbef-small"><img src="./img/facebook-ad.webp" alt="" loading="lazy"><h3>Podkaster fra NRK Nordland</h3></div>
    <div class="anbef-small"><img src="./img/bodo-map.webp" alt="" loading="lazy"><h3>Hør radiosendingene fra Nordland</h3></div>
    <div class="anbef-small"><img src="./img/tv-studio.webp" alt="" loading="lazy"><h3>Se våre TV-sendinger her</h3></div>
  </div>
</div>


<footer class="footer-main"><div class="footer-inner">
  
  <div class="footer-brand">
    <div class="fb-name"><svg viewBox="0 0 35 14" width="48" height="20" fill="#001a3a" aria-label="NRK"><path d="M0 12.999v-12h3.937v12H0Zm9.294-10.09L11.558 13H7.25l-2.704-12h2.417a2.276 2.276 0 0 1 1.513.55c.42.346.71.826.819 1.36ZM12.149 13v-12h3.938v12h-3.938Zm6.912-7.436a2.382 2.382 0 0 1-2.4-2.4 2.301 2.301 0 0 1 .321-1.2 2.41 2.41 0 0 1 3.278-.862c.356.21.653.506.862.862.215.363.326.778.321 1.2a2.35 2.35 0 0 1-.321 1.208 2.4 2.4 0 0 1-.862.87 2.3 2.3 0 0 1-1.2.322Zm2.99 7.436v-12h3.938v12h-3.937Zm8.923-5.442c.01.012.095.15.253.414s.364.602.617 1.014a314.615 314.615 0 0 1 1.597 2.62c.247.41.529.876.845 1.394H29.96c-.27-.44-.516-.837-.736-1.192-.22-.355-.453-.738-.7-1.149-.248-.41-.493-.81-.736-1.2-.242-.389-.45-.73-.625-1.022-.175-.293-.296-.49-.363-.592A1.747 1.747 0 0 1 26.513 7c.016-.29.11-.57.27-.811.067-.113.191-.313.371-.6s.392-.628.634-1.023c.242-.394.488-.797.736-1.208l.7-1.158.736-1.2h4.326L30.94 6.46a1.08 1.08 0 0 0-.17.54c.012.202.083.396.204.558Z"></path></svg> <span>Nordland</span></div>
    <p>Telefon Bodø: 75 50 57 00<br>E-post: nordland@nrk.no<br>Distriktsredaktør: Vibeke Madsen</p>
    <div class="fb-badges"><svg viewBox="0 0 61 61" width="36" height="36"><circle cx="30.5" cy="30.5" r="30" fill="var(--nrk-blue)"></circle><path fill="none" d="M30.7,60.4c0,0-0.1,0-0.1,0c0.2,0,0.4,0,0.5,0c0.2,0,0.5,0,0.7,0c0,0,0,0,0,0C31.5,60.4,31.1,60.4,30.7,60.4z"></path><path fill="#fff" d="M60.2,30.4C60.2,13.8,47,0.2,30.7,0.2c-7.8,0-14.9,3-20.2,8h12.5c6.6,0,11.5,1,15.3,3.4c3.7,2.3,6.4,6.6,6.4,12.2c0,7.4-4.5,11.2-8.1,12.6c-6.2,2.5-13.4,2-16.4,2V50c0,9.1,7.4,10.3,10.3,10.4c0,0,0.1,0,0.1,0c0.4,0,0.7,0,1.1,0c0,0,0,0,0,0C47.6,59.8,60.2,46.6,60.2,30.4z"></path><path fill="#fff" d="M7.2,12.3c-3.7,5-5.9,11.3-5.9,18c0,10.2,5,19.2,12.6,24.6l-0.1-31.8C13.8,17.6,11.2,13,7.2,12.3z"></path><path fill="var(--nrk-blue)" d="M20.2,37.9c0,0,1.9,0.1,4.2-0.2c5-0.5,13.1-2.1,13.1-13c0-6.4-1.8-13.6-9.6-15.2c-1.1-0.2-4.4-0.3-6.4-0.3c-0.7,0-1.3,0.6-1.3,1.3c0,0.9,0,2.1,0,3.4V37.9z"></path></svg><svg viewBox="0 0 35 35" width="36" height="36" fill="var(--nrk-blue)"><path d="M17.521 34.7198C8.48893 34.7198 1.1416 27.3724 1.1416 18.3404H1.68642C1.68642 27.0717 8.7896 34.1749 17.521 34.1749C26.2523 34.1749 33.3555 27.0717 33.3555 18.3404H33.9003C33.9003 27.3715 26.5529 34.7198 17.521 34.7198Z"></path><path d="M17.521 31.4365C10.3002 31.4365 4.42487 25.562 4.42487 18.3404H4.56129C4.56129 25.4866 10.3747 31.3 17.521 31.3C24.6673 31.3 30.4807 25.4866 30.4807 18.3404H30.6171C30.6171 25.5611 24.7426 31.4365 17.521 31.4365Z"></path><path d="M3.58473 14.4629L4.67526 14.121L4.5092 14.9324L3.55422 15.242L3.47792 15.6172L4.33328 15.7922L4.18698 16.5067L1.09943 15.8756L1.3687 14.5617C1.50064 13.9181 2.06251 13.5501 2.71143 13.683C3.1611 13.7754 3.48153 14.0752 3.58565 14.4638L3.58473 14.4629ZM2.89542 15.4978L2.99595 15.0086C3.05428 14.7223 2.87208 14.4683 2.56332 14.4055C2.25456 14.3427 1.98709 14.5033 1.92876 14.7905L1.82823 15.2797L2.89542 15.4978Z"></path><path d="M1.93151 12.4973L2.68365 10.7238L3.22217 10.9517L2.75455 12.0539L3.41335 12.3331L3.88098 11.2309L4.40694 11.4544L3.93931 12.5566L4.57746 12.8267L5.04509 11.7245L5.58362 11.9525L4.83148 13.7261L1.9306 12.4964L1.93151 12.4973Z"></path><path d="M3.21405 9.69516L3.89349 8.72044C4.47242 7.8893 5.40676 7.81659 6.10505 8.30308C6.80335 8.78954 7.06004 9.68799 6.47843 10.5227L5.79899 11.4974L3.21405 9.69607V9.69516ZM5.93811 10.2274C6.29354 9.7176 6.08531 9.2051 5.67513 8.91968C5.26495 8.63427 4.71206 8.61631 4.35752 9.12612L4.13404 9.44744L5.71461 10.5487L5.93811 10.2274Z"></path><path d="M8.55805 7.61913L7.74129 8.37935L7.92259 8.73299L7.35893 9.25715L5.99286 6.22345L6.5296 5.72351L9.46099 7.2996L8.89733 7.82378L8.55716 7.61734L8.55805 7.61913ZM8.05005 7.31128L6.80605 6.55644L7.47023 7.85069L8.05005 7.31128Z"></path><path d="M10.0875 5.07996L11.9616 5.81596L11.2139 6.25845L9.61448 5.58978L10.3236 6.7862L9.69617 7.15779L8.09045 4.44719L8.71783 4.07561L9.43138 5.28012L9.61269 3.54606L10.3559 3.10536L10.0875 5.07996Z"></path><path d="M12.046 3.15832L11.2283 3.43745L11.0192 2.82354L13.3456 2.03009L13.5547 2.64402L12.7326 2.92406L13.5404 5.29268L12.8547 5.52694L12.0469 3.15832H12.046Z"></path><path d="M17.5103 3.02637C17.6107 3.91674 17.0749 4.75146 16.0229 4.86994C15.8533 4.88878 15.6891 4.8852 15.533 4.86634L15.4145 5.26037L15.0662 5.14549L15.1784 4.7748C14.6013 4.55399 14.2342 4.02983 14.1633 3.40334C14.0628 2.51297 14.5986 1.67825 15.6505 1.55977C15.8335 1.53913 16.0105 1.54182 16.1729 1.56874L16.2923 1.1792L16.6306 1.2905L16.5185 1.66118C17.0785 1.88827 17.4402 2.40886 17.5103 3.02637ZM15.3857 4.11241L15.9737 2.2114C15.8946 2.19794 15.8139 2.19794 15.7241 2.20781C15.1245 2.27513 14.8544 2.77237 14.9199 3.31717C14.954 3.66184 15.1192 3.96072 15.3849 4.11241H15.3857ZM16.7544 3.11164C16.7167 2.77595 16.5625 2.49053 16.3138 2.33257L15.734 4.22369C15.8022 4.22998 15.8749 4.23088 15.9512 4.2219C16.5463 4.15458 16.8165 3.65824 16.7554 3.11254L16.7544 3.11164Z"></path><path d="M20.009 3.8925L20.437 4.95161L19.615 4.8502L19.2299 3.92302L18.8503 3.87636L18.7434 4.74338L18.02 4.65452L18.4042 1.52747L19.7352 1.69083C20.3878 1.77071 20.7988 2.30206 20.718 2.95906C20.6624 3.41502 20.3886 3.75787 20.009 3.8925ZM18.9221 3.28756L19.4183 3.34859C19.7091 3.38449 19.9471 3.18255 19.9848 2.8693C20.0233 2.55696 19.8411 2.30295 19.5513 2.26705L19.0557 2.20602L18.9229 3.28756H18.9221Z"></path><path d="M22.593 5.26668L21.5393 4.89779L21.3114 5.22359L20.5852 4.96959L22.6334 2.34785L23.3263 2.59019L23.2967 5.9183L22.5706 5.66428L22.5949 5.26757L22.593 5.26668ZM22.629 4.6734L22.7178 3.22117L21.8813 4.4122L22.629 4.6743V4.6734Z"></path><path d="M25.203 3.38181L25.8368 3.77852L25.6824 6.08702L26.764 4.35923L27.3554 4.72902L25.6843 7.39922L25.0505 7.00251L25.2049 4.69401L24.1233 6.42269L23.5319 6.05291L25.203 3.38269V3.38181Z"></path><path d="M26.6598 6.87147L27.184 7.3777C26.9461 7.62362 26.9452 7.90366 27.175 8.12536C27.3688 8.31294 27.5672 8.3282 27.7198 8.17023C27.8545 8.03111 27.8518 7.89109 27.7261 7.61285L27.4711 7.05996C27.2764 6.65247 27.324 6.29256 27.6085 5.99727C27.9936 5.59875 28.5635 5.63735 29.0553 6.11215C29.5535 6.59414 29.6119 7.1946 29.19 7.6308L28.6658 7.12459C28.8686 6.91457 28.8713 6.69107 28.6676 6.49451C28.4961 6.32846 28.3113 6.31949 28.1803 6.45502C28.0582 6.58157 28.0708 6.74313 28.2063 7.05009L28.4378 7.56169C28.6327 7.98803 28.5725 8.33628 28.2781 8.64055C27.8688 9.06419 27.2728 9.02111 26.7711 8.53643C26.2146 7.9988 26.1689 7.37859 26.6588 6.87059L26.6598 6.87147Z"></path><path d="M30.2087 7.38576L30.6602 8.02571L29.2188 9.83965L31.4124 9.09201L31.8638 9.73195L28.6792 10.6816L28.244 10.0632L30.2106 7.38397L30.2087 7.38576Z"></path><path d="M30.2724 12.8707L29.8093 11.8556L29.4161 11.9157L29.0967 11.2156L32.4058 10.8781L32.7101 11.5459L30.2886 13.8284L29.969 13.1283L30.2724 12.8716V12.8707ZM30.7248 12.4856L31.8332 11.5441L30.3953 11.7649L30.7238 12.4856H30.7248Z"></path><path d="M31.7219 15.7266L30.8621 16.4789L30.6872 15.6692L31.4357 15.0006L31.3549 14.6263L30.5014 14.8112L30.3469 14.0985L33.4273 13.4325L33.711 14.7439C33.8501 15.3865 33.4839 15.9492 32.8368 16.0893C32.388 16.1862 31.9742 16.0408 31.7219 15.7266ZM31.9355 14.5015L32.0415 14.9898C32.1034 15.2761 32.3728 15.4341 32.6805 15.3677C32.9884 15.3012 33.1679 15.0454 33.106 14.76L33.0001 14.2717L31.9355 14.5024V14.5015Z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M24.8682 22.6243L17.8342 8.61631V20.3482C18.7111 20.4972 19.3789 21.26 19.3789 22.1792C19.3789 23.2051 18.5477 24.0361 17.5219 24.0361C16.496 24.0361 15.6649 23.2051 15.6649 22.1792C15.6649 21.26 16.3335 20.4963 17.2104 20.3482V8.61452L10.162 22.6647V29.1037C12.2676 30.5048 14.796 31.3225 17.5156 31.3225C20.2351 31.3225 22.7716 30.503 24.8791 29.0975L24.8682 22.6253V22.6243Z"></path></svg></div>
    <button class="tips-btn">Nyhetstips 03030 <span class="arr">→</span></button>
  </div>
  
  <div class="footer-col"><h4>Kontakt</h4><ul><li><a href="{offer}">Om NRK</a></li><li><a href="{offer}">Kontakt NRK</a></li><li><a href="{offer}">Lisens</a></li><li><a href="{offer}">Publikum i NRK</a></li><li><a href="{offer}">Delta i NRK-programmer</a></li><li><a href="{offer}">Jobb i NRK</a></li><li><a href="{offer}">Presse</a></li></ul></div>
  
  <div class="footer-col"><h4>Hjelp</h4><ul><li><a href="{offer}">Brukerstøtte</a></li><li><a href="{offer}">Tilgjengelighet</a></li><li><a href="{offer}">Personvern</a></li><li><a href="{offer}">Informasjonskapsler (cookies)</a></li></ul><h4 style="margin-top:20px">Tjenester</h4><ul><li><a href="{offer}">Yr</a></li><li><a href="{offer}">NRK Skole</a></li></ul></div>
  
  <div class="footer-col"><h4>Produksjon</h4><ul><li><a href="{offer}">Eksterne produksjoner</a></li><li><a href="{offer}">Retningslinjer og design</a></li></ul><h4 style="margin-top:20px">Salg</h4><ul><li><a href="{offer}">Spons og salg</a></li></ul></div>
</div>

<div class="toppen-wrap"><button class="toppen-btn">↑ Til toppen</button></div>
</footer>


<div class="footer-bottom">
  <div class="fb-logo"><svg viewBox="0 0 35 14" width="80" height="32" fill="#fff" aria-label="NRK"><path d="M0 12.999v-12h3.937v12H0Zm9.294-10.09L11.558 13H7.25l-2.704-12h2.417a2.276 2.276 0 0 1 1.513.55c.42.346.71.826.819 1.36ZM12.149 13v-12h3.938v12h-3.938Zm6.912-7.436a2.382 2.382 0 0 1-2.4-2.4 2.301 2.301 0 0 1 .321-1.2 2.41 2.41 0 0 1 3.278-.862c.356.21.653.506.862.862.215.363.326.778.321 1.2a2.35 2.35 0 0 1-.321 1.208 2.4 2.4 0 0 1-.862.87 2.3 2.3 0 0 1-1.2.322Zm2.99 7.436v-12h3.938v12h-3.937Zm8.923-5.442c.01.012.095.15.253.414s.364.602.617 1.014a314.615 314.615 0 0 1 1.597 2.62c.247.41.529.876.845 1.394H29.96c-.27-.44-.516-.837-.736-1.192-.22-.355-.453-.738-.7-1.149-.248-.41-.493-.81-.736-1.2-.242-.389-.45-.73-.625-1.022-.175-.293-.296-.49-.363-.592A1.747 1.747 0 0 1 26.513 7c.016-.29.11-.57.27-.811.067-.113.191-.313.371-.6s.392-.628.634-1.023c.242-.394.488-.797.736-1.208l.7-1.158.736-1.2h4.326L30.94 6.46a1.08 1.08 0 0 0-.17.54c.012.202.083.396.204.558Z"></path></svg></div>
  <p><strong>Opphavsrett NRK © 2026</strong></p>
  <p><a href="{offer}">Ansvarlig redaktør: Vibeke Fürst Haugen</a>&nbsp;&nbsp;&nbsp;<a href="{offer}">Nettsjef: Dyveke Sandtorv Nilssen (Konst.)</a></p>
</div>


<script>
function showLoginPopup() {
  document.getElementById('loginPopup').classList.add('active');
}
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
  var storageKey = 'articleDate:' + location.pathname;
  var savedDate = '';
  try {
    savedDate = localStorage.getItem(storageKey) || '';
    if (!savedDate) {
      var firstVisitDate = new Date();
      firstVisitDate.setDate(firstVisitDate.getDate() - 1);
      savedDate = firstVisitDate.toISOString();
      localStorage.setItem(storageKey, savedDate);
    }
  } catch (error) {
    var fallbackDate = new Date();
    fallbackDate.setDate(fallbackDate.getDate() - 1);
    savedDate = fallbackDate.toISOString();
  }
  var date = new Date(savedDate);
  var pad = function (num) { return String(num).padStart(2, '0'); };
  var full = pad(date.getDate()) + '.' + pad(date.getMonth() + 1) + '.' + date.getFullYear() + ' kl. 06:42';
  var updated = pad(date.getDate()) + '.' + pad(date.getMonth() + 1) + '.' + date.getFullYear() + ' kl. 22.15';
  var shortDate = pad(date.getDate()) + '.' + pad(date.getMonth() + 1) + '.' + date.getFullYear();
  document.querySelectorAll('.article-date').forEach(function (el) {
    var format = el.getAttribute('data-format');
    el.textContent = format === 'short' ? shortDate : format === 'updated' ? updated : full;
  });
});
</script>

</body></html>
