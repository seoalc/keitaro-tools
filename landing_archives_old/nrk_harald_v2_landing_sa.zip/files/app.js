(function () {
  "use strict";

  var header = document.getElementById("nrkno-header");

  function toggle(btn, cls) {
    if (!btn || !header) return;
    btn.addEventListener("click", function (event) {
      event.preventDefault();
      var open = !header.classList.contains(cls);
      header.classList.toggle(cls, open);
      document.documentElement.classList.toggle("nrk-menu-lock", open);
      document.body.classList.toggle("nrk-menu-lock", open);
      btn.setAttribute("aria-expanded", open ? "true" : "false");
      if (btn.id === "nrkno-menu-button") btn.setAttribute("aria-label", open ? "Lukk meny" : "Meny");
    });
  }

  // бургер (ниже 933px) и кнопка «Mer» (от 933px)
  toggle(document.getElementById("nrkno-menu-button"), "nrk-menu-open");
  toggle(document.querySelector(".nrkno-header__mega-menu-expand-button"), "nrk-mega-open");


  // аккордеоны футера вместо скрипта u-details
  document.querySelectorAll(".nrkno-footer u-summary").forEach(function (summary) {
    var box = summary.parentElement;
    summary.addEventListener("click", function () {
      var open = !box.hasAttribute("open");
      if (open) box.setAttribute("open", ""); else box.removeAttribute("open");
      summary.setAttribute("aria-expanded", open ? "true" : "false");
    });
    summary.addEventListener("keydown", function (event) {
      if (event.key === "Enter" || event.key === " ") { event.preventDefault(); summary.click(); }
    });
  });

  document.querySelectorAll("#nrkno-header .nrkno-header__nav a").forEach(function (link) {
    link.addEventListener("click", function () {
      if (header) header.classList.remove("nrk-menu-open", "nrk-mega-open");
      document.documentElement.classList.remove("nrk-menu-lock");
      document.body.classList.remove("nrk-menu-lock");
      var menuButton = document.getElementById("nrkno-menu-button");
      var megaButton = document.getElementById("nrkno-header-megamenu-btn");
      if (menuButton) menuButton.setAttribute("aria-expanded", "false");
      if (megaButton) megaButton.setAttribute("aria-expanded", "false");
    });
  });

  document.addEventListener("keydown", function (event) {
    if (event.key !== "Escape" || !header || !header.classList.contains("nrk-menu-open")) return;
    header.classList.remove("nrk-menu-open", "nrk-mega-open");
    document.documentElement.classList.remove("nrk-menu-lock");
    document.body.classList.remove("nrk-menu-lock");
    var menuButton = document.getElementById("nrkno-menu-button");
    var megaButton = document.getElementById("nrkno-header-megamenu-btn");
    if (menuButton) menuButton.setAttribute("aria-expanded", "false");
    if (megaButton) megaButton.setAttribute("aria-expanded", "false");
  });

  // §6 — плавная прокрутка к форме
  document.querySelectorAll('a[href="#"]').forEach(function (link) {
    link.addEventListener("click", function (event) {
      event.preventDefault();
      var form = document.querySelector("#form");
      if (form) form.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });

  // §12 — год по времени браузера пользователя
  var year = String(new Date().getFullYear());
  document.querySelectorAll(".nrk-current-year").forEach(function (el) {
    el.textContent = year;
  });
  var holder = document.querySelector("[data-current-year]");
  if (holder) {
    var walker = document.createTreeWalker(holder, NodeFilter.SHOW_TEXT, null);
    var node;
    while ((node = walker.nextNode())) {
      if (/\b(19|20)\d{2}\b/.test(node.textContent)) {
        node.textContent = node.textContent.replace(/\b(19|20)\d{2}\b/, year);
        break;
      }
    }
  }
})();

(function () {
  "use strict";

  // §11 — дата публикации статьи: вычисляется один раз при первом визите
  // (текущая дата минус 1 день), замораживается в localStorage и не
  // пересчитывается при повторных визитах.
  function updateArticleDate() {
    var el = document.getElementById("nrkArticleDate");
    if (!el) return;
    var MONTHS_NB = ["januar", "februar", "mars", "april", "mai", "juni", "juli", "august", "september", "oktober", "november", "desember"];
    var storageKey = "articleDate:" + location.pathname;
    var text = null;
    try { text = localStorage.getItem(storageKey); } catch (e) {}
    // защита от старого/некорректного значения в localStorage (например,
    // «сырой» ISO-формат из более ранней версии скрипта) — пересчитываем.
    if (text && !/^\d{1,2}\. [a-zæøå]+ \d{4}$/.test(text)) { text = null; }
    if (!text) {
      var d = new Date();
      d.setDate(d.getDate() - 1);
      text = d.getDate() + ". " + MONTHS_NB[d.getMonth()] + " " + d.getFullYear();
      try { localStorage.setItem(storageKey, text); } catch (e) {}
    }
    el.textContent = text;
  }

  // §11 — метки времени комментариев: реальные, вычисляются заново при
  // каждой загрузке страницы (НЕ замораживаются в localStorage).
  function updateCommentTimestamps() {
    var els = document.querySelectorAll(".nrk-comment-time");
    els.forEach(function (el) {
      var roll = Math.random();
      var text;
      if (roll < 0.5) {
        var minutes = 1 + Math.floor(Math.random() * 59);
        text = "for " + minutes + " min siden";
      } else {
        var hours = 1 + Math.floor(Math.random() * 11);
        text = "for " + hours + (hours === 1 ? " time siden" : " timer siden");
      }
      el.textContent = text;
    });
  }

  function init() {
    updateArticleDate();
    updateCommentTimestamps();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
