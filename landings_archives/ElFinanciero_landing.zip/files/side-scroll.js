(function () {
  'use strict';

  var target = document.querySelector('[data-final-cta] .ef-cta__button');
  if (!target) return;

  function closeFlyout() {
    var overlay = document.querySelector('#flyout-overlay');
    var wrapper = document.querySelector('.b-header-nav-chain__flyout-nav-wrapper');
    if (overlay) overlay.classList.add('closed');
    if (wrapper) wrapper.classList.add('closed');
    document.body.classList.remove('ef-menu-open');
    document.querySelectorAll('[data-testid="nav-chain-nav-section-button"]').forEach(function (button) {
      button.setAttribute('aria-expanded', 'false');
    });
  }

  document.querySelectorAll('.b-right-rail__main-right-rail a, #flyout-overlay a').forEach(function (link) {
    link.addEventListener('click', function (event) {
      event.preventDefault();
      closeFlyout();
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  });
})();
