(function () {
  'use strict';

  // Гамбургер. На сайте меню открывает скрипт Fusion, он вырезан (§13),
  // поэтому поведение восстановлено вручную: снимаем класс closed
  // с выезжающей панели и затемнения. Кнопок две — десктопная и мобильная.
  var wrap = document.querySelector('.b-header-nav-chain__flyout-nav-wrapper');
  var overlay = document.querySelector('.b-header-nav-chain__flyout-overlay');
  function setMenu(open) {
    if (wrap) wrap.classList.toggle('closed', !open);
    if (overlay) overlay.classList.toggle('closed', !open);
    document.querySelectorAll('[data-testid="nav-chain-nav-section-button"]').forEach(function (b) {
      b.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.body.classList.toggle('ef-menu-open', open);
  }
  document.querySelectorAll('[data-testid="nav-chain-nav-section-button"]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      setMenu(wrap ? wrap.classList.contains('closed') : true);
    });
  });
  if (overlay) overlay.addEventListener('click', function () { setMenu(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });

  // Раскрытие подразделов внутри меню (Televisión, Opinión и т.д.)
  document.querySelectorAll('button[aria-controls^="header_sub_section_"]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      var box = document.getElementById(btn.getAttribute('aria-controls'));
      var open = btn.getAttribute('aria-expanded') !== 'true';
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (box) box.hidden = !open;
    });
  });

  // §11 — дата публикации: текущая минус один день, фиксируется в localStorage,
  // чтобы у одного посетителя она не пересчитывалась при каждой загрузке.
  var KEY = 'ef_pub_date';
  function pubDate() {
    var saved = null;
    try { saved = localStorage.getItem(KEY); } catch (e) {}
    if (saved) {
      var d = new Date(saved);
      if (!isNaN(d.getTime())) return d;
    }
    var d2 = new Date();
    d2.setDate(d2.getDate() - 1);
    try { localStorage.setItem(KEY, d2.toISOString()); } catch (e) {}
    return d2;
  }
  var MES = ['enero','febrero','marzo','abril','mayo','junio',
             'julio','agosto','septiembre','octubre','noviembre','diciembre'];
  document.querySelectorAll('[data-pub-date]').forEach(function (el) {
    var d = pubDate();
    el.textContent = d.getDate() + ' de ' + MES[d.getMonth()] + ' de ' + d.getFullYear();
  });

  // §11 — год в подвале: просто актуальный, по времени браузера, без фиксации
  document.querySelectorAll('[data-current-year]').forEach(function (holder) {
    var year = String(new Date().getFullYear());
    var walker = document.createTreeWalker(holder, NodeFilter.SHOW_TEXT, null);
    var node;
    while ((node = walker.nextNode())) {
      if (/\b(19|20)\d{2}\b/.test(node.textContent)) {
        node.textContent = node.textContent.replace(/\b(19|20)\d{2}\b/, year);
        break;
      }
    }
  });
})();
