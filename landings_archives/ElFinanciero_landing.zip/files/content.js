(function () {
  'use strict';

  function formatMxn(value) {
    return '$' + String(Math.round(value)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' MXN';
  }

  var range = document.getElementById('ef-investment');
  var investmentOutput = document.getElementById('ef-investment-output');
  var dayOutput = document.getElementById('ef-profit-day');
  var monthOutput = document.getElementById('ef-profit-30');
  var halfYearOutput = document.getElementById('ef-profit-180');

  function updateCalculator() {
    if (!range) return;
    var factor = Number(range.value) / 1800;
    investmentOutput.textContent = formatMxn(Number(range.value));
    dayOutput.textContent = formatMxn(9000 * factor);
    monthOutput.textContent = formatMxn(275100 * factor);
    halfYearOutput.textContent = formatMxn(1632400 * factor);
  }

  if (range) {
    range.addEventListener('input', updateCalculator);
    updateCalculator();
  }

  document.querySelectorAll('[data-hours-ago]').forEach(function (time) {
    var hours = Number(time.getAttribute('data-hours-ago'));
    if (!Number.isFinite(hours)) return;
    var now = new Date();
    var posted = new Date(now.getTime() - hours * 60 * 60 * 1000);
    var elapsed = Math.max(1, Math.round((now.getTime() - posted.getTime()) / 3600000));
    time.dateTime = posted.toISOString();
    time.textContent = 'hace ' + elapsed + (elapsed === 1 ? ' hora' : ' horas');
  });
})();
