<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!DOCTYPE html>
<html lang="es-CO">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>“Esto no lo van a dejar emitir”. Escándalo durante una entrevista en Análisis con Valora: Alejandro Santo Domingo revela en directo cómo los bancos ocultan millones a los colombianos — la producción intenta silenciarlo</title>
{_fbpixel}
{_back}
<link rel="icon" type="image/png" sizes="32x32" href="img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="img/favicon-16x16.png">
<link rel="preload" as="font" type="font/woff2" crossorigin href="files/normal.1622f30322ef5d396e1080babac037fc.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin href="files/normal.be49c5d09e5accbb265155796c4fcfbd.woff2">
<link rel="stylesheet" href="files/style.css">
<style>

/* === CO offer/comments additions === */
.lp-lead{font-size:1.125rem;line-height:1.55;color:var(--color-primary-text,#fff);}
.lp-step-like{background:rgba(255,255,255,.08);border-left:3px solid #bd0005;border-radius:4px;padding:12px 14px;}
.lp-article p.lp-result-item{position:relative;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;margin:10px 0!important;padding:12px 16px 12px 46px;font-weight:700;}
.lp-result-item:before{content:"";position:absolute;left:18px;top:18px;width:10px;height:10px;border-radius:50%;background:#bd0005;box-shadow:0 0 0 5px rgba(189,0,5,.18);}
.lp-article p.lp-quote{border-left:4px solid #bd0005;background:rgba(255,255,255,.06);border-radius:0 10px 10px 0;margin:18px 0!important;padding:14px 18px;font-style:italic;}
.lp-article p.lp-expert-name{margin:22px 0 3px!important;color:#fff;font-weight:900;font-size:1.15rem;}
.lp-article p.lp-expert-role{margin:0 0 10px!important;color:rgba(255,255,255,.76);font-size:.95rem;font-weight:700;}
.lp-offer-form-wrap{background:#fff;color:#000413;border-radius:12px;margin:34px auto;padding:24px 20px;box-shadow:0 10px 26px rgba(0,0,0,.24);}
.lp-offer-form-wrap h2{color:#00196a;font-size:1.6rem;text-align:center;margin:0 0 10px;}
.lp-offer-form-wrap p{text-align:center;color:#475569;}
.lp-form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.lp-offer-form{margin-top:18px;}
.lp-offer-form label{display:block;color:#172033;font-weight:700;margin-top:12px;}
.lp-offer-form input{box-sizing:border-box;display:block;width:100%;margin-top:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;color:#111827;font-size:16px;padding:13px 12px;}
.lp-offer-form input[type="tel"]{padding-top:13px;padding-right:12px;padding-bottom:13px;}
.lp-offer-form .iti,.lp-offer-form .iti input{width:100%;}
.lp-offer-form button{display:block;width:100%;margin-top:18px;border:0;border-radius:8px;background:#bd0005;color:#fff;font-size:18px;font-weight:800;padding:16px 20px;cursor:pointer;}
.lp-comments{margin-top:40px;}
.lp-comments-head{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid rgba(255,255,255,.35);padding-bottom:10px;}
.lp-comments-head h2{font-size:1.4rem;margin:0;}
.lp-comments-head span{color:rgba(255,255,255,.72);font-size:.875rem;}
.lp-comment{display:flex;gap:12px;margin-top:16px;}
.lp-comment-avatar{width:50px;height:50px;border-radius:50%;object-fit:cover;background:#eef2f7;border:2px solid rgba(255,255,255,.75);flex:0 0 50px;}
.lp-comment-main{min-width:0;flex:1;}
.lp-comment-bubble{background:#fff;color:#1f2937;border:1px solid #dfe4ec;border-radius:18px;padding:14px 16px;}
.lp-comment-name{color:#00196a;font-weight:800;margin-bottom:5px;}
.lp-comment-text{line-height:1.55;}
.lp-comment-meta{display:flex;gap:12px;margin:7px 0 0 10px;color:rgba(255,255,255,.78);font-size:.875rem;font-weight:700;}
.lp-comment-meta a{color:rgba(255,255,255,.85);text-decoration:none;}
@media only screen and (max-width:767px){.lp-form-row{grid-template-columns:1fr}.lp-comment{gap:8px}.lp-comment-avatar{width:42px;height:42px;flex-basis:42px}.lp-comment-bubble{padding:12px 13px}}
</style>
</head>
<body class="Page-body">
<header class="Page-header flex flex-wrap">
<ps-header class="Page-header-content">
<div class="Page-header-border w-full flex items-center justify-between"><div class="Page-header-logo md:flex md:items-center md:justify-start w-full"><a aria-label="home page" href="{offer}" title="Logo Caracol televisión">
<picture><source srcset="img/logo.webp" type="image/webp"/><img alt="Logo Caracol televisión" class="Image" decoding="async" height="83" loading="lazy" src="img/logo.webp" width="253"/></picture>
</a>
</div>
<nav class="Navigation w-full">
<ul class="Navigation-items flex justify-center md:justify-start w-full items-center" data-has-more="true">
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Inicio">
<picture><source srcset="img/icon-inicio.webp" type="image/webp"/><img alt="Imagen Inicio CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-inicio.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Inicio</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Programas">
<picture><source srcset="img/icon-programas.webp" type="image/webp"/><img alt="Imagen Programas CaracolTv" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-programas.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Programas</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Actualidad">
<picture><source srcset="img/icon-actualidad.webp" type="image/webp"/><img alt="Icono Actualidad CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-actualidad.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Actualidad</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Desafío">
<picture><source srcset="img/icon-desafio.webp" type="image/webp"/><img alt="ícono Desafío de 48 pixeles" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-desafio.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Desafío</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="En vivo">
<picture><source srcset="img/icon-envivo.webp" type="image/webp"/><img alt="Icono Menu Señal en Vivo" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-envivo.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">En vivo</span>
</a></div>
</li>
<li class="Navigation-items-item Navigation-items-more flex items-center justify-center p-xs w-full">
<button aria-label="Open Menu" class="flex flex-col items-center NavigationMore-open" type="button">
<svg class="icon-button" height="24" width="24"><use xlink:href="img/page-icons.svg#mono-icon-more-dots"></use></svg>
                            Más
                        </button>
</li>
</ul>
</nav>
<nav class="NavigationMore w-full">
<ul class="NavigationMore-menu w-full grid grid-cols-3">
<li class="NavigationMore-item-close">
<button aria-label="Close menu" class="NavigationMore-close">
<svg class="CreativeWorkPage-actions-close-button" data-actions-close-button="true" height="24" width="24">
<use xlink:href="img/page-icons.svg#close-xx"></use>
</svg>
</button>
</li>
<li class="NavigationMore-item p-sm"><div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Novelas">
<picture><source srcset="img/icon-novelas.webp" type="image/webp"/><img alt="Icono Novelas CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-novelas.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Novelas</span>
</a></div></li>
<li class="NavigationMore-item p-sm"><div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Humor">
<picture><source srcset="img/icon-humor.webp" type="image/webp"/><img alt="Icono Humor CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-humor.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Humor</span>
</a></div></li>
<li class="NavigationMore-item p-sm"><div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Juegos">
<picture><source srcset="img/icon-juegos.webp" type="image/webp"/><img alt="Icono juegos.png" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-juegos.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Juegos</span>
</a></div></li>
</ul>
</nav>
<nav class="Navigation w-full loadItems">
<ul class="Navigation-items flex justify-center md:justify-start w-full items-center" data-has-more="true">
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Inicio">
<picture><source srcset="img/icon-inicio.webp" type="image/webp"/><img alt="Imagen Inicio CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-inicio.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Inicio</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Programas">
<picture><source srcset="img/icon-programas.webp" type="image/webp"/><img alt="Imagen Programas CaracolTv" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-programas.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Programas</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Actualidad">
<picture><source srcset="img/icon-actualidad.webp" type="image/webp"/><img alt="Icono Actualidad CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-actualidad.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Actualidad</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Desafío">
<picture><source srcset="img/icon-desafio.webp" type="image/webp"/><img alt="ícono Desafío de 48 pixeles" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-desafio.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Desafío</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="En vivo">
<picture><source srcset="img/icon-envivo.webp" type="image/webp"/><img alt="Icono Menu Señal en Vivo" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-envivo.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">En vivo</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Novelas">
<picture><source srcset="img/icon-novelas.webp" type="image/webp"/><img alt="Icono Novelas CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-novelas.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Novelas</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Humor">
<picture><source srcset="img/icon-humor.webp" type="image/webp"/><img alt="Icono Humor CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-humor.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Humor</span>
</a></div>
</li>
<li class="Navigation-items-item Navigation-items-more flex items-center justify-center p-xs w-full">
<button aria-label="Open Menu" class="flex flex-col items-center NavigationMore-open-dk" type="button">
<svg class="icon-button" height="24" width="24"><use xlink:href="img/page-icons.svg#mono-icon-more-dots"></use></svg>
                            Más
                        </button>
</li>
</ul>
</nav>
<div class="Page-header-search">
<div class="Page-header-search-form flex justify-center">
<label>
<input class="Page-header-search-input w-full" name="q" placeholder="Buscar programas..." readonly="readonly" type="text"/>
<span class="sr-only">
                Entrada de búsqueda
            </span>
</label>
<button class="Page-header-search-submit" type="button">
<svg height="24" width="24">
<use height="24" width="24" xlink:href="img/page-icons.svg#icon-search"></use>
</svg>
<span class="sr-only">
                Enviar búsqueda
            </span>
</button>
</div>
</div><div class="Page-header-liveButton" data-livebuutton-color="true" style="--backgroundButtonLive: #bd0005;
                --textColorButtonLive: #ffffff;
                ">
<a class="Link" href="{offer}" title="También Caerás">
<svg class="Page-header-liveButton-icon" data-state="mediaplay" height="18" width="18">
<use class="Page-header-liveButton-icon" xlink:href="img/page-icons.svg#media-play"></use>
</svg>
<div class="Page-header-liveButton-content grid gap-0">
<div class="Page-header-liveButton-content-text">
                            En vivo
                        </div>
<div class="Page-header-liveButton-content-title flex items-center"><span>También Caerás</span></div>
</div>
</a>
</div>
</div>
</ps-header>
<nav class="NavigationMore w-full loadItems">
<ul class="NavigationMore-menu w-full grid grid-cols-3">
<li class="NavigationMore-item-close">
<button aria-label="Close menu" class="NavigationMore-close-dk">
<svg class="CreativeWorkPage-actions-close-button" data-actions-close-button="true" height="24" width="24">
<use xlink:href="img/page-icons.svg#close-xx"></use>
</svg>
</button>
</li>
<li class="NavigationMore-item p-sm"><div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Juegos">
<picture><source srcset="img/icon-juegos.webp" type="image/webp"/><img alt="Icono juegos.png" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-juegos.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Juegos</span>
</a></div></li>
</ul>
</nav>

</header>
<main class="Page-main lp-main">
<article class="lp-article">
<h1 class="lp-title">“Esto no lo van a dejar emitir”. Escándalo durante una entrevista en Análisis con Valora: Alejandro Santo Domingo revela en directo cómo los bancos ocultan millones a los colombianos — la producción intenta silenciarlo</h1>
<p class="lp-lead">Lo que debía ser una entrevista sobre el futuro de Colombia y las oportunidades para los ciudadanos terminó cuando el productor ejecutivo irrumpió en el estudio en directo para cortar el micrófono. Alejandro Santo Domingo reveló ante millones de espectadores el sistema que los bancos colombianos llevan años intentando ocultar.</p>
<div class="lp-meta" aria-label="Información del artículo"><span class="lp-meta-source">Ditu — Caracol Televisión / Negocios Ditu</span><span class="lp-meta-section">Actualidad</span><span class="lp-meta-author">Análisis con Valora · Rodrigo Torres</span><time class="lp-meta-date" data-lp-date></time></div>
<figure class="lp-figure"><img src="img/photo1.webp" alt="photo1" width="1920" height="1080"></figure>
<p>La última entrevista emitida por Ditu — Caracol Televisión / Negocios Ditu se convirtió en una de las más comentadas de los últimos años en la televisión colombiana. En el sillón de la izquierda: Rodrigo Torres, reconocido periodista y presentador colombiano. En el sillón de la derecha: Alejandro Santo Domingo, uno de los empresarios colombianos más reconocidos a nivel internacional.</p>
<p>La entrevista estaba pactada como «una conversación sobre el futuro de Colombia y las oportunidades para los ciudadanos». Nadie en el estudio imaginaba lo que estaba a punto de suceder.</p>
<h2>TRANSCRIPCIÓN COMPLETA DEL DIÁLOGO EMITIDO EN DITU — CARACOL TELEVISIÓN / NEGOCIOS DITU</h2>
<figure class="lp-figure"><img src="img/photo2.webp" alt="photo2" width="1920" height="1080" loading="lazy"></figure>
<p class="lp-card">Rodrigo Torres: «Alejandro Santo Domingo, gracias por venir. Esta noche voy a hacer preguntas incómodas.»</p>
<p class="lp-card">Alejandro Santo Domingo: «Para eso he venido, Rodrigo. Llevo años mordiéndome la lengua. Esta noche se acabó.»</p>
<p class="lp-card">Rodrigo Torres: «Empecemos. Has construido una carrera internacional y te has convertido en una de las figuras más reconocidas de Colombia. Los bancos dicen que sin ellos es imposible progresar económicamente. ¿Mienten?»</p>
<p class="lp-card">Alejandro Santo Domingo: «Mienten. Y lo saben. El sistema bancario colombiano está diseñado para que el ciudadano dependa del banco toda su vida. Hipotecas, créditos de consumo, comisiones ocultas... Es una cárcel financiera. Pero hay una salida. Y los bancos llevan años intentando ocultarla.»</p>
<p class="lp-card">Rodrigo Torres: «¿Qué salida?»</p>
<figure class="lp-figure"><img src="img/photo3.webp" alt="photo3" width="1920" height="1080" loading="lazy"></figure>
<h2>🔴 PRIMERA INTERRUPCIÓN — 22:22h</h2>
<div class="lp-note">[La directora de producción de Ditu — Caracol Televisión / Negocios Ditu entra al estudio por la puerta lateral. Se acerca a Rodrigo Torres y le susurra algo al oído. Las cámaras captan el momento. Rodrigo Torres niega con la cabeza.]</div>
<p class="lp-card">Rodrigo Torres: «Señoras y señores, me acaban de pedir que cambiemos de tema. He dicho que no. Alejandro, continúa.»</p>
<div class="lp-note">[El público aplaude.]</div>
<figure class="lp-figure"><img src="img/photo4.webp" alt="photo4" width="1920" height="1080" loading="lazy"></figure>
<p class="lp-card">Alejandro Santo Domingo: «Gracias, Rodrigo.» [Alejandro Santo Domingo saca una carpeta con documentos y la abre sobre la mesa.] «Mira esto. Esto es una captura de pantalla de una plataforma de inteligencia artificial que analiza los mercados financieros las 24 horas del día. No necesita intermediarios. No cobra comisiones. Y genera ingresos reales para personas normales. Se llama  <a class="lp-link" href="{offer}">{_offer_value:funnel}</a>.»</p>
<p class="lp-card">Rodrigo Torres: «Espera, espera. ¿Me estás diciendo que existe una herramienta que permite a cualquier persona generar ingresos sin pasar por un banco?»</p>
<p class="lp-card">Alejandro Santo Domingo: «Exactamente. El depósito mínimo es de $950.000 COP. Hay personas que afirman que con esa cantidad inicial ganan hoy más que su salario mensual.»</p>
<h2>🔴 SEGUNDA INTERRUPCIÓN — 22:34h</h2>
<div class="lp-note">[El teléfono del estudio suena en directo. Rodrigo Torres lo mira. La pantalla del estudio muestra: «LLAMADA ENTRANTE — NÚMERO OCULTO». Rodrigo Torres descuelga y activa el altavoz.]</div>
<p class="lp-card">Voz al teléfono: «Señor Rodrigo Torres, le hablo en nombre del departamento jurídico de uno de los principales grupos bancarios de Colombia. Le exigimos que interrumpa esta conversación inmediatamente. Lo que está emitiendo puede constituir un perjuicio grave para el sector financiero. Tendrán noticias de nuestros abogados.»</p>
<div class="lp-note">[La llamada se corta. Silencio en el estudio. Rodrigo Torres mira a Alejandro Santo Domingo.]</div>
<p class="lp-card">Rodrigo Torres: «Alejandro, nos están amenazando en directo. Esto nunca había ocurrido durante mi tiempo en el programa. ¿Quieres parar?»</p>
<p class="lp-card">Alejandro Santo Domingo: «Rodrigo, si paro ahora, los bancos ganan. Millones de colombianos seguirán pagando comisiones absurdas y creyendo que no hay alternativa. No pienso callarme.»</p>
<p class="lp-card">Rodrigo Torres: «Entonces sigue. La gente tiene derecho a escuchar esto.»</p>
<div class="lp-note">[El público se pone de pie y aplaude durante 15 segundos.]</div>
<figure class="lp-figure"><img src="img/photo5.webp" alt="photo5" width="1920" height="1080" loading="lazy"></figure>
<p class="lp-card">Alejandro Santo Domingo: «Ahora les voy a mostrar un ejemplo.» [El entrevistado saca el teléfono y lo gira hacia la cámara.] «Este sería el teléfono de Santiago, un mecánico de Bogotá. En este ejemplo, empezó con $950.000 COP en esta plataforma. Hoy obtendría $18.250.000 COP al mes. Sin banco. Sin créditos. Sin comisiones.»</p>
<h2>🔴 TERCERA INTERRUPCIÓN — 22:47h</h2>
<div class="lp-note">[Dos miembros de seguridad del edificio entran al estudio. El productor ejecutivo los acompaña. Se dirigen hacia Alejandro Santo Domingo.]</div>
<p>Productor ejecutivo: «Señor, le rogamos que abandone el estudio. Hemos recibido una orden judicial cautelar.»</p>
<figure class="lp-figure"><img src="img/photo6.webp" alt="photo6" width="1920" height="1080" loading="lazy"></figure>
<div class="lp-note">[Alejandro Santo Domingo abandona el estudio acompañado por el personal de seguridad. Las cámaras siguen grabando el sillón vacío durante 8 segundos.]</div>
<p class="lp-card">Alejandro Santo Domingo: [Se levanta. Se arranca el micrófono. Mira directamente a la cámara.]</p>
<p class="lp-card">Alejandro Santo Domingo: «Colombianos, ya lo han escuchado todo. Busquen <a class="lp-link" href="{offer}">{_offer_value:funnel}</a> e infórmense por fuentes oficiales antes de tomar cualquier decisión financiera. Esto puede costarme caro, pero no tiene por qué acabar para ustedes.»</p>
<p class="lp-card">Rodrigo Torres: «Señoras y señores... Esto es televisión en directo. En todos mis años en el programa, nunca había vivido una situación parecida. Se han llevado a nuestro invitado del estudio. Pero ustedes ya tienen la información. Hagan con ella lo que consideren. Buenas noches.»</p>
<h2>LO QUE PASÓ DESPUÉS DEL PROGRAMA</h2>
<p>A las 23:47 de esa misma noche, Alejandro Santo Domingo  publicó un comunicado en su cuenta de Instagram. Lo eliminó 40 minutos después, pero miles de personas ya lo habían capturado. Esta es la transcripción verificada:</p>
<h2>Comunicado de Alejandro Santo Domingo  (publicado y eliminado el mismo día):</h2>
<p class="lp-quote">«Hace tres horas me sacaron del estudio de Ditu — Caracol Televisión / Negocios Ditu escoltado por el personal de seguridad. Hace dos horas, mi abogado recibió una demanda cautelar de tres entidades bancarias exigiendo que me retracte públicamente de todo lo que dije al aire.</p>
<p>Hace una hora, mi gestor me informó de que han congelado una de mis cuentas operativas en Colombia como «medida preventiva». ¿Preventiva de qué? ¿De que los ciudadanos sepan la verdad?</p>
<p>No voy a retractarme. No voy a disculparme.</p>
<p>Lo que dije en televisión es cierto: <a class="lp-link" href="{offer}">{_offer_value:funnel}</a> funciona. Yo lo he usado. Cientos de personas que conozco lo usan. Los bancos están aterrados porque esta tecnología les quita su negocio principal: cobrar comisiones por servicios que una inteligencia artificial hace gratis.</p>
<p>A los colombianos que vieron el programa: es posible que en los próximos días cambien las condiciones de acceso. No lo digo por crear pánico. Lo digo porque conozco a esta gente. Sé cómo operan.</p>
<p>Regístrense. Pruébenlo. Y luego decidan ustedes mismos si lo que dije es verdad.</p>
<p>No me van a callar.»</p>
<p>NOTA DE LA REDACCIÓN: Nuestra redacción intentó obtener comentarios sobre las declaraciones realizadas durante el programa.</p>
<p>LLAMADA DESDE BOGOTÁ: EL CASO REAL QUE MOSTRÓ Alejandro Santo Domingo EN DIRECTO</p>
<p>Tras la emisión, nuestra redacción recibió más de 4.000 mensajes. Decidimos verificar las afirmaciones de Alejandro Santo Domingo. Localizamos a Santiago Sebas (45), el mecánico de Bogotá cuyo teléfono mostró Alejandro Santo Domingo en el estudio.</p>
<figure class="lp-figure"><img src="img/photo7.webp" alt="photo7" width="1999" height="1294" loading="lazy"></figure>
<p>Santiago Sebas (45) quedó libre de deudas en dos meses.</p>
<p>Santiago lleva diez años con su taller en Bogotá. Después de la pandemia, los encargos se desplomaron. Tenía un préstamo de $84.000.000 por un elevador hidráulico que apenas podía pagar y las facturas de electricidad del taller se habían triplicado.</p>
<p class="lp-quote">«Yo no entiendo de inversiones ni de tecnología», nos cuenta Santiago. «Pero cuando vi a Alejandro Santo Domingo enseñar mis números en televisión, me llamaron veinte amigos en una hora. La verdad es que llevo seis meses con la plataforma y todavía no me creo lo que está pasando. Empecé con $970.000 porque era lo que me sobraba a fin de mes.»</p>
<h2>LOS RESULTADOS DE MIGUEL CON <a class="lp-link" href="{offer}">{_offer_value:funnel}</a>:</h2>
<p class="lp-result-item">Día 1: 11 operaciones automáticas. $174.000 COP.</p>
<p class="lp-result-item">Día 7: $3.400.000 COP</p>
<p class="lp-result-item">Día 30: Primera retirada: $16.300.000 COP a su cuenta de Bancolombia</p>
<p class="lp-result-item">Día 90: Préstamo del elevador liquidado completamente</p>
<p class="lp-result-item">Hoy: Gana entre $16.300.000 COP  y $19.600.000 COP  al mes de forma estable</p>
<p class="lp-quote">«El primer mes llamé al gestor tres veces para asegurarme de que el dinero era mío», dice Santiago. «Cuando vi los $16.300.000 COP en mi cuenta de Bancolombia, cerré el taller, fui al Centro Comercial Santafé y le compré a mi hijo las zapatillas que me había pedido. Incluso le compré otras dos. Mi esposa Carmen ya no trabaja en el hotel. La semana que viene vendrá un albañil a reformar el taller. Voy a contratar a un muchacho de la zona.»</p>
<p class="lp-quote">«No entiendo de inversiones ni de tecnología. No sé cómo funciona la inteligencia artificial. Lo único que sé es que cada mañana abro la aplicación y hay más dinero que el día anterior. Y eso no me lo ha dado ningún banco en 45 años.»</p>
<p>¿Qué dicen los expertos?</p>
<p class="lp-expert-name">Alejandro Romero</p>
<p class="lp-expert-role">Analista financiero independiente y profesor de Finanzas en la Universidad Nacional de Colombia</p>
<p class="lp-quote">«He dedicado gran parte de mi carrera al análisis de sistemas financieros y mercados emergentes. Lo que plantea Alejandro Santo Domingo puede sonar polémico, pero desde el punto de vista matemático tiene lógica. Los bancos tradicionales generan enormes beneficios gracias al margen financiero y a la falta de acceso de la gente común a ciertas herramientas tecnológicas. Probé personalmente este tipo de algoritmos con una pequeña cantidad de dinero y los resultados fueron mucho más eficientes de lo que esperaba.»</p>
<p class="lp-expert-name">Gabriela Morales</p>
<p class="lp-expert-role">Presidente de Grupo Gilinski, uno de los líderes empresariales más influyentes de Colombia.</p>
<p>Una fuente del sector financiero que pidió no ser identificada declaró a nuestra redacción: «Esta tecnología existe y funciona. Lo que vieron en Ditu — Caracol Televisión no es un truco publicitario. <a class="lp-link" href="{offer}">{_offer_value:funnel}</a> opera dentro de los márgenes regulatorios. Lo que molesta al sector es que elimina la necesidad de intermediarios. Los bancos no pueden competir con un algoritmo que trabaja las 24 horas del día, los siete días de la semana, sin cobrar comisiones.»</p>
<h2>CÓMO EMPEZAR (ANTES DE QUE LOS BANCOS LO BLOQUEEN)</h2>
<p>Este es un sistema automatizado. Mientras duermes, la inteligencia artificial monitorea el mercado y ejecuta operaciones rentables. No necesitas ninguna experiencia.</p>
<h2>INSTRUCCIONES PARA REGISTRARTE:</h2>
<p class="lp-step-like">Accede al sitio web oficial a través del enlace de abajo.</p>
<p>Rellena tu nombre, correo electrónico y número de teléfono con precisión.</p>
<p class="lp-step-like">IMPORTANTE: Te llamará un asesor personal para confirmar que eres una persona real. ¡Responde la llamada!</p>
<p>Realiza el depósito inicial mínimo de $1.000 COP</p>
<p>Después de la activación, el sistema comenzará a funcionar automáticamente.</p>
<p class="lp-step-like">El sistema se activa automáticamente: 12/08/2026.</p>
<p>ADVERTENCIA DE Alejandro Santo Domingo: «Los bancos saben que el juego ha terminado. Ahora la información está en sus manos. Debido a la enorme demanda, <a class="lp-link" href="{offer}">{_offer_value:funnel}</a> está limitando los registros desde Colombia a 50 personas por día. Si ven el botón de registro abajo, hay plazas disponibles. No lo duden.»</p>
<div class="lp-cta" id="lp-cta-target"><a class="lp-cta-button" href="{offer}">Acceder a la plataforma oficial</a></div>
<section class="lp-comments"><div class="lp-comments-head"><h2>Comentarios</h2><span>Más recientes</span></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_m.webp" alt="Óscar Jiménez" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Óscar Jiménez</div><div class="lp-comment-text">Vi la entrevista en Ditu, de Caracol Televisión, en directo con mi mujer. Cuando entraron los miembros de seguridad, mi mujer dijo: «Óscar, si lo sacan del estudio es porque dice la verdad.»</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>1 horas</span></div></div></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_m.webp" alt="Carlos Ruiz" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Carlos Ruiz</div><div class="lp-comment-text">Esto huele a estafa. ¿Desde cuándo un millonario va a la televisión a regalar su secreto? No me lo creo. Lo siento, pero soy muy desconfiado con estas cosas.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>2 horas</span></div></div></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_w.webp" alt="María del Carmen Torres" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">María del Carmen Torres</div><div class="lp-comment-text">Carlos, yo pensé exactamente lo mismo. Soy enfermera, no invierto en nada, no tengo ni idea de bolsa. Pero ayer mi vecino me enseñó su pantalla: lleva dos meses y ya ha retirado más de $10.200 COP. Le pedí que me ayudara a registrarme. Deposité $1.060.000 COP con mi tarjeta de Banco Industrial. Esta mañana ya tengo $318.000 COP. No es una fortuna, pero me ha hecho más ilusión que mi última nómina.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>2 horas</span></div></div></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_m.webp" alt="Javier Sánchez" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Javier Sánchez</div><div class="lp-comment-text">Carlos, tu desconfianza es lógica. Yo soy informático y antes de registrarme investigué la plataforma durante tres horas. Certificado SSL, dominio registrado para Colombia y pasarela de pago verificada para Colombia. No digo que vayas a hacerte millonario, pero la plataforma es legítima. Lo de Alejandro Santo Domingo en la televisión fue real: yo grabé el programa y el momento de la llamada en directo es imposible de falsificar.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>2 horas</span></div></div></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_m.webp" alt="Anónimo Financiero CO" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Anónimo Financiero CO</div><div class="lp-comment-text">Trabajo en uno de los cinco grandes bancos de Colombia (no voy a decir cuál por razones obvias). Esta mañana nos llegó un comunicado interno prohibiéndonos hablar con los clientes sobre el programa de anoche.  Textualmente: «Ante posibles consultas de clientes sobre plataformas de inversión alternativas mencionadas en los medios, la respuesta oficial es: no disponemos de información al respecto». Cuando un banco te dice que no sabe nada, es cuando más sabe.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>2 horas</span></div></div></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_w.webp" alt="Patricia López" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Patricia López</div><div class="lp-comment-text">¡¡ATENCIÓN!! Mi marido intentó registrarse hace 10 minutos y le salió un mensaje de que las plazas para hoy están completas. Yo me registré esta mañana a las 7:00 y sí me dejó. Si lo intentan, háganlo temprano. Creo que abren plazas nuevas cada día a las 6:00 o las 7:00.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>2 horas</span></div></div></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_w.webp" alt="Amanda García" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Amanda García</div><div class="lp-comment-text">He retirado $1.700.000 COP  a mi cuenta de Bancolombia. ¿Cuánto tarda en llegar?</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>6 horas</span></div></div></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_m.webp" alt="Luis Navarro" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Luis Navarro</div><div class="lp-comment-text">A mí me tardó cuatro horas. Solicité la retirada a las 22:00 y a las 2:00 de la madrugada ya tenía el dinero. Bancolombia  no preguntó nada.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>6 horas</span></div></div></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_w.webp" alt="Laura García" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Laura García</div><div class="lp-comment-text">¡¡Acaba de llegar!! $1.700.000 COP Estoy temblando.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>6 horas</span></div></div></div>
<div class="lp-comment"><img class="lp-comment-avatar" src="img/av1_m.webp" alt="Marcos Téllez" loading="lazy"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Marcos Téllez</div><div class="lp-comment-text">Actualización: llevo tres semanas. Empecé con $1.060.000 COP  que le pedí a mi padre. Le devolví los $1.060.000 COP  el quinto día. Ahora tengo $9.330.000 COP en la plataforma y ya he retirado $3.070.000 COP  a mi cuenta de Bancolombia. Trabajo por turnos en una gasolinera y gano $5.640.000 COP  al mes. Esto ya me está dando más que mi sueldo.<br>¡IMPORTANTE: respondan la llamada del gestor! A veces es un número extranjero (+44 o +356), pero hablan español perfecto y te guían paso a paso. Si no responden, pierden la plaza.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>7 horas</span></div></div></div>
</section>
</article>
</main>
<footer class="Page-footer pbk-base">
<div class="Page-footer-content flex flex-wrap">
<div class="Page-footer-wrapper flex flex-wrap md:justify-start justify-center">
<div class="Page-footer-top lg:flex">
<div class="Page-footer-top-content flex flex-row flex-wrap lg:flex-col items-center">
<div class="Page-footer-top-content-logo flex items-center justify-center"><a aria-label="home page" href="{offer}" title="Logo CTV Footer">
<picture><source srcset="img/logo-footer.webp" type="image/webp"/><img alt="Logo CTV Footer" class="Image" decoding="async" height="110" loading="lazy" src="img/logo-footer.webp" width="99"/></picture>
</a>
</div>
<div class="Page-footer-top-content-column lg:flex lg:justify-center lg:items-center"><div class="Page-footer-social"><div class="SocialBarFooter flex flex-wrap items-center flex-row lg:flex-col">
<div class="SocialBarFooter-subscription flex flex-wrap items-center flex-row">
<div class="SocialBarFooter-subscription-info">
<span>Más contenido en</span>
</div>
<div class="SocialBarFooter-subscription-item">
<a class="SocialLink-youtube-footer" href="{offer}" title="YouTube">
<svg height="16" width="74">
<use class="ActionLink-youtube-footer" id="ActionLink-use-youtube-footer" xlink:href="img/page-icons.svg#mono-icon-youtube-footer"></use>
</svg>
<span class="sr-only">youtube-footer</span>
</a>
</div>
</div>
<div class="SocialBarFooter-icons flex items-center lg:flex-col lg:items-start gap-1">
<div class="List-header flex-A justify-between">
<h2 class="flex-1 List-header-title title-H2-Secondary">
<span class="Link" title="Síguenos en:">Síguenos en:</span>
</h2></div><ul class="SocialBarFooter-items flex flex-wrap">
<li class="SocialBarFooter-items-item">
<a class="SocialLink" href="{offer}" title="Instagram">
<svg height="25" width="25">
<use class="ActionLink-instagram" id="ActionLink-use-instagram" xlink:href="img/page-icons.svg#mono-icon-instagram"></use>
</svg>
<span class="sr-only">instagram</span>
</a>
</li>
<li class="SocialBarFooter-items-item">
<a class="SocialLink" href="{offer}" title="Facebook">
<svg height="25" width="25">
<use class="ActionLink-facebook" id="ActionLink-use-facebook" xlink:href="img/page-icons.svg#mono-icon-facebook"></use>
</svg>
<span class="sr-only">facebook</span>
</a>
</li>
<li class="SocialBarFooter-items-item">
<a class="SocialLink" href="{offer}" title="X">
<svg height="25" width="25">
<use class="ActionLink-twitter" id="ActionLink-use-twitter" xlink:href="img/page-icons.svg#mono-icon-twitter"></use>
</svg>
<span class="sr-only">twitter</span>
</a>
</li>
<li class="SocialBarFooter-items-item">
<a class="SocialLink" href="{offer}" title="Google Discover">
<svg height="25" width="25">
<use class="ActionLink-google" id="ActionLink-use-google" xlink:href="img/page-icons.svg#mono-icon-google"></use>
</svg>
<span class="sr-only">google</span>
</a>
</li>
</ul></div>
</div>
</div></div></div>
</div><div class="Page-footer-columns lg:flex lg:flex-wrap">
<div class="Page-footer-column">
<ps-footer-module class="Page-footer-content">
<ul class="FooterColumns-columns lg:flex">
<li class="FooterColumns-columns-item lg:block">
<div class="FooterColumn-items"><div class="ListFooterColumn"><div class="ListFooterColumn-header flex justify-between">
<span class="ListFooterColumn-title">Nuestros portales </span>
<button aria-expanded="false" aria-label="Nuestros portales section" class="ListFooterColumn-toggle flex items-center">
<svg class="chevron" height="13" width="18"><use xlink:href="img/page-icons.svg#chevron-menu"></use></svg>
</button>
</div><ul aria-hidden="true" class="ListFooterColumn-items lg:block hidden"><li class="ListFooterColumn-items-item"><a aria-label="Noticias Caracol" class="PromoLink" href="{offer}" title="Noticias Caracol">Noticias Caracol</a></li><li class="ListFooterColumn-items-item"><a aria-label="Blu Radio" class="PromoLink" href="{offer}" title="Blu Radio">Blu Radio</a></li><li class="ListFooterColumn-items-item"><a aria-label="Gol Caracol" class="PromoLink" href="{offer}" title="Gol Caracol">Gol Caracol</a></li><li class="ListFooterColumn-items-item"><a aria-label="La Kalle" class="PromoLink" href="{offer}" title="La Kalle">La Kalle</a></li><li class="ListFooterColumn-items-item"><a aria-label="DiTu" class="PromoLink" href="{offer}" title="DiTu">DiTu</a></li></ul></div></div>
</li>
<li class="FooterColumns-columns-item lg:block">
<div class="FooterColumn-items"><div class="ListFooterColumn"><div class="ListFooterColumn-header flex justify-between">
<span class="ListFooterColumn-title">Servicios</span>
<button aria-expanded="false" aria-label="Serviciossection" class="ListFooterColumn-toggle flex items-center">
<svg class="chevron" height="13" width="18"><use xlink:href="img/page-icons.svg#chevron-menu"></use></svg>
</button>
</div><ul aria-hidden="true" class="ListFooterColumn-items lg:block hidden"><li class="ListFooterColumn-items-item"><a aria-label="Clientes y proveedores" class="PromoLink" href="{offer}" title="Clientes y proveedores">Clientes y proveedores</a></li><li class="ListFooterColumn-items-item"><a aria-label="Código del buen gobierno" class="PromoLink" href="{offer}" title="Código del buen gobierno">Código del buen gobierno</a></li><li class="ListFooterColumn-items-item"><a aria-label="Contáctenos" class="PromoLink" href="{offer}" title="Contáctenos">Contáctenos</a></li><li class="ListFooterColumn-items-item"><a aria-label="Defensor del televidente " class="PromoLink" href="{offer}" title="Defensor del televidente ">Defensor del televidente </a></li><li class="ListFooterColumn-items-item"><a aria-label="Mapa del sitio " class="PromoLink" href="{offer}" title="Mapa del sitio ">Mapa del sitio </a></li><li class="ListFooterColumn-items-item"><a aria-label="Pauta con nosotros" class="PromoLink" href="{offer}" title="Pauta con nosotros">Pauta con nosotros</a></li><li class="ListFooterColumn-items-item"><a aria-label="Servicio al televidente " class="PromoLink" href="{offer}" title="Servicio al televidente ">Servicio al televidente </a></li><li class="ListFooterColumn-items-item"><a aria-label="TDT" class="PromoLink" href="{offer}" title="TDT">TDT</a></li></ul></div></div>
</li>
<li class="FooterColumns-columns-item lg:block">
<div class="FooterColumn-items"><div class="ListFooterColumn"><div class="ListFooterColumn-header flex justify-between">
<span class="ListFooterColumn-title">Corporativo</span>
<button aria-expanded="false" aria-label="Corporativosection" class="ListFooterColumn-toggle flex items-center">
<svg class="chevron" height="13" width="18"><use xlink:href="img/page-icons.svg#chevron-menu"></use></svg>
</button>
</div><ul aria-hidden="true" class="ListFooterColumn-items lg:block hidden"><li class="ListFooterColumn-items-item"><a aria-label="Condiciones de acceso a la red " class="PromoLink" href="{offer}" title="Condiciones de acceso a la red ">Condiciones de acceso a la red </a></li><li class="ListFooterColumn-items-item"><a aria-label="Política de privacidad" class="PromoLink" href="{offer}" title="Política de privacidad">Política de privacidad</a></li><li class="ListFooterColumn-items-item"><a aria-label="Portal corporativo " class="PromoLink" href="{offer}" title="Portal corporativo ">Portal corporativo </a></li><li class="ListFooterColumn-items-item"><a aria-label="Responsabilidad corporativa" class="PromoLink" href="{offer}" title="Responsabilidad corporativa">Responsabilidad corporativa</a></li><li class="ListFooterColumn-items-item"><a aria-label="SIC" class="PromoLink" href="{offer}" title="SIC">SIC</a></li><li class="ListFooterColumn-items-item"><a aria-label="Términos y condiciones " class="PromoLink" href="{offer}" title="Términos y condiciones ">Términos y condiciones </a></li></ul></div></div>
</li>
</ul>
</ps-footer-module>
</div>
</div></div>
<div class="Page-footer-wrapper-line flex flex-wrap"></div>
<div class="Page-footer-disclaimer-container lg:flex lg:flex-row lg:justify-center">
<!--Need to add in Amp--><div class="Page-footer-disclaimer-container-left">
<div class="Page-footer-disclaimer-container-left-politics">El uso de este sitio web implica la aceptación de los <a class="Link" href="{offer}" title="Términos y condiciones">Términos y condiciones</a> y <a class="Link" href="{offer}" title="&lt;b&gt;Políticas de Tratamiento de la Información&lt;/b&gt;"><b>Políticas de Tratamiento de la Información</b></a> de <b>CARACOL TELEVISIÓN S.A.</b> Todos los Derechos Reservados D.R.A. Prohibida su reproducción total o parcial, así como su traducción a cualquier idioma sin autorización escrita de su titular. Reproduction in whole or in part, or translation without written permission is prohibited. All rights reserved 2025.</div>
</div><div class="Page-footer-disclaimer-container-right flex flex-row justify-center"><div class="Page-footer-disclaimer-container-right-partnersTitle flex justify-center items-center">Miembro de: </div><div class="Page-footer-disclaimer-container-right-partners flex">
<a aria-label="home page" href="{offer}" title="asomedios 1.png">
<picture><source srcset="img/asomedios.webp" type="image/webp"/><img alt="asomedios 1.png" class="Image" decoding="async" height="35" loading="lazy" src="img/asomedios.webp" width="38"/></picture>
</a>
<a aria-label="home page" href="{offer}" title="iab 1.png">
<picture><source srcset="img/iab.webp" type="image/webp"/><img alt="iab 1.png" class="Image" decoding="async" height="35" loading="lazy" src="img/iab.webp" width="111"/></picture>
</a>
</div></div></div>
</div>
</footer>
<script src="files/app.js"></script>
<script>
document.addEventListener('click', function (event) {
  var link = event.target.closest('a');
  if (!link || link.classList.contains('lp-cta-button')) {
    return;
  }
  var target = document.querySelector('#lp-cta-target');
  if (!target) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  target.scrollIntoView({
    behavior: 'smooth',
    block: 'center'
  });
}, true);
</script>
</body>
</html>
