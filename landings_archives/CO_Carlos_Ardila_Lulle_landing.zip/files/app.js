(function () {
  "use strict";

  var root = document.documentElement;

  /* ---- меню "Más" в шапке ---- */
  function setMenu(open) {
    if (open) {
      root.setAttribute("toggle-options", "true");
    } else {
      root.removeAttribute("toggle-options");
    }
  }

  document.querySelectorAll(".NavigationMore-open, .NavigationMore-open-dk").forEach(function (btn) {
    btn.addEventListener("click", function () {
      setMenu(!root.hasAttribute("toggle-options"));
    });
  });

  document.querySelectorAll(".NavigationMore-close").forEach(function (btn) {
    btn.addEventListener("click", function () {
      setMenu(false);
    });
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") setMenu(false);
  });

  /* ---- раскрывающиеся колонки подвала (мобильная версия) ---- */
  document.querySelectorAll(".ListFooterColumn-toggle").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var column = btn.closest(".ListFooterColumn");
      if (!column) return;
      var list = column.querySelector(".ListFooterColumn-items");
      if (!list) return;
      var willOpen = list.classList.contains("hidden");
      list.classList.toggle("hidden", !willOpen);
      list.setAttribute("aria-hidden", willOpen ? "false" : "true");
      btn.setAttribute("aria-expanded", willOpen ? "true" : "false");
      var chevron = btn.querySelector(".chevron");
      if (chevron) chevron.style.transform = willOpen ? "rotate(-90deg)" : "";
    });
  });

  /* ---- дата публикации статьи: текущая минус 1 день, фиксируется у посетителя ---- */
  var dateNodes = document.querySelectorAll("[data-lp-date]");
  if (dateNodes.length) {
    var KEY = "lp_pubdate";
    var stored = null;
    try {
      stored = window.localStorage.getItem(KEY);
    } catch (e) {
      stored = null;
    }
    var published;
    if (stored && !isNaN(new Date(stored).getTime())) {
      published = new Date(stored);
    } else {
      published = new Date();
      published.setDate(published.getDate() - 1);
      try {
        window.localStorage.setItem(KEY, published.toISOString());
      } catch (e) {}
    }
    var formatted = published.toLocaleDateString(document.documentElement.lang || undefined, {
      day: "numeric",
      month: "long",
      year: "numeric"
    });
    dateNodes.forEach(function (node) {
      node.textContent = formatted;
      node.setAttribute("datetime", published.toISOString().slice(0, 10));
    });
  }
})();
