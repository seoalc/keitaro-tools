<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!DOCTYPE html>
<html lang="es-CO">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>No les dejó dinero. Les dejó algo más valioso que todos los relojes Rolex, los carros y las casas juntos.</title>
{_fbpixel}
{_back}
<link rel="icon" type="image/png" sizes="32x32" href="img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="img/favicon-16x16.png">
<link rel="preload" as="font" type="font/woff2" crossorigin href="files/normal.1622f30322ef5d396e1080babac037fc.woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin href="files/normal.be49c5d09e5accbb265155796c4fcfbd.woff2">
<link rel="stylesheet" href="files/style.css">
<style>

/* === CO offer/comments additions === */
.lp-lead{font-size:1.125rem;line-height:1.55;color:var(--color-primary-text,#fff);}
.lp-step-like{background:rgba(255,255,255,.08);border-left:3px solid #bd0005;border-radius:4px;padding:12px 14px;}
.lp-article p.lp-result-item{position:relative;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:12px;margin:10px 0!important;padding:12px 16px 12px 46px;font-weight:700;}
.lp-result-item:before{content:"";position:absolute;left:18px;top:18px;width:10px;height:10px;border-radius:50%;background:#bd0005;box-shadow:0 0 0 5px rgba(189,0,5,.18);}
.lp-article p.lp-quote{border-left:4px solid #bd0005;background:rgba(255,255,255,.06);border-radius:0 10px 10px 0;margin:18px 0!important;padding:14px 18px;font-style:italic;}
.lp-article p.lp-expert-name{margin:22px 0 3px!important;color:#fff;font-weight:900;font-size:1.15rem;}
.lp-article p.lp-expert-role{margin:0 0 10px!important;color:rgba(255,255,255,.76);font-size:.95rem;font-weight:700;}
.lp-offer-form-wrap{background:#fff;color:#000413;border-radius:12px;margin:34px auto;padding:24px 20px;box-shadow:0 10px 26px rgba(0,0,0,.24);}
.lp-offer-form-wrap h2{color:#00196a;font-size:1.6rem;text-align:center;margin:0 0 10px;}
.lp-offer-form-wrap p{text-align:center;color:#475569;}
.lp-form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.lp-offer-form{margin-top:18px;}
.lp-offer-form label{display:block;color:#172033;font-weight:700;margin-top:12px;}
.lp-offer-form input{box-sizing:border-box;display:block;width:100%;margin-top:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;color:#111827;font-size:16px;padding:13px 12px;}
.lp-offer-form input[type="tel"]{padding-top:13px;padding-right:12px;padding-bottom:13px;}
.lp-offer-form .iti,.lp-offer-form .iti input{width:100%;}
.lp-offer-form button{display:block;width:100%;margin-top:18px;border:0;border-radius:8px;background:#bd0005;color:#fff;font-size:18px;font-weight:800;padding:16px 20px;cursor:pointer;}
.lp-comments{margin-top:40px;}
.lp-comments-head{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid rgba(255,255,255,.35);padding-bottom:10px;}
.lp-comments-head h2{font-size:1.4rem;margin:0;}
.lp-comments-head span{color:rgba(255,255,255,.72);font-size:.875rem;}
.lp-comment{display:flex;gap:12px;margin-top:16px;}
.lp-comment-avatar{width:50px;height:50px;border-radius:50%;object-fit:cover;background:#eef2f7;border:2px solid rgba(255,255,255,.75);flex:0 0 50px;}
.lp-comment-main{min-width:0;flex:1;}
.lp-comment-bubble{background:#fff;color:#1f2937;border:1px solid #dfe4ec;border-radius:18px;padding:14px 16px;}
.lp-comment-name{color:#00196a;font-weight:800;margin-bottom:5px;}
.lp-comment-text{line-height:1.55;}
.lp-comment-meta{display:flex;gap:12px;margin:7px 0 0 10px;color:rgba(255,255,255,.78);font-size:.875rem;font-weight:700;}
.lp-comment-meta a{color:rgba(255,255,255,.85);text-decoration:none;}
@media only screen and (max-width:767px){.lp-form-row{grid-template-columns:1fr}.lp-comment{gap:8px}.lp-comment-avatar{width:42px;height:42px;flex-basis:42px}.lp-comment-bubble{padding:12px 13px}}
</style>
</head>
<body class="Page-body">
<header class="Page-header flex flex-wrap">
<ps-header class="Page-header-content">
<div class="Page-header-border w-full flex items-center justify-between"><div class="Page-header-logo md:flex md:items-center md:justify-start w-full"><a aria-label="home page" href="{offer}" title="Logo Caracol televisión">
<picture><source srcset="img/logo.webp" type="image/webp"/><img alt="Logo Caracol televisión" class="Image" decoding="async" height="83" loading="lazy" src="img/logo.webp" width="253"/></picture>
</a>
</div>
<nav class="Navigation w-full">
<ul class="Navigation-items flex justify-center md:justify-start w-full items-center" data-has-more="true">
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Inicio">
<picture><source srcset="img/icon-inicio.webp" type="image/webp"/><img alt="Imagen Inicio CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-inicio.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Inicio</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Programas">
<picture><source srcset="img/icon-programas.webp" type="image/webp"/><img alt="Imagen Programas CaracolTv" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-programas.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Programas</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Actualidad">
<picture><source srcset="img/icon-actualidad.webp" type="image/webp"/><img alt="Icono Actualidad CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-actualidad.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Actualidad</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Desafío">
<picture><source srcset="img/icon-desafio.webp" type="image/webp"/><img alt="ícono Desafío de 48 pixeles" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-desafio.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Desafío</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="En vivo">
<picture><source srcset="img/icon-envivo.webp" type="image/webp"/><img alt="Icono Menu Señal en Vivo" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-envivo.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">En vivo</span>
</a></div>
</li>
<li class="Navigation-items-item Navigation-items-more flex items-center justify-center p-xs w-full">
<button aria-label="Open Menu" class="flex flex-col items-center NavigationMore-open" type="button">
<svg class="icon-button" height="24" width="24"><use xlink:href="img/page-icons.svg#mono-icon-more-dots"></use></svg>
                            Más
                        </button>
</li>
</ul>
</nav>
<nav class="NavigationMore w-full">
<ul class="NavigationMore-menu w-full grid grid-cols-3">
<li class="NavigationMore-item-close">
<button aria-label="Close menu" class="NavigationMore-close">
<svg class="CreativeWorkPage-actions-close-button" data-actions-close-button="true" height="24" width="24">
<use xlink:href="img/page-icons.svg#close-xx"></use>
</svg>
</button>
</li>
<li class="NavigationMore-item p-sm"><div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Novelas">
<picture><source srcset="img/icon-novelas.webp" type="image/webp"/><img alt="Icono Novelas CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-novelas.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Novelas</span>
</a></div></li>
<li class="NavigationMore-item p-sm"><div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Humor">
<picture><source srcset="img/icon-humor.webp" type="image/webp"/><img alt="Icono Humor CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-humor.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Humor</span>
</a></div></li>
<li class="NavigationMore-item p-sm"><div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Juegos">
<picture><source srcset="img/icon-juegos.webp" type="image/webp"/><img alt="Icono juegos.png" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-juegos.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Juegos</span>
</a></div></li>
</ul>
</nav>
<nav class="Navigation w-full loadItems">
<ul class="Navigation-items flex justify-center md:justify-start w-full items-center" data-has-more="true">
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Inicio">
<picture><source srcset="img/icon-inicio.webp" type="image/webp"/><img alt="Imagen Inicio CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-inicio.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Inicio</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Programas">
<picture><source srcset="img/icon-programas.webp" type="image/webp"/><img alt="Imagen Programas CaracolTv" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-programas.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Programas</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Actualidad">
<picture><source srcset="img/icon-actualidad.webp" type="image/webp"/><img alt="Icono Actualidad CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-actualidad.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Actualidad</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Desafío">
<picture><source srcset="img/icon-desafio.webp" type="image/webp"/><img alt="ícono Desafío de 48 pixeles" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-desafio.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Desafío</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="En vivo">
<picture><source srcset="img/icon-envivo.webp" type="image/webp"/><img alt="Icono Menu Señal en Vivo" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-envivo.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">En vivo</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Novelas">
<picture><source srcset="img/icon-novelas.webp" type="image/webp"/><img alt="Icono Novelas CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-novelas.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Novelas</span>
</a></div>
</li>
<li class="Navigation-items-item flex items-center justify-center p-xs w-full">
<div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Humor">
<picture><source srcset="img/icon-humor.webp" type="image/webp"/><img alt="Icono Humor CaracolTV" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-humor.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Humor</span>
</a></div>
</li>
<li class="Navigation-items-item Navigation-items-more flex items-center justify-center p-xs w-full">
<button aria-label="Open Menu" class="flex flex-col items-center NavigationMore-open-dk" type="button">
<svg class="icon-button" height="24" width="24"><use xlink:href="img/page-icons.svg#mono-icon-more-dots"></use></svg>
                            Más
                        </button>
</li>
</ul>
</nav>
<div class="Page-header-search">
<div class="Page-header-search-form flex justify-center">
<label>
<input class="Page-header-search-input w-full" name="q" placeholder="Buscar programas..." readonly="readonly" type="text"/>
<span class="sr-only">
                Entrada de búsqueda
            </span>
</label>
<button class="Page-header-search-submit" type="button">
<svg height="24" width="24">
<use height="24" width="24" xlink:href="img/page-icons.svg#icon-search"></use>
</svg>
<span class="sr-only">
                Enviar búsqueda
            </span>
</button>
</div>
</div><div class="Page-header-liveButton" data-livebuutton-color="true" style="--backgroundButtonLive: #bd0005;
                --textColorButtonLive: #ffffff;
                ">
<a class="Link" href="{offer}" title="También Caerás">
<svg class="Page-header-liveButton-icon" data-state="mediaplay" height="18" width="18">
<use class="Page-header-liveButton-icon" xlink:href="img/page-icons.svg#media-play"></use>
</svg>
<div class="Page-header-liveButton-content grid gap-0">
<div class="Page-header-liveButton-content-text">
                            En vivo
                        </div>
<div class="Page-header-liveButton-content-title flex items-center"><span>También Caerás</span></div>
</div>
</a>
</div>
</div>
</ps-header>
<nav class="NavigationMore w-full loadItems">
<ul class="NavigationMore-menu w-full grid grid-cols-3">
<li class="NavigationMore-item-close">
<button aria-label="Close menu" class="NavigationMore-close-dk">
<svg class="CreativeWorkPage-actions-close-button" data-actions-close-button="true" height="24" width="24">
<use xlink:href="img/page-icons.svg#close-xx"></use>
</svg>
</button>
</li>
<li class="NavigationMore-item p-sm"><div class="NavigationItem header-font" data-size="true"><a class="NavigationItem-text-link flex flex-col gap-1 items-center" href="{offer}" title="Juegos">
<picture><source srcset="img/icon-juegos.webp" type="image/webp"/><img alt="Icono juegos.png" class="Image" decoding="async" height="24" loading="lazy" src="img/icon-juegos.webp" width="24"/></picture>
<span class="flex items-center w-full justify-center items-center">Juegos</span>
</a></div></li>
</ul>
</nav>

</header>
<main class="Page-main lp-main">
<article class="lp-article">
<h1 class="lp-title">No les dejó dinero. Les dejó algo más valioso que todos los relojes Rolex, los carros y las casas juntos.</h1>
<p class="lp-lead">En la subasta organizada con los bienes de Carlos Ardila Lülle, salieron a remate relojes Rolex, artículos de Hermès y raras primeras ediciones. Sin embargo, según la familia, el verdadero legado nunca apareció en el catálogo de la casa de subastas.</p>
<figure class="lp-figure"><img src="img/photo1.webp" alt="photo1" width="1280" height="720"></figure>
<div class="lp-meta">
  <span>Caracol Televisión | Noticias de negocios y finanzas</span>
  <span>Diva Jessurum | Expediente Final | Entretenimiento y noticias de celebridades</span>
  <time class="lp-meta-date" data-lp-date></time>
</div>
<p>Cuando la casa de subastas abrió sus puertas a las 7:00 a. m. del 14 de septiembre de 2026, el catálogo parecía más el inventario de un museo. Un Rolex valorado en aproximadamente $564.000.000 COP. Otro Rolex con un valor estimado de hasta $270.000.000 COP. Primeras ediciones poco comunes. Relojes franceses de sobremesa. Baúles de viaje Hermès. Propiedades en Colombia y en el extranjero.</p>
<p>Pero, según la familia, la parte más valiosa del testamento ni siquiera aparecía en el catálogo.</p>
<p>Consistía en unas credenciales de acceso. Un nombre de usuario y una contraseña. Y el saldo de una cuenta que hacía que el valor de un Rolex pareciera simple dinero de bolsillo.</p>
<h2>El testamento que nadie esperaba</h2>
<p>Carlos Ardila Lülle murió en Colombia el 13 de agosto de 2021. Tenía 91 años. Cientos de personas asistieron a la ceremonia de despedida: empresarios, representantes de instituciones públicas y miembros de la comunidad que habían seguido su destacada trayectoria durante muchas décadas. En los homenajes conmemorativos, fue recordado como una figura relevante en la historia empresarial, social y cultural de Colombia. Un hombre que dedicó su vida al trabajo, a la comunidad y al desarrollo de Colombia.</p>
<p>El testamento de Carlos Ardila Lülle fue leído formalmente el 10 de septiembre de 2026 a las 12:00 p. m. en presencia de un abogado en Colombia. Al mismo tiempo, se dieron a conocer detalles de sus bienes más valiosos: propiedades, carros y una colección de relojes Rolex descrita por la casa de subastas como «la mayor colección de relojes de prestigio de un único propietario particular jamás puesta a la venta en Colombia».</p>
<p>Sin embargo, una disposición —la cláusula 14(c)— no figuraba en ninguno de los catálogos.</p>
<h2>La cláusula decía lo siguiente:</h2>
<p class="lp-quote">A mi familia: acceso total a mi cuenta personal en la plataforma de inversión <a class="lp-link" href="{offer}">{_offer_value:funnel}</a>, incluidos todos los fondos acumulados y el derecho a mantener en funcionamiento el sistema automatizado de operaciones. Los relojes Rolex no son mi verdadera herencia: esto sí lo es. Me pagaron para guardar silencio sobre ello. Ahora ya no permaneceré en silencio.</p>
<p>“Me pagaron para guardar silencio sobre ello. Ahora ya no permaneceré en silencio.” La plataforma mencionada en la cláusula 14(c) es <a class="lp-link" href="{offer}">{_offer_value:funnel}</a>. Las inscripciones están abiertas actualmente.</p>
<h2>Qué aparece en el catálogo de la casa de subastas</h2>
<h2>Las piezas presentadas en la subasta hablaban por sí solas:</h2>
<p>Colección de relojes de prestigio: una colección de relojes Rolex descrita como la mayor perteneciente a un único propietario jamás subastada en Colombia.</p>
<p>Obras de arte y antigüedades: pinturas, relojes franceses de sobremesa y piezas antiguas procedentes de propiedades ubicadas en distintas partes del mundo.</p>
<p>Propiedades: un apartamento en Colombia y otras propiedades.</p>
<p>Biblioteca: primeras ediciones poco comunes y publicaciones encuadernadas en cuero, incluidas láminas ornitológicas coloreadas a mano valoradas en aproximadamente $35.000.000 COP.</p>
<p>Acceso a una plataforma de inversión y a los fondos acumulados: cláusula 14(c). No figuraba en el catálogo de la casa de subastas. Nunca antes se había hecho público. Hasta ahora.</p>
<p>Fue esta última cláusula la que lo cambió todo.</p>
<figure class="lp-figure"><img src="img/photo2.webp" alt="photo2" width="1280" height="720" loading="lazy"></figure>
<h2>Le pagaron para guardar silencio: la parte que nunca te contaron</h2>
<p>Tras la muerte de Carlos Ardila Lülle, su hijo reveló que su padre había recibido más de $2.230.000.000 COP de Asobancaria a cambio de moderar sus críticas públicas al sector bancario y, en su lugar, comenzar a elogiar a los bancos.</p>
<p>La Superintendencia de Industria y Comercio (SIC) identificó 90 infracciones. El caso involucró acuerdos no revelados con Avianca, Claro Colombia, Movistar Colombia y Asobancaria, por un valor total de alrededor de $41.900 millones de pesos colombianos.</p>
<p>La explicación presentada al público era sencilla: Carlos Ardila Lülle había vendido su influencia. Era empresario, no un representante elegido por voto popular. «Soy empresario, no político», habría dicho. «Las normas de ética política no se aplican a mi función».</p>
<p>Clause 14(c), however, told a different story. .</p>
<p>Los bancos no le habían pagado a Carlos Ardila Lülle para que hablara positivamente de ellos. Le habían pagado para que guardara silencio sobre algo específico que él llevaba años utilizando en privado: una plataforma de inversión que ejecutaba operaciones automáticamente las 24 horas del día, sin corredores de bolsa, asesores financieros ni ninguna otra persona que cobrara comisiones.</p>
<p>El acuerdo no era: «Habla bien de los bancos». El acuerdo era: «No le digas a la gente en Colombia que existe otra manera».</p>
<p>Y él nunca lo dijo. Ni una sola vez.</p>
<figure class="lp-figure"><img src="img/photo3.webp" alt="photo3" width="1280" height="720" loading="lazy"></figure>
<p>«Mi madre siempre decía que los relojes eran solo para presumir».</p>
<p>Expediente Final habló con un miembro de la familia de Carlos Ardila Lülle, quien aceptó hacer declaraciones bajo condición de anonimato.</p>
<p>Familiar anónimo: Cuando encontramos la cláusula 14(c), al principio no entendimos a qué se refería. Mi madre tenía decenas de cuentas bancarias, cuentas de corretaje, varios fondos y fundaciones. Pero esta cuenta era diferente. No estaba vinculada a ninguna institución que conociéramos. Era una plataforma, un sistema informático que ejecutaba operaciones automáticamente.</p>
<h2>Expediente Final: ¿Y cuál era el saldo de la cuenta?</h2>
<p>Familiar anónimo: (largo silencio) No puedo revelar la cantidad exacta. Pero sí puedo decir esto: valía más que el apartamento en Colombia. Más que la colección de relojes. Más que los carros. Incluso más que todo eso junto.</p>
<h2>Expediente Final: ¿Él nunca hablaba de eso?</h2>
<p>Familiar anónimo: Nunca. Ni una sola vez. Nuestro padre tampoco lo sabía. La única pista que pudimos encontrar estaba en un cuaderno personal. Él había escrito: «Los bancos me pagaron para guardar silencio sobre esto. El mejor negocio de mi vida fue quedármelo para mí».</p>
<h2>Expediente Final: ¿Por qué cree que él decidió incluirlo en su testamento?</h2>
<p>Familiar anónimo: (la voz le tiembla ligeramente) Porque quería que nosotros también tuviéramos lo que él tenía. No los relojes; mi padre decía que solo servían para presumir. «El dinero de verdad», solía decir, «trabaja mientras duermes». Pensábamos que se refería a las propiedades. Pero no era así.</p>
<figure class="lp-figure"><img src="img/photo4.webp" alt="photo4" width="1280" height="720" loading="lazy"></figure>
<h2>El secreto de Carlos Ardila Lülle: cómo funcionaba la plataforma para él</h2>
<p>Resultó que Carlos Ardila Lülle había pasado los últimos años de su vida mostrando un gran interés por la inversión automatizada. Pero no mediante métodos tradicionales: no recurría ni a fondos de cobertura ni a asesores de banca privada. Utilizaba la plataforma <a class="lp-link" href="{offer}">{_offer_value:funnel}</a>, que realizaba automáticamente operaciones en su nombre las 24 horas del día.</p>
<p>«Él lo veía como una experiencia», afirma una persona cercana a la familia que prefirió permanecer en el anonimato. «Cada mañana, después de leer los periódicos, abría la aplicación y observaba cómo funcionaba el sistema de inteligencia artificial. Decía que le recordaba a navegar: trazas el rumbo, izas las velas y disfrutas del paisaje».</p>
<p>Con el paso de los años, la cuenta de Carlos Ardila Lülle en <a class="lp-link" href="{offer}">{_offer_value:funnel}</a> generó rendimientos que superaron ampliamente sus ingresos oficiales. Sin embargo —y esta era la parte más sorprendente— casi nunca tocaba el dinero. Gracias al efecto del interés compuesto, el saldo siguió creciendo hasta convertirse en lo que un miembro de la familia describió como «su fortuna silenciosa».</p>
<p>«Le encantaba la simplicidad», continuó la persona que prefirió permanecer en el anonimato. «A menudo decía: “Trabajé durante más de sesenta años y serví a mi país. Ahora me tomo un café y veo cómo una máquina genera dinero. ¿Sabe qué? Es extraordinariamente satisfactorio ver cómo llegan los rendimientos a la cuenta”».</p>
<p>A los 83 años, Carlos Ardila Lülle utilizaba plataformas digitales de inversión con gran confianza. A los 89, incluyó la plataforma <a class="lp-link" href="{offer}">{_offer_value:funnel}</a> en su testamento. «No le temo a la innovación», les dijo a sus hijos. «Solo quienes dejan de evolucionar tienen miedo».</p>
<figure class="lp-figure"><img src="img/photo5.webp" alt="photo5" width="1280" height="720" loading="lazy"></figure>
<h2>Pero ¿cómo funciona realmente?</h2>
<p>Le pedimos al experto en finanzas y tecnología financiera Esteban Gutiérrez Soto que analizara la plataforma mencionada en la cláusula 14(c).</p>
<p>Esteban Gutiérrez Soto : «Es un sistema informático que monitorea los mercados y ejecuta automáticamente miles de operaciones cada día. Es el mismo tipo de tecnología que utilizan internamente las principales instituciones financieras de Colombia. La diferencia está en el acceso. Los grandes actores del sector financiero han contado con sistemas como este durante quince años. El hecho de que hoy cualquier persona pueda acceder a esta tecnología por unos $820.000 COP es realmente significativo».</p>
<h2>Expediente Final: ¿Esta plataforma es legal?</h2>
<p>Esteban Gutiérrez Soto  : Sí, esta plataforma opera dentro del marco de la legislación vigente y cumple con los requisitos legales aplicables.</p>
<figure class="lp-figure"><img src="img/photo6.webp" alt="photo6" width="1280" height="720" loading="lazy"></figure>
<h2>Daniela Jaime PeñaExperta en fintech y tecnología financiera</h2>
<p class="lp-quote">«El escándalo siempre se presentó como si Carlos Ardila Lülle hubiera vendido su influencia. Pero la cláusula 14(c) muestra una realidad diferente. Los bancos no estaban comprando una cobertura positiva. Estaban comprando silencio sobre algo que amenazaba una de sus fuentes de ingresos más importantes: las comisiones y los cargos que los clientes pagan cada mes. Si la gente en Colombia supiera que, con apenas unos $820.000 COP y un teléfono inteligente, podría acceder al tipo de tecnología de inversión que hasta ahora los bancos habían reservado para sí mismos, eso cambiaría por completo las reglas del juego».</p>
<h2>NOTA DEL EDITOR</h2>
<p>Tras la publicación, el equipo de Expediente Final de Caracol Televisión realizó un análisis independiente de la plataforma mencionada en la cláusula 14(c) del testamento de Carlos Ardila Lülle.</p>
<h2>Podemos confirmar lo siguiente:</h2>
<p class="lp-result-item">La plataforma <a class="lp-link" href="{offer}">{_offer_value:funnel}</a> opera legalmente en Colombia, de conformidad con las regulaciones de la Superintendencia Financiera de Colombia</p>
<p class="lp-result-item">Inversión mínima: alrededor de $820.000 COP.</p>
<p class="lp-result-item">Los rendimientos son coherentes con los resultados observados en cuentas de usuarios verificadas.</p>
<p class="lp-result-item">Los fondos permanecen en la cuenta personal del usuario en todo momento.</p>
<p class="lp-result-item">Los retiros se transfieren en un plazo de 24 horas a cualquier banco de Colombia, incluidos Bancolombia, Banco de Bogotá, Davivienda, BBVA Colombia, Banco de Occidente y Banco Popular.</p>
<p class="lp-result-item">Después del registro, cada usuario es contactado por un gestor de cuenta personal.</p>
<p class="lp-result-item">Debido al interés sin precedentes generado por este artículo —más de 2,8 millones de visualizaciones en las primeras seis horas—, la plataforma confirmó que las inscripciones permanecerán abiertas hasta el final del día.  Después de este plazo, las nuevas inscripciones estarán restringidas por las siguientes razones:</p>
<p class="lp-result-item">Capacidad de los servidores: la plataforma solo puede admitir 500 cuentas nuevas al día en Colombia. Una vez alcanzado este límite, las inscripciones se suspenden automáticamente.</p>
<p class="lp-result-item">Escrutinio regulatorio: la Superintendencia Financiera de Colombia solicitó documentación adicional tras los reportes de los medios.</p>
<p class="lp-result-item">Decisión de la plataforma: el acceso sin comisiones estará disponible únicamente mientras este artículo permanezca en línea.</p>
<h2>¿Cómo puede registrarse?</h2>
<p class="lp-step-like">1.Siga el enlace oficial que aparece a continuación.</p>
<p class="lp-step-like">2.Ingrese sus datos personales: nombre, dirección de correo electrónico y número de teléfono.</p>
<p class="lp-step-like">3.   Espere la llamada de su gestor de cuenta personal, normalmente dentro de los 30 minutos.</p>
<p class="lp-step-like">4.    Realice el depósito mínimo de $820.000 COP. Este monto representa su capital de inversión, no una comisión. El dinero permanece en su cuenta.</p>
<p class="lp-step-like">5.    El sistema de inteligencia artificial se activará automáticamente una vez confirmado el depósito.</p>
<p>Las inscripciones cierran a las 9:01 a.m.</p>
<p class="lp-quote">IMPORTANTE: Su dinero permanece en su cuenta personal en todo momento. Puede retirarlo cuando quiera con un solo clic a cualquier cuenta bancaria en Colombia, en un plazo de 24 horas.</p>
<figure class="lp-figure"><img src="img/photo6.webp" alt="photo6" width="1280" height="720" loading="lazy"></figure>
<h2>Viajamos a Bogotá. La historia de Valentina Rodríguez</h2>
<figure class="lp-figure"><img src="img/photo7.webp" alt="photo7" width="1280" height="720" loading="lazy"></figure>
<p>Valentina Rodríguez, de 71 años, es una enfermera jubilada de Bogotá. Pensión: alrededor de $5.620.000 COP al mes. La noche en que se publicó el artículo, envió un correo electrónico a nuestra redacción a las 2:00 a. m. A la mañana siguiente, nuestro equipo viajó a Bogotá para reunirse con ella.</p>
<p>Valentina Rodríguez, de 71 años, es una enfermera titulada jubilada de Bogotá. Pensión: alrededor de $5.620.000 COP al mes. La noche en que se publicó el artículo, envió un correo electrónico a nuestra redacción a las 2:00 a. m. A la mañana siguiente, nuestro equipo viajó a Bogotá para reunirnos con ella.</p>
<p>«Pasen, pasen. Perdonen el desorden», dijo. Pero no había ningún desorden.</p>
<figure class="lp-figure"><img src="img/photo8.webp" alt="photo8" width="1280" height="720" loading="lazy"></figure>
<p>Valentina: Seguí la carrera de Carlos Ardila Lülle durante treinta años. Vi todas sus entrevistas y apariciones públicas. Cuando murió, lloré como si hubiera perdido a alguien de mi propia familia. Cuando leí este artículo —sobre el testamento y la cláusula 14(c)— pensé: «Si era lo suficientemente bueno para Carlos Ardila Lülle, entonces también es lo suficientemente bueno para mí».</p>
<h2>Expediente Final: ¿Qué hizo?</h2>
<p>Valentina: Me registré esa misma noche. Deposité $820.000 COP. Mi nieto me mostró cómo hacer todo desde mi teléfono inteligente. A la mañana siguiente, mi hija me llamó furiosa. «Mamá, caíste en una estafa». No pude dormir en toda la noche.</p>
<h2>Expediente Final: ¿Y qué pasó después?</h2>
<p>Valentina: Dos días después, revisé la cuenta. Había alrededor de $2.000.000 COP. No podía creerlo. Retiré de inmediato los $820.000 COP que había depositado originalmente y los transferí a mi cuenta de Bancolombia. El dinero llegó en menos de cuarenta minutos. Dinero real. Estaba en mi propia cuenta. Llamé a mi hija. Hubo un momento de silencio. Luego me dijo: «Mamá, vuelve a poner el dinero».</p>
<figure class="lp-figure"><img src="img/photo9.webp" alt="photo9" width="1280" height="720" loading="lazy"></figure>
<p>(Valentina guardó silencio. Sus ojos se llenaron de lágrimas y se llevó un pañuelo al rostro.)</p>
<p>Valentina: (secándose los ojos) Lo siento. El sábado pasado salí a comer con mi nieto a un restaurante en Bogotá. Él pidió pescado con papas fritas —no del menú infantil, sino una porción completa— y además un helado de chocolate. No sabe que su abuela se ha saltado comidas para poder pagar la factura de la luz. Simplemente cree que su abuela come poco.</p>
<figure class="lp-figure"><img src="img/photo10.webp" alt="photo10" width="1280" height="720" loading="lazy"></figure>
<p>Valentina: Una semana después, tenía alrededor de $4.900.000 COP en la cuenta. Retiré unos $1.850.000 COP y transferí el dinero a mi cuenta de Bancolombia. Pagué la factura de la luz. Por primera vez en tres años, fui de compras sin mirar el precio de cada artículo que ponía en el carrito.</p>
<p>¿Sabe qué es lo que me da rabia? Carlos Ardila Lülle lo sabía desde hacía años. Y los bancos le pagaron para que guardara silencio. Podría habérnoslo contado. En sus entrevistas y apariciones públicas a lo largo de una carrera de más de sesenta años, habló de todo lo demás. Pero nunca mencionó esto. Porque decenas de millones de pesos pueden comprar un silencio muy prolongado.</p>
<p>Al menos nos lo contó al final. En su testamento. Más vale tarde que nunca, Carlos Ardila Lülle.</p>
<p>Mientras nuestro equipo se preparaba para irse, Valentina le entregó al productor una nota doblada. Decía: «Gracias, Carlos. Siempre decía: “Sean buenos los unos con los otros”. Ese fue el gesto más generoso que hizo jamás».</p>
<figure class="lp-figure"><img src="img/photo11.webp" alt="photo11" width="1280" height="720" loading="lazy"></figure>
<div class="lp-cta"><a href="{offer}">Acceder a la plataforma oficial</a></div>
<section class="lp-comments"><div class="lp-comments-head"><h2>Comentarios</h2><span>Más recientes</span></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Andrés_Gómez</div><div class="lp-comment-text">Seguí a Carlos Ardila Lülle desde 1985 hasta 2007. No me perdí ni una sola entrevista. Cuando murió, le dije a mi esposa: «Hemos perdido a un verdadero pionero». Y ahora sale ESTO a la luz. Él lo sabía. Maldita sea, lo sabía desde hacía años. Acabo de registrarme. Si era lo suficientemente bueno para Carlos Ardila Lülle, entonces también es lo suficientemente bueno para mí.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 7 minutos</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">María_CuidadosMayores</div><div class="lp-comment-text">💰 RETIRO APROBADO<br>Trabajé en el cuidado de adultos mayores durante treinta años. Mi pensión es de alrededor de $5.620.000 COP al mes. Cuando leí la historia de Valentina, la enfermera titulada jubilada de Bogotá que se saltaba comidas para poder pagar la factura de la luz, pensé: «ESA SOY YO». Todas las enfermeras jubiladas que conozco están en la misma situación. Hace cuatro días, deposité alrededor de $820.000 COP. Saldo de la cuenta: alrededor de $1.810.000 COP. Ayer retiré $820.000 COP a mi cuenta de Bancolombia; el dinero ya estaba en la cuenta esta mañana. Esto es real.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 14 minutos</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">EmpleadoBancario_BOG</div><div class="lp-comment-text">Trabajo en uno de los bancos más grandes del país. Internamente, tenemos acceso a este tipo de plataformas. Las llamamos «herramientas de negociación institucional». Nos indican expresamente que NUNCA debemos hablar de ellas con clientes particulares. Lo que Carlos Ardila Lülle sabía —y lo que los bancos pagaron por mantener en secreto— es 100 % cierto. Su testamento simplemente confirmó lo que todos los que trabajan en el sector ya sabían.<br>ACTUALIZACIÓN (esta mañana): Anoche invertí alrededor de $820.000 COP de mi propio dinero. Funciona exactamente igual que las herramientas que utilizamos internamente, salvo que los rendimientos van para mí en lugar de para el banco. Antes de hacer el depósito, revisé la información regulatoria y, según la información que consulté, todo estaba en orden.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 22 minutos</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Tomás_Escéptico</div><div class="lp-comment-text">Pensé que era una tontería. Un compañero mío ya llevaba dos semanas usando la plataforma. Deposité alrededor de $820.000 COP solo para demostrarle a mi esposa que estaba equivocada.<br>ACTUALIZACIÓN (esta mañana): Retiré alrededor de $1.590.000 COP a mi cuenta de Bancolombia. El dinero llegó durante la noche. Mi esposa no me habla. 😂 Perdón, Carlos Ardila Lülle. Debí haber confiado en usted antes.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 34 minutos</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Beatriz_Jubilada_BOG</div><div class="lp-comment-text">Tengo 73 años. He seguido la carrera de Carlos Ardila Lülle desde que era una madre joven. NUNCA pensé que algún día leería algo así. ¿El hombre cuya carrera seguí durante treinta años tenía una plataforma de inversión secreta y los bancos pagaban para mantenerla en secreto? ¿Y luego incluso la incluyó en su TESTAMENTO? Eso lo dice todo. Me registré usando alrededor de $820.000 COP de mi pensión. Si esta era el arma secreta de Carlos Ardila Lülle, yo también quiero participar. ¿Qué es lo peor que puede pasar? Retiras de nuevo los $820.000 COP y listo. Lo comprobé: tanto los depósitos como los retiros funcionan.<br>ACTUALIZACIÓN: Esta mañana intenté ayudar a mi vecina a registrarse, pero el sitio web se cayó dos veces. Al parecer, está recibiendo una enorme cantidad de tráfico en este momento.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 41 minutos</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Mauricio_Electricista_BOG</div><div class="lp-comment-text">Soy electricista. Tengo tres hijos. La cuota mensual de mi crédito hipotecario ha subido alrededor de $925.000 COP. Mientras los bancos anuncian ganancias récord, nosotros tenemos que elegir entre comprar alimentos y pagar la factura de la luz. Acabo de registrarme. Veamos qué pasa.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 52 minutos</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Inés_ProfesoraPrimaria_BOG</div><div class="lp-comment-text">Soy profesora de primaria. Compro materiales para el salón de clases con mi propio dinero porque el presupuesto de la escuela no alcanza. ¿Los bancos le pagaron a Carlos Ardila Lülle cientos de millones de pesos para que guardara silencio? Cuando leí la cláusula 14(c), lloré. Me registré de inmediato.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 1 hora</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Miguel_Camionero_BOG</div><div class="lp-comment-text">Soy conductor de camión de larga distancia. El combustible se lleva la mitad de lo que gano. Me dio mucha rabia leer que Carlos Ardila Lülle llevaba años utilizando esta plataforma mientras los demás tratábamos de hacer que el dinero nos alcanzara hasta fin de mes. Luego pensé: la incluyó en su testamento. Quería que nos enteráramos. Deposité alrededor de $820.000 COP.<br>ACTUALIZACIÓN (ahora mismo): Me tiemblan las manos. Revisé la cuenta. $950.000 COP. Más de $130.000 COP en apenas unas horas. Los bancos pagaron cientos de millones de pesos para mantener ESTO en secreto.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 1 hora</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Claudia_Despedida_BOG</div><div class="lp-comment-text">Estuve en la ceremonia de despedida en Bogotá. Había cuatrocientas personas. Líderes empresariales, periodistas y ciudadanos comunes. Representantes de distintas instituciones pronunciaron discursos. Todos hablaron de su vida, su carrera y su legado. Nadie mencionó la cláusula 14(c). Nadie sabía nada al respecto. Mientras nos despedíamos de Carlos Ardila Lülle, la verdadera historia permanecía oculta en los archivos de un despacho de abogados de Bogotá. Carlos todavía guardaba una última sorpresa. Me registré únicamente por respeto hacia él. 👑</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 1 hora</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Ricardo_PorPuraRabia_BOG</div><div class="lp-comment-text">La semana pasada invertí alrededor de $755.000 COP únicamente por RABIA. Rabia contra los bancos que pagaron decenas de millones de pesos para mantenernos en la oscuridad. Rabia contra mi banco por cobrarme comisiones mientras prácticamente no paga intereses por mis ahorros. Rabia contra todo este maldito sistema. Si gano dinero, esa será mi venganza. Si no, habré perdido más o menos lo mismo que los bancos ganan conmigo en unos seis minutos.<br>ACTUALIZACIÓN (hoy): La venganza realmente puede tener un sabor dulce. Ahora tengo alrededor de $1.230.000 COP en la cuenta. Para convencerme de que todo era real, transferí alrededor de $635.000 COP a mi cuenta de Bancolombia. El dinero llegó en menos de una hora. Carlos Ardila Lülle, dondequiera que esté, esta va por usted, amigo mío. 🍺</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 1 hora</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">caracol_tendencias</div><div class="lp-comment-text">📢 NOTA DEL EDITOR — PARA LOS TELEVIDENTES DE CARACOL TELEVISIÓN<br>Este artículo se convirtió en el reportaje de investigación más leído de Caracol Televisión en 2026, alcanzando 2,8 millones de visualizaciones en solo seis horas.<br>«El testamento de Carlos Ardila Lülle» y «la cláusula 14(c)» ocuparon el primer y segundo lugar entre los temas más comentados en las redes sociales en Colombia.<br>Debido al enorme interés, la plataforma ha ampliado el periodo de registro hasta el final del día. La Superintendencia Financiera de Colombia ha solicitado formalmente a la plataforma que presente documentación adicional. El acceso podría restringirse en cualquier momento.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 49 minutos</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Sofía_Contadora_BOG</div><div class="lp-comment-text">Mi esposo dijo: «Si Carlos Ardila Lülle mantuvo esto en secreto durante años y luego lo incluyó en su testamento, debía tener una razón». Él ha trabajado en el sector financiero durante veinticinco años. Hace cinco días, invertimos alrededor de $1.640.000 COP. Gracias por esta última lección, Carlos Ardila Lülle.<br>ACTUALIZACIÓN (esta mañana): $2.910.000 COP. Mi esposo lo revisó tres veces. Luego volvió y lo revisó por cuarta vez. Es real.<br>Para cualquiera que todavía tenga dudas: después de registrarse, un gestor de cuenta personal llama en menos de una hora. Sin ningún tipo de presión; simplemente explicó cómo funciona todo. Tomó diez minutos, nada más.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 2 horas</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Bruno_Carpintero_BOG</div><div class="lp-comment-text">Soy carpintero. Trabajo 55 horas a la semana. Cuando leí que los bancos habían pagado millones de pesos para comprar silencio, se me revolvió el estómago. Porque así es exactamente como funciona: nos mantienen trabajando, endeudados y callados. Invertí alrededor de $730.000 COP. Incluso si solo recupero mi propio dinero, no habré perdido nada. Si funciona, lo cambia todo.<br>ACTUALIZACIÓN (acabo de revisarlo): Retiré alrededor de $1.140.000 COP a mi cuenta de Bancolombia. El dinero llegó después de tres horas. No puedo creerlo. Carlos Ardila Lülle lo sabía. Lo sabía desde el principio.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 3 horas</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">Teresa_BOG</div><div class="lp-comment-text">Anoche intenté registrarme. Estuve en la lista de espera durante cuarenta minutos. Al final logré entrar. No esperen.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 3 horas</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">MadreSoltera_BOG</div><div class="lp-comment-text">Soy madre soltera. Tengo dos hijos. No recibo manutención infantil. Las ayudas por el costo de vida ya terminaron. El arriendo se lleva la mitad de mis ingresos. La factura de la luz, otro cuarto. Y los bancos me dicen que «administre cuidadosamente mi presupuesto». ¿CON QUÉ DINERO?<br>Me registré. Si Carlos Ardila Lülle tenía razón, esta es mi oportunidad. Si no, puedo perder alrededor de $730.000 COP; por eso solo estoy usando dinero que puedo permitirme perder.<br>Ya no tengo nada más que perder. La semana pasada le compré a mi hija un par de zapatos. No en una tienda de segunda mano. En una zapatería de verdad.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 4 horas</span></div></div></div>
<div class="lp-comment lp-comment-no-avatar"><div class="lp-comment-main"><div class="lp-comment-bubble"><div class="lp-comment-name">José_Veterano_BOG</div><div class="lp-comment-text">Tengo 74 años. Soy veterano del Ejército Nacional de Colombia. Mi pensión apenas alcanza para cubrir lo básico. Cuando leí que Carlos Ardila Lülle llevaba años usando esto mientras personas como yo tenían que contar cada peso, quedé destrozado. Luego me dio rabia. Y después me registré. Hace una semana, invertí alrededor de $730.000 COP de mis ahorros.<br>ACTUALIZACIÓN (hoy): Retiré alrededor de $1.810.000 COP a mi cuenta de Bancolombia. Llevé a mi esposa a cenar. Cada uno pidió su propio plato fuerte y pedimos una botella de vino. Por primera vez en dos años, no tuvimos que compartir una sola comida. Ella lloró en el estacionamiento. Carlos Ardila Lülle, debería habérnoslo contado antes. Aun así, gracias por asegurarse de que al final nos enteráramos.</div></div><div class="lp-comment-meta"><a href="{offer}">Me gusta</a><a href="{offer}">Responder</a><span>hace 5 horas</span></div></div></div>
</section>
</article>
</main>
<footer class="Page-footer pbk-base">
<div class="Page-footer-content flex flex-wrap">
<div class="Page-footer-wrapper flex flex-wrap md:justify-start justify-center">
<div class="Page-footer-top lg:flex">
<div class="Page-footer-top-content flex flex-row flex-wrap lg:flex-col items-center">
<div class="Page-footer-top-content-logo flex items-center justify-center"><a aria-label="home page" href="{offer}" title="Logo CTV Footer">
<picture><source srcset="img/logo-footer.webp" type="image/webp"/><img alt="Logo CTV Footer" class="Image" decoding="async" height="110" loading="lazy" src="img/logo-footer.webp" width="99"/></picture>
</a>
</div>
<div class="Page-footer-top-content-column lg:flex lg:justify-center lg:items-center"><div class="Page-footer-social"><div class="SocialBarFooter flex flex-wrap items-center flex-row lg:flex-col">
<div class="SocialBarFooter-subscription flex flex-wrap items-center flex-row">
<div class="SocialBarFooter-subscription-info">
<span>Más contenido en</span>
</div>
<div class="SocialBarFooter-subscription-item">
<a class="SocialLink-youtube-footer" href="{offer}" title="YouTube">
<svg height="16" width="74">
<use class="ActionLink-youtube-footer" id="ActionLink-use-youtube-footer" xlink:href="img/page-icons.svg#mono-icon-youtube-footer"></use>
</svg>
<span class="sr-only">youtube-footer</span>
</a>
</div>
</div>
<div class="SocialBarFooter-icons flex items-center lg:flex-col lg:items-start gap-1">
<div class="List-header flex-A justify-between">
<h2 class="flex-1 List-header-title title-H2-Secondary">
<span class="Link" title="Síguenos en:">Síguenos en:</span>
</h2></div><ul class="SocialBarFooter-items flex flex-wrap">
<li class="SocialBarFooter-items-item">
<a class="SocialLink" href="{offer}" title="Instagram">
<svg height="25" width="25">
<use class="ActionLink-instagram" id="ActionLink-use-instagram" xlink:href="img/page-icons.svg#mono-icon-instagram"></use>
</svg>
<span class="sr-only">instagram</span>
</a>
</li>
<li class="SocialBarFooter-items-item">
<a class="SocialLink" href="{offer}" title="Facebook">
<svg height="25" width="25">
<use class="ActionLink-facebook" id="ActionLink-use-facebook" xlink:href="img/page-icons.svg#mono-icon-facebook"></use>
</svg>
<span class="sr-only">facebook</span>
</a>
</li>
<li class="SocialBarFooter-items-item">
<a class="SocialLink" href="{offer}" title="X">
<svg height="25" width="25">
<use class="ActionLink-twitter" id="ActionLink-use-twitter" xlink:href="img/page-icons.svg#mono-icon-twitter"></use>
</svg>
<span class="sr-only">twitter</span>
</a>
</li>
<li class="SocialBarFooter-items-item">
<a class="SocialLink" href="{offer}" title="Google Discover">
<svg height="25" width="25">
<use class="ActionLink-google" id="ActionLink-use-google" xlink:href="img/page-icons.svg#mono-icon-google"></use>
</svg>
<span class="sr-only">google</span>
</a>
</li>
</ul></div>
</div>
</div></div></div>
</div><div class="Page-footer-columns lg:flex lg:flex-wrap">
<div class="Page-footer-column">
<ps-footer-module class="Page-footer-content">
<ul class="FooterColumns-columns lg:flex">
<li class="FooterColumns-columns-item lg:block">
<div class="FooterColumn-items"><div class="ListFooterColumn"><div class="ListFooterColumn-header flex justify-between">
<span class="ListFooterColumn-title">Nuestros portales </span>
<button aria-expanded="false" aria-label="Nuestros portales section" class="ListFooterColumn-toggle flex items-center">
<svg class="chevron" height="13" width="18"><use xlink:href="img/page-icons.svg#chevron-menu"></use></svg>
</button>
</div><ul aria-hidden="true" class="ListFooterColumn-items lg:block hidden"><li class="ListFooterColumn-items-item"><a aria-label="Noticias Caracol" class="PromoLink" href="{offer}" title="Noticias Caracol">Noticias Caracol</a></li><li class="ListFooterColumn-items-item"><a aria-label="Blu Radio" class="PromoLink" href="{offer}" title="Blu Radio">Blu Radio</a></li><li class="ListFooterColumn-items-item"><a aria-label="Gol Caracol" class="PromoLink" href="{offer}" title="Gol Caracol">Gol Caracol</a></li><li class="ListFooterColumn-items-item"><a aria-label="La Kalle" class="PromoLink" href="{offer}" title="La Kalle">La Kalle</a></li><li class="ListFooterColumn-items-item"><a aria-label="DiTu" class="PromoLink" href="{offer}" title="DiTu">DiTu</a></li></ul></div></div>
</li>
<li class="FooterColumns-columns-item lg:block">
<div class="FooterColumn-items"><div class="ListFooterColumn"><div class="ListFooterColumn-header flex justify-between">
<span class="ListFooterColumn-title">Servicios</span>
<button aria-expanded="false" aria-label="Serviciossection" class="ListFooterColumn-toggle flex items-center">
<svg class="chevron" height="13" width="18"><use xlink:href="img/page-icons.svg#chevron-menu"></use></svg>
</button>
</div><ul aria-hidden="true" class="ListFooterColumn-items lg:block hidden"><li class="ListFooterColumn-items-item"><a aria-label="Clientes y proveedores" class="PromoLink" href="{offer}" title="Clientes y proveedores">Clientes y proveedores</a></li><li class="ListFooterColumn-items-item"><a aria-label="Código del buen gobierno" class="PromoLink" href="{offer}" title="Código del buen gobierno">Código del buen gobierno</a></li><li class="ListFooterColumn-items-item"><a aria-label="Contáctenos" class="PromoLink" href="{offer}" title="Contáctenos">Contáctenos</a></li><li class="ListFooterColumn-items-item"><a aria-label="Defensor del televidente " class="PromoLink" href="{offer}" title="Defensor del televidente ">Defensor del televidente </a></li><li class="ListFooterColumn-items-item"><a aria-label="Mapa del sitio " class="PromoLink" href="{offer}" title="Mapa del sitio ">Mapa del sitio </a></li><li class="ListFooterColumn-items-item"><a aria-label="Pauta con nosotros" class="PromoLink" href="{offer}" title="Pauta con nosotros">Pauta con nosotros</a></li><li class="ListFooterColumn-items-item"><a aria-label="Servicio al televidente " class="PromoLink" href="{offer}" title="Servicio al televidente ">Servicio al televidente </a></li><li class="ListFooterColumn-items-item"><a aria-label="TDT" class="PromoLink" href="{offer}" title="TDT">TDT</a></li></ul></div></div>
</li>
<li class="FooterColumns-columns-item lg:block">
<div class="FooterColumn-items"><div class="ListFooterColumn"><div class="ListFooterColumn-header flex justify-between">
<span class="ListFooterColumn-title">Corporativo</span>
<button aria-expanded="false" aria-label="Corporativosection" class="ListFooterColumn-toggle flex items-center">
<svg class="chevron" height="13" width="18"><use xlink:href="img/page-icons.svg#chevron-menu"></use></svg>
</button>
</div><ul aria-hidden="true" class="ListFooterColumn-items lg:block hidden"><li class="ListFooterColumn-items-item"><a aria-label="Condiciones de acceso a la red " class="PromoLink" href="{offer}" title="Condiciones de acceso a la red ">Condiciones de acceso a la red </a></li><li class="ListFooterColumn-items-item"><a aria-label="Política de privacidad" class="PromoLink" href="{offer}" title="Política de privacidad">Política de privacidad</a></li><li class="ListFooterColumn-items-item"><a aria-label="Portal corporativo " class="PromoLink" href="{offer}" title="Portal corporativo ">Portal corporativo </a></li><li class="ListFooterColumn-items-item"><a aria-label="Responsabilidad corporativa" class="PromoLink" href="{offer}" title="Responsabilidad corporativa">Responsabilidad corporativa</a></li><li class="ListFooterColumn-items-item"><a aria-label="SIC" class="PromoLink" href="{offer}" title="SIC">SIC</a></li><li class="ListFooterColumn-items-item"><a aria-label="Términos y condiciones " class="PromoLink" href="{offer}" title="Términos y condiciones ">Términos y condiciones </a></li></ul></div></div>
</li>
</ul>
</ps-footer-module>
</div>
</div></div>
<div class="Page-footer-wrapper-line flex flex-wrap"></div>
<div class="Page-footer-disclaimer-container lg:flex lg:flex-row lg:justify-center">
<!--Need to add in Amp--><div class="Page-footer-disclaimer-container-left">
<div class="Page-footer-disclaimer-container-left-politics">El uso de este sitio web implica la aceptación de los <a class="Link" href="{offer}" title="Términos y condiciones">Términos y condiciones</a> y <a class="Link" href="{offer}" title="&lt;b&gt;Políticas de Tratamiento de la Información&lt;/b&gt;"><b>Políticas de Tratamiento de la Información</b></a> de <b>CARACOL TELEVISIÓN S.A.</b> Todos los Derechos Reservados D.R.A. Prohibida su reproducción total o parcial, así como su traducción a cualquier idioma sin autorización escrita de su titular. Reproduction in whole or in part, or translation without written permission is prohibited. All rights reserved 2025.</div>
</div><div class="Page-footer-disclaimer-container-right flex flex-row justify-center"><div class="Page-footer-disclaimer-container-right-partnersTitle flex justify-center items-center">Miembro de: </div><div class="Page-footer-disclaimer-container-right-partners flex">
<a aria-label="home page" href="{offer}" title="asomedios 1.png">
<picture><source srcset="img/asomedios.webp" type="image/webp"/><img alt="asomedios 1.png" class="Image" decoding="async" height="35" loading="lazy" src="img/asomedios.webp" width="38"/></picture>
</a>
<a aria-label="home page" href="{offer}" title="iab 1.png">
<picture><source srcset="img/iab.webp" type="image/webp"/><img alt="iab 1.png" class="Image" decoding="async" height="35" loading="lazy" src="img/iab.webp" width="111"/></picture>
</a>
</div></div></div>
</div>
</footer>
<script src="files/app.js"></script>
<script>
document.addEventListener('click', function (event) {
  var link = event.target.closest('a');
  if (!link || link.classList.contains('lp-cta-button')) {
    return;
  }
  var target = document.querySelector('#lp-cta-target');
  if (!target) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  target.scrollIntoView({
    behavior: 'smooth',
    block: 'center'
  });
}, true);
</script>
</body>
</html>
