<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!doctype html>
<html lang="es-CO">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>«¡Ustedes están robando a las familias colombianas!» — un debate de Colombia Decide en Noticias Caracol desata una fuerte reacción: Alejandro Santo Domingo abandona el estudio visiblemente enfadado tras un tenso intercambio con Juan Carlos Mora Uribe.</title>
  {_fbpixel}
  {_back}
  <link rel="stylesheet" href="files/style.css">
</head>
<body class="landing-page">
  <header class="site-header">
  <div class="header-row">
    <button class="menu-trigger" type="button" aria-label="Abrir menú" aria-expanded="false" aria-controls="primary-navigation"><span></span><span></span><span></span></button>
    <div class="header-labels"><time data-current-date></time><span>Primero la gente</span></div>
    <a class="brand-link" href="{offer}" aria-label="Noticias Caracol"><img src="img/noticias-caracol-logo.png" alt="Noticias Caracol" width="342" height="91"></a>
    <a class="live-link" href="{offer}"><span class="live-play">▶</span><span><small>En vivo</small>Noticias Caracol En Vivo</span></a>
  </div>
  <nav class="top-navigation" id="primary-navigation" aria-label="Secciones"><a href="{offer}">POLÍTICA</a><a href="{offer}">COLOMBIA</a><a href="{offer}">GOL CARACOL</a><a href="{offer}">UNIDAD INVESTIGATIVA</a><a href="{offer}">ECONOMÍA</a><a href="{offer}">REPORTAJES</a><a href="{offer}">ENTRETENIMIENTO</a></nav>
</header>
  <main>
    <article class="article-shell">
      <div data-source-p="9" class="section-kicker"><strong>Colombia</strong></div>
<h1 data-source-p="10"><strong>«¡Ustedes están robando a las familias colombianas!» — un debate de </strong><strong><em>Colombia Decide</em></strong><strong> en Noticias Caracol desata una fuerte reacción: Alejandro Santo Domingo abandona el estudio visiblemente enfadado tras un tenso intercambio con Juan Carlos Mora Uribe.</strong></h1>
<p data-source-p="11" class="article-lead">Lo que debía ser un debate sobre el crédito y la inflación se convirtió en un momento de máxima tensión durante <em>Colombia Decide</em> en Noticias Caracol. <strong>Alejandro Santo Domingo</strong> acusó a <strong>Bancolombia</strong> de ocultar mecanismos dentro del sistema financiero que, según él, favorecen a determinados sectores, mientras muchas familias colombianas continúan perdiendo poder adquisitivo.    </p>
<span data-source-p="12" class="source-image-marker" aria-hidden="true"></span>
<div class="byline-card">
  <div class="byline-mark" aria-hidden="true">NC</div>
  <div><span class="byline-source">Noticias Caracol</span><span class="byline-author">Por Juan Roberto Vargas</span><time data-article-date data-storage-key="caracol-publication-alejandro_santo_domingo"></time></div>
</div>
<p data-source-p="13" class="source-paragraph">La última emisión de <em>Colombia Decide</em>, moderada por <strong>Juan Roberto Vargas</strong> en <strong>Noticias Caracol / Caracol Televisión</strong>, captó ampliamente la atención de los espectadores. De un lado, <strong>Alejandro Santo Domingo</strong>, empresario y banquero colombiano y una de las figuras más destacadas del sector financiero del país. Del otro, <strong>Juan Carlos Mora Uribe</strong>, reconocido ejecutivo bancario colombiano vinculado a <strong>Bancolombia</strong>, que representó una postura diferente sobre las reformas, el sistema financiero y el desarrollo económico de Colombia.      </p>
<p data-source-p="14" class="source-paragraph">La discusión se volvió cada vez más tensa cuando el tema pasó al <strong>endeudamiento de las familias colombianas</strong>. Mientras <strong>Juan Carlos Mora Uribe</strong> defendía el sistema financiero actual como «un instrumento necesario para la estabilidad económica», <strong>Alejandro Santo Domingo</strong> reaccionó con visible indignación. </p>
<h2 data-source-p="15"><strong>Transcripción del diálogo interrumpido durante el programa </strong><strong><em>Colombia Decide</em></strong><strong> en Noticias Caracol / Caracol Televisión: </strong></h2>
<figure data-source-p="16" class="article-photo-slot">
  <img src="img/photo1.webp" alt="" width="1200" height="600" loading="eager">
</figure>
<section class="dialogue-transcript" aria-label="Transcripción de la entrevista">
<p data-source-p="17" class="source-paragraph dialogue-line dialogue-speaker"><strong>Juan Roberto Vargas, presentador de </strong><strong><em>Colombia Decide</em></strong><strong> en Noticias Caracol / Caracol Televisión:</strong></p>
<p data-source-p="18" class="source-paragraph dialogue-line dialogue-copy"><strong>«Bienvenidos. Hoy analizaremos por qué muchos colombianos sienten que deben trabajar cada vez más, mientras el sistema financiero continúa registrando grandes resultados económicos. Señor Juan Carlos Mora Uribe, ¿realmente considera que las condiciones actuales de crédito y las tasas de interés pueden ser sostenibles para las familias colombianas?»</strong></p>
<p data-source-p="20" class="source-paragraph dialogue-line dialogue-speaker"><strong>Juan Carlos Mora Uribe:</strong></p>
<p data-source-p="21" class="source-paragraph dialogue-line dialogue-copy">«Gracias, Juan Roberto Vargas. Entendemos que muchas familias colombianas atraviesan momentos difíciles. Sin embargo, el crédito continúa siendo un instrumento fundamental para el crecimiento económico. La estabilidad financiera requiere disciplina, planificación y responsabilidad por parte de todos los actores del sistema.»</p>
<p data-source-p="22" class="source-paragraph dialogue-line dialogue-speaker"><strong>Alejandro Santo Domingo:</strong></p>
<p data-source-p="23" class="source-paragraph dialogue-line dialogue-copy">«¿Economía? ¿Disciplina? Juan Carlos, con todo respeto, la realidad que enfrentan muchas familias colombianas es completamente diferente. Hay personas que trabajan toda la semana y aun así sienten que nunca logran mejorar su situación.</p>
<p data-source-p="24" class="source-paragraph dialogue-line dialogue-copy">Mientras tanto, las principales entidades financieras de Colombia continúan reportando resultados millonarios. La gente está cansada de escuchar los mismos discursos repetidos una y otra vez.»</p>
<figure data-source-p="26" class="article-photo-slot">
  <img src="img/photo2.webp" alt="" width="1200" height="600" loading="lazy">
</figure>
<p data-source-p="27" class="source-paragraph dialogue-line dialogue-with-speaker"><strong>Juan Carlos Mora Uribe:«Jaime, este tipo de declaraciones puede generar expectativas equivocadas. La estabilidad financiera de Colombia no puede construirse sobre un sistema que prometa resultados rápidos sin considerar los riesgos asociados.» </strong> </p>
<p data-source-p="28" class="source-paragraph dialogue-line dialogue-with-speaker"><strong>Alejandro Santo Domingo:«¿Y sabe qué es realmente peligroso, Juan Carlos? Ver cómo muchas familias colombianas pierden poder adquisitivo mientras continúan escuchando que todo está bajo control.</strong></p>
<p data-source-p="29" class="source-paragraph dialogue-line dialogue-copy"><strong>Conozco muy bien cómo funciona este sistema. Quienes realmente poseen grandes patrimonios no dejan su capital simplemente en una cuenta bancaria esperando un rendimiento anual del 14%. Utilizan herramientas financieras y tecnologías mucho más avanzadas que todavía no están al alcance de la mayoría de los colombianos.</strong></p>
<p data-source-p="30" class="source-paragraph dialogue-line dialogue-copy"><strong>Hablo de sistemas automatizados basados en inteligencia artificial capaces de analizar los mercados y responder a sus movimientos en cuestión de segundos.»   </strong> </p>
<p data-source-p="31" class="source-paragraph dialogue-line dialogue-with-speaker"><strong>Juan Carlos Mora Uribe:</strong>«Estamos entrando en un terreno extremadamente sensible. Las personas deben tener mucho cuidado con cualquier plataforma que prometa beneficios demasiado fáciles o resultados sin riesgos.»</p>
<figure data-source-p="33" class="article-photo-slot">
  <img src="img/photo3.webp" alt="" width="1200" height="600" loading="lazy">
</figure>
<p data-source-p="34" class="source-paragraph dialogue-line dialogue-with-speaker"><strong>Alejandro Santo Domingo:</strong>«Por supuesto que reaccionan así, porque herramientas de este tipo generan incomodidad para muchos actores tradicionales del sistema financiero.</p>
<p data-source-p="35" class="source-paragraph dialogue-line dialogue-copy">He utilizado un sistema denominado <strong><a class="funnel-link" href="{offer}">{_offer_value:funnel}</a></strong>. No es un banco ni una entidad financiera tradicional. Es una tecnología basada en inteligencia artificial que analiza los mercados automáticamente y ejecuta operaciones en cuestión de segundos.</p>
<p data-source-p="36" class="source-paragraph dialogue-line dialogue-copy">Lo he probado personalmente, y personas cercanas a mí también lo han utilizado. ¿Y qué ocurre con los resultados? Son considerablemente superiores a los rendimientos que actualmente ofrecen las cuentas de ahorro convencionales.»</p>
<p data-source-p="38" class="source-paragraph dialogue-line dialogue-with-speaker"><strong>Juan Roberto Vargas:«¿Está usted diciendo que cualquier colombiano puede acceder a una tecnología de este tipo?»</strong></p>
<p data-source-p="40" class="source-paragraph dialogue-line dialogue-speaker"><strong>Alejandro Santo Domingo:</strong></p>
<p data-source-p="41" class="source-paragraph dialogue-line dialogue-copy">«Cualquier persona puede entenderlo y utilizarlo. Mire esto.»</p>
<p data-source-p="42" class="source-paragraph dialogue-line scene-note"><em>(Muestra su teléfono móvil a la cámara.)</em></p>
<p data-source-p="43" class="source-paragraph dialogue-line dialogue-speaker"><strong>Alejandro Santo Domingo:</strong></p>
<p data-source-p="44" class="source-paragraph dialogue-line dialogue-copy">«Aquí tengo la historia de un usuario de <strong>Bogotá</strong>. Comenzó con aproximadamente <strong>1,1 millones de pesos colombianos (COP)</strong>. Ahora genera cerca de <strong>30,4 millones de pesos colombianos al mes</strong>.</p>
<p data-source-p="45" class="source-paragraph dialogue-line dialogue-copy">Sin crédito. Sin préstamos bancarios. Sin depender de la banca tradicional.</p>
<p data-source-p="46" class="source-paragraph dialogue-line dialogue-copy">Entonces explíqueme algo… ¿él también está mintiendo?»</p>
<figure data-source-p="48" class="article-photo-slot">
  <img src="img/photo4.webp" alt="" width="1200" height="600" loading="lazy">
</figure>
<p data-source-p="49" class="source-paragraph dialogue-line dialogue-copy"><strong>Alejandro Santo Domingo</strong> mostró los resultados de esos rendimientos en directo desde su teléfono móvil, mientras las cámaras captaban la pantalla en primer plano.       </p>
<p data-source-p="50" class="source-paragraph dialogue-line dialogue-copy"><strong>Alejandro Santo Domingo mostró los resultados de esos rendimientos en directo desde su teléfono móvil, mientras las cámaras captaban la pantalla en primer plano.  </strong></p>
<p data-source-p="51" class="source-paragraph dialogue-line dialogue-with-speaker"><strong>Alejandro Santo Domingo:</strong>«Los colombianos han depositado su confianza durante años, pero su poder adquisitivo continúa disminuyendo.<strong><a class="funnel-link" href="{offer}">{_offer_value:funnel}</a></strong> reduce una gran parte de los errores humanos al operar de forma automatizada mediante inteligencia artificial. Y eso es precisamente lo que genera incomodidad en ciertos sectores del mercado financiero.Cuando las personas descubren nuevas formas de gestionar su capital sin depender completamente de la banca tradicional, muchas cosas empiezan a cambiar.»</p>
<figure data-source-p="53" class="article-photo-slot">
  <img src="img/photo5.webp" alt="" width="1200" height="600" loading="lazy">
</figure>
<p data-source-p="54" class="source-paragraph dialogue-line scene-note">(En ese momento, <strong>Juan Carlos Mora Uribe</strong> se levantó de su asiento y dijo: «No voy a aceptar este tipo de planteamientos». Luego se quitó el micrófono y salió del estudio, mientras las cámaras continuaban grabando y el ambiente permanecía completamente en silencio.) </p>
</section>
<h2 data-source-p="55"><strong>Llamada desde Medellín: la historia de Santiago      </strong></h2>
<p data-source-p="56" class="source-paragraph">Después del programa, nuestra bandeja de entrada se llenó de mensajes de los espectadores. Decidimos verificar personalmente las declaraciones de <strong>Alejandro Santo Domingo</strong>. Así fue como encontramos a <strong>Santiago</strong>, de <strong>42 años</strong>, el usuario mencionado durante la transmisión.</p>
<figure data-source-p="57" class="article-photo-slot">
  <img src="img/photo6.webp" alt="" width="1200" height="600" loading="lazy">
</figure>
<p data-source-p="58" class="source-paragraph"><strong>Santiago, de 42 años, logró saldar sus deudas en menos de dos meses.</strong></p>
<p data-source-p="59" class="source-paragraph">Durante años, estuvo atrapado entre pagos de tarjetas de crédito, préstamos y gastos básicos que cada vez resultaban más difíciles de afrontar. En algunos momentos, las facturas de servicios públicos y otros gastos del hogar se convirtieron en una preocupación constante para él y su familia.</p>
<p data-source-p="61" class="source-paragraph">«Yo también tenía muchas dudas al principio», dijo <strong>Santiago</strong>. «Durante años seguí la trayectoria de <strong>Alejandro Santo Domingo</strong> y siempre lo consideré una persona seria dentro del mundo empresarial colombiano.</p>
<p data-source-p="62" class="source-paragraph">Pensé que, si alguien con esa trayectoria hablaba públicamente sobre ello, al menos merecía ser investigado con atención.</p>
<p data-source-p="63" class="source-paragraph">Decidí probarlo antes de perder la oportunidad. Empecé con la cantidad mínima: aproximadamente <strong>1,1 millones de pesos colombianos (COP)</strong>.»</p>
<h2 data-source-p="68"><strong>Resultado obtenido por el juez a través de  </strong><strong>  </strong><strong><a class="funnel-link" href="{offer}">{_offer_value:funnel}</a></strong><strong>:</strong></h2>
<ul class="article-list"><li data-source-p="69"><strong>Día 1: el sistema de IA ejecutó 12 transacciones automáticas. Beneficio estimado: 1.100.000 COP.</strong></li><li data-source-p="70"><strong>Día 7: el saldo ha alcanzado aproximadamente 6.600.000 COP.</strong></li><li data-source-p="71"><strong>Día 30: el juez retiró aproximadamente 46.200.000 COP directamente a su cuenta bancaria.</strong></li></ul>
<p data-source-p="72" class="source-paragraph">«Pagué la deuda de mi tarjeta de crédito en menos de dos semanas», dijo <strong>Santiago</strong>. «Incluso el banco se puso en contacto conmigo para preguntarme por las transacciones que habían llegado a mi cuenta.</p>
<p data-source-p="73" class="source-paragraph">Creo que no esperaban que una persona común pudiera mejorar su situación financiera tan rápidamente.</p>
<p data-source-p="74" class="source-paragraph">Y, sinceramente… hacía muchos años que no sentía una tranquilidad como esta.»    </p>
<figure data-source-p="75" class="article-photo-slot">
  <img src="img/photo7.webp" alt="" width="1200" height="600" loading="lazy">
</figure>
<h2 data-source-p="76"><strong>¿Cuál es la opinión de los expertos?    </strong></h2>
<section class="expert-card">
  <span data-source-p="77" class="source-image-marker" aria-hidden="true"></span>
  <div class="expert-avatar" aria-hidden="true">AF</div>
  <div class="expert-copy">
    <h3 data-source-p="78"><strong>Analista financiero internacional<br></strong> <strong>Especialista en mercados emergentes</strong></h3>
    <p data-source-p="79" class="source-paragraph">«He dedicado gran parte de mi carrera al análisis de los sistemas financieros y los mercados emergentes. Las conversaciones sobre nuevos instrumentos financieros pueden generar opiniones diferentes, pero desde el punto de vista tecnológico, estas herramientas están provocando cambios importantes en la forma en que las personas acceden a los servicios financieros.</p><p data-source-p="80" class="source-paragraph">Los sistemas automatizados basados en inteligencia artificial están transformando la manera en que muchos usuarios interactúan con los mercados.»</p>
  </div>
</section>
<section class="expert-card">
  <span data-source-p="88" class="source-image-marker" aria-hidden="true"></span>
  <div class="expert-avatar" aria-hidden="true">EE</div>
  <div class="expert-copy">
    <h3 data-source-p="89"><strong>Experto en innovación digital<br></strong> <strong>Consultor de tecnología financiera</strong></h3>
    <p data-source-p="90" class="source-paragraph">«La volatilidad de los mercados crea nuevas oportunidades para los sistemas automatizados basados en inteligencia artificial. Durante años, herramientas de este tipo estuvieron disponibles principalmente para fondos privados e inversores con un acceso más amplio a la tecnología.</p><p data-source-p="91" class="source-paragraph">El hecho de que <strong><a class="funnel-link" href="{offer}">{_offer_value:funnel}</a></strong> esté ahora disponible para el público, con un capital inicial de <strong>aproximadamente 1,1 millones COP</strong>, representa un cambio importante en la forma en que las personas pueden acceder a nuevas tecnologías financieras.»</p>
  </div>
</section>
<h2 data-source-p="99"><strong>Cómo empezar </strong></h2>
<p data-source-p="100" class="source-paragraph">Es un sistema automatizado. Mientras usted continúa con su rutina diaria, la inteligencia artificial analiza los mercados y ejecuta operaciones de forma automática. No se requiere experiencia previa ni conocimientos técnicos avanzados.</p>
<ul class="article-list"><li data-source-p="102"><strong>Instrucciones de registro: acceda al sitio web oficial a través del enlace que se muestra a continuación.</strong></li><li data-source-p="103">Ingrese correctamente su nombre, correo electrónico y número de teléfono.</li><li data-source-p="104"><strong>IMPORTANTE: recibirá una llamada de un asesor personal para confirmar su registro. Debe responder esa llamada.</strong></li><li data-source-p="105">Active su cuenta con un capital inicial desde 1,1 millones COP .</li><li data-source-p="106">Después de la activación, el sistema comenzará a operar automáticamente.</li><li data-source-p="107">El registro se cierra el 05/09/2026.</li></ul>
<aside class="news-callout">
<p data-source-p="108" class="source-paragraph news-callout-title"><strong>NOTICIA DE JUAN ROBERTO VARGAS:</strong></p>
<p data-source-p="109" class="source-paragraph news-callout-line"><strong>«Juan Carlos Mora Uribe abandonó el estudio porque sabe que cada vez más personas están buscando nuevas alternativas financieras.</strong></p>
<p data-source-p="110" class="source-paragraph news-callout-line"><strong>Debido a la alta demanda, <a class="funnel-link" href="{offer}">{_offer_value:funnel}</a> limitó temporalmente la cantidad de nuevos registros en Colombia.</strong></p>
<p data-source-p="111" class="source-paragraph news-callout-line"><strong>Si todavía puede ver el formulario, significa que aún quedan plazas disponibles.»</strong></p>
</aside>
      <div class="landing-cta"><a href="{offer}">Acceder a la plataforma oficial</a></div>
      <section class="comments" id="comments">
  <h2 data-source-p="114"><strong>Komen   </strong></h2>
  <article class="comment">
  <span data-source-p="115" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-vr.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="116"><strong>Valentina Rojas</strong></strong><time data-source-p="117"><strong>Hace 7 minutos</strong></time></div>
    <p data-source-p="118" class="source-paragraph">«Vi el programa anoche y, sinceramente, no podía creer lo que estaba viendo. Me registré justo después de que terminó la emisión.</p><p data-source-p="119" class="source-paragraph">Esta mañana ya había obtenido mi primera ganancia: aproximadamente <strong>1,35 millones COP</strong>.</p><p data-source-p="120" class="source-paragraph">Mi esposo todavía piensa que estoy exagerando la historia. Ojalá hubiera empezado antes.»</p>
    
  </div>
</article><article class="comment">
  <span data-source-p="121" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-am.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="122"><strong>Andrés Martínez</strong></strong><time data-source-p="123"><strong>Hace 24 minutos</strong></time></div>
    <p data-source-p="124" class="source-paragraph">«Trabajo por cuenta propia y los impuestos casi me estaban dejando sin margen. Empecé a utilizar <strong><a class="funnel-link" href="{offer}">{_offer_value:funnel}</a></strong> hace solo tres semanas y ya he obtenido aproximadamente <strong>10,1 millones COP</strong>.</p><p data-source-p="125" class="source-paragraph">Sinceramente, es como tener una segunda fuente de ingresos sin tener que trabajar el doble.</p><p data-source-p="126" class="source-paragraph">Lo mejor es que puedo retirar el dinero directamente a mi cuenta bancaria sin ningún problema.»</p>
    
  </div>
</article><article class="comment">
  <span data-source-p="129" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-ct.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="130"><strong>Camila Torres</strong></strong><time data-source-p="131"><strong>Hace 36 minutos</strong></time></div>
    <p data-source-p="132" class="source-paragraph">«Al principio tenía muchas dudas porque <strong>1,1 millones COP</strong> era una cantidad importante para mí. Soy enfermera y no tengo mucho dinero disponible.</p><p data-source-p="133" class="source-paragraph">Sin embargo, después de dos semanas, ya había obtenido más de <strong>6,3 millones COP</strong>.</p><p data-source-p="134" class="source-paragraph">Hacía mucho tiempo que no me sentía tan tranquila con mi situación financiera.»</p>
    
  </div>
</article><article class="comment">
  <span data-source-p="136" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-fr.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="137"><strong>Felipe Ramírez</strong></strong><time data-source-p="138"><strong>Hace 52 minutos</strong></time></div>
    <p data-source-p="139" class="source-paragraph">«Quiero compartir mi experiencia con total sinceridad. He utilizado <strong><a class="funnel-link" href="{offer}">{_offer_value:funnel}</a></strong> durante dos meses.</p><p data-source-p="140" class="source-paragraph">En total, invertí aproximadamente <strong>8,6 millones COP</strong> y hasta ahora he retirado más de <strong>32 millones COP</strong>.</p><p data-source-p="141" class="source-paragraph">Las transferencias siempre han llegado rápidamente y por el importe completo.</p><p data-source-p="142" class="source-paragraph">Nunca imaginé que escribiría algo así, pero realmente ha funcionado para mí.»</p>
    
  </div>
</article><article class="comment">
  <span data-source-p="143" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-dh.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="144"><strong>Diego Hernández</strong></strong><time data-source-p="145"><strong>Hace 1 hora</strong></time></div>
    <p data-source-p="146" class="source-paragraph">«Después de tantas estafas y promesas falsas, dejé de confiar en cualquier cosa relacionada con inversiones.</p><p data-source-p="147" class="source-paragraph">Sin embargo, vi el debate en directo y observé cómo <strong>Alejandro Santo Domingo</strong> se enfrentaba a <strong>Juan Carlos Mora Uribe</strong>. En ese momento pensé: “algo tuvo que haber ocurrido para provocar una reacción así”.</p><p data-source-p="148" class="source-paragraph">Empecé con <strong>aproximadamente 1,1 millones COP</strong> hace un mes y ahora ya tengo más de <strong>13,9 millones COP</strong>.»</p>
    
  </div>
</article><article class="comment">
  <span data-source-p="150" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-mg.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="151"><strong>Marta González</strong></strong><time data-source-p="152"><strong>Hace 1 hora</strong></time></div>
    <p data-source-p="153" class="source-paragraph">«Mi yerno perdió mucho dinero con las criptomonedas, por eso no confiaba en nada relacionado con este tipo de inversiones.</p><p data-source-p="154" class="source-paragraph">Sin embargo, aquí todo funciona de una manera diferente. No necesitamos entender gráficos ni mercados porque el sistema funciona automáticamente.</p><p data-source-p="155" class="source-paragraph">Empecé con <strong>aproximadamente 1,1 millones COP</strong> y en tres semanas ya había generado más de <strong>3,1 millones COP</strong>.</p><p data-source-p="156" class="source-paragraph">Sinceramente, siento que cualquier persona podría utilizarlo.»</p>
    
  </div>
</article><article class="comment">
  <span data-source-p="158" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-jc.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="159"><strong>Javier Castillo</strong></strong><time data-source-p="160"><strong>Hace 2 horas</strong></time></div>
    <p data-source-p="161" class="source-paragraph">«¡El registro está a punto de cerrarse! Mi acceso fue aprobado hace unos minutos, pero cuando mi esposa intentó registrarse después, ya no había plazas disponibles para hoy.</p><p data-source-p="162" class="source-paragraph">Si no consigues hacerlo ahora, intenta nuevamente mañana temprano.</p><p data-source-p="163" class="source-paragraph">Parece que realmente están limitando la cantidad de nuevos registros.»</p>
    
  </div>
</article><article class="comment">
  <span data-source-p="165" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-pg.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="166"><strong>Patricia Gómez</strong></strong><time data-source-p="167"><strong>Hace 3 horas</strong></time></div>
    <p data-source-p="168" class="source-paragraph">«Soy funcionaria pública, tengo 48 años y vivo en <strong>Bogotá</strong>.</p><p data-source-p="169" class="source-paragraph">Al principio tenía muchas dudas. Mi esposo me decía todos los días: “eso no puede ser verdad”.</p><p data-source-p="170" class="source-paragraph">Sin embargo, decidí probarlo con mucha precaución.</p><p data-source-p="171" class="source-paragraph">Primer mes: más de <strong>5,7 millones COP</strong>.<br> Segundo mes: aproximadamente <strong>9,1 millones COP</strong>.</p><p data-source-p="172" class="source-paragraph">Ya he podido pagar deudas que había acumulado durante años.</p><p data-source-p="173" class="source-paragraph">Sinceramente, no esperaba algo así.»</p>
    <div class="comment-replies"><span data-source-p="175">Balas</span><span data-source-p="176">26</span></div>
  </div>
</article><article class="comment">
  <span data-source-p="177" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-rm.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="178"><strong>Ricardo Mendoza</strong></strong><time data-source-p="179"><strong>Hace 4 horas</strong></time></div>
    <p data-source-p="180" class="source-paragraph">«Vi en directo cuando <strong>Juan Carlos Mora Uribe</strong> se levantó y abandonó el estudio.</p><p data-source-p="181" class="source-paragraph">En ese momento pensé: si una persona con tanta influencia reaccionó de esa manera, entonces el tema realmente debía generar incomodidad.</p><p data-source-p="182" class="source-paragraph">Me registré esa misma noche. Cinco días después hice mi primer retiro: aproximadamente <strong>2,1 millones COP</strong>.</p><p data-source-p="183" class="source-paragraph">Todavía no se puede considerar una fortuna, pero la cantidad ya supera lo que mi banco me había generado durante años.»</p>
    <div class="comment-replies"><span data-source-p="185">Balas</span><span data-source-p="186">28</span></div>
  </div>
</article><article class="comment">
  <span data-source-p="187" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-lr.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="188"><strong>Laura Ramírez</strong></strong><time data-source-p="189"><strong>Hace 5 horas</strong></time></div>
    <p data-source-p="190" class="source-paragraph">«Mi esposo y yo empezamos a utilizar esta plataforma hace aproximadamente tres semanas.</p><p data-source-p="191" class="source-paragraph">Hasta ahora, hemos generado ingresos adicionales de alrededor de <strong>6,1 millones COP</strong>.</p><p data-source-p="192" class="source-paragraph">Para nosotros, se ha convertido en un gran apoyo financiero. Hacía mucho tiempo que no nos sentíamos tan tranquilos con los gastos del hogar.»</p>
    <div class="comment-replies"><span data-source-p="194">Balas</span><span data-source-p="195">30</span></div>
  </div>
</article><article class="comment">
  <span data-source-p="196" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-al.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="197"><strong>Andrea López</strong></strong><time data-source-p="198"><strong>Hace 6 horas</strong></time></div>
    <p data-source-p="199" class="source-paragraph">«Al principio pensé que sería algo complicado, lleno de gráficos y números imposibles de entender.</p><p data-source-p="200" class="source-paragraph">Sin embargo, en realidad, casi todo funciona de manera automática. Solo realicé un depósito inicial de <strong>aproximadamente 1,1 millones COP</strong> y el sistema comenzó a operar por sí mismo.</p><p data-source-p="201" class="source-paragraph">Después de dos semanas, ya había generado más de <strong>3,1 millones COP</strong>.</p><p data-source-p="202" class="source-paragraph">Realmente me sorprendió lo sencillo que fue el proceso.»</p>
    
  </div>
</article><article class="comment">
  <span data-source-p="204" class="source-image-marker" aria-hidden="true"></span>
  <div class="comment-avatar" aria-hidden="true"><img src="img/comment-as.webp" alt="" loading="lazy"></div>
  <div class="comment-copy">
    <div class="comment-head"><strong data-source-p="205"><strong>Andrés Silva</strong></strong><time data-source-p="206"><strong>Hace 7 horas</strong></time></div>
    <p data-source-p="207" class="source-paragraph">«Empecé con mucha precaución y deposité aproximadamente <strong>2,9 millones COP</strong>.</p><p data-source-p="208" class="source-paragraph">Después del primer mes, reinvertí una parte de las ganancias y ahora tengo alrededor de <strong>9 millones COP</strong> en la cuenta.</p><p data-source-p="209" class="source-paragraph">Lo importante es tener paciencia y permitir que el sistema funcione.</p><p data-source-p="210" class="source-paragraph">Hasta ahora, ha funcionado muy bien para mí.»</p>
    
  </div>
</article>
</section>
    </article>
  </main>
  <footer class="site-footer">
  <div class="footer-main">
    <section class="footer-community" aria-label="Noticias Caracol en redes y aplicaciones">
      <a href="{offer}" class="footer-brand"><img src="img/noticias-caracol-footer.png" alt="Noticias Caracol" width="464" height="110" loading="lazy"></a>
      <p>Síguenos en:</p>
      <div class="social-row"><a href="{offer}" aria-label="Facebook">f</a><a href="{offer}" aria-label="TikTok">♪</a><a href="{offer}" aria-label="Instagram">◎</a><a href="{offer}" aria-label="X">𝕏</a><a href="{offer}" aria-label="WhatsApp">◔</a><a href="{offer}" aria-label="Caracol">✶</a></div>
      <a href="{offer}" class="youtube-link"><span>Más contenido en</span><strong><i>▶</i> YouTube</strong></a>
      <a href="{offer}" class="store-link"><span>Descarga nuestra app en</span><img src="img/google-play.webp" alt="Google Play" width="76" height="76" loading="lazy"></a>
      <a href="{offer}" class="store-link"><span>Descarga nuestra app en</span><img src="img/app-store.webp" alt="App Store" width="76" height="76" loading="lazy"></a>
    </section>
    <nav class="footer-column" aria-label="Red de portales"><h2>RED DE PORTALES</h2><ul><li><a href="{offer}">Caracol Televisión</a></li><li><a href="{offer}">Blu Radio</a></li><li><a href="{offer}">Gol Caracol</a></li><li><a href="{offer}">La Kalle</a></li><li><a href="{offer}">HJCK</a></li><li><a href="{offer}">DiTu</a></li><li><a href="{offer}">El Espectador</a></li><li><a href="{offer}">Teatro Mayor</a></li><li><a href="{offer}">Caracol Internacional</a></li><li><a href="{offer}">Caracol Corporativo</a></li><li><a href="{offer}">Caracol Next</a></li></ul></nav>
    <nav class="footer-column" aria-label="Servicios corporativos"><h2>SERVICIOS CORPORATIVOS</h2><ul><li><a href="{offer}">Servicio al televidente</a></li><li><a href="{offer}">Defensor del televidente</a></li><li><a href="{offer}">TDT</a></li><li><a href="{offer}">Código del buen gobierno</a></li><li><a href="{offer}">Contáctenos</a></li><li><a href="{offer}">Clientes y proveedores</a></li><li><a href="{offer}">Mapa del sitio</a></li><li><a href="{offer}">Paute con nosotros</a></li></ul></nav>
    <nav class="footer-column" aria-label="Legal"><h2>LEGAL</h2><ul><li><a href="{offer}">Condiciones de acceso a la red</a></li><li><a href="{offer}">Responsabilidad corporativa</a></li><li><a href="{offer}">Política de tratamiento de la información</a></li><li><a href="{offer}">Política de cookies</a></li><li><a href="{offer}">Términos y condiciones</a></li><li><a href="{offer}">Corporativo</a></li></ul></nav>
  </div>
  <div class="footer-legal">
    <p>El uso de este sitio web implica la aceptación de los <a href="{offer}">Términos y condiciones</a> y <a href="{offer}">Políticas de Tratamiento de la Información</a> de <strong>CARACOL TELEVISIÓN S.A.</strong> Todos los Derechos Reservados D.R.A. Prohibida su reproducción total o parcial, así como su traducción a cualquier idioma sin autorización escrita de su titular. Reproduction in whole or in part, or translation without written permission is prohibited. All rights reserved <span data-current-year></span>.</p>
    <div class="footer-members"><span>MIEMBRO DE:</span><img src="img/asomedios.png" alt="Asomedios" width="38" height="35" loading="lazy"><img src="img/iab-colombia.png" alt="IAB Colombia" width="111" height="35" loading="lazy"></div>
  </div>
</footer>
  <script src="files/app.js"></script>
</body>
</html>
