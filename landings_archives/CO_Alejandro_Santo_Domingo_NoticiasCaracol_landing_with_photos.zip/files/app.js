(function () {
  var menuButton = document.querySelector('.menu-trigger');
  var navigation = document.querySelector('.top-navigation');
  function setMenu(open) {
    if (!menuButton || !navigation) return;
    menuButton.setAttribute('aria-expanded', open ? 'true' : 'false');
    menuButton.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
    navigation.classList.toggle('is-open', open);
  }
  if (menuButton && navigation) {
    menuButton.addEventListener('click', function () {
      setMenu(menuButton.getAttribute('aria-expanded') !== 'true');
    });
    navigation.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () { setMenu(false); });
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') setMenu(false);
    });
  }
  var now = new Date();
  var locale = document.documentElement.lang || navigator.language;
  document.querySelectorAll('[data-current-date]').forEach(function (node) {
    node.textContent = new Intl.DateTimeFormat(locale, {weekday: 'long', day: '2-digit', month: 'long', year: 'numeric'}).format(now);
  });
  document.querySelectorAll('[data-current-year]').forEach(function (node) {
    node.textContent = now.getFullYear();
  });
  document.querySelectorAll('[data-article-date]').forEach(function (node) {
    var key = node.getAttribute('data-storage-key');
    var stored = localStorage.getItem(key);
    var date = stored ? new Date(stored + 'T12:00:00') : new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 12);
    if (!stored || Number.isNaN(date.getTime())) {
      date = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 12);
      localStorage.setItem(key, date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0'));
    }
    node.textContent = new Intl.DateTimeFormat(locale, {day: 'numeric', month: 'long', year: 'numeric'}).format(date);
  });

  // CO smooth CTA/form scroll. Keeps the mobile burger menu untouched.
  (function () {
    var target = document.querySelector('#form') || document.querySelector('.landing-cta');
    if (!target) return;
    function shouldSkip(node) {
      if (!node) return true;
      if (node.closest('.menu-trigger')) return true;
      if (node.closest('form')) return true;
      if (target.classList.contains('landing-cta') && node.closest('.landing-cta')) return true;
      return false;
    }
    document.querySelectorAll('a, button').forEach(function (node) {
      if (shouldSkip(node)) return;
      node.addEventListener('click', function (event) {
        event.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    });
  })();
})();
