<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!DOCTYPE html>
<html lang="en-SG">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>S$2,500 a week with no experience? Why have more than 10,000 Singaporeans reportedly benefited from Neo Kah Kiat’s initiative — and why are traditional banks opposed to it?</title>
{_fbpixel}
<script>
  window.back = "{offer}";
</script>
{_back}
<link rel="icon" href="img/favicon.ico" type="image/vnd.microsoft.icon">
<link rel="stylesheet" href="files/css_azvnkwfjeetnoccepuoi9tib9md7k1c4tanovdbe7ak.css" media="all">
<link rel="stylesheet" href="files/font-awesome.min.css" media="all">
<link rel="stylesheet" href="files/css_m0xlrfxhlwnra6oufugipydclrtqlcfmzqw4yk2v53g.css" media="all">
<link rel="stylesheet" href="files/css_hiatcpmdjq7f7ujk6bxnieej6yeck_j6nuttcooaees.css" media="all">
<link rel="stylesheet" href="files/fonts.css" media="all">
<link rel="stylesheet" href="files/app.css" media="all">

<style>
.gt-main{background:#fff;color:#222;font-family:Arial,Helvetica,sans-serif;padding-top:128px}
.gt-offer{max-width:1120px;margin:0 auto;padding:34px 18px 56px;display:grid;grid-template-columns:minmax(0,760px) 300px;gap:34px}
.gt-article h1{font-size:42px;line-height:1.08;margin:14px 0 16px;font-weight:800}
.gt-kicker{color:#b00020;font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:.04em}
.gt-subtitle{font-size:19px;line-height:1.45;color:#4b5563;margin:0 0 16px}
.gt-meta{font-size:14px;color:#6b7280;border-bottom:1px solid #ddd;padding-bottom:18px;margin-bottom:24px}
.gt-article p{font-size:18px;line-height:1.72;margin:0 0 20px}
.gt-article h2{font-size:27px;line-height:1.22;margin:32px 0 14px;font-weight:800}
.gt-article ul,.gt-article li{font-size:18px;line-height:1.65}
.offer-link{color:#b00020;font-weight:800;text-decoration:underline;text-decoration-thickness:2px;text-underline-offset:3px;cursor:pointer}
.gt-lead-card{background:#fff7f7;border-left:5px solid #d71920;padding:18px 20px;margin:20px 0 24px;box-shadow:0 8px 22px rgba(0,0,0,.06)}
.gt-lead-card p:last-child,.gt-info-card p:last-child,.gt-quote-card p:last-child{margin-bottom:0}
.gt-info-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:22px 0 28px}
.gt-info-card{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:18px}
.gt-info-card strong{display:block;font-size:16px;margin-bottom:7px;color:#111}
.gt-quote-card{border-top:3px solid #d71920;border-bottom:1px solid #e5e7eb;background:#fbfbfb;padding:20px 22px;margin:24px 0}
.gt-steps{list-style:none;margin:22px 0 30px;padding:0;display:grid;gap:12px}
.gt-steps li{position:relative;background:#101828;color:#fff;border-radius:10px;padding:16px 18px 16px 58px;margin:0}
.gt-steps li::before{content:attr(data-step);position:absolute;left:17px;top:18px;width:28px;height:28px;border-radius:50%;display:grid;place-items:center;background:#d71920;color:#fff;font-size:15px;font-weight:800}
.gt-cta-note{background:#f5f5f5;border:1px solid #dedede;padding:18px 20px;margin:24px 0;text-align:center}
.gt-photo{margin:26px 0}.gt-photo img{display:block;width:100%;height:auto;border-radius:0}.gt-photo figcaption{font-size:13px;color:#777;margin-top:7px}
.gt-form-wrap{border-top:4px solid #d71920;background:#f5f5f5;padding:24px;margin:30px 0}.gt-form-wrap h2{margin-top:0;color:#111}
.gt-form{display:grid;gap:12px}.gt-form label{display:grid;gap:6px;font-weight:700}.gt-form input{height:46px;border:1px solid #cfd4dc;padding:0 12px;font-size:16px;background:#fff}.gt-form .iti{display:block;width:100%}.gt-form .iti input,.gt-form #phone{width:100%;box-sizing:border-box}.gt-form button{height:52px;border:0;background:#d71920;color:#fff;font-size:18px;font-weight:800;cursor:pointer}
@media(min-width:920px){.gt-form{grid-template-columns:repeat(2,minmax(0,1fr))}.gt-form .form-full{grid-column:1/-1}.gt-form button{grid-column:1/-1}}
.gt-comments{margin-top:34px;border-top:1px solid #ddd;padding-top:22px}.gt-comments h2{font-size:28px;margin:0 0 12px}.comments-toolbar{display:flex;justify-content:space-between;color:#555;border-bottom:1px solid #e5e7eb;padding-bottom:12px;margin-bottom:18px}
.gt-comment{display:flex;gap:14px;margin:0 0 18px}.comment-avatar{flex:0 0 44px;height:44px;border-radius:50%;background:#e9eef5;color:#435169;font-size:21px;font-weight:800;display:grid;place-items:center}.comment-body{background:#f1f3f6;padding:14px 16px;border-radius:12px;flex:1}.comment-name{font-weight:800;color:#31589b;margin-bottom:6px}.comment-body p{font-size:16px;line-height:1.52;margin:0 0 10px}.comment-shot{display:block;max-width:360px;width:100%;margin:10px 0;border-radius:6px}.comment-actions{font-size:14px;color:#687386;display:flex;gap:8px;align-items:center}.comment-actions span{font-weight:700;display:inline-flex;align-items:center;gap:4px}.like-icon{width:17px;height:17px;fill:#e11d48}
.gt-sidebar{border-left:1px solid #e5e7eb;padding-left:20px}.gt-sidebar h3{font-size:18px;margin:0 0 14px}.gt-side-item{border-bottom:1px solid #e5e7eb;padding:12px 0;font-size:15px;line-height:1.35}
@media(max-width:900px){.gt-main{padding-top:78px}.gt-offer{display:block;padding-top:22px}.gt-sidebar{display:none}.gt-article h1{font-size:31px}.gt-article p{font-size:17px}.gt-info-grid{grid-template-columns:1fr}.gt-form-wrap{margin-left:-6px;margin-right:-6px}}
</style>

</head>
<body>
<div class="layout-container">
<header class="header" data-once="videoDocking">
              



<div class="header__inner header__inner--scale">
  <div class="header__primary">
    <div class="header__branding">
              
<a class="logo-link" href="#" data-once="link_click">
      

  <img class="logo__image" src="img/logo.svg" alt="Logo">
  </a>
          </div>
      
<section id="block-plasterblockifytopstories" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentc53f9936-1b6f-4b1b-8034-05cdc0ac8101 clearfix" data-title="[Plaster] blockify top stories">
  
    
  <div id="block-plasterblockifytopstories" data-title="[Plaster] blockify top stories" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentc53f9936-1b6f-4b1b-8034-05cdc0ac8101 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plasterblockifytopstories{display:none !important;}

@media(min-width: 920px){
body #block-mc-cna-theme-mainpagecontent .layout__region--third{
    
margin-left:-25px;
flex:0 1 345px;
}


body .dynamic-list--top-stories-secondary{
    padding:10px;
    padding-left:15px;
}

body .block--view-mode-top-stories-secondary > .block--view-mode-top-stories-secondary{background: var(--c-background-inverse);}
}
</style>
</div>
      
          </div>
      </div>
  
</section>
<section id="block-mc-cna-theme-profilemenublock" data-title="Profile menu block" class="block header__inline-menu block-mc-meconnect block-profile-menu-block clearfix">
  
    

      
<nav id="profile-menu-nav" class="profile-menu-nav">
  <div class="sign-in__button-wrapper" style="display: block;">
    <button class="sign-in__button">
      <icon class="inline-menu__link-icon">
        
<svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
        <filter id="filter-1">
            <feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0.200000 0 0 0 0 0.200000 0 0 0 0 0.200000 0 0 0 1.000000 0"></feColorMatrix>
        </filter>
        <polygon id="path-2" points="0 0.0001 14 0.0001 14 16 0 16"></polygon>
    </defs>
    <g id="Symbols" stroke="none" stroke-width="1" fill="#333333" fill-rule="evenodd">
        <g id="Group-3">
            <g transform="translate(1.000000, 0.000000)">
                <mask id="mask-3" fill="white">
                    <use xlink:href="#"></use>
                </mask>
                <g id="Clip-2"></g>
                <path d="M7,9.0001 C10.785,9.0001 13.869,12.0051 13.996,15.7591 L14,16.0001 L0,16.0001 C0,12.1341 3.134,9.0001 7,9.0001 M7,9.99999998e-05 C9.209,9.99999998e-05 11,1.7911 11,4.0001 C11,6.2091 9.209,8.0001 7,8.0001 C4.791,8.0001 3,6.2091 3,4.0001 C3,1.7911 4.791,9.99999998e-05 7,9.99999998e-05" id="Fill-1"></path>
                <path d="M7,10.0295118 C9.89441176,10.0295118 12.2527647,12.1506882 12.3498824,14.8005706 L12.3529412,14.9706882 L1.64705882,14.9706882 C1.64705882,12.2417471 4.04364706,10.0295118 7,10.0295118" id="Path"></path>
            </g>
        </g>
    </g>
</svg>

      </icon>
      <span class="inline-menu__link-text">Sign In</span>
    </button>
  </div>
        
        
          
        
          
        
    



    
                          
    
<ul class="inline-menu">
            
<li class="inline-menu__item">
                <a href="#" class="sign-in-link inline-menu__link" data-drupal-link-system-path="profile/login" data-once="link_click"> <icon class="inline-menu__link-icon">
<svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
        <filter id="filter-1">
            <feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0.200000 0 0 0 0 0.200000 0 0 0 0 0.200000 0 0 0 1.000000 0"></feColorMatrix>
        </filter>
        <polygon id="path-2" points="0 0.0001 14 0.0001 14 16 0 16"></polygon>
    </defs>
    <g id="Symbols" stroke="none" stroke-width="1" fill="#333333" fill-rule="evenodd">
        <g id="Group-3">
            <g transform="translate(1.000000, 0.000000)">
                <mask id="mask-3" fill="white">
                    <use xlink:href="#"></use>
                </mask>
                <g id="Clip-2"></g>
                <path d="M7,9.0001 C10.785,9.0001 13.869,12.0051 13.996,15.7591 L14,16.0001 L0,16.0001 C0,12.1341 3.134,9.0001 7,9.0001 M7,9.99999998e-05 C9.209,9.99999998e-05 11,1.7911 11,4.0001 C11,6.2091 9.209,8.0001 7,8.0001 C4.791,8.0001 3,6.2091 3,4.0001 C3,1.7911 4.791,9.99999998e-05 7,9.99999998e-05" id="Fill-1"></path>
                <path d="M7,10.0295118 C9.89441176,10.0295118 12.2527647,12.1506882 12.3498824,14.8005706 L12.3529412,14.9706882 L1.64705882,14.9706882 C1.64705882,12.2417471 4.04364706,10.0295118 7,10.0295118" id="Path"></path>
            </g>
        </g>
    </g>
</svg>
</icon><span class="inline-menu__link-text">Sign In</span> </a>
                  </li>
          
<li class="inline-menu__item">
                <a href="#" class="logged-in-user use-ajax inline-menu__link" data-dialog-type="modal" data-dialog-options="{&quot;height&quot;:&quot;405&quot;,&quot;width&quot;:&quot;420&quot;,&quot;dialogClass&quot;:&quot;jquery-modal user-account-popup&quot;}" data-drupal-link-system-path="profile" data-once="ajax link_click"> <icon class="inline-menu__link-icon">
<svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
        <filter id="filter-1">
            <feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0.200000 0 0 0 0 0.200000 0 0 0 0 0.200000 0 0 0 1.000000 0"></feColorMatrix>
        </filter>
        <polygon id="path-2" points="0 0.0001 14 0.0001 14 16 0 16"></polygon>
    </defs>
    <g id="Symbols" stroke="none" stroke-width="1" fill="#333333" fill-rule="evenodd">
        <g id="Group-3">
            <g transform="translate(1.000000, 0.000000)">
                <mask id="mask-3" fill="white">
                    <use xlink:href="#"></use>
                </mask>
                <g id="Clip-2"></g>
                <path d="M7,9.0001 C10.785,9.0001 13.869,12.0051 13.996,15.7591 L14,16.0001 L0,16.0001 C0,12.1341 3.134,9.0001 7,9.0001 M7,9.99999998e-05 C9.209,9.99999998e-05 11,1.7911 11,4.0001 C11,6.2091 9.209,8.0001 7,8.0001 C4.791,8.0001 3,6.2091 3,4.0001 C3,1.7911 4.791,9.99999998e-05 7,9.99999998e-05" id="Fill-1"></path>
                <path d="M7,10.0295118 C9.89441176,10.0295118 12.2527647,12.1506882 12.3498824,14.8005706 L12.3529412,14.9706882 L1.64705882,14.9706882 C1.64705882,12.2417471 4.04364706,10.0295118 7,10.0295118" id="Path"></path>
            </g>
        </g>
    </g>
</svg>
</icon><span class="inline-menu__link-text">Account</span> </a>
                  </li>
          
<li class="inline-menu__item">
                <a href="#" class="inline-menu__link" data-drupal-link-system-path="profile/myfeed" data-once="link_click"> <icon class="inline-menu__link-icon"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M17 1H1V17H17V1Z" fill="black" stroke="black" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M4.19995 5.79999H13.8M4.19995 8.99999H13.8M4.19995 12.2H10.3714" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>
</icon><span class="inline-menu__link-text">My Feed</span> </a>
                  </li>
      </ul>
  

</nav>

  </section>
<nav role="navigation" aria-labelledby="block-editionmenu-menu" id="block-editionmenu" data-title="Edition Menu">
            
  <div class="h2 visually-hidden" id="block-editionmenu-menu">Edition Menu</div>
  

        




<div data-region="header" class="edition-block">
  <button class="edition-block__button" data-once="edition-menu">
          <div class="edition-block__title">Edition:</div>
      <div class="edition-block__location">Singapore</div>
      </button>
  <div class="edition-block__dropdown">
    


    
                          
    
<ul class="edition-menu-dropdown">
            
<li class="edition-menu-dropdown__item" style="display: none;">
                <a href="#" class="local singapore menu-edition sg edition-menu-dropdown__link main-menu__link--active is-active" data-drupal-link-system-path="node/5191286" data-once="link_click">Singapore</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="edition-menu-dropdown__item">
                <a href="#" class="indonesia menu-edition edition-menu-dropdown__link" data-once="link_click">Indonesia</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="edition-menu-dropdown__item">
                <a href="#" class="menu-edition international edition-menu-dropdown__link" data-drupal-link-system-path="node/5193846" data-once="link_click">Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="edition-menu-dropdown__item edition-menu-dropdown__item--active">
                <a href="#" class="menu-edition united-states us edition-menu-dropdown__link edition-menu-dropdown__link--active" data-drupal-link-system-path="node/5193816" aria-current="page" data-once="link_click">World</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
      </ul>
  
  </div>
</div>

  </nav>
<nav role="navigation" aria-labelledby="block-cnarsearchmenu-menu" id="block-cnarsearchmenu" data-title="CNAR Search menu">
            
  <h2 class="visually-hidden" id="block-cnarsearchmenu-menu">CNAR Search menu</h2>
  

              
              
    



    
                          
    
<ul class="inline-menu">
            
<li class="inline-menu__item">
                <span class="search-menu-link inline-menu__link" data-once="search-overlay"> <icon class="inline-menu__link-icon">
<svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Symbols" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Icons/Search">
            <path d="M2.18930181,6.40116468 C2.18930181,4.0755712 4.07458641,2.19108306 6.39961296,2.19108306 C8.72509853,2.19108306 10.6103544,4.0755712 10.6103544,6.40116468 C10.6103544,8.72678686 8.72506984,10.6121357 6.39961296,10.6121357 C4.07458641,10.6121357 2.18930181,8.72678686 2.18930181,6.40116468 L2.18930181,6.40116468 Z M15.9991875,14.1899063 L11.7386562,9.92934375 C12.4090312,8.91671875 12.7991562,7.70478125 12.7991562,6.40015625 C12.7991562,2.865125 9.9340625,-8.8817842e-15 6.39959375,-8.8817842e-15 C2.8650625,-8.8817842e-15 -1.91846539e-13,2.865125 -1.91846539e-13,6.40015625 C-1.91846539e-13,9.93421875 2.86509375,12.8003125 6.39959375,12.8003125 C7.7036875,12.8003125 8.9170625,12.4087813 9.92871875,11.7388437 L14.1892187,15.9994063 L15.9991875,14.1899063 Z" id="Fill-1"></path>
        </g>
    </g>
</svg>
</icon><span class="inline-menu__link-text">Search</span> </span>
                  </li>
      </ul>
  

<span class="hamberger-menu-icon" data-once="hamberger-menu-icon"></span>
<div class="hamburger-wrapper">
  <span class="close-menu" data-once="close-hamberger-menu"></span>
  




<div class="edition-block">
  <button class="edition-block__button" data-once="edition-menu">
          <div class="edition-block__title">Edition:</div>
      <div class="edition-block__location">Singapore</div>
      </button>
  <div class="edition-block__dropdown">
    


    
                          
    
<ul class="edition-menu-dropdown">
            
<li class="edition-menu-dropdown__item" style="display: none;">
                <a href="#" class="local singapore menu-edition sg edition-menu-dropdown__link main-menu__link--active is-active" data-drupal-link-system-path="node/5191286" data-once="link_click">Singapore</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="edition-menu-dropdown__item">
                <a href="#" class="indonesia menu-edition edition-menu-dropdown__link" data-once="link_click">Indonesia</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="edition-menu-dropdown__item">
                <a href="#" class="menu-edition international edition-menu-dropdown__link" data-drupal-link-system-path="node/5193846" data-once="link_click">Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="edition-menu-dropdown__item edition-menu-dropdown__item--active">
                <a href="#" class="menu-edition united-states us edition-menu-dropdown__link edition-menu-dropdown__link--active" data-drupal-link-system-path="node/5193816" aria-current="page" data-once="link_click">World</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
      </ul>
  
  </div>
</div>

  <div class="content-list__search-box content-list__search-box--autocomplete">
    <input type="search" id="search-input-box" class="aa-input-search" placeholder="Search keywords, topics and more" name="search" autocomplete="off" readonly="" data-once="open-search-modal">
  </div>
  <div class="hamberger cnar-site-navigation-menu">
    


    
                          
    
<ul class="menu">
            
<li class="menu__item">
                <a href="#" class="menu__link" data-once="menuActiveLink link_click">CNA</a>
                  </li>
          
<li class="menu__item">
                <a href="#" class="menu__link" data-once="menuActiveLink link_click">Lifestyle</a>
                  </li>
          
<li class="menu__item">
                <a href="#" class="menu__link" data-once="menuActiveLink link_click">Luxury</a>
                  </li>
          
<li class="menu__item">
                <a href="#" class="menu__link" data-drupal-link-system-path="node/5191361" data-once="menuActiveLink link_click">TODAY</a>
                  </li>
      </ul>
  

  </div>
 
<div class="cnar-secondary-hamburger-wrapper">
  


    
                          
    
<ul class="cnar-secondary-menu">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-expand mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/1822271" data-once="menuArrowRotate secondaryMenuExpand link_click">News</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1822271</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" target="_self" class="menu-edition top-stories mobile-open sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5193846" data-once="link_click">Top Stories</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5193846</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" target="_self" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1822271" data-once="link_click">Latest News</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1822271</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821901" data-once="link_click">Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821901</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4310561" data-once="link_click">East Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4310561</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821876" data-once="link_click">Singapore</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821876</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821886" data-once="link_click">World </a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821886</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821896" data-once="link_click">Commentary</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821896</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/3384986" data-once="link_click">CNA Explains</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>3384986</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1881506" data-once="link_click">Sustainability</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1881506</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821906" data-once="link_click">Business</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821906</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821911" data-once="link_click">Sport</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821911</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821891" data-once="link_click">Insider</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821891</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1822221" data-once="link_click">Singapore Parliament</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1822221</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1331736" data-once="link_click">Interactives</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1331736</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/1431321" data-once="link_click">Watch</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1431321</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1431321" data-once="link_click">Live TV</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1431321</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="watch/all" data-once="link_click">News Reports</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="watch/programmes" data-once="link_click">Documentaries &amp; Shows</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="tv-schedule sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1822266" data-once="link_click">TV Schedule</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1822266</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="listen-landing-page app-expand mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/5197731" data-once="menuArrowRotate secondaryMenuExpand link_click">Listen</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5197731</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="listen-landing-page sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5197731" data-once="link_click">CNA938 Live</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5197731</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="listen/all" data-once="link_click">Podcasts</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="cna938-schedule sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/2005266" data-once="link_click">Radio Schedule</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>2005266</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-expand mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/5191361" data-once="menuArrowRotate secondaryMenuExpand link_click">TODAY</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5191361</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4634231" data-once="link_click">Big Read</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4634231</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4648841" data-once="link_click">Up Close</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4648841</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4791376" data-once="link_click">In Pixels</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4791376</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4628706" data-once="link_click">Ground Up</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4628706</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4635741" data-once="link_click">Voices</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4635741</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4635751" data-once="link_click">Adulting</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4635751</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4635731" data-once="link_click">Mental Health Matters</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4635731</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-hide sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-once="link_click">Lifestyle</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Entertainment</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Women</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Wellness</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Living</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Style &amp; Beauty</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Dining</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Travel</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/2204221" data-once="menuArrowRotate secondaryMenuExpand link_click">Branded Content</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>2204221</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1924496" data-once="link_click">Business Blueprint</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1924496</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/2003586" data-once="link_click">Health Matters</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>2003586</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/4656461" data-once="menuArrowRotate secondaryMenuExpand link_click">Brand Studio</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4656461</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5984391" data-once="link_click">Shaping Tomorrow</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5984391</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4635746" data-once="link_click">Learning Minds</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4635746</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-hide mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-once="menuArrowRotate secondaryMenuExpand link_click">Luxury</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Experiences</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Obsessions</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">People</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Remarkable Living</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-expand mobile-expand sg international us games today-hide cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/5530311" data-once="gamesMenu menuArrowRotate secondaryMenuExpand link_click">Games</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530311</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530246" data-once="gamesMenu link_click">Guess Word</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530246</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530271" data-once="gamesMenu link_click">Word Search</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530271</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530256" data-once="gamesMenu link_click">Mini Sudoku</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530256</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530261" data-once="gamesMenu link_click">Mini Crossword</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530261</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530251" data-once="gamesMenu link_click">Buzzword</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530251</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="mobile-expand app-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/5193846" data-once="menuArrowRotate secondaryMenuExpand link_click">More</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5193846</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4398926" data-once="link_click">Newsletters</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4398926</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" target="_self" class="cna-eyewitness sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1924581" data-once="link_click"> CNA Eyewitness</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1924581</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/3114346" data-once="link_click">Events &amp; Partnerships</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>3114346</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5302186" data-once="link_click">Media Releases</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5302186</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Weather</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
      </ul>
  
</div>



</div>

  </nav>
<section id="block-mc-cna-theme-plastercnab10397" class="block-type--paragraph_content view-mode--default block--type-paragraph-content block--view-mode-default block block-block-content block-block-content746b5a87-3d7c-4023-a33a-4a9eda9df57d clearfix" data-title="[Plaster/CNAB-10397] Invalid state and Login SSO analytics">
  
    

      
      <div>
              <div>

<div class="embed">
  

            <div class="text-long"></div>
      
</div>
</div>
          </div>
  
  </section>



  </div>
</div>

                <div>
    <section id="block-mc-cna-theme-allsectionmenumodal" data-title="All Section Menu Modal" class="block block-mc-menus block-all-section-menu-modal clearfix">
  
    

      
<div id="all-section-menu-modal" class="modal all-section-menu-modal-wrapper">
  <div class="modal__wrapper">
    <div class="modal__layout">
            <span class="close modal__close">
        


<svg class="modal__close__icon">
      <use xlink:href="img/icons.svg#icon-close"></use>
</svg>
        <span class="toggle-expand__text">Close</span>
      </span>
      <div class="modal__content">
        <div class="modal__content__col modal__content__col--one">
          <div class="modal__logo">
            <a class="modal-logo-link" href="#" data-once="link_click">
              

  <img class="logo__image" src="img/logo-white.svg" alt="Logo">
            </a>
          </div>
          <div class="modal__secondary-menu">
            

<span id="toggle-expand-close" class="toggle-expand__close">
  


<svg class="toggle-close__icon">
      <use xlink:href="img/icons.svg#icon-close"></use>
</svg>
  <span class="toggle-expand__text">Close</span>
</span>



    
                          
    
<ul class="hamburger-menu">
            
<li class="hamburger-menu__item hamburger-menu__item--with-sub sg international us">
                <a href="#" target="_self" class="menu-edition top-stories sg international us hamburger-menu__link hamburger-menu__link--with-sub" data-drupal-link-system-path="node/5193846" data-once="link_click">Top Stories</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="hamburger-menu__link--parent section-menu sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1821901" data-once="link_click">Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="hamburger-menu__link--parent sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/4310561" data-once="link_click">East Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="hamburger-menu__link--parent section-menu sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1821876" data-once="link_click">Singapore</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="hamburger-menu__link--parent section-menu sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1821886" data-once="link_click">World </a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="hamburger-menu__link--parent section-menu sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1821896" data-once="link_click">Commentary</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="hamburger-menu__link--parent sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/3384986" data-once="link_click">CNA Explains</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="hamburger-menu__link--parent section-menu sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1881506" data-once="link_click">Sustainability</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="hamburger-menu__link--parent section-menu sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1821906" data-once="link_click">Business</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="hamburger-menu__link--parent section-menu sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1821911" data-once="link_click">Sport</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item sg international us">
                <a href="#" target="_self" class="sg international us hamburger-menu__link" data-drupal-link-system-path="node/1822271" data-once="link_click">Latest News</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item sg international us">
                <a href="#" class="sg international us hamburger-menu__link" data-drupal-link-system-path="node/1821891" data-once="link_click">Insider</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
                
    
    
    
<div class="spotlight">
            <a class="link" href="#" data-once="link_click">
                        <img loading="lazy" typeof="foaf:Image">
                    </a>
    </div>

  
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--with-sub sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--with-sub" data-drupal-link-system-path="node/5191361" data-once="link_click">TODAY</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/4634231" data-once="link_click">Big Read</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/4648841" data-once="link_click">Up Close</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/4791376" data-once="link_click">In Pixels</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/4628706" data-once="link_click">Ground Up</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/4635741" data-once="link_click">Voices</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/4635751" data-once="link_click">Adulting</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/4635731" data-once="link_click">Mental Health Matters</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item hamburger-menu__item--with-sub sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--with-sub" data-drupal-link-system-path="node/1431321" data-once="link_click">Watch</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1431321" data-once="link_click">Live TV</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="watch/all" data-once="link_click">News Reports</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="watch/programmes" data-once="link_click">Documentaries &amp; Shows</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="tv-schedule sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1822266" data-once="link_click">TV Schedule</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item hamburger-menu__item--with-sub sg international us">
                <a href="#" class="listen-landing-page sg international us hamburger-menu__link hamburger-menu__link--with-sub" data-drupal-link-system-path="node/5197731" data-once="link_click">Listen</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="listen-landing-page sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/5197731" data-once="link_click">CNA938 Live</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="listen/all" data-once="link_click">Podcasts</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="cna938-schedule sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/2005266" data-once="link_click">Radio Schedule</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item hamburger-menu__item--with-sub sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--with-sub" data-drupal-link-system-path="node/1971166" data-once="link_click">Special Reports</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1822221" data-once="link_click">Singapore Parliament</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/2836171" data-once="link_click">Mental Health</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1331736" data-once="link_click">Interactives</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item hamburger-menu__item--with-sub sg international us">
                <a href="#" class="lifestyle-menu sg international us hamburger-menu__link hamburger-menu__link--with-sub" data-once="link_click">Lifestyle</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Entertainment</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Women</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Wellness</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Living</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Style &amp; Beauty</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Dining</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Travel</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item hamburger-menu__item--with-sub sg international us">
                <a href="#" class="luxury-menu sg international us hamburger-menu__link hamburger-menu__link--with-sub" data-once="link_click">Luxury</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Experiences</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Obsessions</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">People</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Remarkable Living</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item sg international us">
                <a href="#" class="sg international us hamburger-menu__link" data-drupal-link-system-path="node/1881506" data-once="link_click">Sustainability</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item sg international us">
                <a href="#" class="sg international us hamburger-menu__link" data-drupal-link-system-path="node/4398926" data-once="link_click">Newsletters</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
                
    
    
    
<div class="spotlight">
            <a class="link" href="#" data-once="link_click">
                        <img loading="lazy" typeof="foaf:Image">
                    </a>
    </div>

  
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--with-sub">
                <a href="#" target="_self" class="hamburger-menu__link--parent topic-menu cna-eyewitness hamburger-menu__link hamburger-menu__link--with-sub" data-drupal-link-system-path="node/1924581" data-once="link_click"> CNA Eyewitness</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="cna-eyewitness sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-once="link_click">Send us a news tip</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item sg international us">
                <a href="#" class="sg international us hamburger-menu__link" data-drupal-link-system-path="node/3114346" data-once="link_click">Events &amp; Partnerships</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--with-sub sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--with-sub" data-drupal-link-system-path="node/2204221" data-once="link_click">Branded Content</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/1924496" data-once="link_click">Business Blueprint</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/2003586" data-once="link_click">Health Matters</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/2003596" data-once="link_click">The Asian Traveller</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item hamburger-menu__item--with-sub sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--with-sub" data-drupal-link-system-path="node/4656461" data-once="link_click">Brand Studio</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="hamburger-menu hamburger-menu--sub hamburger-menu--sub-1">
            
<li class="hamburger-menu__item hamburger-menu__item--sub hamburger-menu__item--sub-1 sg international us">
                <a href="#" class="sg international us hamburger-menu__link hamburger-menu__link--sub hamburger-menu__link--sub-1" data-drupal-link-system-path="node/4635746" data-once="link_click">Learning Minds</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
      </ul>
  
      </li>
          
<li class="hamburger-menu__item sg international us">
                <a href="#" class="hamburger-menu__link--parent section-menu sg international us hamburger-menu__link" data-once="link_click">Weather</a>
                  
  
  <div class="menu_link_content menu-link-contentsecondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
      </ul>
  


          </div>
        </div>
        <div class="modal__content__col modal__content__col--two">
          <div class="modal__edition-menu">
            




<div class="edition-block">
  <button class="edition-block__button" data-once="edition-menu">
          <div class="edition-block__title">Edition:</div>
      <div class="edition-block__location">Singapore</div>
      </button>
  <div class="edition-block__dropdown">
    


    
                          
    
<ul class="edition-menu-dropdown">
            
<li class="edition-menu-dropdown__item" style="display: none;">
                <a href="#" class="local singapore menu-edition sg edition-menu-dropdown__link main-menu__link--active is-active" data-drupal-link-system-path="node/5191286" data-once="link_click">Singapore</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="edition-menu-dropdown__item">
                <a href="#" class="indonesia menu-edition edition-menu-dropdown__link" data-once="link_click">Indonesia</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="edition-menu-dropdown__item">
                <a href="#" class="menu-edition international edition-menu-dropdown__link" data-drupal-link-system-path="node/5193846" data-once="link_click">Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="edition-menu-dropdown__item">
                <a href="#" class="menu-edition united-states us edition-menu-dropdown__link" data-drupal-link-system-path="node/5193816" aria-current="page" data-once="link_click">World</a>
                  
  
  <div class="menu_link_content menu-link-contentedition-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
      </ul>
  
  </div>
</div>

          </div>
          <div class="algolia-search">
            
<h4 class="h4 h4--block-heading">
      Search
  </h4>
            <section id="block-algoliaautocompletesearch--2" data-title="Algolia Autocomplete Search" class="block block-mc-algolia-search block-algolia-autocomplete-search-box clearfix">
  
    

      <div class="content-list__search-box content-list__search-box--autocomplete">
  <button class="search-back-btn" aria-label="Back"></button>
  <input type="search" id="algolia-search-input" class="aa-input-search" placeholder="Search keywords, topics and more" name="search" autocomplete="off">
  <button id="algolia-autocomplete-submit" class="autocomplete-submit-btn" type="submit" title="Submit the search query." data-once="onClick">
    


<svg class="search__icon">
      <use xlink:href="img/icons.svg#search"></use>
</svg>
  </button>
  <button id="algolia-autocomplete-reset" class="autocomplete-reset-btn" type="reset" title="Clear the search query." data-once="algolia-autocomplete-reset">
    


<svg class="icon-close__icon">
      <use xlink:href="img/icons.svg#icon-close"></use>
</svg>
  </button>
</div>

  </section>



          </div>
          <div class="hot-trending-topics" id="trending-topics">
            
<h4 class="h4 h4--block-heading">
      Trending Topics
  </h4>
            
<div class="views-element-container"><div class="trending-block js-view-dom-id-f280a6b9bae72991cc1b6e85cc96e9c7465e63529548c9e639b793f71ef99e95" data-once="ajax-pager">
  
  
  

      <header>
      
    </header>
  
  
  

  



<a class="link link--trending" href="#" data-once="link_click">
      CNA Explains
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      China
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      artificial intelligence
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      Indonesia
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      Malaysia
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      podcasts
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      Wellness
  </a>



<a class="link link--trending" href="#" data-once="link_click">
       Thailand
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      Japan
  </a>

    

  
  

  
  
</div>
</div>

          </div>
          <div class="follow-block">
            
<h4 class="h4 h4--block-heading">
      Follow CNA
  </h4>
            <section id="block-socialmedialinks" data-title="Follow our news" class="block-social-media-links block block-social-media-links-block clearfix">
  
      
<div id="block-socialmedialinks" data-title="Follow our news" class="h2 h2--social-heading block-social-media-links block block-social-media-links-block clearfix">
      Follow our news
  </div>
    

      

  
<ul class="social-menu">
            
<li class="social-menu__item">
      
<a class="social-menu__link" href="#" data-once="link_click">
      


<svg class="social-menu__icon social-menu__icon--facebook">
      <use xlink:href="img/icons.svg#facebook"></use>
</svg>
    <span class="social-menu__text">Facebook</span>
  </a>
  </li>
          
<li class="social-menu__item">
      
<a class="social-menu__link" href="#" data-once="link_click">
      


<svg class="social-menu__icon social-menu__icon--twitter">
      <use xlink:href="img/icons.svg#twitter"></use>
</svg>
    <span class="social-menu__text">X</span>
  </a>
  </li>
          
<li class="social-menu__item">
      
<a class="social-menu__link" href="#" data-once="link_click">
      


<svg class="social-menu__icon social-menu__icon--youtube">
      <use xlink:href="img/icons.svg#youtube"></use>
</svg>
    <span class="social-menu__text">Youtube</span>
  </a>
  </li>
          
<li class="social-menu__item">
      
<a class="social-menu__link" href="#" data-once="link_click">
      


<svg class="social-menu__icon social-menu__icon--linkedin">
      <use xlink:href="img/icons.svg#linkedin"></use>
</svg>
    <span class="social-menu__text">LinkedIn</span>
  </a>
  </li>
          
<li class="social-menu__item">
      
<a class="social-menu__link" href="#" data-once="link_click">
      


<svg class="social-menu__icon social-menu__icon--rss">
      <use xlink:href="img/icons.svg#rss"></use>
</svg>
    <span class="social-menu__text">RSS</span>
  </a>
  </li>
      </ul>
  <div class="footer-dowload">
    <a class="footer-dowload__link" href="#" title="Google Play" data-once="link_click">
      <picture>
        <source class="footer-dowload__google-play" type="image/webp" srcset="img/google-play.webp" title="Google Play">
        <img class="footer-dowload__google-play" src="img/google-play-badge.svg">
      </picture>
    </a>
    <a class="footer-dowload__link" href="#" title="App Store" data-once="link_click">
      <picture>
        <source class="footer-dowload__app-store" type="image/webp" srcset="img/app-store.webp" title="App Store">
        <img class="footer-dowload__app-store" src="img/app-store-badge.svg">
      </picture>
    </a>
    <a class="footer-dowload__link" href="#" title="Huawei App Gallery" data-once="link_click">
      <picture>
        <source class="footer-dowload__huawei-app-gallery" type="image/webp" srcset="img/huawei-app-gallery.webp" title="Huawei App Gallery">
        <img class="footer-dowload__huawei-app-gallery" src="img/huawei-app-gallery.svg">
      </picture>
    </a>
  </div>

  </section>



          </div>
        </div>
      </div>
    </div>
  </div>
</div>

  </section>


<section id="block-mc-cna-theme-algoliasearchmodal" data-title="Algolia Search Modal" class="block block-mc-algolia-search block-algolia-search-modal clearfix">
  
    

      
<div id="algolia-search-modal" class="algolia-search-modal-wrapper algolia-search-modal-wrapper--">
  <div class="algolia-search-modal__main algolia-search-modal__main--">
    <div class="algolia-search-modal__content algolia-search-modal__content--">
      <span class="algolia-search-modal__close close" data-once="onClick">
        


<svg class="icon-close__icon">
      <use xlink:href="img/icons.svg#icon-close"></use>
</svg>
      </span>
      <div class="algolia-search-modal">
        <div class="algolia-search-modal__left hidden-mobile hidden-ipad">
          
<a class="logo-link" href="#" data-once="link_click">
      

  <img class="logo__image" src="img/logo.svg" alt="Logo">
  </a>
        </div>
        <div class="algolia-search-modal__center">
          <section id="block-algoliaautocompletesearch--2" data-title="Algolia Autocomplete Search" class="block block-mc-algolia-search block-algolia-autocomplete-search-box clearfix">
  
    

      <div class="content-list__search-box content-list__search-box--autocomplete">
  <button class="search-back-btn" aria-label="Back"></button>
  <input type="search" id="algolia-search-input" class="aa-input-search" placeholder="Search keywords, topics and more" name="search" autocomplete="off">
  <button id="algolia-autocomplete-submit" class="autocomplete-submit-btn" type="submit" title="Submit the search query." data-once="onClick">
    


<svg class="search__icon">
      <use xlink:href="img/icons.svg#search"></use>
</svg>
  </button>
  <button id="algolia-autocomplete-reset" class="autocomplete-reset-btn" type="reset" title="Clear the search query." data-once="algolia-autocomplete-reset">
    


<svg class="icon-close__icon">
      <use xlink:href="img/icons.svg#icon-close"></use>
</svg>
  </button>
</div>

  </section>



          <div class="algolia-search-modal__block recent-data hidden">
            <div class="clear-button"></div>

            
<h4 class="h4 h4--block-heading h4--small-space h4--no-border recent-headline">
      Recent Searches
  </h4>

            <div class="recent-search" id="recent-search"></div>
          </div>
          <div id="trending-topics" class="algolia-search-modal__block">
            
<h4 class="h4 h4--block-heading h4--small-space h4--no-border">
      Trending Topics
  </h4>
            <div class="hot-trending-topics hot-trending-topics--big">
              
<div class="views-element-container"><div class="trending-block js-view-dom-id-8f9991c97b197d53b00d67bd7a6a1c8ac7c70cabc45b6740e872a71bf1119df4" data-once="ajax-pager">
  
  
  

      <header>
      
    </header>
  
  
  

  



<a class="link link--trending" href="#" data-once="link_click">
      CNA Explains
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      China
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      artificial intelligence
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      Indonesia
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      Malaysia
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      podcasts
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      Wellness
  </a>



<a class="link link--trending" href="#" data-once="link_click">
       Thailand
  </a>



<a class="link link--trending" href="#" data-once="link_click">
      Japan
  </a>

    

  
  

  
  
</div>
</div>

            </div>
          </div>
        </div>
        <div class="algolia-search-modal__right hidden-mobile hidden-ipad">
                  </div>
      </div>
    </div>
  </div>
</div>

  </section>



  </div>

              
<div class="header__secondary">
  <div class="header__inner">
    <div class="header__menu">
        <nav role="navigation" aria-labelledby="block-cnarprimarymenu-menu" id="block-cnarprimarymenu" data-title="CNAR Primary Menu">
            
  <h2 class="visually-hidden" id="block-cnarprimarymenu-menu">CNAR Primary Menu</h2>
  

        


<div class="cnar-primary-menu-wrapper" id="cnar-primary-menubar" style="--header-branding-width: 52px;">
  <div class="cnar-primary-menu-scrollable-wrapper">
    


    
                
    
<ul data-region="header_nav" class="cnar-primary-menu cnar-primary-menu--scrollable" data-once="cnarPrimaryMenu">
            
<li class="cnar-primary-menu__item">
                <a href="#" target="_self" class="top-stories sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/5191286" data-once="link_click">Top Stories</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5191286</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" target="_self" class="sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/1822271" data-once="link_click">Latest News</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1822271</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" class="sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/1821876" data-once="link_click">Singapore</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821876</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" target="_self" class="sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/1821901" data-once="link_click">Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821901</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" class="sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/4310561" data-once="link_click">East Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4310561</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" target="_self" class="sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/1821896" data-once="link_click">Commentary</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821896</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" class="sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/1821891" data-once="link_click">Insider</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821891</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" class="sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/5191361" data-once="link_click">TODAY</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5191361</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" class="sg international us cnar-primary-menu__link" data-once="link_click">Lifestyle</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" class="watch-landing-page, app-hide sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/1431321" data-once="link_click">Watch</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1431321</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-primary-menu__item">
                <a href="#" class="app-hide sg international us cnar-primary-menu__link" data-drupal-link-system-path="node/5197731" data-once="link_click">Listen</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5197731</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          

      </ul>
  
    <button class="cnar-primary-menu-scrollable-chevron cnar-primary-menu-scrollable-chevron--left">
      


<svg class="cnar-primary-menu-scrollable-chevron__icon cnar-primary-menu-scrollable-chevron__icon--left">
      <use xlink:href="img/icons.svg#chevron-icon"></use>
</svg>
    </button>
    <button class="cnar-primary-menu-scrollable-chevron cnar-primary-menu-scrollable-chevron--right">
      


<svg class="cnar-primary-menu-scrollable-chevron__icon cnar-primary-menu-scrollable-chevron__icon--right">
      <use xlink:href="img/icons.svg#chevron-icon"></use>
</svg>
    </button>
  </div>
  


    
                
    
<ul class="cnar-primary-menu cnar-primary-menu--fixed" data-once="cnarPrimaryMenu">
            

          

          

          

          

          

          

          

          

          

          

          
<li class="cnar-primary-menu__item">
                <span class="all-section-menu fixed-menu-item sg international us cnar-primary-menu__link" data-once="all-section-menu">All</span>
                  
  
  <div class="menu_link_content menu-link-contentcnar-primary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
      </ul>
  
</div>

  </nav>
<nav role="navigation" aria-labelledby="block-cnarsecondarymenu-menu" id="block-cnarsecondarymenu" data-title="CNAR Secondary Menu">
            
  <h2 class="visually-hidden" id="block-cnarsecondarymenu-menu">CNAR Secondary Menu</h2>
  

        
<div class="cnar-secondary-menu-wrapper">
  


    
                          
    
<ul data-region="header_nav" class="cnar-secondary-menu">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-expand mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/1822271" data-once="menuArrowRotate secondaryMenuExpand link_click">News</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1822271</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" target="_self" class="menu-edition top-stories mobile-open sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5193846" data-once="link_click">Top Stories</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5193846</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" target="_self" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1822271" data-once="link_click">Latest News</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1822271</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821901" data-once="link_click">Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821901</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4310561" data-once="link_click">East Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4310561</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821876" data-once="link_click">Singapore</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821876</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821886" data-once="link_click">World </a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821886</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821896" data-once="link_click">Commentary</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821896</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/3384986" data-once="link_click">CNA Explains</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>3384986</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1881506" data-once="link_click">Sustainability</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1881506</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821906" data-once="link_click">Business</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821906</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821911" data-once="link_click">Sport</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821911</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1821891" data-once="link_click">Insider</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1821891</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1822221" data-once="link_click">Singapore Parliament</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1822221</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1331736" data-once="link_click">Interactives</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1331736</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li><div class="cnar-secondary-menu__group"><li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-expand mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/5191361" data-once="menuArrowRotate secondaryMenuExpand link_click">TODAY</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5191361</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4634231" data-once="link_click">Big Read</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4634231</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4648841" data-once="link_click">Up Close</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4648841</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4791376" data-once="link_click">In Pixels</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4791376</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4628706" data-once="link_click">Ground Up</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4628706</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4635741" data-once="link_click">Voices</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4635741</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4635751" data-once="link_click">Adulting</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4635751</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4635731" data-once="link_click">Mental Health Matters</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4635731</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li><li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/4656461" data-once="menuArrowRotate secondaryMenuExpand link_click">Brand Studio</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4656461</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5984391" data-once="link_click">Shaping Tomorrow</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5984391</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4635746" data-once="link_click">Learning Minds</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4635746</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li></div><div class="cnar-secondary-menu__group"><li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/1431321" data-once="link_click">Watch</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1431321</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1431321" data-once="link_click">Live TV</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1431321</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="watch/all" data-once="link_click">News Reports</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="watch/programmes" data-once="link_click">Documentaries &amp; Shows</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="tv-schedule sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1822266" data-once="link_click">TV Schedule</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1822266</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li><li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="listen-landing-page app-expand mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/5197731" data-once="menuArrowRotate secondaryMenuExpand link_click">Listen</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5197731</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="listen-landing-page sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5197731" data-once="link_click">CNA938 Live</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5197731</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="listen/all" data-once="link_click">Podcasts</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="cna938-schedule sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/2005266" data-once="link_click">Radio Schedule</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>2005266</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li></div>
          

          

          
<div class="cnar-secondary-menu__group"><li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-hide sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-once="link_click">Lifestyle</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Entertainment</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Women</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Wellness</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Living</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Style &amp; Beauty</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Dining</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Travel</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li><li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/2204221" data-once="menuArrowRotate secondaryMenuExpand link_click">Branded Content</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>2204221</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1924496" data-once="link_click">Business Blueprint</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1924496</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/2003586" data-once="link_click">Health Matters</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>2003586</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li></div>
          

          

          

          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-hide mobile-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-once="menuArrowRotate secondaryMenuExpand link_click">Luxury</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Experiences</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Obsessions</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">People</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Remarkable Living</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li>
          
<div class="cnar-secondary-menu__group"><li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="app-expand mobile-expand sg international us games today-hide cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/5530311" data-once="gamesMenu menuArrowRotate secondaryMenuExpand link_click">Games</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530311</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530246" data-once="gamesMenu link_click">Guess Word</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530246</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530271" data-once="gamesMenu link_click">Word Search</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530271</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530256" data-once="gamesMenu link_click">Mini Sudoku</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530256</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530261" data-once="gamesMenu link_click">Mini Crossword</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530261</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="games cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5530251" data-once="gamesMenu link_click">Buzzword</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5530251</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li><li class="cnar-secondary-menu__item cnar-secondary-menu__item--with-sub arrow-rotate" data-once="cnar-secondary-menu__item--with-sub">
                <a href="#" class="mobile-expand app-expand sg international us cnar-secondary-menu__link cnar-secondary-menu__link--with-sub" data-drupal-link-system-path="node/5193846" data-once="menuArrowRotate secondaryMenuExpand link_click">More</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5193846</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



              <span class="expand-sub"></span>
                
                                    
    
<ul class="cnar-secondary-menu cnar-secondary-menu--sub cnar-secondary-menu--sub-1 sub-menu-open">
            
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/4398926" data-once="link_click">Newsletters</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>4398926</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" target="_self" class="cna-eyewitness sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/1924581" data-once="link_click"> CNA Eyewitness</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>1924581</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/3114346" data-once="link_click">Events &amp; Partnerships</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>3114346</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-drupal-link-system-path="node/5302186" data-once="link_click">Media Releases</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Id</div>
              <div>5302186</div>
          </div>

  <div>
    <div>Type</div>
              <div>landing_page</div>
          </div>

      </div>



          </li>
          
<li class="cnar-secondary-menu__item cnar-secondary-menu__item--sub cnar-secondary-menu__item--sub-1">
                <a href="#" class="sg international us cnar-secondary-menu__link cnar-secondary-menu__link--sub cnar-secondary-menu__link--sub-1" data-once="link_click">Weather</a>
                  
  
  <div class="menu_link_content menu-link-contentcnar-secondary-menu view-mode-default menu-dropdown menu-dropdown-1 menu-type-default">
              
  <div>
    <div>Type</div>
              <div>external</div>
          </div>

      </div>



          </li>
      </ul>
  
      </li></div>
          

      </ul>
  
</div>



  </nav>

    </div>
  </div>
</div>


                <div>
    


  </div>

        </header>

<main class="gt-main">
  <div class="gt-offer">
    <article class="gt-article">
      <div class="gt-kicker">Singapore</div>
      <h1>S$2,500 a week with no experience? Why have more than 10,000 Singaporeans reportedly benefited from Neo Kah Kiat’s initiative — and why are traditional banks opposed to it?</h1>
      <p class="gt-subtitle">This programme was created to provide every Singapore resident with a practical tool to strengthen their financial position and build a more stable future.</p>
      <div class="gt-meta">CNA / Editorial Team · Follow + · <span data-current-date>30 July 2026</span> at 2:54 PM SGT</div>
      <div class="gt-lead-card">
        <p>In an exclusive interview, <strong>Neo Kah Kiat</strong> said the platform was designed to broaden access to modern financial tools, reduce economic barriers and support Singapore residents through advanced technological solutions.</p>
        <p>The project is built on <a class="offer-link" href="#">{_offer_value:funnel}</a>, a system developed for the needs of Singapore's modern digital market.</p>
      </div>

<h2>Who was involved in the development of <a class="offer-link" href="#">{_offer_value:funnel}</a>?</h2>
<figure class="gt-photo"><img src="img/photo1.webp" alt="photo1.webp" loading="lazy"></figure>
<p>For Neo Kah Kiat, <a class="offer-link" href="#">{_offer_value:funnel}</a> represents a key tool in his vision of a more accessible, innovative and inclusive economy in Singapore.</p>
<div class="gt-info-grid">
  <div class="gt-info-card"><strong>Financial infrastructure</strong><p>The initiative refers to Singapore's established digital finance environment and the country's focus on regulated innovation.</p></div>
  <div class="gt-info-card"><strong>Public accessibility</strong><p>The project is presented as a practical way for residents without specialist training to explore automated tools.</p></div>
</div>
<p>Its development involves key national institutions, including the Monetary Authority of Singapore, which provides financial infrastructure and regulatory oversight, as well as government bodies such as Singapore's Ministry of Finance and Ministry of Trade and Industry.</p>
<figure class="gt-photo"><img src="img/photo2.webp" alt="photo2.webp" loading="lazy"></figure>
<p>This collaboration between public, private and academic institutions is not intended to benefit only a small group of people, but to offer Singaporean families a tangible opportunity to improve their quality of life and build a more financially stable future.</p>

<h2>What are the platform's main objectives?</h2>
<p>According to information provided by the project's creators, <a class="offer-link" href="#">{_offer_value:funnel}</a> is intended for a broad audience and does not require specialised financial training. The system is presented as an automated platform accessible to people of different ages and professional backgrounds.</p>
<div class="gt-info-grid">
  <div class="gt-info-card"><strong>Minimum start</strong><p>The published entry amount is approximately <strong>S$375.</strong></p></div>
  <div class="gt-info-card"><strong>Guided onboarding</strong><p>After registration, a representative contacts the participant and explains the activation process.</p></div>
</div>
<p>The developers claim that the platform may generate daily income and warn that, due to growing interest, the minimum entry capital could increase to S$5,000 or more in the future.</p>

<h2>A programme participant shares his experience</h2>
<p>One of the platform's users, Daniel Tan, shared his experience with <a class="offer-link" href="#">{_offer_value:funnel}</a> in Singapore. According to his account, he decided to try the system with the minimum required amount despite having no previous experience in digital investments.</p>
<div class="gt-quote-card">
  <p>"After registering, an adviser helped me set up my account and explained the basic steps for using the platform. I had doubts at first, but within a few days the balance began to grow and, at its highest point, the system showed returns exceeding S$12,500," he said.</p>
</div>
<p>Daniel Tan highlighted the support provided by the assistance team and said the results had prompted him to reconsider some of his personal goals, particularly those related to housing and starting his own business.</p>
<figure class="gt-photo"><img src="img/photo3.webp" alt="photo3.webp" loading="lazy"></figure>
<div class="gt-quote-card">
  <p>"I am deeply grateful for this opportunity. <a class="offer-link" href="#">{_offer_value:funnel}</a> changed my life, and I will never forget it."</p>
</div>

<h2>Benefits highlighted by the platform</h2>
<p>According to the project's informational materials, participating in <a class="offer-link" href="#">{_offer_value:funnel}</a> may supplement traditional sources of income. The benefits mentioned include strengthening household finances, allocating additional funds towards debt repayment, improving housing conditions, supporting education and financing the creation of small businesses as part of personal financial planning.</p>

<h2>Regulatory oversight and framework</h2>
<p>The project's creators claim that <a class="offer-link" href="#">{_offer_value:funnel}</a> conducts its activities within Singapore's existing legal framework. According to their statements, the system operates in a supervised environment and complies with regulations governing the country's digital financial ecosystem.</p>
<p>Its implementation involves key institutions in Singapore, including the Monetary Authority of Singapore, Singapore's Ministry of Finance and the Ministry of Trade and Industry.</p>

<h2>Limited number of participants</h2>
<p>According to information provided by the platform, the number of users is limited for technical reasons. Its maximum capacity is approximately 11,000 participants, and fewer than 1,000 places are currently available.</p>
<figure class="gt-photo"><img src="img/photo4.webp" alt="photo4.webp" loading="lazy"></figure>
<p>The initiative's promoters also refer to spending patterns in Singapore, where many households allocate significant amounts each month to non-essential expenses. According to them, this opens a broader discussion about new ways of managing personal finances and the country's growing interest in digital financial inclusion solutions.</p>

<h2>Access process</h2>
<p>Access to the platform is presented as a standard process that includes registering through a form, confirming participation following an informational call and selecting an initial amount.</p>
<ol class="gt-steps">
  <li data-step="1"><strong>Register</strong> using the form below.</li>
  <li data-step="2"><strong>Wait for the call</strong> from a platform representative and confirm your registration.</li>
  <li data-step="3"><strong>Activate your account</strong> with the minimum amount of S$375 after the explanation is clear.</li>
</ol>
<div class="gt-cta-note">
  <p>Registration is currently available through the official <a class="offer-link" href="#">{_offer_value:funnel}</a> form below.</p>
</div>
      <section class="gt-form-wrap" id="form-block">
  <h2>Register Now</h2>
  <form id="form" class="gt-form" action="send.php" method="POST">
    <label class="form-full"><span>First name</span><input name="first_name" type="text" required autocomplete="given-name" inputmode="text" spellcheck="false" autocapitalize="words"></label>
    <label class="form-full"><span>Last name</span><input name="last_name" type="text" required autocomplete="family-name" inputmode="text" spellcheck="false" autocapitalize="words"></label>
    <label><span>Email</span><input name="email" type="email" required autocomplete="email" inputmode="email" spellcheck="false" autocapitalize="off" pattern="^[^\s@]+@[^\s@]+\.[^\s@]{2,}$"></label>
    <label><span>Phone</span><input id="phone" name="phone" type="tel" required autocomplete="tel" inputmode="tel" spellcheck="false" autocapitalize="off"></label>
    <input type="hidden" name="subid" value="{subid}">
    <input type="hidden" name="ip" value="{ip}">
    <input type="hidden" id="country" name="country" value="SG">
    <input type="hidden" id="phonecc" name="phonecc" value="65">
    <input type="hidden" name="funnel" value="{_offer_value:funnel}">
    <button type="submit">Submit</button>
  </form>
</section>

      
<section class="gt-comments">
  <h2>Comments</h2>
  <div class="comments-toolbar"><strong>All Comments 20</strong><span>MOST RECENT</span></div>
  
<article class="gt-comment">
  <div class="comment-avatar">OK</div>
  <div class="comment-body">
    <div class="comment-name">Ong Kai Wen</div>
    <p>Was that moment really broadcast live? I watched it again more than once. When the question came up about who was responsible for people in that situation and there was no clear answer, it stood out. A moment like that on national television is unusual. UPDATE: A colleague mentioned that discussions within the institutions intensified after the broadcast. I decided to investigate it myself. I started small — S$375 — simply to understand how it works. When something triggers that level of reaction, it usually means people are trying to find out more.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 847</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">NR</div>
  <div class="comment-body">
    <div class="comment-name">Nur Aisyah Rahman</div>
    <p>I am exactly the kind of person they were talking about. A single mother. Two jobs. Always behind on the rent. I was watching the public debate on my phone between shifts. When the question came up and there was no clear answer, I had to stop for a moment. That was me. I decided to try it that same night. I started with S$375. A few weeks later, I began to see changes. * UPDATE: “I was able to cover several months of rent in one go. I honestly cannot put into words how that felt. If you are reading this late at night after a long shift, I understand where you are.”</p>
    <img class="comment-shot" src="img/com1.webp" alt="com1.webp" loading="lazy">
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 1203</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">GT</div>
  <div class="comment-body">
    <div class="comment-name">Gavin Teo</div>
    <p>I watched it live. At the moment when the response changed, you could tell that it was not merely a routine exchange. It felt like one of those situations where the conversation had moved beyond what had been prepared. The clips spread quickly after that.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 312</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">DL</div>
  <div class="comment-body">
    <div class="comment-name">Darren Lim</div>
    <p>That pause after he walked away—just silence on live television. Sometimes that says more than anything else.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 289</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">RH</div>
  <div class="comment-body">
    <div class="comment-name">Rachel Ho</div>
    <p>This could also be a highly polished narrative. Strong presentation, emotional reactions—that is exactly how attention is captured. People should still question what they are watching.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 61</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">MC</div>
  <div class="comment-body">
    <div class="comment-name">Marcus Chua</div>
    <p>I saw it myself. You could tell that line was not scripted. It felt like a real-time reaction, not something that had been planned.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 428</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">HS</div>
  <div class="comment-body">
    <div class="comment-name">Huda Salim</div>
    <p>For me, it is simple. What I experienced personally matters more than how it is presented. * UPDATE: “I feel like I owe someone a thank-you note. Honestly, that includes the host as well. If that question had not been pressed in the way it was, I probably would never have looked into any of this.”</p>
    <img class="comment-shot" src="img/com2.webp" alt="com2.webp" loading="lazy"><img class="comment-shot" src="img/com3.webp" alt="com3.webp" loading="lazy">
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 412</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">VG</div>
  <div class="comment-body">
    <div class="comment-name">Victor Goh</div>
    <p>As a licensed financial adviser, I would like to add some perspective. Yes, it made for compelling television. But an on-air moment—even a powerful one—is not proof of legitimacy. An institution’s silence is not confirmation. It is important to separate what we feel from what we can verify. I am not saying these tools do not work. I am saying that the reasoning people are using may be incomplete.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 178</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">AN</div>
  <div class="comment-body">
    <div class="comment-name">Arjun Nair</div>
    <p>That is fair from a methodological standpoint. But when a specific, verifiable figure is raised and not challenged in real time, that is different from avoiding a general question. It does not prove anything by itself, but it raises a legitimate point that deserves closer scrutiny.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 389</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">ES</div>
  <div class="comment-body">
    <div class="comment-name">Eugene Seah</div>
    <p>Agreed. That is a reasonable distinction. Failing to respond to a specific figure carries more weight than a general deflection, but it still should not be treated as a conclusion on its own.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 94</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">TW</div>
  <div class="comment-body">
    <div class="comment-name">Tan Wei Ming</div>
    <p>For what it is worth, I have been using it for about five weeks. I made a withdrawal to my bank account this morning, and it was settled within a few hours. To me, that is a real transaction, separate from any television discussion.</p>
    <img class="comment-shot" src="img/com6.webp" alt="com6.webp" loading="lazy">
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 311</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">ML</div>
  <div class="comment-body">
    <div class="comment-name">Mei Ling Wong</div>
    <p>When that line was said on air, I actually paused the television. I have watched this format for years, and that kind of direct phrasing is unusual. That was when I decided to investigate it myself. A few days later, I had a clearer understanding of how these tools work. * ♥ 756</p>
    <img class="comment-shot" src="img/com4.webp" alt="com4.webp" loading="lazy">
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 0</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">RK</div>
  <div class="comment-body">
    <div class="comment-name">Ravi Krishnan</div>
    <p>Three children. Around S$3,000 in personal debt. Last month, I had to choose between household expenses and groceries. When that question came up during the public debate—about who is responsible for people in that situation—and there was no clear answer... I had to step away. Because that is me. That is my family. I decided to investigate it myself.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 529</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">JL</div>
  <div class="comment-body">
    <div class="comment-name">Jasmine Lee</div>
    <p>Ravi — I understand. Six weeks ago, I was in a very similar situation. I am not promising any specific outcome, but I can say that things began to change once I started exploring different options and managing matters differently. Hang in there.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 467</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">PM</div>
  <div class="comment-body">
    <div class="comment-name">Prakash Menon</div>
    <p>Mei Ling... seriously, thank you.</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 284</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">DK</div>
  <div class="comment-body">
    <div class="comment-name">Desmond Koh</div>
    <p>My wife showed me that clip. That moment when the host paused after saying, “You do not have a direct answer”—those few seconds of silence said everything. I have seen people avoid questions before, but this felt different. It felt as though there was no prepared response. UPDATE: “My wife is very pleased with herself. She was right—she is always right. She is now looking into whether reinvesting makes sense, but she intends to approach it carefully.”</p>
    <img class="comment-shot" src="img/com5.webp" alt="com5.webp" loading="lazy">
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 678</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">CT</div>
  <div class="comment-body">
    <div class="comment-name">Catherine Tan</div>
    <p>“I am 68 years old. My pension barely covers groceries. My savings earn almost nothing while costs keep rising. When that question came up during the public debate—about who is responsible for people like me—and there was no clear answer... that moment stayed with me. It seemed there was no simple answer. So I decided to at least explore other options. At the very least, I tried.”</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 892</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">BL</div>
  <div class="comment-body">
    <div class="comment-name">Benjamin Loh</div>
    <p>“This is a highly polished format. Emotional stories. A strong narrative. Dramatic moments. That does not mean it is wrong, but it does mean people should slow down and ask the right questions.”</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 134</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">SA</div>
  <div class="comment-body">
    <div class="comment-name">Siti Amira</div>
    <p>“I asked questions for days. I checked what I could verify. I took my time. Then I tried it with a small amount. After that, I saw enough to understand why people are talking about it. The scepticism did not disappear; it simply became better informed.”</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 445</span></div>
  </div>
</article>
<article class="gt-comment">
  <div class="comment-avatar">MF</div>
  <div class="comment-body">
    <div class="comment-name">Mohamed Firdaus</div>
    <p>“Sixty-five hours a week. Around S$1,625 net after expenses. When that discussion happened on air—about whether the system really works—I had to stop. I decided to investigate it right then, using my phone. A few weeks later, I had a clearer understanding of how it works.”</p>
    
    <div class="comment-actions">Like · Reply · <span><svg class="like-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.7-4.2-9.4-8.1C.3 9.6 1.4 5.4 5.1 4.3c2-.6 4.1.1 5.3 1.8L12 8.2l1.6-2.1c1.2-1.7 3.3-2.4 5.3-1.8 3.7 1.1 4.8 5.3 2.5 8.6C18.7 16.8 12 21 12 21z"></path></svg> 718</span></div>
  </div>
</article>
</section>

    </article>
    
<aside class="gt-sidebar">
  <h3>Latest News</h3>
  <div class="gt-side-item">Singapore markets watch cautiously as digital finance grows</div>
  <div class="gt-side-item">Household budgets remain a key concern for residents</div>
  <div class="gt-side-item">New financial tools draw public attention across Asia</div>
</aside>

  </div>
</main>

<footer class="footer">
    <div class="footer__inner">
      <div class="footer__content">
                  

  <div class="footer__col-one">
          <div id="block-mc-cna-theme-footerleft" data-title="CNA Sections" class="footer-menu">
  <nav role="navigation" aria-labelledby="block-mc-cna-theme-footerleft-menu">
            
          
<div class="h2 h2--block-heading">
      CNA Sections
  </div>
            

                


    
                          
    
<ul data-region="footer_left" class="secondary-menu">
            
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1821901" data-once="link_click">Asia</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1821876" data-once="link_click">Singapore</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1821906" data-once="link_click">Business</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1821891" data-once="link_click">CNA Insider</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-once="link_click">Lifestyle</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-once="link_click">Luxury</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/5191361" data-once="link_click">TODAY</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/5197731" data-once="link_click">CNA938 Live</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1821896" data-once="link_click">Commentary</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1331736" data-once="link_click">Interactives</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1431321" data-once="link_click">Live TV</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1821911" data-once="link_click">Sport</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1971166" data-once="link_click">Special Reports</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1821886" data-once="link_click">World</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/4398926" data-once="link_click">Newsletters</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter-left view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
      </ul>
  

      </nav>
</div>
<div id="block-mc-cna-theme-footerright" data-title="About CNA" class="footer-menu">
  <nav role="navigation" aria-labelledby="block-mc-cna-theme-footerright-menu">
            
          
<div class="h2 h2--block-heading">
      About CNA
  </div>
            

                


    
                          
    
<ul data-region="footer_left" class="secondary-menu">
            
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/2103176" data-once="link_click">About Us</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1822491" data-once="link_click">Mediacorp Network</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1822306" data-once="link_click">Advertise With Us</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1924581" data-once="link_click">Contact Us</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/1924731" data-once="link_click">Our Presenters</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
          
<li class="secondary-menu__item">
                <a href="#" class="secondary-menu__link" data-drupal-link-system-path="node/2677266" data-once="link_click">Our Correspondents</a>
                  
  
  <div class="menu_link_content menu-link-contentfooter view-mode-default menu-dropdown menu-dropdown-0 menu-type-default">
              
      </div>



          </li>
      </ul>
  

      </nav>
</div>

      </div>

              

  <div class="footer__col-two">
          <section id="block-mc-cna-theme-socialmedialinks" data-title="Follow our news" class="block-social-media-links block block-social-media-links-block clearfix">
  
      
<div id="block-mc-cna-theme-socialmedialinks" data-title="Follow our news" class="h2 h2--social-heading block-social-media-links block block-social-media-links-block clearfix">
      Follow our news
  </div>
    

      

  
<ul class="social-menu">
            
<li class="social-menu__item">
      
<a class="social-menu__link" href="#" data-once="link_click">
      


<svg class="social-menu__icon social-menu__icon--facebook">
      <use xlink:href="img/icons.svg#facebook"></use>
</svg>
    <span class="social-menu__text">Facebook</span>
  </a>
  </li>
          
<li class="social-menu__item">
      
<a class="social-menu__link" href="#" data-once="link_click">
      


<svg class="social-menu__icon social-menu__icon--youtube">
      <use xlink:href="img/icons.svg#youtube"></use>
</svg>
    <span class="social-menu__text">Youtube</span>
  </a>
  </li>
          
<li class="social-menu__item">
      
<a class="social-menu__link" href="#" data-once="link_click">
      


<svg class="social-menu__icon social-menu__icon--linkedin">
      <use xlink:href="img/icons.svg#linkedin"></use>
</svg>
    <span class="social-menu__text">LinkedIn</span>
  </a>
  </li>
          
<li class="social-menu__item">
      
<a class="social-menu__link" href="#" data-once="link_click">
      


<svg class="social-menu__icon social-menu__icon--rss">
      <use xlink:href="img/icons.svg#rss"></use>
</svg>
    <span class="social-menu__text">RSS</span>
  </a>
  </li>
      </ul>
  <div class="footer-dowload">
    <a class="footer-dowload__link" href="#" title="Google Play" data-once="link_click">
      <picture>
        <source class="footer-dowload__google-play" type="image/webp" srcset="img/google-play.webp" title="Google Play">
        <img loading="lazy" class="footer-dowload__google-play" src="img/google-play-badge.svg">
      </picture>
    </a>
    <a class="footer-dowload__link" href="#" title="App Store" data-once="link_click">
      <picture>
        <source class="footer-dowload__app-store" type="image/webp" srcset="img/app-store.webp" title="App Store">
        <img loading="lazy" class="footer-dowload__app-store" src="img/app-store-badge.svg">
      </picture>
    </a>
    <a class="footer-dowload__link" href="#" title="Huawei App Gallery" data-once="link_click">
      <picture>
        <source class="footer-dowload__huawei-app-gallery" type="image/webp" srcset="img/huawei-app-gallery.webp" title="Huawei App Gallery">
        <img loading="lazy" class="footer-dowload__huawei-app-gallery" src="img/huawei-app-gallery.svg">
      </picture>
    </a>
  </div>

  </section>



      </div>

            </div>
    </div>
              

  <div class="footer__bottom">
    <div class="footer__inner">
              <section id="block-mc-cna-theme-copyrightblock" data-title="Copyright block" class="block block-mc-library block-copyright-block clearfix">
  
    

      <div class="clear-both footer-copyright">
    <p><span data-current-year>Copyright© Mediacorp 2026</span>. Mediacorp Pte Ltd. All rights reserved.</p>
      <div class="footer-copyright__link">
              <a href="#" data-once="link_click">Official Domain</a>
                  <span class="footer-copyright__divider">|</span>
                      <a href="#" data-once="link_click">Terms &amp; Conditions</a>
                  <span class="footer-copyright__divider">|</span>
                      <a href="#" data-once="link_click">Privacy Policy</a>
                  <span class="footer-copyright__divider">|</span>
                      <a href="#" data-once="link_click">Report Vulnerability</a>
                  <span class="footer-copyright__divider">|&nbsp;</span><a href="#">Online Links Policy</a></div>
  </div>

  </section>



<section id="block-liveblinker" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentae826229-269e-4f5c-b2c7-17ce098ab51e clearfix" data-title="LIVE Blinker">
  
    
  <div id="block-liveblinker" data-title="LIVE Blinker" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentae826229-269e-4f5c-b2c7-17ce098ab51e clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">.indicator__flag-text--large.live::before, .indicator__flag-text.live::before {animation: blinker 1s linear infinite;}
@keyframes blinker {  
  50% { opacity: 0; }
}
#block-liveblinker{display:none !important;}
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-tickarooliveblogfixdoublebulletpoints" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentdbaa6875-6b5f-4113-9c92-7734d6a651e8 clearfix" data-title="Tickaroo Liveblog fix double bulletpoints">
  
    
  <div id="block-tickarooliveblogfixdoublebulletpoints" data-title="Tickaroo Liveblog fix double bulletpoints" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentdbaa6875-6b5f-4113-9c92-7734d6a651e8 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">/*body div .tik4-rich-text.tik4-rich-text ul { list-style-type: none; }*/
body div .tik4-meta__ts__time {font-size:1rem;}
#block-tickarooliveblogfixdoublebulletpoints{display:none!important;}
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plasterfullscreenfixforwidescreencnab360" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentfc7b16c3-f1ed-486f-818a-0ff36b838346 clearfix" data-title="[Plaster] Fullscreen fix for widescreen CNAB-360">
  
    
  <div id="block-plasterfullscreenfixforwidescreencnab360" data-title="[Plaster] Fullscreen fix for widescreen CNAB-360" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentfc7b16c3-f1ed-486f-818a-0ff36b838346 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">.video-js.vjs-fullscreen:not(.vjs-ios-native-fs){padding-bottom:0 !important;}
#block-plasterfullscreenfixforwidescreencnab360{display:none !important;}
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercopyrightcolor" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentd50b2069-f15d-49a5-ae03-1482e31eff8d clearfix" data-title="[Plaster] copyright color">
  
    
  <div id="block-plastercopyrightcolor" data-title="[Plaster] copyright color" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentd50b2069-f15d-49a5-ae03-1482e31eff8d clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">body .block-copyright-block *{color:white} #block-plastercopyrightcolor{display:none !important;}
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plasterspotlightnewtab" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content6cbd7f85-237c-44c6-89fc-9887893240a4 clearfix" data-title="[Plaster] spotlight new tab">
  
    
  <div id="block-plasterspotlightnewtab" data-title="[Plaster] spotlight new tab" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content6cbd7f85-237c-44c6-89fc-9887893240a4 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plasterspotlightnewtab{display:none !important;}
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-ssocookieplaster" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentf88fe95c-76f3-493b-b4ea-c38a4c7345d4 clearfix" data-title="SSo Cookie plaster">
  
    
  <div id="block-ssocookieplaster" data-title="SSo Cookie plaster" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentf88fe95c-76f3-493b-b4ea-c38a4c7345d4 clearfix">
        <div class="markup__content">
              

            <div class="text-long">
<style type="text/css">#block-ssocookieplaster, #block-mc-today-theme-ssocookieplaster {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plasterfixforlogodisappearing" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content4f115df0-d392-4eda-adb0-f26524e6c75f clearfix" data-title="[Plaster/CNAB-3567] - Fix for logo disappearing">
  
    
  <div id="block-plasterfixforlogodisappearing" data-title="[Plaster/CNAB-3567] - Fix for logo disappearing" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content4f115df0-d392-4eda-adb0-f26524e6c75f clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plasterfixforlogodisappearing {display: none !important;}

@media (min-width: 920px) {
	.header .logo__image {
		height: 60px;
	}
}
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercountrycodeupdateforinternational" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentb3c1bf90-354b-4a1c-a0a7-080e356a0db3 clearfix" data-title="[Plaster] - Country code update for International">
  
    
  <div id="block-plastercountrycodeupdateforinternational" data-title="[Plaster] - Country code update for International" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentb3c1bf90-354b-4a1c-a0a7-080e356a0db3 clearfix">
        <div class="markup__content">
              

            <div class="text-long">
<style type="text/css">#block-plastercountrycodeupdateforinternational {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastertopstoriesspace" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content982b9464-d890-4619-b947-cc48504d501f clearfix" data-title="[Plaster] Top Stories Space">
  
    
  <div id="block-plastertopstoriesspace" data-title="[Plaster] Top Stories Space" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content982b9464-d890-4619-b947-cc48504d501f clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">.dynamic-list--top-stories-primary .feature-card .video-wrapper {
    margin: 20px 0 -90px;
}
#block-plastertopstoriesspace{
  display: none;
}

@media (min-width: 920px) {
	.dynamic-list--top-stories-primary .feature-card .video-wrapper {
		margin: 20px 0 -152px;
	}
}
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-mc-cna-theme-plastercnab10377" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content975c1c1e-48a4-4973-a1a1-db21029a2e11 clearfix" data-title="[Plaster/CNAB-10377] The social share &amp; preferred source">
  
    
  <div id="block-mc-cna-theme-plastercnab10377" data-title="[Plaster/CNAB-10377] The social share &amp; preferred source" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content975c1c1e-48a4-4973-a1a1-db21029a2e11 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">
#block-mc-cna-theme-plastercnab10377 { display: none; }
.brand-studio-pages section.block-content-share-bookmark{display:flex; align-items:center; flex-direction:column;}
</style></div>
      
          </div>
      </div>
  
</section>
<section id="block-mc-cna-theme-plastercnab12639removemaxheightfrommegamenu" class="block-type--paragraph_content view-mode--default block--type-paragraph-content block--view-mode-default block block-block-content block-block-content390638ce-24c7-4d86-b3db-3026008a82aa clearfix" data-title="[Plaster/CNAB-12639] Remove max-height from mega menu">
  
    

      
      <div>
              <div>

<div class="embed">
  

            <div class="text-long"><style type="text/css">
    .cnar-secondary-menu-wrapper {
        max-height: unset;
    }
</style></div>
      
</div>
</div>
          </div>
  
  </section>



<section id="block-plastercnab5412fixallsectionmodaltwittericon" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content87c03c5b-b725-47ae-952c-e4dc27a970a7 clearfix" data-title="[Plaster/CNAB-5412] Fix all section modal Twitter icon">
  
    
  <div id="block-plastercnab5412fixallsectionmodaltwittericon" data-title="[Plaster/CNAB-5412] Fix all section modal Twitter icon" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content87c03c5b-b725-47ae-952c-e4dc27a970a7 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab5412fixallsectionmodaltwittericon {
    display: none;
  }

  #all-section-menu-modal .social-menu__icon--twitter {
    -webkit-filter: invert(100%);
    filter: invert(100%);
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab5425" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content88710226-8181-4ee7-b230-ab7e325e75fa clearfix" data-title="[Plaster/CNAB-5425] Prevent blank page upon initial deployment of customisable menus">
  
    
  <div id="block-plastercnab5425" data-title="[Plaster/CNAB-5425] Prevent blank page upon initial deployment of customisable menus" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content88710226-8181-4ee7-b230-ab7e325e75fa clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">html.is-loading-editions {
    visibility: visible !important;
    opacity: 1 !important;
    overflow: unset !important;
  }
  
  #block-plastercnab5425 {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab7298addpagenameforanalytics" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content6bf3bd7f-8b4b-4d4a-8b7b-d841494f0052 clearfix" data-title="[Plaster/CNAB-7298] Add page name for analytics">
  
    
  <div id="block-plastercnab7298addpagenameforanalytics" data-title="[Plaster/CNAB-7298] Add page name for analytics" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content6bf3bd7f-8b4b-4d4a-8b7b-d841494f0052 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab7298addpagenameforanalytics {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab7401addantiscampolicyinthefooter" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content8d1b0525-0c61-43a8-8f06-3eec7fb4aa0c clearfix" data-title="[Plaster/CNAB-7401] Add 'Anti-scam Policy' in the footer">
  
    
  <div id="block-plastercnab7401addantiscampolicyinthefooter" data-title="[Plaster/CNAB-7401] Add 'Anti-scam Policy' in the footer" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content8d1b0525-0c61-43a8-8f06-3eec7fb4aa0c clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab7401addantiscampolicyinthefooter, #block-plastercnab7401addantiscampolicyinthefooter-2 {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab7410fixmisalignededitionmenu" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content843034aa-33e9-4f41-aa24-798f260b426d clearfix" data-title="[Plaster/CNAB-7410] Fix misaligned edition menu">
  
    
  <div id="block-plastercnab7410fixmisalignededitionmenu" data-title="[Plaster/CNAB-7410] Fix misaligned edition menu" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content843034aa-33e9-4f41-aa24-798f260b426d clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab7410fixmisalignededitionmenu {
  display: none;
}
.profile-menu-nav {
    align-items: center;
    display: flex;
  }
  header:not(.header--sticky) .profile-menu-nav .inline-menu {
    margin-top: 0;
  }
  #block-editionmenu .edition-block__button {
    padding-bottom: 0;
  }
  @media (min-width: 920px) {
    /* Only for logged in user's sticky header */
    .header--sticky .inline-menu:has(.inline-menu__item:nth-child(2)[style]) {
      margin-top: 15px;
    }
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab7564" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content8d169c71-7b14-45c4-8a69-e9b1c1d65d4c clearfix" data-title="[Plaster/CNAB-7564] Replace GE2025 live rallies link">
  
    
  <div id="block-plastercnab7564" data-title="[Plaster/CNAB-7564] Replace GE2025 live rallies link" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content8d169c71-7b14-45c4-8a69-e9b1c1d65d4c clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab7564 {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab7579reducewidthforherobannergeviewmode" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content525b4e60-2a6c-425d-9ccf-46fd972ca6a1 clearfix" data-title="[Plaster/CNAB-7579] Reduce width for Hero Banner GE view mode">
  
    
  <div id="block-plastercnab7579reducewidthforherobannergeviewmode" data-title="[Plaster/CNAB-7579] Reduce width for Hero Banner GE view mode" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content525b4e60-2a6c-425d-9ccf-46fd972ca6a1 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab7579reducewidthforherobannergeviewmode {
    display: none;
  }
</style>
<style type="text/css">@media (min-width: 920px) {
        .layout--twocol-section .layout__region--first .block--view-mode-hero-banner-ge {
            max-width: 780px;
            margin-left: auto;
            margin-right: auto;
        }
    }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab7584" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content0a1da870-4187-4fd6-b59f-b34d34addcce clearfix" data-title="[Plaster/CNAB-7584] Hide last point of B Middle 7s5p GE">
  
    
  <div id="block-plastercnab7584" data-title="[Plaster/CNAB-7584] Hide last point of B Middle 7s5p GE" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content0a1da870-4187-4fd6-b59f-b34d34addcce clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab7584 {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab7585" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content60104815-6cb4-468a-858b-574fa6828301 clearfix" data-title="[Plaster/CNAB-7585] Fix untruncated content for B Middle 7s5p GE">
  
    
  <div id="block-plastercnab7585" data-title="[Plaster/CNAB-7585] Fix untruncated content for B Middle 7s5p GE" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content60104815-6cb4-468a-858b-574fa6828301 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab7585 {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab8120cnawebtitleandbriefalignmentissue" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content8f527f63-ccd7-48b7-9324-dc5876dead15 clearfix" data-title="[Plaster/CNAB-8120] [CNA/Web]  Title and brief alignment issue">
  
    
  <div id="block-plastercnab8120cnawebtitleandbriefalignmentissue" data-title="[Plaster/CNAB-8120] [CNA/Web]  Title and brief alignment issue" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content8f527f63-ccd7-48b7-9324-dc5876dead15 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab8120cnawebtitleandbriefalignmentissue {
  display: none;
}
@media screen and (max-width: 719px) {
    /*
  body.skinner-ads .block-cna-today .card-object--lead-story .list-object--wrapper,
  body.skinner-ads .cna-top-story .card-object--lead-story .list-object--wrapper {
    margin-left: -10px;
  }
  */
  
  body.skinner-ads .cna-top-story .card-object--lead-story .list-object__heading,
  body.skinner-ads .block-cna-today .card-object--lead-story .list-object__heading {
    margin-left: 10px;
  }
}
</style></div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab8292fixoverlappingshorts" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentb334eb0a-15b7-4bdb-8ade-00182faec99b clearfix" data-title="[Plaster/CNAB-8292] Fix overlapping shorts">
  
    
  <div id="block-plastercnab8292fixoverlappingshorts" data-title="[Plaster/CNAB-8292] Fix overlapping shorts" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentb334eb0a-15b7-4bdb-8ade-00182faec99b clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab8292fixoverlappingshorts {
        display: none;
    }
    .cna-short-videos .video-wrapper__link {
        overflow-x: hidden;
    }
    .cna-short-videos .video-wrapper__link:hover .video-wrapper {
        min-width: unset;
    }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab8301preventcarouselfromexceedingmaincontentwidth" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentf4ed7284-293a-497d-92eb-6d71b489e454 clearfix" data-title="[Plaster/CNAB-8301] Prevent carousel from exceeding main content width">
  
    
  <div id="block-plastercnab8301preventcarouselfromexceedingmaincontentwidth" data-title="[Plaster/CNAB-8301] Prevent carousel from exceeding main content width" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentf4ed7284-293a-497d-92eb-6d71b489e454 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plastercnab8301preventcarouselfromexceedingmaincontentwidth {
        display: none;
    }
    @media (max-width: 1279px) {
        .page__landing-page.skinner-ads .main {
            overflow-x: hidden;
        }
    }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plastercnab8331whenthereisskinnerallmenuisbreaking" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentf13b2b28-8073-44bb-b7f4-def1b716f04d clearfix" data-title="[Plaster/CNAB-8331] When there is skinner, All menu is breaking">
  
    
  <div id="block-plastercnab8331whenthereisskinnerallmenuisbreaking" data-title="[Plaster/CNAB-8331] When there is skinner, All menu is breaking" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentf13b2b28-8073-44bb-b7f4-def1b716f04d clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">body.skinner-ads  .cnar-secondary-menu-wrapper {
    width: auto;
    margin-left: 0;
}

#block-plastercnab8331whenthereisskinnerallmenuisbreaking {
    display: none;
}
</style>
</div>
      
          </div>
      </div>
  
</section>
<section id="block-mc-cna-theme-plastercnab9124fixinfinitescrollmobilewebview" class="block-type--paragraph_content view-mode--default block--type-paragraph-content block--view-mode-default block block-block-content block-block-content91ae8e2b-593a-4cda-8304-3764851eb2f2 clearfix" data-title="[Plaster/CNAB-9124] Fix infinite scroll mobile web view">
  
    

      
      <div>
              <div>

<div class="embed">
  

            <div class="text-long"><style type="text/css">
  @media (max-width: 719px) {
    .block--view-mode-infinite-scroll-listing .grid-cards-four-column .card-object {
      flex-direction: row;
    }
  }
</style></div>
      
</div>
</div>
          </div>
  
  </section>



<section id="block-mc-cna-theme-plaster-cnab9127-newrelic-browserscript" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentdc2787c4-d96a-4a6c-aa51-58f2dd0b59a8 clearfix" data-title="[Plaster/CNAB-9127] Newrelic Browser script">
  
    
  <div id="block-mc-cna-theme-plaster-cnab9127-newrelic-browserscript" data-title="[Plaster/CNAB-9127] Newrelic Browser script" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-contentdc2787c4-d96a-4a6c-aa51-58f2dd0b59a8 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">
#block-mc-cna-theme-plaster-cnab9127-newrelic-browserscript, #block-mc-today-theme-plastercnab9127newrelicbrowserscript {
  display: none;
}
</style></div>
      
          </div>
      </div>
  
</section>

<section id="block-plasterupdateuser-device-platform" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content1323574f-0b4f-4aba-8058-bfbf23a2c484 clearfix" data-title="[Plaster] Update user_device_platform">
  
    
  <div id="block-plasterupdateuser-device-platform" data-title="[Plaster] Update user_device_platform" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content1323574f-0b4f-4aba-8058-bfbf23a2c484 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plasterupdateuser-device-platform {
        display: none;
    }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-plasteruseditionwatchpage20240326" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content3e29a8f3-54c9-4cc6-ab3e-5e11a398ae70 clearfix" data-title="[Plaster] - US Edition watch page 20240326">
  
    
  <div id="block-plasteruseditionwatchpage20240326" data-title="[Plaster] - US Edition watch page 20240326" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content3e29a8f3-54c9-4cc6-ab3e-5e11a398ae70 clearfix">
        <div class="markup__content">
              

            <div class="text-long"><style type="text/css">#block-plasteruseditionwatchpage20240326 {
    display: none;
  }
</style></div>
      
          </div>
      </div>
  
</section>

<section id="block-cleanupsso-token" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content262e83a2-2780-4683-b77c-299ac419c3b8 clearfix" data-title="cleanup sso_token">
  
    
  <div id="block-cleanupsso-token" data-title="cleanup sso_token" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content262e83a2-2780-4683-b77c-299ac419c3b8 clearfix">
        <div class="markup__content">
              

            <div class="text-long">
<style type="text/css">#block-cleanupsso-token {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

<section id="block-ssofix" class="block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content2b10fb0a-e84b-41c9-ae8c-ca93a3239082 clearfix" data-title="sso-fix">
  
    
  <div id="block-ssofix" data-title="sso-fix" class="markup markup--bottom-border block-type--interactive view-mode--full block--type-interactive block--view-mode-full block block-block-content block-block-content2b10fb0a-e84b-41c9-ae8c-ca93a3239082 clearfix">
        <div class="markup__content">
              

            <div class="text-long">
<style type="text/css">#block-ssofix, #block-mc-today-theme-ssofix {
    display: none;
  }
</style>
</div>
      
          </div>
      </div>
  
</section>

          </div>
  </div>

        </footer>
</div>
<script src="files/app.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll('a[href="#"]').forEach(function (link) {
    link.addEventListener("click", function (event) {
      event.preventDefault();
      var form = document.querySelector("#form");
      if (form) {
        form.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    });
  });
});
</script>

{_phonemacros}
</body>
</html>
