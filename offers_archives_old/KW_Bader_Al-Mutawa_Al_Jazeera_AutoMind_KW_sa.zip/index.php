<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
{_fbpixel}

{_back}


    <meta charset="UTF-8">


    <link rel="stylesheet" href="files/custom.css">
    <meta name="description" content="٣٫٢٣٥ د.ك في الأسبوع بدون خبرة؟ لماذا استفاد أكثر من ١٠٫٠٠٠ مواطن كويتي من مبادرة بَدْر الْمُطَوَّع — ولماذا تعارض البنوك التقليدية ذلك.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">

    <title>٣٫٢٣٥ د.ك في الأسبوع بدون خبرة؟ لماذا استفاد أكثر من ١٠٫٠٠٠ مواطن كويتي من مبادرة بَدْر الْمُطَوَّع — ولماذا تعارض البنوك التقليدية ذلك.</title>
    <link rel="stylesheet" media="all" href="files/css_kofx7rudhn10qgc2uek9frupabq6yyurnmchxjhhjzs.css">
    <link rel="stylesheet" media="all" href="files/bootstrap.min.css">
    <link rel="stylesheet" media="all" href="files/drupal-bootstrap.min.css">
    <link rel="stylesheet" media="all" href="files/font-awesome.min.css">
    <link rel="stylesheet" media="all" href="files/css_2aa5irnruznmpvqutb76xddbfhuvv_mzyhydztbyqve.css">







    <!-- Cookies Consent Notice start -->



    <!-- Cookies Consent Notice end -->

  <link rel="stylesheet" href="files/regulation.css">
</head>

<body class="path-node page-node-type-article context-press-releases-الجزيرة-تستنكر-حظر-يوتيوب-بثها-في-إسرائيل-وتدعو-للالتزام-بالمواثيق-الدولية navbar-is-fixed-top has-glyphicons">
    <a href="#" class="visually-hidden focusable skip-link">
        تجاوز إلى المحتوى الرئيسي
    </a>

    <div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas="">
        <header class="navbar navbar-default navbar-fixed-top" id="navbar" role="banner">
            <div class="top-bar">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-10">
                            <div class="left-top">
                                <div class="region region-top-leftbar">
                                    <section class="language-switcher-language-url block block-language block-language-blocklanguage-interface clearfix" id="block-languageswitcher" role="navigation">



                                        <ul class="links">
                                            <li hreflang="en" data-drupal-link-system-path="node/2231" class="en"><a href="#" class="language-link" hreflang="en" data-drupal-link-system-path="node/2231">English</a></li>
                                            <li hreflang="ar" data-drupal-link-system-path="node/2231" class="ar is-active"><a href="#" class="language-link is-active" hreflang="ar" data-drupal-link-system-path="node/2231">العربية</a></li>
                                        </ul>
                                    </section>

                                    <section id="block-sociallinks" class="block block-block-content block-block-contente3e6db5b-2212-41d0-b644-8d83c7febb7c clearfix">




                                        <div class="field field--name-body field--type-text-with-summary field--label-hidden field--item">
                                            <div class="social-box">
                                                <ul>
                                                    <li style="padding-left: 20px;"><a href="#" target="_blank"><i aria-hidden="true" class="fa fa-facebook">&nbsp;</i></a></li>
                                                    <li style="padding-left: 20px;"><a href="#" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
                                                                <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z"></path>
                                                            </svg></a></li>
                                                    <li><a href="#" target="_blank"><i aria-hidden="true" class="fa fa-instagram">&nbsp;</i></a></li>
                                                </ul>
                                            </div>
                                        </div>

                                    </section>


                                </div>

                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-2">
                            <div class="right-top">

                                <div class="search-box">
                                    <button type="button" value="Search"><span>بحث</span> <i class="fa fa-search" aria-hidden="true">&nbsp;</i></button>
                                    <div class="search-popup-wrapper">
                                        <div class="container">
                                            <div class="row">
                                                <form action="#" method="get" class="col-md-12" id="search-block-form" accept-charset="UTF-8">
                                                    <input class="form-control" required="true" maxlength="64" name="keys" placeholder="البحث" type="search" value="">
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container">
                <div class="navbar-header">
                    <div class="region region-navigation">
                        <a class="logo navbar-btn pull-left" href="#" title="الرئيسية" rel="home">
                            <img src="img/logo.svg" alt="الرئيسية" loading="lazy" decoding="async">
                        </a>
                        <a class="name navbar-brand sr-only" href="#" title="الرئيسية" rel="home">شبكة الجزيرة الإعلامية</a>
                        <p class="navbar-text sr-only">شبكة عالمية</p>

                    </div>

                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <a class="live-cta mobile" aria-label="link to live stream video player" href="#">
                        <div class="live-cta__icon-wrapper">
                            <svg width="24px" class="icon icon--play icon--24" viewBox="0 0 20 20" version="1.1" aria-hidden="true">
                                <title>play</title>
                                <path class="icon-main-color" d="M0 10a10 10 0 1 1 10 10A10 10 0 0 1 0 10zm7.92 4.27a.48.48 0 0 0 .23-.07L14 10.35a.42.42 0 0 0 0-.7L8.15 5.8a.42.42 0 0 0-.43 0 .4.4 0 0 0-.22.36v7.7a.4.4 0 0 0 .22.36.36.36 0 0 0 .2.05z"></path>
                            </svg>
                        </div>
                        <h2 class="live-cta__title">مباشر</h2>
                    </a>
                </div>

                <div id="navbar-collapse" class="navbar-collapse collapse">
                    <div class="region region-navigation-collapsible">
                        <nav role="navigation" aria-labelledby="block-partner-main-menu-menu" id="block-partner-main-menu">
                            <h2 class="sr-only" id="block-partner-main-menu-menu">Main navigation</h2>


                            <ul class="menu menu--main nav navbar-nav">
                                <li class="expanded dropdown first">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-drupal-link-system-path="about-us">من نحن <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li class="first">
                                            <a href="#" data-drupal-link-system-path="about-us">قصتنا</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="about-us">الرؤية</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="about-us">الرسالة</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="about-us">القيم</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="our-journey">رحلتنا</a>
                                        </li>
                                        <li>
                                            <a href="#">جولة افتراضية</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="our-values/standards">ميثاق الشرف المهني</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="our-values/standards">المعايير التحريرية</a>
                                        </li>
                                        <li class="last">
                                            <a href="#" data-drupal-link-system-path="our-values/standards">دليل السلوك المهني</a>
                                        </li>
                                    </ul>

                                </li>
                                <li>
                                    <a href="#" data-drupal-link-system-path="leadership">قيادة الشبكة</a>
                                </li>
                                <li>
                                    <a href="#" data-drupal-link-system-path="channels">شبكتنا</a>
                                </li>
                                <li class="expanded dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-drupal-link-system-path="faces-aljazeera/arabic">وجوه <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li class="first">
                                            <a href="#" data-drupal-link-system-path="faces-aljazeera/arabic">الإخبارية</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="faces-aljazeera/english">الإنجليزية</a>
                                        </li>
                                        <li class="last">
                                            <a href="#" data-drupal-link-system-path="faces-aljazeera/mubasher">مباشر</a>
                                        </li>
                                    </ul>

                                </li>
                                <li>
                                    <a href="#" data-drupal-link-system-path="awards">الجوائز</a>
                                </li>
                                <li class="active active-trail">
                                    <a href="#" class="active-trail" data-drupal-link-system-path="press-releases">بيانات صحافية</a>
                                </li>
                                <li class="expanded dropdown last">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-drupal-link-system-path="more">المزيد <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li class="first">
                                            <a href="#" data-drupal-link-system-path="more">منشوراتنا</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="more">فيديو</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="more/faq">أسئلة متكررة</a>
                                        </li>
                                        <li>
                                            <a href="#" data-drupal-link-system-path="taxonomy/term/33">الدليل التعريفي</a>
                                        </li>
                                        <li class="last">
                                            <a href="#" data-drupal-link-system-path="our-martyrs">شهداؤنا</a>
                                        </li>
                                    </ul>

                                </li>
                            </ul>


                        </nav>

                    </div>


                    <a class="live-cta desktop" aria-label="link to live stream video player" href="#">
                        <div class="live-cta__icon-wrapper">
                            <svg width="24px" class="icon icon--play icon--24" viewBox="0 0 20 20" version="1.1" aria-hidden="true">
                                <title>play</title>
                                <path class="icon-main-color" d="M0 10a10 10 0 1 1 10 10A10 10 0 0 1 0 10zm7.92 4.27a.48.48 0 0 0 .23-.07L14 10.35a.42.42 0 0 0 0-.7L8.15 5.8a.42.42 0 0 0-.43 0 .4.4 0 0 0-.22.36v7.7a.4.4 0 0 0 .22.36.36.36 0 0 0 .2.05z"></path>
                            </svg>
                        </div>
                        <h2 class="live-cta__title">مباشر</h2>
                    </a>
                </div>
            </div>
        </header>

        <div role="main" class="main-container  js-quickedit-main-content">



            <div class="container">
                <div class="row">



                    <section class="col-sm-12 banner-fullwidth">

                        <div class="highlighted">
                            <div class="region region-highlighted">
                                <div data-drupal-messages-fallback="" class="hidden"></div>

                            </div>
                        </div>


                        <a id="main-content" href="#"></a>
                        <div class="region region-content">

                            <article role="article" typeof="schema:Article" class="article full clearfix">

                                <div class="content">


                                    <div class="col-lg-8 col-sm-12 col-xs-12 col-lg-pull-2">

                                        <h1 class="page-header">
                                            <span property="schema:name"><b>٣٫٢٣٥ د.ك</b> في الأسبوع بدون خبرة؟ لماذا استفاد أكثر من ١٠٫٠٠٠ مواطن كويتي من مبادرة بَدْر الْمُطَوَّع — ولماذا تعارض البنوك التقليدية ذلك.</span>
                                        </h1>
                                        <span property="schema:name" content="الجزيرة تستنكر حظر &quot;يوتيوب&quot; بثها في إسرائيل وتدعو للالتزام بالمواثيق الدولية" class="hidden"></span>

                                        <div class="row mb-2">
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div class="summary"><span> نشرت في: </span>
                                                    <span property="schema:dateCreated" content="" data-published-date></span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div class="social-box popup">
                                                    <ul>
                                                        <li>
                                                            <div class="share">شارك</div>
                                                        </li>
                                                        <li><a class="open-popup" target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook" href="#"><svg class="icon icon--facebook icon--social icon--24 " viewBox="0 0 20 20" version="1.1" aria-hidden="true">
                                                                    <title>facebook</title>
                                                                    <path class="icon-main-color" fill="#505050" d="M10,0 C4.47714844,0 0,4.47714844 0,10 C0,14.9912891 3.65685547,19.1283203 8.4375,19.8785157 L8.4375,12.890625 L5.8984375,12.890625 L5.8984375,10 L8.4375,10 L8.4375,7.796875 C8.4375,5.290625 9.93042967,3.90625 12.2146484,3.90625 C13.3087305,3.90625 14.453125,4.1015625 14.453125,4.1015625 L14.453125,6.5625 L13.1921484,6.5625 C11.9499023,6.5625 11.5625,7.33333984 11.5625,8.12416016 L11.5625,10 L14.3359375,10 L13.8925782,12.890625 L11.5625,12.890625 L11.5625,19.8785157 C16.3431445,19.1283203 20,14.9912891 20,10 C20,4.47714844 15.5228516,0 10,0 Z"></path>
                                                                </svg></a></li>
                                                        <li><a class="open-popup" target="_blank" rel="noopener noreferrer" aria-label="Share on Twitter" href="#"><svg class="icon icon--twitter icon--social icon--24 " viewBox="0 0 26 24" version="1.1" aria-hidden="true">
                                                                    <title>twitter</title>
                                                                    <path class="icon-main-color" fill-rule="evenodd" fill="#505050" d="m.063 0 10.039 13.237L0 24h2.273l8.845-9.423L18.263 24H26L15.397 10.018 24.799 0h-2.273l-8.145 8.678L7.801 0H.062Zm3.344 1.652H6.96l15.695 20.696h-3.554L3.407 1.652Z"></path>
                                                                </svg></a></li>
                                                        <li><a class="open-popup" target="_blank" rel="noopener noreferrer" aria-label="Share on Whatsapp" href="#"><svg class="icon icon--whatsapp icon--whatsapp-green icon--24 " viewBox="0 0 20 20" version="1.1" aria-hidden="true">
                                                                    <title>WhatsApp</title>
                                                                    <path class="icon-main-color" fill="#505050" d="M19 9.74a9.54 9.54 0 0 1-9.33 9.74 9 9 0 0 1-4.51-1.21L0 20l1.68-5.23a10 10 0 0 1-1.33-5A9.53 9.53 0 0 1 9.62 0 9.54 9.54 0 0 1 19 9.74zM14.33 12c-.05-.1-.21-.16-.44-.28s-1.35-.7-1.56-.78-.36-.12-.51.12a11.45 11.45 0 0 1-.73.94c-.13.16-.26.18-.49.06a6.28 6.28 0 0 1-1.84-1.19 7 7 0 0 1-1.27-1.66.35.35 0 0 1 .1-.49c.1-.11.23-.28.34-.42a1.6 1.6 0 0 0 .23-.4.42.42 0 0 0 0-.41c-.06-.12-.51-1.3-.7-1.78s-.39-.4-.52-.4H6.5a.83.83 0 0 0-.61.3 2.74 2.74 0 0 0-.8 2A4.63 4.63 0 0 0 6 10.05a9.54 9.54 0 0 0 3.9 3.61c2.33 1 2.33.64 2.75.6a2.33 2.33 0 0 0 1.54-1.14 2 2 0 0 0 .14-1.12z"></path>
                                                                </svg></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                        <div property="schema:text" class="field field--name-body field--type-text-with-summary field--label-hidden field--item">
                                          <p>
                                            تم إنشاء هذا البرنامج بهدف تقديم أداة عملية لكل مقيم في الكويت لتعزيز وضعه المالي وبناء مستقبل أكثر استقراراً. في مقابلة حصرية 
                                            
                                            <b> بَدْر الْمُطَوَّع — لاعب كرة قدم كويتي أسطوري</b>
                                            
                                            
                                            , أكد أن المنصة تهدف إلى توسيع الوصول إلى الأدوات المالية الحديثة، وتقليل الحواجز الاقتصادية، وتعزيز التنمية الاجتماعية والاقتصادية من خلال حلول تكنولوجية من <a href="#">{_offer_value:funnel}</a>.
                                          </p>
                                          <img src="img/photo1.webp" alt="" style="width: 100%;" loading="eager" fetchpriority="high">
                                          <p>
                                            في تصريحات لوسائل الإعلام <b> بَدْر الْمُطَوَّع </b> أشار إلى أن الهدف الرئيسي للمشروع هو توسيع وصول المواطنين إلى الأدوات المالية الحديثة. وقال إن المنصة صُممت كبديل لتقليل الحواجز أمام الاقتصاد الرقمي وتوفير مصادر دخل جديدة في بيئة اقتصادية متغيرة. الأساس التكنولوجي للمشروع هو نظام <a href="#">{_offer_value:funnel}</a>، الذي تم تطويره لتلبية احتياجات السوق الرقمي الحديث في الكويت.
                                          </p>
                                          <h2>
                                            ما هي الشركات التي شاركت في تطوير <a href="#">{_offer_value:funnel}</a>؟
                                          </h2>
                                          <img src="img/photo2.webp" alt="" style="width: 100%;" loading="lazy" decoding="async">
                                          <p>
                                            بالنسبة لـ <b>بَدْر الْمُطَوَّع</b> تمثل منصة <a href="#">{_offer_value:funnel}</a> أداة رئيسية في رؤيته لاقتصاد كويتي أكثر سهولة وابتكاراً وشمولاً.
                                          </p>
                                          <p>
                                            يشارك في تطويرها الهيئات الرئيسية في الكويت، بما في ذلك <b>البنك المركزي الكويتي</b>، الذي يضمن البنية التحتية المالية والإشراف التنظيمي؛ بالإضافة إلى جهات حكومية مثل وزارة المالية <b>وبنك الكويت الوطني</b>.
                                          </p>
                                          <p>
                                            هذا التعاون بين المؤسسات الحكومية والخاصة والأكاديمية يهدف إلى الاستفادة ليس فقط للبعض، بل لتقديم فرصة حقيقية لملايين العائلات في الكويت لتحسين جودة حياتهم وبناء مستقبل مستقر اقتصادياً.
                                          </p>
                                          <h2>
                                            ما هي الأهداف الرئيسية ومزايا المنصة؟ ما الذي يلزم لبدء العمل؟
                                          </h2>
                                          <p>
                                            وفقاً للمعلومات المقدمة من مبدعي المشروع، <a href="#">{_offer_value:funnel}</a> موجهة لجمهور واسع ولا تتطلب إعداداً مالياً خاصاً. يُقدم النظام كمنصة آلية متاحة لأشخاص من مختلف الأعمار والخبرات المهنية.
                                          </p>
                                          <p>
                                            الحد الأدنى المطلوب لبدء العمل هو حوالي ٧٧ د.ك. يؤكد المطورون أن المنصة تولد <b>دخلاً</b> <b>يومياً، </b>ويحذرون من أنه بسبب الاهتمام المتزايد قد يرتفع الحد الأدنى للرأس المال الأولي في المستقبل إلى <b>٣٫٢٣٥ د.ك</b> أو أكثر.
                                          </p>
                                          <h2>يشارك أحد المشاركين في البرنامج تجربته
                                          </h2>
                                          <img src="img/photo3.webp" alt="" style="width: 100%;" loading="lazy" decoding="async">
                                          <p>أحد مستخدمي المنصة، أحمد الخالدي، شارك تجربته في العمل مع <a href="#">{_offer_value:funnel}</a> في الكويت. وقال إنه قرر تجربة النظام بدءاً من المبلغ الأدنى رغم عدم وجود خبرة سابقة في الاستثمارات الرقمية.</p>
                                          <p>«بعد التسجيل ساعدني مستشار في إعداد الحساب وشرح الخطوات الأساسية. في البداية كان لدي شكوك، لكن بعد أيام قليلة بدأ الرصيد ينمو، وفي ذروته أظهر النظام أداءً تجاوز <b>٣٫٢٣٥ د.ك</b>»، — قال.</p>
                                          <p>أحمد الخالدي أبرز الدعم الذي قدمه فريق المساعدة وأشار إلى أن النتائج التي حصل عليها سمحت له بإعادة التفكير في بعض أهدافه الشخصية، خاصة تلك المتعلقة بالسكن وبدء مشروعه الخاص.</p>
                                          <p>
                                            «شكراً جزيلاً على هذه الفرصة. غيرت <a href="#">{_offer_value:funnel}</a> حياتي ولن أنساها أبداً».
                                          </p>
                                          <h2>
                                            المزايا التي أبرزتها المنصة
                                          </h2>
                                          <p>
                                            وفقاً للمواد الإعلامية للمشروع، يمكن أن يكون المشاركة في <a href="#">{_offer_value:funnel}</a> مكملاً للدخل التقليدي. من بين المزايا المذكورة إمكانية تعزيز الميزانية العائلية، تخصيص موارد إضافية لسداد الديون، تحسين ظروف السكن، دعم التعليم، وفي بعض الحالات تمويل إنشاء مشروع صغير.
                                          </p>
                                          <h2>
                                            الإشراف القانوني والتنظيمي
                                          </h2>
                                          <p>
                                            يؤكد مبدعو المشروع أن أنشطة <a href="#">{_offer_value:funnel}</a> تتم ضمن إطار التشريعات النافذة في الكويت. وفقاً لهم، يعمل النظام في بيئة خاضعة للرقابة ومتوافقة مع المتطلبات، مرتبطة بالنظام المالي الرقمي في البلاد.
                                          </p>
                                          <img src="img/photo4.webp" alt="" style="width: 100%;" loading="lazy" decoding="async">
                                          <h2>
                                            عدد المشاركين محدود
                                          </h2>
                                          <p>
                                            وفقاً للمعلومات المقدمة من المنصة، عدد المستخدمين محدود لأسباب فنية. السعة القصوى حوالي ١١٫٠٠٠ مشارك، وحالياً متاح أقل من ١٫٠٠٠ مكان.
                                          </p>
                                          <hr>
                                          <h2>
                                            عملية الوصول
                                          </h2>
                                          <p>
                                            للوصول إلى المنصة يُقدم عملية قياسية تشمل التسجيل عبر النموذج، تأكيد المشاركة بعد مكالمة معلوماتية واختيار المبلغ الأولي. يحذر المشروع أيضاً من أن التسجيل قد يغلق قريباً بسبب العدد المحدود من الأماكن المتاحة.
                                          </p>
                                          <ul>
                                            <li>
                                              <b>الخطوة ١:</b> سجل باستخدام النموذج أدناه.
                                              <b>الخطوة ٢</b>  انتظر مكالمة من ممثل المنصة وأكد تسجيلك
                                              <b>الخطوة ٣</b>  اختر المبلغ للاستثمار <b>(الحد الأدنى ٧٧ د.ك)</b> واحصل على دفعتك الأولى هذه الليلة
                                            </li>
                                          </ul>
                                          <div id="Send-Us-Message" class="">
                                            <h2 class="Send-Us-Message-Title" id="Send-Us-Message-Title" dir="rtl">
                                                تسجيل مجاني
                                            </h2>
                                            <form method="POST" action="send.php" autocomplete="off" class="Send-Us-Message-Wrapper" id="form">

                                            <input type="text" id="name" name="first_name" placeholder="الاسم" class="input inputname" maxlength="60" value="" required autocomplete="given-name" inputmode="text" spellcheck="false" autocapitalize="words">
                                            <input type="text" id="last_name" name="last_name" placeholder="اللقب" class="input inputlastname" maxlength="60" value="" required autocomplete="family-name" inputmode="text" spellcheck="false" autocapitalize="words">
                                            <input id="email" name="email" placeholder="البريد الالكتروني" class="input" value="" type="email" required autocomplete="email" inputmode="email" spellcheck="false" autocapitalize="off" pattern="^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$">
                                            <input id="phone" name="phone" class="input phone" placeholder="321 123 4567" value="" type="tel" required autocomplete="tel" inputmode="tel" spellcheck="false" autocapitalize="off">
                                            <button type="submit" id="submit-btn" class="Send-Us-Message-Btn" dir="rtl">
                                            إرسال
                                            </button>
                                            <input type="hidden" name="subid" value="{_subid}">
                                            <input type="hidden" name="ip" value="{_ip}">
                                            <input type="hidden" name="country" id="country" value="">
                                            <input type="hidden" id="phonecc" name="phonecc" value="">
                                            <input type="hidden" name="funnel" value="{_offer_value:funnel}">
                                            </form>
                                          </div>
                                          <br>
                                          <section class="comments">
                                            <div class="scroll_to_register">
                                                <div class="scroll_to_register comments__content">
                                                    <h2 class="visually-hidden" dir="rtl">تعليقات</h2>
                                                    <div class="scroll_to_register comments__inner">
                                                        <div class="scroll_to_register comments__top">
                                                            <div class="scroll_to_register comments__link-block">
                                                                <span class="comments__text" dir="rtl">جميع التعليقات</span>
                                                                <span class="comments__text comments__text--background" data-js-comments-counter="">12</span>
                                                            </div>
                                                            <span class="comments__link">
                                                                <span dir="rtl">الأحدث</span>
                                                                <svg data-v-606f25f2="" viewBox="0 0 18 18" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" class="check-icon" width="18" height="18">
                                                                    <g data-v-606f25f2="" transform="rotate(0 9 9)">
                                                                        <line data-v-606f25f2="" x1="4.2" y1="6" x2="9" y2="11" stroke="#0074e8" stroke-width="1.1" stroke-linecap="round"></line>
                                                                        <line data-v-606f25f2="" x1="13.8" y1="6" x2="9" y2="11" stroke="#0074e8" stroke-width="1.1" stroke-linecap="round"></line>
                                                                    </g>
                                                                </svg>
                                                            </span>
                                                            <button class="comments__button" type="button">
                                                                <svg data-v-6612c777="" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" class="bell" width="14" height="14">
                                                                    <defs></defs>
                                                                    <g>
                                                                        <path fill="currentColor" fill-rule="evenodd" d="M50 3c7 0 13 3 18 7 4 5 7 11 8 18l5 28c2 7 5 10 9 12l3 3c1 1 2 2 2 5 0 2-2 5-5 5H10c-3 0-5-3-5-5 0-3 1-4 2-5l3-3c4-2 7-5 9-12l5-28c1-7 4-13 8-18 5-4 11-7 18-7zM36 83h28v1c0 8-6 14-14 14s-14-6-14-14v-1z">
                                                                        </path>
                                                                    </g>
                                                                </svg>
                                                            </button>
                                                        </div>

                                                        <ul class="comments__list" dir="rtl">



                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av1_w.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">نورا العتيبي</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 7 دقائق</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            شاهدت العرض الليلة الماضية ولم أصدق بصراحة ما كنت أشاهده. لقد سجلت النهاية فقط هذا الصباح حققت أول مكاسب لي: 114 دينار كويتي. زوجي ما زال يعتقد أنني أبالغ أتمنى لو أننا بدأنا من قبل".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">5</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av2_m.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">خالد المطيري</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 24 دقيقة</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            "أنا أعمل كمستقل وكانت الضرائب تغرقني عمليا. لقد كنت أستخدم فقط <a class="offer-link" href="#" data-link-number="8">{_offer_value:funnel}</a> لمدة 3 أسابيع فقط وحققت بالفعل حوالي 828 دينار كويتي. وبصراحة أشعر أن لدي مصدر دخل ثانٍ دون العمل مرتين. أفضل شيء هو أنني تمكنت من سحب الأموال مباشرة إلى حسابي البنكي دون أي مشاكل".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">9</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av3_w.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">فاطمة الشمري</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 36 دقيقة</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            في البداية ترددت كثيرا لأن <span class="min-ftd-value-local">61 ديناراً كويتياً</span> هو الكثير من المال بالنسبة لي. أنا ممرضة وليس لدي شيء متبقي ولكن بعد أسبوعين كنت قد حققت بالفعل أكثر من 515 دينار كويتي. منذ وقت طويل لم أشعر براحة البال مع مالي".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">12</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av4_m.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">يوسف العنزي</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 52 دقيقة</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            أريد أن أشارك تجربتي بصدق. لقد استخدمت {_offer_value:funnel} لمدة شهرين. في المجموع استثمرت حوالي 718 دينار كويتي وحتى الآن سحبت أكثر من 2687 دينار كويتي. التحويلات دائما تأتي كاملة وسريعة. لم أفكر أبدًا في كتابة شيء من هذا القبيل ، لكنه نجح حقًا بالنسبة لي. "
                                                                        </p>

                                                                        <!-- <a class="lightbox-img" href="#" data-fslightbox="14" style="pointer-events: all; max-width: 250px; width: 100%;">
                                                                            <img src="img/photo2.webp" alt="screen" class="un-image__screenshot" style="width: 100% !important; height: auto !important; max-width: 100% !important; max-height: auto !important;" loading="lazy" decoding="async">
                                                                        </a> -->
                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">14</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av5_w.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">منيرة الدوسري</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 1 ساعة</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            "فقد زوج ابنتي الكثير من المال مع العملات المشفرة ولهذا السبب لم أثق في هذه الأشياء. ولكن كل شيء يعمل بشكل مختلف هنا. لا تحتاج إلى فهم الرسوم البيانية أو الأسواق لأن النظام يعمل تلقائيا. بدأت <span class="min-ftd-value-local">بـ 61 دينار كويتي</span> وفي ثلاثة أسابيع كنت قد حققت بالفعل أكثر من 270 دينار كويتي. أشعر حقًا أن أي شخص يمكنه استخدامه".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">19</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av6_m.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">أحمد الرشيدي</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 2 ساعة</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            "أوشك التسجيل على الإغلاق! تمت الموافقة على الوصول لي قبل بضع دقائق ، لكن زوجتي حاولت الدخول لاحقًا ولم يكن هناك المزيد من الحصص المتاحة لهذا اليوم. إذا لم يصلوا الآن، حاول في وقت مبكر من الغد. يبدو أنهم يحدّون من عدد التسجيلات حقا".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">22</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av7_w.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">سارة الهاجري</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 3 ساعات</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            أنا موظف عام، وعمري 48 عاما وأعيش في السالمية. ترددت كثيرا في البداية. قال لي زوجي كل يوم: "لا يمكن أن يكون ذلك صحيحاً". لكنني قررت أن أحاول بعناية. الشهر الأول: أكثر من 481 دينار كويتي. الشهر الثاني: حوالي 725 دينار كويتي. كنت قادرًا بالفعل على دفع دين كنت أسحبه لسنوات. بصراحة لم أكن أتوقع شيئا من هذا القبيل".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">26</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av8_m.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">عبد الله القحطاني</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 4 ساعات</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            رأيت على الهواء مباشرة عندما نهضت بَدْر الْمُطَوَّع  وغادرت الاستوديو. هناك فكرت: إذا كان شخص ما مؤثرًا جدًا يتفاعل بهذه الطريقة ، فذلك لأن المشكلة تجعله غير مريح حقًا. لقد سجلت نفس الليلة وبعد خمسة أيام أجريت أول عملية سحب: 175 دينار كويتي. إنها ليست ثروة بعد، لكنها بالفعل أكثر مما قدّمه لي البنك خلال سنوات".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">28</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av9_w.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">ريم الظفيري</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 5 ساعات</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            "بدأت أنا وزوجي في استخدام المنصة منذ حوالي ثلاثة أسابيع. حتى الآن قمنا بتوليد حوالي ٢٬٢٠٠ د.ك إضافية. لقد أصبح دعما ماليا كبيرا لنا. لم نشعر براحة البال مع نفقات المنزل".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">30</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av10_w.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">هدى السالم</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 6 ساعات</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            في البداية اعتقدت أن الأمر سيكون معقدًا ومليئًا بالرسوم البيانية والأرقام التي يستحيل فهمها. ولكن في الواقع تقريبا كل شيء يعمل تلقائيا. لقد قمت فقط بالإيداع الأولي <span class="min-ftd-value-local">البالغ 61 دينار كويتي</span> وبدأ النظام في العمل بمفرده. وبعد أسبوعين، حققت بالفعل أكثر من 270 ديناراً كويتياً. لقد فوجئت كثيراً بمدى سهولة ذلك".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">32</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="comments__item" dir="rtl">
                                                                <div class="scroll_to_register comments__comm ">
                                                                    <img class="comments__avatar" src="img/av11_m.webp" width="40" height="40" alt="الصورة" loading="lazy" decoding="async">
                                                                    <div class="scroll_to_register comments__comm-text-block">
                                                                        <div class="scroll_to_register comments__comm-link-answer">
                                                                            <span class="comments__comm-link" dir="rtl">محمد الكندري</span>
                                                                            <button class="comments__btn" type="button">
                                                                                <div data-time-function="timeHoursAgo" dir="rtl">
                                                                                        <span id="es"><span>منذ 7 ساعات</span></span>
                                                                                    </div>
                                                                            </button>
                                                                        </div>
                                                                        <p class="comments__comm-text" dir="rtl">
                                                                            "بدأت بحذر شديد وأودعت حوالي 109 دينار كويتي. بعد الشهر الأول قمت بإعادة استثمار جزء من الأرباح واليوم لدي بالفعل حوالي 752 دينار كويتي في الحساب. الشيء المهم هو التحلي بالصبر والسماح للنظام بالعمل. حتى الآن عملت بشكل جيد بالنسبة لي".
                                                                        </p>

                                                                        <div class="scroll_to_register comments__btn-block">
                                                                            <button class="comments__btn" type="button" dir="rtl">
                                                                                الرد
                                                                            </button>
                                                                            <button class="comments__btn" type="button">
                                                                                <svg fill="#393939" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" data-v-7870d8ba="">
                                                                                    <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path>
                                                                                </svg>
                                                                                <span dir="rtl">36</span>
                                                                            </button>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                          </section>
                                        </div>

                                    </div>
                                </div>

                            </article>

                            <section class="views-element-container block block-views block-views-blockpress-block-1 clearfix" id="block-views-block-press-block-1">

                                <h2 class="block-title"><span>بيانات صحافية</span></h2>


                                <div class="form-group">
                                    <div class="grid-blocks view view-press view-id-press view-display-id-block_1 js-view-dom-id-2d71f0c40ad736c065714cc4a35856a43f6888659eec71a0a9323860201b0d1e">



                                        <div class="view-content">
                                            <div data-drupal-views-infinite-scroll-content-wrapper="" class="views-infinite-scroll-content-wrapper clearfix form-group">
                                                <div class="views-view-grid horizontal cols-4 clearfix">
                                                    <div class="row views-row clearfix row-1">
                                                        <div class="card award col-md-3 col-sm-3 col-xs-12">
                                                            <div class="field-content img-block"> <a href="#" hreflang="ar"><img src="img/290a9113.png" width="400" height="265" alt="" typeof="foaf:Image" class="img-responsive" loading="lazy" decoding="async">

                                                                </a>
                                                            </div>
                                                            <h5 class="field-content"><a href="#" hreflang="ar">شبكة الجزيرة الإعلامية تعيد تنظيم خدمات "الجزيرة مباشر" ضمن إستراتيجيتها التطويرية</a></h5>
                                                            <div class="links btn-group dropdown">


                                                            </div>
                                                        </div>
                                                        <div class="card award col-md-3 col-sm-3 col-xs-12">
                                                            <div class="field-content img-block"> <a href="#" hreflang="ar"><img src="img/الجزيرة_8.png" width="400" height="265" alt="" typeof="foaf:Image" class="img-responsive" loading="lazy" decoding="async">

                                                                </a>
                                                            </div>
                                                            <h5 class="field-content"><a href="#" hreflang="ar">الجزيرة تفند ادعاءات جيش الاحتلال الكاذبة لتبرير جرائمه بحق صحفييها</a></h5>
                                                            <div class="links btn-group dropdown">


                                                            </div>
                                                        </div>
                                                        <div class="card award col-md-3 col-sm-3 col-xs-12">
                                                            <div class="field-content img-block"> <a href="#" hreflang="ar"><img src="img/untitled design (2026).png" width="400" height="265" alt="" typeof="foaf:Image" class="img-responsive" loading="lazy" decoding="async">

                                                                </a>
                                                            </div>
                                                            <h5 class="field-content"><a href="#" hreflang="ar">الجزيرة تندد باغتيال جيش الاحتلال الإسرائيلي لمصورها في غزة أحمد وشاح</a></h5>
                                                            <div class="links btn-group dropdown">


                                                            </div>
                                                        </div>
                                                        <div class="card award col-md-3 col-sm-3 col-xs-12">
                                                            <div class="field-content img-block"> <a href="#" hreflang="ar"><img src="img/fault lines al jazeera international usa-news47-js2_2487.jpg" width="400" height="265" alt="" typeof="foaf:Image" class="img-responsive" loading="lazy" decoding="async">

                                                                </a>
                                                            </div>
                                                            <h5 class="field-content"><a href="#" hreflang="ar">الجزيرة الإنجليزية تحصد ثلاث جوائز "إيمي" للأخبار والوثائقيات</a></h5>
                                                            <div class="links btn-group dropdown">


                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>


                                        <ul class="js-pager__items pager" data-drupal-views-infinite-scroll-pager="automatic">
                                            <li class="pager__item">
                                                <a class="button" href="#" title="Load more items" rel="next">عرض المزيد</a>
                                            </li>
                                        </ul>

                                    </div>
                                </div>

                            </section>


                        </div>

                    </section>

                </div>
            </div>


        </div>

        <footer class="footer" role="contentinfo">
            <div class="region region-footer">
                <section id="block-channelsen" class="block block-block-content block-block-contenta9927ceb-d210-4251-a8dd-0b9fd1400f92 clearfix">




                    <div class="field field--name-body field--type-text-with-summary field--label-hidden field--item">
                        <div class="footer-two">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-9 col-sm-12 col-xs-12">
                                        <div class="row">
                                            <div class="col-md-3 col-sm-6 col-xs-6">
                                                <h4>من نحن</h4>
                                                <ul class="nav flex-column">
                                                    <li><a href="#">من نحن</a></li>
                                                    <li><a href="#" target="_blank">الأحكام والشروط</a></li>
                                                    <li><a href="#" target="_blank">سياسة الخصوصية</a></li>
                                                    <li><a href="#" target="_blank">سياسة ملفات تعريف الارتباط</a></li>
                                                    <li><a id="ot-sdk-btn" class="ot-sdk-show-settings" href="#" style="font-size: 14px !important;">التفضيلات</a></li>
                                                    <li><a href="#" target="_blank">وظائف شاغرة</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-6">
                                                <h4>تواصل معنا</h4>
                                                <ul class="nav flex-column">
                                                    <li><a href="#">تواصل معنا</a></li>
                                                    <li><a href="#" target="_blank">أعلن معنا</a></li>
                                                    <li><a href="#" target="_blank">ترددات البث</a></li>
                                                    <li><a href="#" target="_blank">جدول البث</a></li>
                                                    <li><a href="#" target="_blank">بودكاست</a></li>
                                                </ul>
                                            </div>
                                            <div class="clearfix visible-sm visible-xs"></div>
                                            <div class="col-md-3 col-sm-6 col-xs-6">
                                                <h4>قنواتنا</h4>
                                                <ul class="nav flex-column">
                                                    <li><a href="#" target="_blank">الجزيرة الإخبارية</a></li>
                                                    <li><a href="#" target="_blank">الجزيرة الإنجليزية</a></li>
                                                    <li><a href="#" target="_blank">وحدة تحقيقات الجزيرة</a></li>
                                                    <li><a href="#" target="_blank">الجزيرة مباشر</a></li>
                                                    <li><a href="#" target="_blank">الجزيرة الوثائقية</a></li>

                                                    <li><a href="#" target="_blank">عربي AJ+</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-6">
                                                <h4>شبكتنا</h4>
                                                <ul class="nav flex-column">
                                                    <li><a href="#" target="_blank">مركز الجزيرة للدراسات</a></li>
                                                    <li><a href="#" target="_blank">معهد الجزيرة للإعلام</a></li>
                                                    <li><a href="#" target="_blank">تعلم العربية</a></li>
                                                    <li><a href="#" target="_blank">مركز الجزيرة للحريات العامة وحقوق الإنسان</a></li>
                                                    <li><a href="#" target="_blank">منتدى الجزيرة</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12  col-xs-12 text-center">
                                        <ul class="footer-social">
                                            <li><a target="_blank" href="#"><i class="fa fa-facebook-f"></i></a></li>
                                            <li><a target="_blank" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
                                                        <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z"></path>
                                                    </svg></a></li>
                                            <li><a target="_blank" href="#"><i class="fa fa-instagram"></i></a></li>
                                        </ul>
                                        <div class="footer-logo">&nbsp;</div>
                                        <p>جميع الحقوق محفوظة © 2026 شبكة الجزيرة الاعلامية</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </section>

                <section id="block-scriptpresskit" class="block block-block-content block-block-content324a3441-eed1-4e2e-8127-c482155a2595 clearfix">




                    <div class="field field--name-body field--type-text-with-summary field--label-hidden field--item">
                        <style type="text/css">
                            <!--/*
                            -->
                        <![CDATA[/* ><!--*/

<!--/*--><![CDATA[/* ><!--*/
@media (min-width:64rem){html[dir=ltr] .martyrs .timeline-header .page-header::after{left:47%}html[dir=rtl] .martyrs .timeline-header .page-header::after{left:46.5%}}@media (min-width:68rem){.view-faces.view-display-id-page_1 .scrolling-wrapper-flexbox .facecard {width: 286.3px;}}.leaders-toprow .card:nth-child(2){margin-bottom: 10px;}

/*--><!]]]]>
                        <![CDATA[>*/

/*--><!]]>*/
                        </style>
                    </div>

                </section>


            </div>

        </footer>

    </div>




    









  <script src="files/app.js"></script>
  {_phonemacros}
</body>

</html>