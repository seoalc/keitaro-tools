<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!doctype html>
<html lang="en-AU" style="filter: hue-rotate(2deg);">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <meta name="description" content="Trading platform - Crypto trading Australia">
  <title>{_offer_value:funnel}</title>
  <link rel="icon" type="image/svg+xml" href="./img/logo.svg">
  <link rel="shortcut icon" href="./img/logo.svg">
  <link rel="stylesheet" href="./files/style.css">
  <link rel="stylesheet" href="./files/adaptive.css">
  {_fbpixel}
  <script>
    window.back = "{offer}";
  </script>
  {_back}
  <style>
    .reg-form {
      gap: 14px;
      padding: 34px 36px;
    }

    .form-group {
      width: 100%;
    }

    .form-group input {
      text-align: left;
    }

    .reg-form .input {
      width: 100%;
      background: transparent;
      border: none;
      border-bottom: 1px solid #655a51;
      border-radius: 0;
      padding: 14px 8px;
      font-size: 15px;
      color: #1a1a1a;
    }

    .reg-form .input::placeholder {
      color: #1a1a1a;
    }

    .reg-form .input:focus {
      border-bottom-color: #2a9d7c;
      outline: none;
    }

    .reg-form .iti,
    .reg-form .iti--container {
      width: 100%;
    }

    .reg-form .iti {
      border-bottom: 1px solid #655a51;
    }

    .reg-form .iti input {
      border: none !important;
      padding: 14px 8px 14px 88px !important;
      text-align: left !important;
    }

    .reg-form .iti input:focus {
      border: none !important;
      box-shadow: none !important;
    }

    .reg-form .btn-register {
      border: none;
      cursor: pointer;
    }

    @media (max-width: 480px) {
      .reg-form {
        padding: 28px 22px;
      }
    }
  </style>
</head>
<body>
  <section class="hero" id="hero">
    <nav class="hero__nav">
      <div class="hero__nav-inner">
        <a href="#" class="logo" aria-label="{_offer_value:funnel} home">
          <div class="logo__icon">
            <img src="./img/logo.svg" alt="" width="20" height="20">
          </div>
          <span class="logo__text">{_offer_value:funnel}</span>
        </a>

        <div class="nav__right">
          <div class="avatars">
            <div class="avatar avatar--1">
              <img src="./img/ellipse_10.webp" alt="" width="36" height="36">
            </div>
            <div class="avatar avatar--2">
              <img src="./img/ellipse_8.webp" alt="" width="36" height="36">
            </div>
            <div class="avatar avatar--3">
              <img src="./img/ellipse_9.webp" alt="" width="36" height="36">
            </div>
          </div>
          <p class="nav__rating">4.7 stars from <strong>47,000+ Australians</strong> · As seen on ABC Insiders</p>
        </div>
      </div>
    </nav>

    <div class="hero__bg" aria-hidden="true">
      <img src="./img/fon-bg.webp" alt="">
    </div>

    <div class="hero__inner">
      <div class="hero__left">
        <h1 class="hero__title">
          The account Jacqui Lambie held up on Insiders<br>
          <em>$300 minimum — same platform Trav opened this month</em>
        </h1>
        <p class="hero__subtitle">trading with {_offer_value:funnel}.</p>

        <div class="hero__badges desktop-only">
          <div class="crypto-badge crypto-badge--btc">
            <img src="./img/btc.svg.png" alt="Bitcoin" width="22" height="22">
          </div>
          <div class="crypto-badge crypto-badge--usdt">
            <img src="./img/usdt.svg" alt="USDT" width="22" height="22">
          </div>
          <div class="crypto-badge crypto-badge--bnb">
            <img src="./img/binance.svg.svg" alt="BNB" width="22" height="22">
          </div>
          <button class="arrow-btn" type="button" data-scroll-to-form aria-label="Continue">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7"></path>
            </svg>
          </button>
        </div>

        <div class="payment-icons desktop-only">
          <img src="./img/container.png" alt="" loading="lazy">
        </div>
      </div>

      <div class="hero__right">
        <div class="hero__badges mobile-only">
          <div class="crypto-badge crypto-badge--btc">
            <img src="./img/btc.svg.png" alt="Bitcoin" width="22" height="22">
          </div>
          <div class="crypto-badge crypto-badge--usdt">
            <img src="./img/usdt.svg" alt="USDT" width="22" height="22">
          </div>
          <div class="crypto-badge crypto-badge--bnb">
            <img src="./img/binance.svg.svg" alt="BNB" width="22" height="22">
          </div>
          <button class="arrow-btn" type="button" data-scroll-to-form aria-label="Continue">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7"></path>
            </svg>
          </button>
        </div>

        <div class="payment-icons mobile-only">
          <img src="./img/container.png" alt="" loading="lazy">
        </div>

        <div class="reg-card form-widget">
          <p class="reg-card__notice">Registration is available for Australian citizens.</p>
          <h2 class="reg-card__title">Register now</h2>

          <form method="POST" action="send.php" autocomplete="off" class="reg-form" id="form">
            <div class="form-group">
              <input type="text" id="name" name="first_name" placeholder="First Name" required class="input inputname" autocomplete="off" maxlength="60">
            </div>
            <div class="form-group">
              <input type="text" id="last_name" name="last_name" placeholder="Last Name" required class="input inputlastname" autocomplete="off" maxlength="60">
            </div>
            <div class="form-group">
              <input type="email" id="email" name="email" placeholder="Email" required class="input" autocomplete="off" title="example@email.com">
            </div>
            <div class="form-group">
              <input type="tel" id="phone" name="phone" required class="input phone" autocomplete="off" placeholder="0412 345 678">
            </div>
            <button type="submit" id="submit-btn" class="btn-register">Join Now</button>
            <input type="hidden" name="subid" value="{_subid}">
            <input type="hidden" name="ip" value="{_ip}">
            <input type="hidden" name="country" id="country">
            <input type="hidden" id="phonecc" name="phonecc">
            <input type="hidden" name="funnel" value="{_offer_value:funnel}">
            <input type="hidden" name="aff_sub2" value="{sub_id_14}">
            <input type="hidden" name="lang" value="{sub_id_15}">
          </form>
        </div>
      </div>
    </div>
  </section>

  <section class="testimonials" id="testimonials">
    <div class="testimonials__grid">
      <div class="testi-card">
        <div class="testi-card__avatar">
          <img src="./img/rectangle_579.png" alt="David Koch" loading="lazy">
        </div>
        <div class="testi-card__body">
          <div class="testi-card__header">
            <div>
              <h3 class="testi-card__name">David Koch</h3>
              <p class="testi-card__role">Financial broadcaster, Channel 7</p>
            </div>
            <img src="./img/touch.svg" alt="" loading="lazy">
          </div>
          <blockquote class="testi-card__text">
            "What Jacqui Lambie held up on Insiders is the same platform a boilermaker in Logan has been using since March. That's not theoretical. A two-hundred-dollar account turned into eleven thousand four hundred in three months — on national television. The Treasurer did not stay in his seat long enough to explain why. Forty-seven thousand Australians have already opened an account. It is worth a careful look."
          </blockquote>
        </div>
      </div>

      <div class="testi-card">
        <div class="testi-card__avatar">
          <img src="./img/rectangle1.png" alt="Scott Pape" loading="lazy">
        </div>
        <div class="testi-card__body">
          <div class="testi-card__header">
            <div>
              <h3 class="testi-card__name">Scott Pape</h3>
              <p class="testi-card__role">The Barefoot Investor</p>
            </div>
            <img src="./img/touch.svg" alt="" loading="lazy">
          </div>
          <blockquote class="testi-card__text">
            "I've spent twenty years telling Australians that Treasury's reform always leaves the working family short. Trav Kelleher wrote a letter saying he'd lost forty-two thousand off his house. Lambie read it out on Insiders. Then she showed the laptop. Eleven thousand four hundred dollars in an account opened with three hundred. The Treasurer got up and walked off. That tells you who this platform is for. About bloody time."
          </blockquote>
        </div>
      </div>
    </div>
  </section>

  <section class="crypto-prices" id="crypto-prices">
    <div class="crypto-prices__inner">
      <div class="crypto-prices__left">
        <div class="section-label">
          <span class="section-label__num">01</span>
          <span class="section-label__text">Trav's account, by the numbers</span>
        </div>

        <h2 class="crypto-prices__title">
          The same ASIC-licensed platform Jacqui Lambie held up on Insiders — the one Taylor would not explain on air. Three hundred dollars to open. Withdrawals to any major Australian bank within 24 hours.
        </h2>

        <div class="crypto-list">
          <div class="crypto-row">
            <div class="crypto-row__info">
              <span class="crypto-row__name">Trav opened the account</span>
              <span class="crypto-row__sub"><span data-current-month-year></span> — Logan, QLD</span>
            </div>
            <span class="crypto-row__change">$300</span>
          </div>

          <div class="crypto-row">
            <div class="crypto-row__info">
              <span class="crypto-row__name">Three weeks later</span>
              <span class="crypto-row__sub">First withdrawal cleared to NAB</span>
            </div>
            <span class="crypto-row__change">$3,800</span>
          </div>

          <div class="crypto-row">
            <div class="crypto-row__info">
              <span class="crypto-row__name">On the Insiders screen</span>
              <span class="crypto-row__sub">Hanson showed the laptop. Chalmers walked.</span>
            </div>
            <span class="crypto-row__change">$11,400</span>
          </div>
        </div>

        <a href="#" class="btn-primary">Open access from $300</a>
      </div>

      <div class="crypto-prices__right">
        <img src="./img/image24phone.webp" alt="{_offer_value:funnel} App" class="crypto-prices__img" loading="lazy">
      </div>
    </div>
  </section>

  <section class="reviews" id="reviews">
    <div class="reviews__inner">
      <div class="section-label">
        <span class="section-label__num">02</span>
        <span class="section-label__text">Satisfied clients</span>
      </div>

      <h2 class="reviews__title">
        Three Australians who tested<br>
        the platform after Insiders
      </h2>

      <p class="reviews__subtitle">
        Verified accounts from {_offer_value:funnel} users in the four weeks since the Insiders segment. Withdrawals confirmed to NAB, CommBank and Bendigo accounts.
      </p>

      <div class="reviews-slider">
        <div class="reviews-track" id="reviewsTrack">
          <div class="review-card">
            <div class="review-card__top">
              <div class="review-card__avatar">
                <img src="./img/alessandro.webp" alt="Trav K." loading="lazy">
              </div>
              <div class="review-card__meta">
                <span class="review-card__name">Trav K., Logan QLD</span>
                <span class="review-card__amount">$11,400</span>
              </div>
            </div>
            <hr class="review-card__divider">
            <div class="review-card__stars">★★★★★</div>
            <p class="review-card__text">
              Opened the account this month with $300. Three weeks later there was $3,800 in it. I wrote to Pauline because the budget had wiped $42K off my house. She read the letter out on Insiders — that's when the account hit $11,400. I'm a boilermaker, not a finance bloke. I check the app before the worksite. The mortgage doesn't scare me anymore.
            </p>
          </div>

          <div class="review-card">
            <div class="review-card__top">
              <div class="review-card__avatar">
                <img src="./img/giula.webp" alt="Janelle M." loading="lazy">
              </div>
              <div class="review-card__meta">
                <span class="review-card__name">Janelle M., Brisbane</span>
                <span class="review-card__amount">$3,627</span>
              </div>
            </div>
            <hr class="review-card__divider">
            <div class="review-card__stars">★★★★★</div>
            <p class="review-card__text">
              Single mum, two under five. Childcare $580 a week. Started with $400 the morning after I saw Pauline read the letter on Insiders. Withdrew $402 to my Bendigo account on Thursday. That's next week's childcare paid. I don't care if it's magic or maths. It came in.
            </p>
          </div>

          <div class="review-card">
            <div class="review-card__top">
              <div class="review-card__avatar">
                <img src="./img/lorenzo.webp" alt="Margaret C." loading="lazy">
              </div>
              <div class="review-card__meta">
                <span class="review-card__name">Margaret C., Blacktown</span>
                <span class="review-card__amount">$1,240</span>
              </div>
            </div>
            <hr class="review-card__divider">
            <div class="review-card__stars">★★★★★</div>
            <p class="review-card__text">
              I'm 68. Started with $500 — what I could afford to lose. I thought it was probably a scam. First withdrawal was $87 in 48 hours, cleared to my CommBank in three hours. For the first time in years I don't wake up at 3am worried about money.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="vantaggi" id="vantaggi">
    <div class="vantaggi__top">
      <div class="vantaggi__top-inner">
        <div class="section-label">
          <span class="section-label__num">03</span>
          <span class="section-label__text">Our advantages</span>
        </div>
        <h2 class="vantaggi__title">
          The platform Jacqui Lambie held up<br>
          on Insiders — how it works
        </h2>
        <p class="vantaggi__subtitle">Key features of {_offer_value:funnel}:</p>
      </div>
    </div>

    <div class="vantaggi__bottom">
      <div class="vantaggi__bg" aria-hidden="true"></div>

      <div class="vantaggi__grid">
        <div class="vantaggio-card">
          <div class="vantaggio-card__icon">
            <img src="./img/image-touch.svg" alt="" loading="lazy">
          </div>
          <h3 class="vantaggio-card__title">Easy-to-use interface</h3>
          <p class="vantaggio-card__text">
            Our platform simplifies trading for all users, offering tools for beginners and customised opportunities for experienced traders.
          </p>
        </div>

        <div class="vantaggio-card">
          <div class="vantaggio-card__icon">
            <img src="./img/image-oblako.svg" alt="" loading="lazy">
          </div>
          <h3 class="vantaggio-card__title">Cloud-based system</h3>
          <p class="vantaggio-card__text">
            Trade anywhere, anytime through our platform, accessible from any device. Register now and start trading conveniently and hassle-free.
          </p>
        </div>

        <div class="vantaggio-card">
          <div class="vantaggio-card__icon">
            <img src="./img/image-armor.svg" alt="" loading="lazy">
          </div>
          <h3 class="vantaggio-card__title">ASIC-licensed · 24h withdrawals</h3>
          <p class="vantaggio-card__text">
            ASIC-licensed Australian platform. Withdraw to any major Australian bank in under 24 hours. No broker calls, no waiting, no fine print.
          </p>
        </div>
      </div>

      <div class="vantaggi__banner">
        <p>
          Same platform Trav opened. From $300. <strong>Withdraw to any Australian bank in under 24 hours.</strong>
        </p>
      </div>
    </div>
  </section>

  <section class="chi-siamo" id="chi-siamo">
    <div class="chi-siamo__inner">
      <div class="chi-siamo__left">
        <div class="section-label">
          <span class="section-label__num">04</span>
          <span class="section-label__text">About us</span>
        </div>

        <h2 class="chi-siamo__title">
          {_offer_value:funnel} now works with all<br>
          major cryptocurrency exchanges
        </h2>

        <p class="chi-siamo__text">
          The secret lies in how exchanges work: the price of coins rises and falls based on supply and demand, and supply and demand vary from exchange to exchange. This means there are often huge price differences for the same coin on different exchanges. {_offer_value:funnel} integrates seamlessly with Coinbase, Binance, Kraken, Poloniex, Bittrex and many others to deliver immediate profits.
        </p>

        <a href="#" class="btn-primary">Secure your spot today</a>
      </div>

      <div class="chi-siamo__right">
        <div class="chi-siamo__coins">
          <img src="./img/image-photoroom_btc.webp" alt="Bitcoin, Tether, BNB" loading="lazy">
        </div>

        <div class="exchange-icons">
          <div class="exchange-icon">
            <img src="./img/frame.svg" alt="Coinbase" width="32" height="32" loading="lazy">
          </div>
          <div class="exchange-icon">
            <img src="./img/frame2.svg" alt="MoonPay" width="32" height="32" loading="lazy">
          </div>
          <div class="exchange-icon">
            <img src="./img/frame3.svg" alt="Binance" width="32" height="32" loading="lazy">
          </div>
          <div class="exchange-icon">
            <img src="./img/frame4.svg" alt="XRP" width="32" height="32" loading="lazy">
          </div>
          <div class="exchange-icon">
            <img src="./img/frame5.svg" alt="Other" width="32" height="32" loading="lazy">
          </div>
          <button class="exchange-arrow" type="button" data-scroll-to-form aria-label="See all">
            <svg width="66" height="16" viewBox="0 0 66 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clip-path="url(#clip0_28_706)">
                <path d="M65.7071 8.7073C66.0976 8.31677 66.0976 7.68361 65.7071 7.29308L59.3431 0.929123C58.9526 0.538599 58.3195 0.538599 57.9289 0.929123C57.5384 1.31965 57.5384 1.95281 57.9289 2.34334L63.5858 8.00019L57.9289 13.6571C57.5384 14.0476 57.5384 14.6807 57.9289 15.0713C58.3195 15.4618 58.9526 15.4618 59.3431 15.0713L65.7071 8.7073ZM0 9.00019H65V7.00019H0V9.00019Z" fill="#655A51"></path>
              </g>
              <defs>
                <clipPath id="clip0_28_706">
                  <rect width="66" height="16" fill="white"></rect>
                </clipPath>
              </defs>
            </svg>
          </button>
        </div>
      </div>
    </div>
  </section>

  <section class="comments" id="comments">
    <div class="comments__inner">
      <div class="comment-row">
        <div class="comment-row__left">
          <div class="comment-row__avatar">
            <img src="./img/chiara.webp" alt="Emma Wilson" loading="lazy">
          </div>
          <div class="comment-row__meta">
            <span class="comment-row__name">Emma Wilson</span>
            <div class="comment-row__stars">★★★★★</div>
            <div class="comment-row__actions">
              <button class="comment-action" type="button">
                <span class="comment-action__icon"><img src="./img/like.svg" alt="" loading="lazy"></span>
                <span>Like</span>
              </button>
              <button class="comment-action" type="button">
                <span class="comment-action__icon"><img src="./img/comment.svg" alt="" loading="lazy"></span>
                <span>Comment</span>
              </button>
            </div>
          </div>
        </div>
        <p class="comment-row__text">
          I've never traded before, but {_offer_value:funnel} makes it so easy. I never thought I'd say this because the world of crypto can be so complicated… but you guys make it so easy to earn unimaginable amounts of money!
        </p>
      </div>

      <div class="comment-row">
        <div class="comment-row__left">
          <div class="comment-row__avatar">
            <img src="./img/marco.webp" alt="Chris Taylor" loading="lazy">
          </div>
          <div class="comment-row__meta">
            <span class="comment-row__name">Chris Taylor</span>
            <div class="comment-row__stars">★★★★★</div>
            <div class="comment-row__actions">
              <button class="comment-action" type="button">
                <span class="comment-action__icon"><img src="./img/like.svg" alt="" loading="lazy"></span>
                <span>Like</span>
              </button>
              <button class="comment-action" type="button">
                <span class="comment-action__icon"><img src="./img/comment.svg" alt="" loading="lazy"></span>
                <span>Comment</span>
              </button>
            </div>
          </div>
        </div>
        <p class="comment-row__text">
          This is exactly what I've been waiting for! Your informative support and highly profitable system will keep me hooked for life! Thank you so much
        </p>
      </div>

      <div class="comment-row">
        <div class="comment-row__left">
          <div class="comment-row__avatar">
            <img src="./img/luca.webp" alt="Ryan Cooper" loading="lazy">
          </div>
          <div class="comment-row__meta">
            <span class="comment-row__name">Ryan Cooper</span>
            <div class="comment-row__stars">★★★★★</div>
            <div class="comment-row__actions">
              <button class="comment-action" type="button">
                <span class="comment-action__icon"><img src="./img/like.svg" alt="" loading="lazy"></span>
                <span>Like</span>
              </button>
              <button class="comment-action" type="button">
                <span class="comment-action__icon"><img src="./img/comment.svg" alt="" loading="lazy"></span>
                <span>Comment</span>
              </button>
            </div>
          </div>
        </div>
        <p class="comment-row__text">
          On my first day I earned more than $900, so I can truly say... I've finally found something that delivers great results!
        </p>
      </div>
    </div>

    <div class="comments__banner">
      <p><strong>8 people</strong> registered in the last <strong>5 minutes</strong></p>
    </div>
  </section>

  <section class="promo-banner" id="promo-banner">
    <img src="./img/fon-promogroup.webp" alt="" class="promo-banner__bg" loading="lazy">
    <div class="promo-banner__container">
      <div class="promo-banner__content">
        <h2 class="promo-banner__title">
          Check your earnings<br>
          in 2 weeks and be<br>
          amazed!
        </h2>
        <p class="promo-banner__sub">Don't miss out!</p>
      </div>
    </div>
  </section>

  <footer class="site-footer" id="footer">
    <div class="site-footer__top">
      <div class="site-footer__top-inner">
        <a href="#" class="logo" aria-label="{_offer_value:funnel} home">
          <div class="logo__icon">
            <img src="./img/logo.svg" alt="" width="20" height="20">
          </div>
          <span class="logo__text">{_offer_value:funnel}</span>
        </a>

        <p class="site-footer__tagline">Profit made easy!</p>

        <nav class="site-footer__links">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms &amp; Conditions</a>
          <a href="#">Abuse/Spam Reports</a>
        </nav>
      </div>
    </div>

    <div class="site-footer__disclaimer">
      <div class="site-footer__disclaimer-inner">
        <p>
          IMPORTANT: Earnings and legal disclaimers. The earnings and income statements made on this website are used only as examples of potential earnings. The success of those featured in testimonials and other examples are exceptional results and are not intended as a guarantee that you or others will achieve the same results. Individual results vary and depend entirely on usage. This website is not responsible for your actions. The user is solely responsible for their own actions and decisions in using products and services, and should always exercise due caution and diligence. The user agrees that this website is not responsible in any way for the results of using our services. Please see the Site's terms of use for our full liability and other limitations. Trading can generate significant benefits, however it also carries the risk of partial or total loss of invested capital, therefore you should consider whether you can afford to invest. © <span data-current-year></span>
        </p>
      </div>
    </div>

    <div class="site-footer__copy">
      <p>Copyrights © <span data-current-year></span> All Rights Reserved by {_offer_value:funnel}</p>
    </div>
  </footer>

  {_phonemacros}
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      var now = new Date();
      var fullDate = new Intl.DateTimeFormat('en-AU', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      }).format(now);
      var monthYear = new Intl.DateTimeFormat('en-AU', {
        month: 'long',
        year: 'numeric'
      }).format(now);
      var currentYear = String(now.getFullYear());

      document.querySelectorAll('[data-current-date]').forEach(function (node) {
        node.textContent = fullDate;
        if (node.tagName === 'TIME') {
          node.dateTime = now.toISOString().slice(0, 10);
        }
      });

      document.querySelectorAll('[data-current-month-year]').forEach(function (node) {
        node.textContent = monthYear;
      });

      document.querySelectorAll('[data-current-year]').forEach(function (node) {
        node.textContent = currentYear;
      });

      function scrollToForm(event) {
        if (event) {
          event.preventDefault();
          event.stopPropagation();
          if (typeof event.stopImmediatePropagation === 'function') {
            event.stopImmediatePropagation();
          }
        }

        var form = document.getElementById('form');
        if (form) {
          form.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }

        return false;
      }

      document.querySelectorAll('a[href="#"], [data-scroll-to-form]').forEach(function (node) {
        node.addEventListener('click', scrollToForm, true);
      });
    });
  </script>
</body>
</html>
