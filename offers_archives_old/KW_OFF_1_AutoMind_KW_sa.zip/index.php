<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>

<!DOCTYPE html>
<html lang="ar-KW" dir="rtl">

<head>
{_fbpixel}
{_back}
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>في الكويت يمكنك الربح من 160 د.ك يوميًا مع {_offer_value:funnel}</title>
    <link rel="stylesheet" href="files/tailwind.css">
    <link rel="stylesheet" href="files/styles.css">
    <style>
        #floatingButton {
          position: fixed;
          left: 0px;
          bottom: 0px;
          display: none;
          width: 100%;
          cursor: pointer;
          z-index: 9999;
        }
        
        .floatingButton {
          --tw-text-opacity: 1;
          font-family: "Encode Sans Expanded", sans-serif;
          font-size: 1.7rem;
          font-weight: 900;
          color: rgb(255 255 255 / var(--tw-text-opacity));
          background-color: rgb(247 158 27 / var(--tw-bg-opacity));
          position: relative;
          z-index: auto;
          display: block;
          width: 100%;
          padding: 5px;
          margin: 0 auto;
          transition: 0.3s;
          text-align: center;
          text-transform: uppercase;
          text-decoration: none !important;
        }
        
        .floatingButton:hover {
          --tw-brightness: brightness(1.05);
          filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast)
            var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert)
            var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
        }

        body {
          direction: rtl;
        }

        .rf-form-input {
          text-align: right;
        }

        input[type="email"],
        input[type="tel"] {
          direction: ltr;
          text-align: right;
        }

        [dir="rtl"] .text-left {
          text-align: right;
        }

        @media (min-width: 1024px) {
          [dir="rtl"] .lg\:text-left {
            text-align: right;
          }
        }
        
    </style>
</head>

<body >
    <header class="header-new flex flex-col">
        <nav class="nav py-1 lg:py-5 border-b border-b-white/10">
            <div class="relative max-w-8xl px-4 mx-auto pt-2 lg:pt-0 flex items-center justify-between gap-2">
                <a class="logo flex items-center gap-2 flex-shrink-0" href="#" >
                    <img src="img/logo.svg" alt="" class="w-7 h-7 lg:w-auto lg:h-auto">
                    <div class="uppercase text-white font-black text-sm lg:text-base" style="letter-spacing:1px;">{_offer_value:funnel}</div>
                </a>
                <div class="px-2 py-1 bg-primary-main rounded-md text-white font-bold text-xs lg:text-sm whitespace-nowrap flex-shrink-0">
                    <span class="hidden sm:inline">الأماكن المتبقية في الكويت:</span>
                    <span class="sm:hidden">الأماكن المتبقية:</span>
                    <strong class="font-black" data-slot-count="">3</strong>
                </div>
            </div>
        </nav>
        <div class="relative w-full max-w-8xl px-4 mx-auto z-10 flex-grow flex flex-col">
            <div class="header-lines flex flex-col flex-grow">
                <div class="flex flex-col lg:flex-row flex-grow">
                    <div class="w-full lg:w-1/2 my-6 text-center lg:text-left lg:self-center">
                        <div class="text-3xl xl:text-5xl xl:leading-tight font-alt font-black text-white">
                            في الكويت يمكنك الربح من
                        </div>
                        <div class="text-4xl xl:text-6xl xl:leading-tight font-alt font-black text-primary-bright">
                            160 د.ك يوميًا
                        </div>
                        <div class="flex items-center justify-center lg:justify-start">
                            <div class="my-2 text-base xl:text-2xl font-alt font-black text-white text-left">
                                باستخدام منصة التداول<br>
                                {_offer_value:funnel}
                            </div>

                        </div>
                        <div class="my-5 lg:my-10 text-base md:text-lg font-semibold text-white/80">
                            التسجيل في الكويت مفتوح الآن.<br>
                        </div>
                        <div class="flex items-center justify-center lg:justify-start gap-2 xl:gap-5">
                            <div class="flex">
                                <img class="relative w-11 h-9 rounded-full border border-primary-dark z-[3]" src="img/header-avatar-1.webp" alt="">
                                <img class="relative w-11 h-9 -ml-3 rounded-full border border-primary-dark z-[2]" src="img/header-avatar-2.webp" alt="">
                                <img class="relative w-11 h-9 -ml-3 rounded-full border border-primary-dark z-[1]" src="img/header-avatar-3.webp" alt="">
                            </div>
                            <div class="text-left text-xs sm:text-base">
                                <div class="text-white">
                                    <span class="text-white/80">تقييم 4.8 نجوم من أكثر من</span>
                                    <span class="font-bold">2,780 مستخدمًا</span>
                                </div>
                                <img class="h-5" src="img/stars.svg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="header-mobile pt-12 mx-auto lg:ml-auto lg:mr-0 w-full max-w-[420px] lg:max-w-[490px] flex flex-col items-center">
                        <img class="w-12" src="img/logo.svg" alt="">
                        <div style="text-align: center; font-size: 1.2rem" class="mt-1 text-2xl font-black text-white font-alt">
                            سجّل الآن!
                        </div>

                        <!-- FORM -->
                        <form id="form" class="rf-form js-rf-form" method="post" action="send.php">
                         <input type="hidden" name="subid" value="{_subid}">
                            <input type="hidden" name="ip" value="{_ip}">
                            <input type="hidden" name="country" id="country">
                            <input type="hidden" id="phonecc" name="phonecc">
                            <input type="hidden" name="funnel" value="{_offer_value:funnel}">
                            <!-- FORM FIELDS -->
                            <div class="rf-form-field">
                                <input class="rf-form-input" type="text" id="name" name="first_name" placeholder="أدخل اسمك" autocomplete="given-name" inputmode="text" spellcheck="false" autocapitalize="words" required>
                            </div>

                            <div class="rf-form-field">
                                <input class="rf-form-input" type="text" id="lname" name="last_name" placeholder="أدخل اسم العائلة" autocomplete="family-name" inputmode="text" spellcheck="false" autocapitalize="words" required>
                            </div>

                            <div class="rf-form-field">
                                <input class="rf-form-input" type="email" id="email" name="email" placeholder="أدخل بريدك الإلكتروني" autocomplete="email" inputmode="email" spellcheck="false" autocapitalize="off" pattern="^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$" required>
                            </div>

                            <div class="rf-form-field rf-phone-field">
                                <input class="rf-form-input" type="tel" id="phone" name="phone" placeholder="5000 0000" autocomplete="tel" inputmode="tel" spellcheck="false" autocapitalize="off" required>
                            </div>

                            <div class="my-5">
                                <button id="buttonSbmt" class="w-full h-12 border-0 rounded-md text-white font-black font-alt cursor-pointer bg-primary-bright active:brightness-95 hover:brightness-105" type="submit">
                                    تسجيل
                                </button>
                            </div>
                        </form>
                        <div class="h-26 flex payment-methods">
                            <img src="img/payment.svg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main class="main">
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="mb-4 md:mb-16 flex flex-col md:flex-row border border-primary-dark/10 rounded-xl">
                <div class="md:order-2 md:w-1/3 lg:w-auto md:-mr-px flex-shrink-0 md:translate-y-8">
                    <img loading="lazy" class="w-full block rounded-t-xl md:rounded-br-xl" src="img/photo1.webp" alt="">
                </div>
                <div class="flex-grow p-4 sm:p-7">
                    <div class="flex items-center">
                        <img loading="lazy" class="w-12 sm:w-auto mr-4 sm:mr-6" src="img/quote.svg" alt="">
                        <div>
                            <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                                ناصر العتيبي
                            </div>
                            <div class="text-sm uppercase font-bold text-primary-medium">
                                رجل أعمال كويتي ومستثمر تقني دولي
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 sm:mt-7 text-primary-medium lg:text-lg">
                        "بعد سنوات طويلة في بناء أعمال دولية، أستطيع تمييز الفرصة الجادة عندما أراها. لقد جعلت تقنية التداول الآلي الوصول إلى أدوات كانت سابقًا حكرًا على المستثمرين المؤسسيين أكثر سهولة. درست هذه المنصة لمدة ثلاثة أسابيع قبل أن أستثمر 52,000 د.ك. وكانت النتائج لافتة: نمو بنسبة 83.3%" - قال في مقابلة خاصة.
                    </div>
                </div>
            </div>
            <div class="flex flex-col md:flex-row border border-primary-dark/10 rounded-xl md:rounded-bl-none">
                <div class="md:w-1/3 lg:w-auto md:-ml-px flex-shrink-0 md:-translate-y-8">
                    <img loading="lazy" class="w-full block rounded-t-xl md:rounded-br-xl" src="img/photo2.webp" alt="">
                </div>
                <div class="flex-grow p-4 sm:p-7">
                    <div class="flex items-center">
                        <img loading="lazy" class="w-12 sm:w-auto mr-4 sm:mr-6" src="img/quote.svg" alt="">
                        <div>
                            <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                                عبدالله الصالح
                            </div>
                            <div class="text-sm uppercase font-bold text-primary-medium">
                                خبير في القطاع المالي الكويتي
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 sm:mt-7 text-primary-medium lg:text-lg">
                        "أعتبر هذا أحد أكثر مشاريع الاستثمار وضوحًا وتقدمًا. فوجئت بعد دراسة التقنية واختبارها. بعد ثلاثة أسابيع من اكتشاف هذا النظام، استثمرت 148,000 د.ك. ووصل النمو لدي اليوم إلى 91.7%. أكثر ما يثير إعجابي هو الشفافية والتقنية خلف النظام؛ فالدقة والاستقرار والوضوح صفات نحتاجها في التمويل الحديث" - صرّح في مقابلة.
                    </div>
                </div>
            </div>
        </div>
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="mb-7 grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-7 lg:items-center">
                <div class="lg:col-span-2">
                    <div class="mb-2 text-sm uppercase font-black text-primary-medium">
                        01 // خوارزميات التداول
                    </div>
                    <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                        تستخدم <a href="#" class="funnel-link">{_offer_value:funnel}</a> الذكاء الاصطناعي وخوارزميات متقدمة لتحديد فرص التداول الواعدة فقط
                    </div>
                </div>
                <div class="flex justify-center text-primary-medium">
                    <button class="h-12 px-4 sm:px-6 border-0 rounded-md text-white font-black font-alt cursor-pointer bg-primary-bright active:brightness-95 hover:brightness-105 text-sm sm:text-base whitespace-nowrap" >
                        احجز مكانك اليوم!
                    </button>
                </div>
            </div>
            <div class="phones-bg rounded-xl">
                <div class="relative phones-lines pb-64 lg:pb-0 mb-24">
                    <div class="py-7 px-2.5 sm:py-10 lg:p-14 xl:px-20 xl:py-24 flex flex-col md:flex-row md:justify-between md:gap-2.5">
                        <div class="mb-2.5 md:mb-0 min-w-[1px] w-full flex flex-col md:flex-grow lg:flex-grow-0 gap-2.5">
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">S&amp;P</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">الأسهم</div>
                                    <div class="text-white/40 leading-4">الأسواق العالمية</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ 220 د.ك</div>
                            </div>
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">FX</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">العملات</div>
                                    <div class="text-white/40 leading-4">Forex</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ 62 د.ك</div>
                            </div>
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">AU</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">السلع</div>
                                    <div class="text-white/40 leading-4">الذهب، الفضة، النفط</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ 13 د.ك</div>
                            </div>
                        </div>
                        <div class="min-w-[1px] w-full flex flex-col md:flex-grow lg:flex-grow-0 gap-2.5">
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">ETF</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">ETFs</div>
                                    <div class="text-white/40 leading-4">صناديق مؤشرات</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ 145 د.ك</div>
                            </div>
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">IDX</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">المؤشرات</div>
                                    <div class="text-white/40 leading-4">Nasdaq, S&amp;P 500</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ 104 د.ك</div>
                            </div>
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">BND</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">السندات</div>
                                    <div class="text-white/40 leading-4">دخل ثابت</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ 8 د.ك</div>
                            </div>
                        </div>
                    </div>
                    <img loading="lazy" class="absolute left-1/2 bottom-0 lg:bottom-1/2 -translate-x-1/2 translate-y-[20%] lg:translate-y-1/2 w-72 xl:w-auto" src="img/photo3.webp" alt="">
                </div>
            </div>
        </div>
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="mb-7 grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-7 lg:items-center">
                <div class="lg:col-span-2">
                    <div class="mb-2 text-sm uppercase font-black text-primary-medium">
                        02 // آراء المستخدمين
                    </div>
                    <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                        حتى المبتدئون يبدؤون في رؤية نتائج بسرعة، والآن يمكنك أنت أيضًا البدء معنا!
                    </div>
                </div>
                <div class="lg:text-lg text-primary-medium">
                    يعمل برنامج <a href="#" class="funnel-link">{_offer_value:funnel}</a> عند رصد فرص في الأسواق العالمية، حتى في ظل تقلبات الأسعار وضغط السيولة في الكويت والمنطقة.
                </div>
            </div>
            <div class="grid grid-cols-1 gap-4 lg:grid-cols-3 lg:gap-7">
                <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                    <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                    <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                        أريد فقط أن أشكر <a href="#" class="funnel-link">{_offer_value:funnel}</a> لأنه غيّر حياتي فعلًا. خلال بضعة أسابيع بدأت أرى دخلًا لم أتوقعه!
                    </div>
                    <div class="flex items-center">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av1_m.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">
                                أحمد الكندري
                            </div>
                            <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">
                                1,550 د.ك
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                    <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                    <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                        قبل أسبوعين كنت قلقًا من مصاريفي الشهرية. الآن أحقق حوالي 695 د.ك شهريًا. لأول مرة منذ فترة أشعر بالراحة والثقة. شكرًا!
                    </div>
                    <div class="flex items-center">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av2_w.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">
                                مريم العجمي
                            </div>
                            <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">
                                730 د.ك
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                    <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                    <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                        هذا يعمل بالفعل! استخدمته لبضعة أسابيع فقط وحققت أكثر مما توقعت من مصدر دخل إضافي.
                    </div>
                    <div class="flex items-center">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av3_m.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">
                                خالد الرشيدي
                            </div>
                            <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">
                                1,320 د.ك
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="pros-bg">
            <div class="py-7 lg:py-12 w-full max-w-8xl px-4 mx-auto">
                <div class="mb-2 text-sm uppercase font-black text-[#7389a3]">
                    03 // مزايانا
                </div>
                <div class="mb-7 grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-7 lg:items-center">
                    <div class="lg:col-span-2">
                        <div class="text-white text-xl lg:text-2xl font-black font-alt">
                            سجّل اليوم واحصل على وصول فوري إلى برنامج التداول المتقدم هذا!
                        </div>
                    </div>
                    <div class="lg:text-lg text-[#7389a3]">
                        <a href="#" class="funnel-link">{_offer_value:funnel}</a>، دخل بالدينار الكويتي ووصول فوري
                    </div>
                </div>
                <div class="grid grid-cols-1 gap-4 lg:grid-cols-3 lg:gap-7">
                    <div class="border-l border-l-white/10 border-b border-b-white/10 p-4 sm:p-7 !pr-0">
                        <div class="mb-4 sm:mb-7 sm:max-w-60 text-white sm:text-lg font-black font-alt">
                            بسيط وسهل الاستخدام
                        </div>
                        <div class="flex items-start">
                            <img loading="lazy" class="w-16 h-16 sm:w-20 sm:h-20 mr-4 sm:mr-7" src="img/pros-1.svg" alt="">
                            <div class="text-white">
                                يمكن استخدام <a href="#" class="funnel-link">{_offer_value:funnel}</a> خلال ثوانٍ على أي كمبيوتر أو جهاز محمول: PC وMac وAndroid وiOS وغيرها
                            </div>
                        </div>
                    </div>
                    <div class="border-l border-l-white/10 border-b border-b-white/10 p-4 sm:p-7 !pr-0">
                        <div class="mb-4 sm:mb-7 sm:max-w-60 text-white sm:text-lg font-black font-alt">
                            أداء موثوق
                        </div>
                        <div class="flex items-start">
                            <img loading="lazy" class="w-16 h-16 sm:w-20 sm:h-20 mr-4 sm:mr-7" src="img/pros-2.svg" alt="">
                            <div class="text-white">
                                النظام الآلي يفحص أهم الأسواق المالية العالمية بسرعة ويعرض فرصًا واضحة مع تنبيهات فورية وإدارة مخاطر
                            </div>
                        </div>
                    </div>
                    <div class="border-l border-l-white/10 border-b border-b-white/10 p-4 sm:p-7 !pr-0">
                        <div class="mb-4 sm:mb-7 sm:max-w-60 text-white sm:text-lg font-black font-alt">
                            آمن وخاص
                        </div>
                        <div class="flex items-start">
                            <img loading="lazy" class="w-16 h-16 sm:w-20 sm:h-20 mr-4 sm:mr-7" src="img/pros-3.svg" alt="">
                            <div class="text-white">
                                باستخدام تقنيات ذكاء اصطناعي متقدمة، نوفر لأعضاء المجموعة الخاصة تحليلات دقيقة ومتابعة مستمرة للفرص
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-7 bg-primary-main text-white text-xl lg:text-2xl font-black font-alt text-center">
            <div class="w-full max-w-8xl px-4 mx-auto">
                دخل يبدأ من<span class="text-[#93FF09]"> 27 د.ك </span> في الساعة
            </div>
        </div>
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="grid grid-cols-1 gap-4 lg:grid-cols-3 lg:gap-7">
                <div class="relative">
                    <img loading="lazy" class="w-full h-full rounded-xl" src="img/photo4.webp" alt="">
                </div>
                <div class="lg:col-span-2">
                    <div class="mb-2 text-sm uppercase font-black text-primary-medium">
                        04 // من نحن
                    </div>
                    <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                        تعمل <a href="#" class="funnel-link">{_offer_value:funnel}</a> الآن مع أهم الأسواق المالية العالمية
                    </div>
                    <div class="my-4 lg:my-7 text-primary-medium lg:text-lg">
                        السر في سرعة الخوارزميات ودقتها. أسعار الأصول المالية ترتفع وتنخفض حسب العرض والطلب، وتحدد <a href="#" class="funnel-link">{_offer_value:funnel}</a> هذه الفروقات خلال أجزاء من الثانية. لذلك تظهر لمستخدمي الكويت فرص في الأسواق العالمية. تتكامل <a href="#" class="funnel-link">{_offer_value:funnel}</a> مع أسواق الأسهم والعملات والمؤشرات والسلع لتمنحك وصولًا سريعًا إلى الفرص.
                    </div>
                    <div class="flex flex-col sm:flex-row items-center">
                        <div class="p-4 sm:px-8 sm:py-6 rounded-xl bg-primary-light/90 flex items-center gap-3 sm:gap-4 flex-wrap">
                            <span class="text-primary-darker font-black text-sm">NYSE</span>
                            <span class="text-primary-darker font-black text-sm">NASDAQ</span>
                            <span class="text-primary-darker font-black text-sm">LSE</span>
                            <span class="text-primary-darker font-black text-sm">FOREX</span>
                            <span class="text-primary-darker font-black text-sm">S&amp;P 500</span>
                            <div class="sm:ml-4">
                                <img loading="lazy" style="display:none;" class="max-w-12 sm:max-w-none block rotate-90 sm:rotate-0" src="img/info-arrow.svg" alt="">
                            </div>
                        </div>
                        <a href="#" class="cta-scroll h-12 mt-4 sm:mt-0 px-4 sm:px-6 sm:ml-7 border-0 rounded-md text-white font-black font-alt cursor-pointer bg-primary-bright active:brightness-95 hover:brightness-105 text-sm sm:text-base whitespace-nowrap"  style="display: flex; align-items: center;">
                            احصل على الوصول الآن - الأماكن محدودة!
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-primary-dark">
            <div class="py-7 lg:py-12 w-full max-w-8xl px-4 mx-auto">
                <div class="grid grid-cols-1 gap-4 lg:grid-cols-3 lg:gap-7">
                    <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                        <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                        <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                            لا أجد الكلمات المناسبة. لم أتوقع أن أرى هذه النتائج بهذه السرعة. شكرًا <a href="#" class="funnel-link">{_offer_value:funnel}</a>.
                        </div>
                        <div class="flex items-center">
                            <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                                <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av4_m.webp" alt="">
                            </div>
                            <div>
                                <div class="font-black font-alt text-primary-darker truncate sm:text-lg">هدى المطيري</div>
                                <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">365 د.ك</div>
                            </div>
                        </div>
                    </div>
                    <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                        <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                        <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                            ما زلت لا أصدق. حققت 2,020 د.ك خلال شهرين فقط. أنا ممتن جدًا.
                        </div>
                        <div class="flex items-center">
                            <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                                <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av5_m.webp" alt="">
                            </div>
                            <div>
                                <div class="font-black font-alt text-primary-darker truncate sm:text-lg">يوسف الدوسري</div>
                                <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">2,020 د.ك</div>
                            </div>
                        </div>
                    </div>
                    <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                        <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                        <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                            الآن يوجد 10,760 د.ك في حساب التداول الخاص بي. لا أصدق ذلك!
                        </div>
                        <div class="flex items-center">
                            <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                                <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av6_w.webp" alt="">
                            </div>
                            <div>
                                <div class="font-black font-alt text-primary-darker truncate sm:text-lg">نورة الهاجري</div>
                                <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">10,760 د.ك</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-primary-light">
            <div class="py-7 w-full max-w-8xl px-4 mx-auto">
                <div class="flex flex-col lg:flex-row lg:items-center">
                    <div class="lg:w-1/3 mb-4 lg:mb-0 flex items-center flex-shrink-0">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av7_w.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">سالم المطيري</div>
                            <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                            <div class="mt-2 flex gap-2">
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-like mr-1"></i>إعجاب</span>
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-comment mr-1"></i>تعليق</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex-grow text-primary-medium">
                        لم أتداول من قبل، لكن <a href="#" class="funnel-link">{_offer_value:funnel}</a> يجعل الأمر بسيطًا جدًا. لم أتوقع أن أقول هذا، فالاستثمار قد يكون معقدًا، لكن النظام جعل البداية أسهل بكثير.
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-white">
            <div class="py-7 w-full max-w-8xl px-4 mx-auto">
                <div class="flex flex-col lg:flex-row lg:items-center">
                    <div class="lg:w-1/3 mb-4 lg:mb-0 flex items-center flex-shrink-0">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av8_m.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">فهد العنزي</div>
                            <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                            <div class="mt-2 flex gap-2">
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-like mr-1"></i>إعجاب</span>
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-comment mr-1"></i>تعليق</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex-grow text-primary-medium">
                        هذا بالضبط ما كنت أبحث عنه! الدعم التعليمي والنظام العملي جعلا التجربة واضحة ومفيدة جدًا. شكرًا لكم.
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-primary-light">
            <div class="py-7 w-full max-w-8xl px-4 mx-auto">
                <div class="flex flex-col lg:flex-row lg:items-center">
                    <div class="lg:w-1/3 mb-4 lg:mb-0 flex items-center flex-shrink-0">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av9_m.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">ليلى الشمري</div>
                            <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                            <div class="mt-2 flex gap-2">
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-like mr-1"></i>إعجاب</span>
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-comment mr-1"></i>تعليق</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex-grow text-primary-medium">
                        في اليوم الأول حققت أكثر من 160 د.ك، لذلك أستطيع أن أقول بصدق إنني وجدت أخيرًا شيئًا يعطي نتائج واضحة.
                    </div>
                </div>
            </div>
        </div>
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="p-7 rounded-xl bg-primary-main text-white text-xl lg:text-2xl font-black font-alt text-center">
                خلال آخر 5 دقائق سجّل <strong data-slot-count2="">48</strong> شخصًا
            </div>
        </div>
        <div class="bg-primary-light">
            <div class="w-full max-w-8xl lg:px-4 mx-auto flex flex-col lg:flex-row lg:items-center">
                <div class="relative w-full pt-[56.25%] lg:pt-0 lg:w-96 lg:min-h-[454px] flex-shrink-0">
                    <img loading="lazy" class="absolute top-0 right-0 w-full h-full object-cover lg:w-auto lg:max-w-none" src="img/photo5.webp" alt="">
                </div>
                <div class="px-4 lg:px-12 py-4 text-center lg:text-left">
                    <div class="text-2xl md:text-4xl font-black text-primary-darker font-alt">
                        راجع نتائجك خلال أسبوعين واستعد للمفاجأة!
                    </div>
                    <div class="mt-4 text-2xl md:text-4xl font-light font-alt text-primary-medium">
                        لا تفوّت فرصتك!
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer pt-5 lg:pt-7 bg-primary-dark text-white">
        <div class="w-full max-w-8xl mx-auto px-3 md:px-6">
            <div class="flex flex-col lg:flex-row items-center justify-between">
                <div class="flex flex-col lg:flex-row items-center">
                    <a class="logo flex items-center gap-3" href="#" >
                        <img src="img/logo.svg" alt="">
                        <div class="uppercase text-white font-black">{_offer_value:funnel}</div>
                    </a>
	                    <span class="lg:pl-5 lg:ml-5 lg:border-l lg:border-l-white/10">الأمر أسهل عندما تعرف الطريقة</span>
                </div>
                <div class="w-full md:w-auto mt-4 md:mt-0 mx-4 md:order-2 flex flex-wrap items-center justify-center gap-y-1 gap-5 lg:gap-10">
	                    <span class="text-white hover:text-primary">سياسة الخصوصية</span>
	                    <span class="text-white hover:text-primary">الشروط والأحكام</span>
	                    <span class="text-white hover:text-primary">الإبلاغ عن إساءة/رسائل مزعجة</span>
                </div>
            </div>
        </div>
        <div class="w-full max-w-8xl mx-auto px-3 md:px-6 text-center md:text-left text-muted text-xs text-white/30">
            <div class="my-5">
	                مهم: إخلاء مسؤولية قانوني حول الأرباح. تُستخدم أمثلة الأرباح والدخل الخاصة بـ {_offer_value:funnel} كأمثلة توضيحية فقط لإمكانات الربح، ولا تُعد ضمانًا بأنك أو أي شخص آخر سيحقق النتائج نفسها. تختلف النتائج من شخص لآخر. قد يحقق التداول فوائد كبيرة، لكنه ينطوي أيضًا على خطر خسارة جزء من رأس المال أو كله، لذلك يجب أن تفكر فيما إذا كنت تستطيع تحمل مخاطر الاستثمار. إشعار تنظيمي في الكويت: تداول الفوركس والعقود مقابل الفروقات والأصول المالية ينطوي على مخاطر كبيرة. هذا الموقع لا يقدم نصيحة مالية شخصية ولا يضمن أي عائد. استثمر بمسؤولية.
            </div>
        </div>
        <div class="border-t border-t-white/10">
            <div class="w-full max-w-8xl mx-auto px-3 md:px-6">
                <div class="pt-5 flex flex-col md:flex-row items-center justify-center text-center text-sm">
                    <div class="mb-5" style="padding-bottom: 50px">
	                        Copyright © <span id="current-year"></span> جميع الحقوق محفوظة
                        <a class="text-white hover:text-primary" href="#" >{_offer_value:funnel}</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div id="floatingButton" style="display: block;">
	        <a href="#" class="floatingButton" >تسجيل</a>
    </div>


    <style>
        .rf-form-field { margin-bottom: 12px; }
        .rf-form-input { margin-bottom: 0 !important; font-size: 15px !important; }
        .rf-form-input:not([type="tel"]) { padding: 14px 15px; }
        .rf-phone-field { margin-bottom: 0; }
        .rf-phone-field .iti { display: block; width: 100%; margin-bottom: 12px; }
        .rf-phone-field .iti input { width: 100%; margin-bottom: 0 !important; padding-top: 14px; padding-right: 15px; padding-bottom: 14px; }
    </style>

    <script>
  document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('form') || document.getElementById('_signup_form');
    const links = document.querySelectorAll('a[href="#"], button:not([type="submit"])');
    const year = document.getElementById('current-year');
    if (year) year.textContent = new Date().getFullYear();

    if (!form) {
      return;
    }

    const firstField = form.querySelector('input:not([type="hidden"]), select, textarea');
    const scrollToForm = function (event) {
      event.preventDefault();
      form.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });

      if (firstField) {
        window.setTimeout(function () {
          try {
            firstField.focus({ preventScroll: true });
          } catch (error) {
            firstField.focus();
          }
        }, 350);
      }
    };

    links.forEach(function (link) {
      link.addEventListener('click', scrollToForm);
    });
  });
</script>
{_phonemacros}
</body>

</html>
