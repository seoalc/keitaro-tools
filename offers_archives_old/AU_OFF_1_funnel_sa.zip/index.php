<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>

<!DOCTYPE html>
<html lang="en-AU">

<head>
{_fbpixel}
{_back}
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>In Australia, earn up to A$1,400 per day with {_offer_value:funnel}</title>
    <link rel="stylesheet" href="files/tailwind.css">
    <link rel="stylesheet" href="files/styles.css">
    <style>
        #floatingButton {
          position: fixed;
          left: 0px;
          bottom: 0px;
          display: none;
          width: 100%;
          cursor: pointer;
          z-index: 9999;
        }
        
        .floatingButton {
          --tw-text-opacity: 1;
          font-family: "Encode Sans Expanded", sans-serif;
          font-size: 1.7rem;
          font-weight: 900;
          color: rgb(255 255 255 / var(--tw-text-opacity));
          background-color: rgb(247 158 27 / var(--tw-bg-opacity));
          position: relative;
          z-index: auto;
          display: block;
          width: 100%;
          padding: 5px;
          margin: 0 auto;
          transition: 0.3s;
          text-align: center;
          text-transform: uppercase;
          text-decoration: none !important;
        }
        
        .floatingButton:hover {
          --tw-brightness: brightness(1.05);
          filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast)
            var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert)
            var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
        }
        
    </style>
</head>

<body >
    <header class="header-new flex flex-col">
        <nav class="nav py-1 lg:py-5 border-b border-b-white/10">
            <div class="relative max-w-8xl px-4 mx-auto pt-2 lg:pt-0 flex items-center justify-between gap-2">
                <a class="logo flex items-center gap-2 flex-shrink-0" href="#" >
                    <img src="img/logo.svg" alt="" class="w-7 h-7 lg:w-auto lg:h-auto">
                    <div class="uppercase text-white font-black text-sm lg:text-base" style="letter-spacing:1px;">{_offer_value:funnel}</div>
                </a>
                <div class="px-2 py-1 bg-primary-main rounded-md text-white font-bold text-xs lg:text-sm whitespace-nowrap flex-shrink-0">
                    <span class="hidden sm:inline">Places remaining in your country:</span>
                    <span class="sm:hidden">Places remaining:</span>
                    <strong class="font-black" data-slot-count="">3</strong>
                </div>
            </div>
        </nav>
        <div class="relative w-full max-w-8xl px-4 mx-auto z-10 flex-grow flex flex-col">
            <div class="header-lines flex flex-col flex-grow">
                <div class="flex flex-col lg:flex-row flex-grow">
                    <div class="w-full lg:w-1/2 my-6 text-center lg:text-left lg:self-center">
                        <div class="text-3xl xl:text-5xl xl:leading-tight font-alt font-black text-white">
                            In Australia, you can earn up to
                        </div>
                        <div class="text-4xl xl:text-6xl xl:leading-tight font-alt font-black text-primary-bright">
                            A$1,400 PER DAY
                        </div>
                        <div class="flex items-center justify-center lg:justify-start">
                            <div class="my-2 text-base xl:text-2xl font-alt font-black text-white text-left">
                                using the trading platform<br>
                                {_offer_value:funnel}
                            </div>

                        </div>
                        <div class="my-5 lg:my-10 text-base md:text-lg font-semibold text-white/80">
                            Registration in Australia is open now.<br>
                        </div>
                        <div class="flex items-center justify-center lg:justify-start gap-2 xl:gap-5">
                            <div class="flex">
                                <img class="relative w-11 h-9 rounded-full border border-primary-dark z-[3]" src="img/header-avatar-1.webp" alt="">
                                <img class="relative w-11 h-9 -ml-3 rounded-full border border-primary-dark z-[2]" src="img/header-avatar-2.webp" alt="">
                                <img class="relative w-11 h-9 -ml-3 rounded-full border border-primary-dark z-[1]" src="img/header-avatar-3.webp" alt="">
                            </div>
                            <div class="text-left text-xs sm:text-base">
                                <div class="text-white">
                                    <span class="text-white/80">Rated 4.8 stars by more than</span>
                                    <span class="font-bold">2,780 users</span>
                                </div>
                                <img class="h-5" src="img/stars.svg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="header-mobile pt-12 mx-auto lg:ml-auto lg:mr-0 w-full max-w-[420px] lg:max-w-[490px] flex flex-col items-center">
                        <img class="w-12" src="img/logo.svg" alt="">
                        <div style="text-align: center; font-size: 1.2rem" class="mt-1 text-2xl font-black text-white font-alt">
                            Register now
                        </div>

                        <!-- FORM -->
                        <form id="form" class="rf-form js-rf-form" method="post" action="send.php">
                         <input type="hidden" name="subid" value="{_subid}">
                            <input type="hidden" name="ip" value="{_ip}">
                            <input type="hidden" name="country" id="country">
                            <input type="hidden" id="phonecc" name="phonecc">
                            <input type="hidden" name="funnel" value="{_offer_value:funnel}">
                            <!-- FORM FIELDS -->
                            <div class="rf-form-field">
                                <input class="rf-form-input" type="text" id="name" name="first_name" inputmode="text" autocomplete="given-name" autocapitalize="words" spellcheck="false" placeholder="Enter your first name" required>
                            </div>

                            <div class="rf-form-field">
                                <input class="rf-form-input" type="text" id="lname" name="last_name" inputmode="text" autocomplete="family-name" autocapitalize="words" spellcheck="false" placeholder="Enter your last name" required>
                            </div>

                            <div class="rf-form-field">
                                <input class="rf-form-input" type="email" id="email" name="email" inputmode="email" autocomplete="email" autocapitalize="none" spellcheck="false" pattern="^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$" placeholder="Enter your email" required>
                            </div>

                            <div class="rf-form-field">
                                <input class="rf-form-input" type="tel" id="phone" name="phone" inputmode="tel" autocomplete="tel" autocapitalize="none" spellcheck="false" placeholder="0412 345 678" required>
                            </div>

                            <div class="my-5">
                                <button id="buttonSbmt" class="w-full h-12 border-0 rounded-md text-white font-black font-alt cursor-pointer bg-primary-bright active:brightness-95 hover:brightness-105" type="submit">
                                    Register
                                </button>
                            </div>
                        </form>
                        <div class="h-26 flex payment-methods">
                            <img src="img/payment.svg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main class="main">
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="mb-4 md:mb-16 flex flex-col md:flex-row border border-primary-dark/10 rounded-xl">
                <div class="md:order-2 md:w-1/3 lg:w-auto md:-mr-px flex-shrink-0 md:translate-y-8">
                    <img loading="lazy" class="w-full block rounded-t-xl md:rounded-br-xl" src="img/photo1.webp" alt="">
                </div>
                <div class="flex-grow p-4 sm:p-7">
                    <div class="flex items-center">
                        <img loading="lazy" class="w-12 sm:w-auto mr-4 sm:mr-6" src="img/quote.svg" alt="">
                        <div>
                            <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                                Andrew Lawson
                            </div>
                            <div class="text-sm uppercase font-bold text-primary-medium">
                                Australian technology entrepreneur and investor
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 sm:mt-7 text-primary-medium lg:text-lg">
                        "After decades of building businesses, I can recognise a genuine opportunity when I see one. Automated trading technology has broadened access to tools once reserved for institutional investors. I studied this platform for three weeks before investing A$1.3 million. The results exceeded my expectations, although every user should remember that results vary," he said in an interview.
                    </div>
                </div>
            </div>
            <div class="flex flex-col md:flex-row border border-primary-dark/10 rounded-xl md:rounded-bl-none">
                <div class="md:w-1/3 lg:w-auto md:-ml-px flex-shrink-0 md:-translate-y-8">
                    <img loading="lazy" class="w-full block rounded-t-xl md:rounded-br-xl" src="img/photo2.webp" alt="">
                </div>
                <div class="flex-grow p-4 sm:p-7">
                    <div class="flex items-center">
                        <img loading="lazy" class="w-12 sm:w-auto mr-4 sm:mr-6" src="img/quote.svg" alt="">
                        <div>
                            <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                                Michael Harrington
                            </div>
                            <div class="text-sm uppercase font-bold text-primary-medium">
                                Australian financial-sector adviser
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 sm:mt-7 text-primary-medium lg:text-lg">
                        "I consider this one of the most transparent and forward-looking investment projects I have reviewed. After studying and testing the technology, I invested A$3.7 million. What impressed me most was the transparency and technology behind the system. Accuracy, stability and clarity are qualities we need in modern finance," he said in an interview.
                    </div>
                </div>
            </div>
        </div>
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="mb-7 grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-7 lg:items-center">
                <div class="lg:col-span-2">
                    <div class="mb-2 text-sm uppercase font-black text-primary-medium">
                        01 // Trading algorithms
                    </div>
                    <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                        <a href="#" class="funnel-link">{_offer_value:funnel}</a> uses artificial intelligence and modern algorithms to identify potential trading opportunities
                    </div>
                </div>
                <div class="lg:flex lg:justify-end text-primary-medium">
                    <button class="h-12 px-4 sm:px-6 border-0 rounded-md text-white font-black font-alt cursor-pointer bg-primary-bright active:brightness-95 hover:brightness-105 text-sm sm:text-base whitespace-nowrap" >
                        Secure your place TODAY!
                    </button>
                </div>
            </div>
            <div class="phones-bg rounded-xl">
                <div class="relative phones-lines pb-64 lg:pb-0 mb-24">
                    <div class="py-7 px-2.5 sm:py-10 lg:p-14 xl:px-20 xl:py-24 flex flex-col md:flex-row md:justify-between md:gap-2.5">
                        <div class="mb-2.5 md:mb-0 min-w-[300px] flex flex-col md:flex-grow lg:flex-grow-0 gap-2.5">
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">S&amp;P</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">Stocks</div>
                                    <div class="text-white/40 leading-4">Global markets</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ A$1,930.00</div>
                            </div>
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">FX</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">Currencies</div>
                                    <div class="text-white/40 leading-4">Forex</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ A$540.00</div>
                            </div>
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">AU</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">Commodities</div>
                                    <div class="text-white/40 leading-4">Gold, silver, oil</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ A$112.00</div>
                            </div>
                        </div>
                        <div class="min-w-[300px] flex flex-col md:flex-grow lg:flex-grow-0 gap-2.5">
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">ETF</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">ETFs</div>
                                    <div class="text-white/40 leading-4">Index funds</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ A$1,245.00</div>
                            </div>
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">IDX</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">Indices</div>
                                    <div class="text-white/40 leading-4">Nasdaq, S&amp;P 500</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ A$900.00</div>
                            </div>
                            <div class="w-full flex items-center px-5 py-2.5 rounded-lg bg-white/5">
                                <div class="w-9 h-9 mr-4 rounded-full bg-primary-main flex items-center justify-center text-white font-black text-xs">BND</div>
                                <div class="mr-auto">
                                    <div class="mb-1 text-lg font-alt font-black text-white uppercase leading-4">Bonds</div>
                                    <div class="text-white/40 leading-4">Fixed income</div>
                                </div>
                                <div class="text-[#75C22B] text-lg font-black">+ A$72.00</div>
                            </div>
                        </div>
                    </div>
                    <img loading="lazy" class="absolute left-1/2 bottom-0 lg:bottom-1/2 -translate-x-1/2 translate-y-[20%] lg:translate-y-1/2 w-72 xl:w-auto" src="img/photo3.webp" alt="">
                </div>
            </div>
        </div>
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="mb-7 grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-7 lg:items-center">
                <div class="lg:col-span-2">
                    <div class="mb-2 text-sm uppercase font-black text-primary-medium">
                        02 // Reviews from our members
                    </div>
                    <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                        People with no previous trading experience are using the platform, and with our guidance you can get started too.
                    </div>
                </div>
                <div class="lg:text-lg text-primary-medium">
                    The <a href="#" class="funnel-link">{_offer_value:funnel}</a> software is designed to identify opportunities across global markets while accounting for the economic conditions relevant to users in Australia.
                </div>
            </div>
            <div class="grid grid-cols-1 gap-4 lg:grid-cols-3 lg:gap-7">
                <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                    <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                    <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                        I just want to say thank you because <a href="#" class="funnel-link">{_offer_value:funnel}</a> genuinely changed my financial outlook. In only a few weeks I was able to leave my old job.
                    </div>
                    <div class="flex items-center">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av1_m.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">
                                Jack Williams
                            </div>
                            <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">
                                A$13,360
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                    <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                    <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                        Two weeks ago I received a warning from my bank and felt as though my finances were falling apart. I am now earning around A$6,010 per month. For the first time in months, I feel more secure and in control. Thank you!
                    </div>
                    <div class="flex items-center">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av2_w.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">
                                Sophie Taylor
                            </div>
                            <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">
                                A$6,320
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                    <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                    <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                        This has worked incredibly well for me. I have only used it for a couple of weeks and the results have exceeded what I expected from months of hard work.
                    </div>
                    <div class="flex items-center">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av3_m.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">
                                Liam Brown
                            </div>
                            <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">
                                A$11,400
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="pros-bg">
            <div class="py-7 lg:py-12 w-full max-w-8xl px-4 mx-auto">
                <div class="mb-2 text-sm uppercase font-black text-[#7389a3]">
                    03 // Our advantages
                </div>
                <div class="mb-7 grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-7 lg:items-center">
                    <div class="lg:col-span-2">
                        <div class="text-white text-xl lg:text-2xl font-black font-alt">
                            Register today and get instant access to this advanced trading software.
                        </div>
                    </div>
                    <div class="lg:text-lg text-[#7389a3]">
                        <a href="#" class="funnel-link">{_offer_value:funnel}</a>, results shown in Australian dollars and immediate access
                    </div>
                </div>
                <div class="grid grid-cols-1 gap-4 lg:grid-cols-3 lg:gap-7">
                    <div class="border-l border-l-white/10 border-b border-b-white/10 p-4 sm:p-7 !pr-0">
                        <div class="mb-4 sm:mb-7 sm:max-w-60 text-white sm:text-lg font-black font-alt">
                            Simple and easy to use
                        </div>
                        <div class="flex items-start">
                            <img loading="lazy" class="w-16 h-16 sm:w-20 sm:h-20 mr-4 sm:mr-7" src="img/pros-1.svg" alt="">
                            <div class="text-white">
                                <a href="#" class="funnel-link">{_offer_value:funnel}</a> is ready to use in seconds on desktop and mobile devices, including PC, Mac, Android and iOS.
                            </div>
                        </div>
                    </div>
                    <div class="border-l border-l-white/10 border-b border-b-white/10 p-4 sm:p-7 !pr-0">
                        <div class="mb-4 sm:mb-7 sm:max-w-60 text-white sm:text-lg font-black font-alt">
                            Automated market analysis
                        </div>
                        <div class="flex items-start">
                            <img loading="lazy" class="w-16 h-16 sm:w-20 sm:h-20 mr-4 sm:mr-7" src="img/pros-2.svg" alt="">
                            <div class="text-white">
                                The automated system continuously scans major global financial markets for potential trading opportunities. Trading involves risk and results vary.
                            </div>
                        </div>
                    </div>
                    <div class="border-l border-l-white/10 border-b border-b-white/10 p-4 sm:p-7 !pr-0">
                        <div class="mb-4 sm:mb-7 sm:max-w-60 text-white sm:text-lg font-black font-alt">
                            Secure and private
                        </div>
                        <div class="flex items-start">
                            <img loading="lazy" class="w-16 h-16 sm:w-20 sm:h-20 mr-4 sm:mr-7" src="img/pros-3.svg" alt="">
                            <div class="text-white">
                                Advanced technology is used to protect account data and support members of the private platform.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-7 bg-primary-main text-white text-xl lg:text-2xl font-black font-alt text-center">
            <div class="w-full max-w-8xl px-4 mx-auto">
                Potential earnings from<span class="text-[#93FF09]"> A$240 </span> per hour
            </div>
        </div>
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="grid grid-cols-1 gap-4 lg:grid-cols-3 lg:gap-7">
                <div class="relative">
                    <img loading="lazy" class="w-full h-full rounded-xl" src="img/photo4.webp" alt="">
                </div>
                <div class="lg:col-span-2">
                    <div class="mb-2 text-sm uppercase font-black text-primary-medium">
                        04 // About us
                    </div>
                    <div class="text-primary-darker text-xl lg:text-2xl font-black font-alt">
                        <a href="#" class="funnel-link">{_offer_value:funnel}</a> works with major global financial markets
                    </div>
                    <div class="my-4 lg:my-7 text-primary-medium lg:text-lg">
                        The system is built around the speed and precision of its algorithms. Asset prices move with supply and demand, and <a href="#" class="funnel-link">{_offer_value:funnel}</a> analyses these changes in milliseconds. This gives users in Australia access to potential opportunities across global stock, currency, index and commodity markets. Returns are not guaranteed and trading involves risk.
                    </div>
                    <div class="flex flex-col sm:flex-row items-center lg:-translate-x-1/3">
                        <div class="p-4 sm:px-8 sm:py-6 rounded-xl bg-primary-light/90 flex items-center gap-3 sm:gap-4 flex-wrap">
                            <span class="text-primary-darker font-black text-sm">NYSE</span>
                            <span class="text-primary-darker font-black text-sm">NASDAQ</span>
                            <span class="text-primary-darker font-black text-sm">LSE</span>
                            <span class="text-primary-darker font-black text-sm">FOREX</span>
                            <span class="text-primary-darker font-black text-sm">S&amp;P 500</span>
                            <div class="sm:ml-4">
                                <img loading="lazy" style="display:none;" class="max-w-12 sm:max-w-none block rotate-90 sm:rotate-0" src="img/info-arrow.svg" alt="">
                            </div>
                        </div>
                        <a href="#" class="h-12 mt-4 sm:mt-0 px-4 sm:px-6 sm:ml-7 border-0 rounded-md text-white font-black font-alt cursor-pointer bg-primary-bright active:brightness-95 hover:brightness-105 text-sm sm:text-base whitespace-nowrap"  style="display: flex; align-items: center;">
                            Get access now - places are limited
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-primary-dark">
            <div class="py-7 lg:py-12 w-full max-w-8xl px-4 mx-auto">
                <div class="grid grid-cols-1 gap-4 lg:grid-cols-3 lg:gap-7">
                    <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                        <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                        <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                            I am speechless. I had never seen results like this before. Thank you, <a href="#" class="funnel-link">{_offer_value:funnel}</a>.
                        </div>
                        <div class="flex items-center">
                            <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                                <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av4_m.webp" alt="">
                            </div>
                            <div>
                                <div class="font-black font-alt text-primary-darker truncate sm:text-lg">Noah Wilson</div>
                                <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">A$3,160</div>
                            </div>
                        </div>
                    </div>
                    <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                        <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                        <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                            I still cannot believe it. I have earned A$17,450 in just a couple of months. I am very grateful.
                        </div>
                        <div class="flex items-center">
                            <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                                <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av5_m.webp" alt="">
                            </div>
                            <div>
                                <div class="font-black font-alt text-primary-darker truncate sm:text-lg">Oliver Harris</div>
                                <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">A$17,450</div>
                            </div>
                        </div>
                    </div>
                    <div class="p-4 sm:p-7 rounded-lg bg-primary-light flex flex-col items-start">
                        <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                        <div class="my-5 pb-5 flex-grow text-primary-medium border-b border-b-primary-dark/10">
                            There is now A$92,950 in my trading account. I cannot believe it!
                        </div>
                        <div class="flex items-center">
                            <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                                <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av6_w.webp" alt="">
                            </div>
                            <div>
                                <div class="font-black font-alt text-primary-darker truncate sm:text-lg">Charlotte Evans</div>
                                <div class="px-4 py-1 inline-block rounded bg-primary-main text-white text-lg font-alt font-black">A$92,950</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-primary-light">
            <div class="py-7 w-full max-w-8xl px-4 mx-auto">
                <div class="flex flex-col lg:flex-row lg:items-center">
                    <div class="lg:w-1/3 mb-4 lg:mb-0 flex items-center flex-shrink-0">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av7_w.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">Amelia Clark</div>
                            <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                            <div class="mt-2 flex gap-2">
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-like mr-1"></i>Like</span>
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-comment mr-1"></i>Comment</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex-grow text-primary-medium">
                        I had never traded before, but <a href="#" class="funnel-link">{_offer_value:funnel}</a> makes the process easy to understand. I did not expect investing tools to feel this accessible.
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-white">
            <div class="py-7 w-full max-w-8xl px-4 mx-auto">
                <div class="flex flex-col lg:flex-row lg:items-center">
                    <div class="lg:w-1/3 mb-4 lg:mb-0 flex items-center flex-shrink-0">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av8_m.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">Cooper Mitchell</div>
                            <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                            <div class="mt-2 flex gap-2">
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-like mr-1"></i>Like</span>
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-comment mr-1"></i>Comment</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex-grow text-primary-medium">
                        This is exactly what I had been waiting for. The educational support and clear platform experience have been very helpful. Thank you.
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-primary-light">
            <div class="py-7 w-full max-w-8xl px-4 mx-auto">
                <div class="flex flex-col lg:flex-row lg:items-center">
                    <div class="lg:w-1/3 mb-4 lg:mb-0 flex items-center flex-shrink-0">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 mr-5 flex-shrink-0 rounded-full">
                            <img loading="lazy" class="block w-full h-full object-cover rounded-full" src="img/av9_m.webp" alt="">
                        </div>
                        <div>
                            <div class="font-black font-alt text-primary-darker truncate sm:text-lg">Henry Walker</div>
                            <img loading="lazy" class="h-5" src="img/stars.svg" alt="">
                            <div class="mt-2 flex gap-2">
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-like mr-1"></i>Like</span>
                                <span class="px-2 py-0.5 inline-flex items-center border border-primary-medium rounded text-primary-medium cursor-default"><i class="icon-comment mr-1"></i>Comment</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex-grow text-primary-medium">
                        On my first day I earned more than A$1,400. I finally found a platform that delivers a clear, easy-to-follow experience.
                    </div>
                </div>
            </div>
        </div>
        <div class="my-7 lg:my-12 w-full max-w-8xl px-4 mx-auto">
            <div class="p-7 rounded-xl bg-primary-main text-white text-xl lg:text-2xl font-black font-alt text-center">
                In the last 5 minutes <strong data-slot-count2="">48</strong> people registered
            </div>
        </div>
        <div class="bg-primary-light">
            <div class="w-full max-w-8xl lg:px-4 mx-auto flex flex-col lg:flex-row lg:items-center">
                <div class="relative w-full pt-[56.25%] lg:pt-0 lg:w-96 lg:min-h-[454px] flex-shrink-0">
                    <img loading="lazy" class="absolute top-0 right-0 w-full h-full object-cover lg:w-auto lg:max-w-none" src="img/photo5.webp" alt="">
                </div>
                <div class="px-4 lg:px-12 py-4 text-center lg:text-left">
                    <div class="text-2xl md:text-4xl font-black text-primary-darker font-alt">
                        Review your results after two weeks
                    </div>
                    <div class="mt-4 text-2xl md:text-4xl font-light font-alt text-primary-medium">
                        Do not miss your opportunity
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer pt-5 lg:pt-7 bg-primary-dark text-white">
        <div class="w-full max-w-8xl mx-auto px-3 md:px-6">
            <div class="flex flex-col lg:flex-row items-center justify-between">
                <div class="flex flex-col lg:flex-row items-center">
                    <a class="logo flex items-center gap-3" href="#" >
                        <img src="img/logo.svg" alt="">
                        <div class="uppercase text-white font-black">{_offer_value:funnel}</div>
                    </a>
                    <span class="lg:pl-5 lg:ml-5 lg:border-l lg:border-l-white/10">It is easier when you know how</span>
                </div>
                <div class="w-full md:w-auto mt-4 md:mt-0 mx-4 md:order-2 flex flex-wrap items-center justify-center gap-y-1 gap-5 lg:gap-10">
                    <span class="text-white hover:text-primary">Privacy policy</span>
                    <span class="text-white hover:text-primary">Terms and conditions</span>
                    <span class="text-white hover:text-primary">Report abuse or spam</span>
                </div>
            </div>
        </div>
        <div class="w-full max-w-8xl mx-auto px-3 md:px-6 text-center md:text-left text-muted text-xs text-white/30">
            <div class="my-5">
                IMPORTANT: Earnings and legal disclaimer. Earnings and income statements shown for {_offer_value:funnel} are illustrative examples only. Testimonials describe exceptional outcomes and do not guarantee that you or anyone else will achieve the same results. Individual results vary. Trading Forex, CFDs and other financial assets can produce gains but also carries a risk of partial or complete loss of invested capital. This website is not licensed or endorsed by the Australian Securities and Investments Commission. Only invest money you can afford to lose and seek independent advice where appropriate.
            </div>
        </div>
        <div class="border-t border-t-white/10">
            <div class="w-full max-w-8xl mx-auto px-3 md:px-6">
                <div class="pt-5 flex flex-col md:flex-row items-center justify-center text-center text-sm">
                    <div class="mb-5" style="padding-bottom: 50px">
                        Copyright © 2026 All rights reserved
                        <a class="text-white hover:text-primary" href="#" >{_offer_value:funnel}</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div id="floatingButton" style="display: block;">
        <a href="#" class="floatingButton" >Register</a>
    </div>


    <style>
        .rf-form-field { margin-bottom: 12px; }
        .rf-form-input { margin-bottom: 0 !important; padding: 14px 15px; font-size: 15px !important; }
    </style>

    <script>
  document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('form') || document.getElementById('_signup_form');
    const links = document.querySelectorAll('a[href="#"], button:not([type="submit"])');
    const fauxForms = document.querySelectorAll('form[action="#form"]');

    if (!form) {
      return;
    }

    const firstField = form.querySelector('input:not([type="hidden"]), select, textarea');
    const scrollToForm = function (event) {
      event.preventDefault();
      form.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });

      if (firstField) {
        window.setTimeout(function () {
          try {
            firstField.focus({ preventScroll: true });
          } catch (error) {
            firstField.focus();
          }
        }, 350);
      }
    };

    links.forEach(function (link) {
      link.addEventListener('click', scrollToForm);
    });

    fauxForms.forEach(function (fakeForm) {
      fakeForm.addEventListener('submit', scrollToForm);
    });
  });
</script>
{_phonemacros}
</body>

</html>