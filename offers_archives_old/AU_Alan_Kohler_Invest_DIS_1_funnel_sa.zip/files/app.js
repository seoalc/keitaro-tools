(function () {
  "use strict";

  var menu = document.getElementById("menu");
  var overlay = document.getElementById("menuoverlay");

  function setMenu(open) {
    if (!menu) return;
    menu.style.display = open ? "block" : "none";
    menu.classList.toggle("show", open);
    menu.setAttribute("aria-hidden", open ? "false" : "true");
    if (overlay) overlay.classList.toggle("show", open);
    document.body.classList.toggle("modal-open", open);
  }

  document.querySelectorAll(".menu_icon").forEach(function (trigger) {
    trigger.setAttribute("data-ui", "");
    trigger.addEventListener("click", function (event) {
      event.preventDefault();
      setMenu(!(menu && menu.classList.contains("show")));
    });
  });

  document.addEventListener("click", function (event) {
    if (event.target.closest("#vertical-bar .cross, #vertical-bar .menu-close")) {
      event.preventDefault();
      setMenu(false);
      return;
    }
    if (event.target === menu || event.target === overlay) {
      event.preventDefault();
      setMenu(false);
      return;
    }
    if (event.target.closest("#menu a")) {
      setMenu(false);
    }
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") setMenu(false);
  });

  document.querySelectorAll("[data-current-year]").forEach(function (node) {
    var year = String(new Date().getFullYear());
    if (/\b(19|20)\d{2}\b/.test(node.textContent)) {
      node.textContent = node.textContent.replace(/\b(19|20)\d{2}\b/, year);
    } else {
      node.textContent = year;
    }
  });

  document.querySelectorAll("[data-article-date]").forEach(function (node) {
    var storageKey = "articleDate:" + location.pathname;
    var savedDate = "";

    try {
      savedDate = localStorage.getItem(storageKey) || "";
      if (!savedDate) {
        var firstDate = new Date();
        firstDate.setDate(firstDate.getDate() - 1);
        savedDate = firstDate.toISOString();
        localStorage.setItem(storageKey, savedDate);
      }
    } catch (error) {
      var fallbackDate = new Date();
      fallbackDate.setDate(fallbackDate.getDate() - 1);
      savedDate = fallbackDate.toISOString();
    }

    var date = new Date(savedDate);
    var time = node.getAttribute("data-time") || "2:54 pm AEST";
    var formatted = date.toLocaleDateString("en-AU", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });

    node.textContent = "Updated: " + formatted + " at " + time;
  });

  document.querySelectorAll('a[href="#"]:not([data-ui])').forEach(function (link) {
    link.addEventListener("click", function (event) {
      var inMenu = event.currentTarget.closest("#menu");
      if (inMenu) return;
      event.preventDefault();
      var form = document.querySelector("#form");
      if (form) {
        form.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });
})();
