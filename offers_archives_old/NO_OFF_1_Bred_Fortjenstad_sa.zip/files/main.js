(function () {
  'use strict';

  /* Smooth scroll to the form for every in-page CTA (href="#") */
  document.querySelectorAll('a[href="#"]').forEach(function (link) {
    link.addEventListener('click', function (event) {
      event.preventDefault();
      var target = document.querySelector('#form');
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* Footer year - always current, computed client-side, never fixed */
  var yearEl = document.getElementById('footerYear');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  /* "Spots remaining" counter before the form - real 2h cycle, persisted per visitor */
  (function spotsCounter() {
    var el = document.getElementById('timer');
    if (!el) return;
    var KEY = 'spotsCounterEnd';
    var DURATION = 2 * 60 * 60 * 1000;
    var START = 28;
    var FLOOR = 3;

    var end = parseInt(localStorage.getItem(KEY), 10);
    if (!end || isNaN(end) || end <= Date.now()) {
      end = Date.now() + DURATION;
      try { localStorage.setItem(KEY, String(end)); } catch (e) {}
    }

    function update() {
      var remaining = end - Date.now();
      if (remaining <= 0) {
        end = Date.now() + DURATION;
        try { localStorage.setItem(KEY, String(end)); } catch (e) {}
        remaining = DURATION;
      }
      var progress = 1 - remaining / DURATION;
      var value = Math.round(START - (START - FLOOR) * progress);
      el.textContent = value;
    }

    update();
    setInterval(update, 30000);
  })();

  /* Income calculator */
  (function calculator() {
    var btn = document.getElementById('calculatorBtn');
    var input = document.getElementById('calculatorInput');
    var result = document.getElementById('calculatorResult');
    if (!btn || !input || !result) return;

    btn.addEventListener('click', function () {
      var raw = (input.value || '').replace(/\s/g, '').replace(',', '.');
      var val = parseFloat(raw);
      if (!val || val <= 0) val = 1000;
      var income = Math.round(val * 0.46);
      result.textContent = income.toLocaleString('en-IE');
    });
  })();

  /* Reviews slider - init after all deferred scripts (incl. Swiper) have run */
  document.addEventListener('DOMContentLoaded', function () {
    if (window.Swiper) {
      new Swiper('.reviews-slider', {
        slidesPerView: 'auto',
        spaceBetween: 20,
        autoHeight: true,
        loop: true,
        navigation: {
          nextEl: '.reviews-slider__control-next',
          prevEl: '.reviews-slider__control-prev'
        }
      });
    }
  });
})();
