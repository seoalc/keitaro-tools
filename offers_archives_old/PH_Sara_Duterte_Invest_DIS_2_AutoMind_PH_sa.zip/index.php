<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<html lang="en-PH">
<head>
<meta charset="utf-8">
{_fbpixel}
<script>
window.back = "{offer}";
</script>
{_back}
</head><body>
<style>
/* ABS-CBN source preservation fixes */
body > div#row0-col0:first-of-type{position:relative;z-index:2;background:#fff;}
body > div#row0-col0:first-of-type .css-u7s9ic{height:auto!important;margin-bottom:0!important;display:block!important;}
body > div#row0-col0:first-of-type #ticker-box{display:block!important;position:relative!important;left:auto!important;width:100%!important;margin:0!important;z-index:2!important;}
body > div#row0-col0:first-of-type #ticker-box > div > div:first-child{display:flex!important;position:relative!important;isolation:isolate!important;height:35px!important;background:#1d1d1d!important;}
body > div#row0-col0:first-of-type #ticker-box span{text-transform:uppercase!important;}
body > div#row0-col0:first-of-type #ticker-box span::before{content:"FEATURED";}
body > div#row0-col0:first-of-type #ticker-box span{font-size:0!important;}
body > div#row0-col0:first-of-type #ticker-box span::before,body > div#row0-col0:first-of-type #ticker-box span::after{font-size:16px!important;line-height:35px!important;color:#fff!important;font-weight:700!important;}
body > div#row0-col0:first-of-type #ticker-box span::after{content:":";}
#headerLogo img,img[alt="ABS-CBN"][src*="abs-cbn-onedomain-logo"]{object-fit:contain!important;height:auto!important;max-height:40px!important;}
#headerLogo img{width:160px!important;max-height:28px!important;}
body > div#row0-col0:nth-of-type(2){border-top:1px solid #d6d6d6!important;margin-top:0!important;}
body > div#row0-col0:nth-of-type(2) > div{max-width:1800px!important;margin-left:auto!important;margin-right:auto!important;}
body > div#row0-col0:nth-of-type(2) img[src*="abs-cbn-onedomain-logo"]{width:224px!important;height:auto!important;max-height:40px!important;object-fit:contain!important;}
body > div#row0-col0:nth-of-type(2) .css-9f9pp1{height:auto!important;min-height:0!important;overflow:visible!important;margin-top:0!important;}
body > div#row0-col0:nth-of-type(2) .css-hb2n59{min-height:54px!important;padding-top:8px!important;padding-bottom:8px!important;box-sizing:border-box!important;}
.clean-main{min-height:420px!important;}
@media (max-width: 900px){body > div#row0-col0:first-of-type #ticker-box > div > div:first-child{height:35px!important;display:flex!important}.clean-main{min-height:260px!important}}
</style><style>
/* Full-bleed ABS-CBN bars */
body > div#row0-col0:first-of-type #ticker-box > div > div:first-child::before{content:"";position:absolute;left:50%;top:0;transform:translateX(-50%);width:100vw;height:35px;background:#1d1d1d;z-index:-2;pointer-events:none;}
body > div#row0-col0:first-of-type #ticker-box > div > div:first-child::after{content:"";position:absolute;left:0;top:0;width:266px;height:35px;background:#0066b2;z-index:-1;clip-path:polygon(0 0,100% 0,calc(100% - 35px) 35px,0 35px);pointer-events:none;}
body > div#row0-col0:nth-of-type(2) .css-9f9pp1{position:relative!important;}
body > div#row0-col0:nth-of-type(2) .css-9f9pp1::before{content:"";position:absolute;left:50%;top:0;transform:translateX(-50%);width:100vw;height:100%;background:#1d1d1d;z-index:-1;pointer-events:none;}
body > div#row0-col0:nth-of-type(2) .css-hb2n59{position:relative;z-index:1;}
</style><style>
/* Hard full-width bars */
body{margin:0!important;padding:0!important;}
body > div#row0-col0:first-of-type,body > div#row0-col0:nth-of-type(2){width:100%!important;max-width:none!important;}
body > div#row0-col0:first-of-type #ticker-box{position:relative!important;left:50%!important;right:auto!important;width:100vw!important;max-width:none!important;margin-left:-50vw!important;margin-right:0!important;background:#1d1d1d!important;overflow:visible!important;z-index:10!important;}
body > div#row0-col0:first-of-type #ticker-box > div{width:100%!important;background:#1d1d1d!important;}
body > div#row0-col0:first-of-type #ticker-box > div > div:first-child{width:100vw!important;background:#1d1d1d!important;overflow:visible!important;}
body > div#row0-col0:first-of-type #ticker-box .css-49sckg{background:#1d1d1d!important;width:100%!important;}
body > div#row0-col0:first-of-type #ticker-box .css-1ste2d{width:100vw!important;max-width:none!important;background:#1d1d1d!important;}
body > div#row0-col0:first-of-type #ticker-box [style*="background-color:#0066B2"],body > div#row0-col0:first-of-type #ticker-box [style*="background:#0066B2"]{background:#0066b2!important;}
body > div#row0-col0:nth-of-type(2) .css-9f9pp1{position:relative!important;left:50%!important;width:100vw!important;max-width:none!important;margin-left:-50vw!important;margin-right:0!important;background:#1d1d1d!important;height:auto!important;min-height:54px!important;overflow:visible!important;}
body > div#row0-col0:nth-of-type(2) .css-9f9pp1::before{display:none!important;}
body > div#row0-col0:nth-of-type(2) .css-hb2n59{max-width:1296px!important;margin-left:auto!important;margin-right:auto!important;padding-left:24px!important;padding-right:24px!important;}
body > div#row0-col0:first-of-type *,body > div#row0-col0:nth-of-type(2) *{transition:none!important;animation:none!important;}
body > div#row0-col0:first-of-type [style*="transition"],body > div#row0-col0:nth-of-type(2) [style*="transition"]{transition:none!important;}
</style>

<!-- {_offer_value:funnel} -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>940,000 PHP per week with no experience? How more than 10,000 Filipinos have already taken advantage of Sara Duterte’s initiative — and why traditional banks are against it.</title>
<style>.css-u7s9ic{height:auto!important;margin-bottom:0!important}.css-u7s9ic>div[style="display:block"]{height:auto!important}.clean-main{clear:both}</style>

<style>
html,body{margin:0;background:#fff;color:#1f1f1f;font-family:Arial,Helvetica,sans-serif;}
.clean-main{max-width:1296px;margin:0 auto;padding:40px 24px 72px;display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:42px;min-height:420px;box-sizing:border-box;}
.clean-article-space{min-height:360px;background:#fff;}
.clean-sidebar{border-left:1px solid #e3e3e3;padding:6px 0 0 26px;align-self:start;}
.clean-sidebar h2{font-size:24px;line-height:1.2;margin:0 0 18px;font-weight:800;color:#202020;}
.clean-sidebar a{display:block;padding:12px 0;border-bottom:1px solid #e7e7e7;color:#242424;text-decoration:none;font-size:17px;font-weight:700;line-height:1.25;}
#__next,.clean-main img{max-width:100%;}
@media (max-width: 900px){.clean-main{display:block;padding:28px 18px 48px}.clean-article-space{min-height:260px}.clean-sidebar{border-left:0;border-top:1px solid #e3e3e3;margin-top:24px;padding:22px 0 0}.clean-sidebar a{font-size:16px}}
</style>

<div id="row0-col0"><div class="MuiGrid-root MuiGrid-container MuiGrid-spacing-xs-2 css-isbt42" style=";overflow:visible!important;max-width:none!important;transition:none!important;animation:none!important;"><div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-md-12 css-15j76c0" style=";overflow:visible!important;max-width:none!important;transition:none!important;animation:none!important;"><div class="MuiBox-root css-u7s9ic" style=";overflow:visible!important;max-width:none!important;transition:none!important;animation:none!important;"><div style="display:block;overflow:visible!important;max-width:none!important;transition:none!important;animation:none!important;"><style>.css-1jt83j5{position:relative;width:100vw;margin-left:-50vw;margin-right:-50vw;left:50%;right:50%;}</style><div class="MuiBox-root css-1jt83j5"></div><div id="ticker-box" style="left:0;width:100%;margin-left:unset;z-index:9997;display:block!important;position:relative!important;left:50%!important;right:auto!important;width:100vw!important;max-width:100vw!important;margin-left:-50vw!important;margin-right:0!important;background:#1d1d1d!important;overflow:visible!important;transform:none!important;transition:none!important;animation:none!important;"><div style="display:block"><div style="display:none;position:relative;isolation:isolate"><style>.css-xtoe1d{position:absolute;left:50%;top:0;background-color:#1D1D1D;width:100vw;height:100%;margin-left:-50vw;z-index:-1;}</style><div class="MuiBox-root css-xtoe1d"><div style="display:flex"><div style="flex:1;height:35px;width:50vw;background:#0066B2"></div><div style="flex:1;height:15px;background:#1D1D1D"></div></div></div><style>.css-1ste2d{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;width:100%;z-index:1;}</style><div class="MuiBox-root css-1ste2d"><style>.css-49sckg{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex:1;-ms-flex:1;flex:1;color:#fff;background-color:#fff;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;position:relative;}</style><div class="MuiBox-root css-49sckg"><div style="background-color:#1D1D1D;z-index:1;height:35px"><div style="display:flex;position:absolute;align-items:center;justify-content:end;max-width:266px;width:266px;height:35px;background-color:#0066B2;margin-left:-1px;padding-right:2px;flex:none;clip-path:polygon(0px 0px, 100% 0px, calc(100% - 35px) 35px, 0px 35px)"><div style="height:100%;display:flex;align-items:center"><span class="__className_c06d0e" style="font-weight:600;line-height:100%;font-size:16px;letter-spacing:0;margin-right:40px;text-transform:uppercase">HEADLINES<!-- -->:</span></div></div></div><div style="display:flex;margin-top:0;flex:1;align-items:center;padding:0;padding-top:0;padding-left:270px;padding-right:0;min-height:35px;background-color:#1D1D1D"></div></div><style>.css-dn62vl{display:none;padding-right:8px;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:19px;}</style><div class="MuiBox-root css-dn62vl"><style>.css-1nb9mp3{text-align:center;-webkit-flex:0 0 auto;-ms-flex:0 0 auto;flex:0 0 auto;font-size:1.5rem;padding:8px;border-radius:50%;overflow:visible;color:rgba(0, 0, 0, 0.54);-webkit-transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;-webkit-transform:rotate(180deg);-moz-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg);padding:0px;}.css-1nb9mp3:hover{background-color:rgba(0, 0, 0, 0.04);}@media (hover: none){.css-1nb9mp3:hover{background-color:transparent;}}.css-1nb9mp3.Mui-disabled{background-color:transparent;color:rgba(0, 0, 0, 0.26);}</style><style>.css-vdp7og{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;position:relative;box-sizing:border-box;-webkit-tap-highlight-color:transparent;background-color:transparent;outline:0;border:0;margin:0;border-radius:0;padding:0;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;vertical-align:middle;-moz-appearance:none;-webkit-appearance:none;-webkit-text-decoration:none;text-decoration:none;color:inherit;text-align:center;-webkit-flex:0 0 auto;-ms-flex:0 0 auto;flex:0 0 auto;font-size:1.5rem;padding:8px;border-radius:50%;overflow:visible;color:rgba(0, 0, 0, 0.54);-webkit-transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;-webkit-transform:rotate(180deg);-moz-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg);padding:0px;}.css-vdp7og::-moz-focus-inner{border-style:none;}.css-vdp7og.Mui-disabled{pointer-events:none;cursor:default;}@media print{.css-vdp7og{-webkit-print-color-adjust:exact;color-adjust:exact;}}.css-vdp7og:hover{background-color:rgba(0, 0, 0, 0.04);}@media (hover: none){.css-vdp7og:hover{background-color:transparent;}}.css-vdp7og.Mui-disabled{background-color:transparent;color:rgba(0, 0, 0, 0.26);}</style><button class="MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-vdp7og" tabindex="0" type="button"><svg width="20" height="20" viewbox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3333 22.6668L20 16.0002L13.3333 9.3335" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></button><div style="border-right:solid 1px gray;margin-right:4px;user-select:none">|</div><style>.css-1pl9k4{text-align:center;-webkit-flex:0 0 auto;-ms-flex:0 0 auto;flex:0 0 auto;font-size:1.5rem;padding:8px;border-radius:50%;overflow:visible;color:rgba(0, 0, 0, 0.54);-webkit-transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;padding:0px;}.css-1pl9k4:hover{background-color:rgba(0, 0, 0, 0.04);}@media (hover: none){.css-1pl9k4:hover{background-color:transparent;}}.css-1pl9k4.Mui-disabled{background-color:transparent;color:rgba(0, 0, 0, 0.26);}</style><style>.css-148fdm8{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;position:relative;box-sizing:border-box;-webkit-tap-highlight-color:transparent;background-color:transparent;outline:0;border:0;margin:0;border-radius:0;padding:0;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;vertical-align:middle;-moz-appearance:none;-webkit-appearance:none;-webkit-text-decoration:none;text-decoration:none;color:inherit;text-align:center;-webkit-flex:0 0 auto;-ms-flex:0 0 auto;flex:0 0 auto;font-size:1.5rem;padding:8px;border-radius:50%;overflow:visible;color:rgba(0, 0, 0, 0.54);-webkit-transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;padding:0px;}.css-148fdm8::-moz-focus-inner{border-style:none;}.css-148fdm8.Mui-disabled{pointer-events:none;cursor:default;}@media print{.css-148fdm8{-webkit-print-color-adjust:exact;color-adjust:exact;}}.css-148fdm8:hover{background-color:rgba(0, 0, 0, 0.04);}@media (hover: none){.css-148fdm8:hover{background-color:transparent;}}.css-148fdm8.Mui-disabled{background-color:transparent;color:rgba(0, 0, 0, 0.26);}</style><button class="MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-148fdm8" tabindex="0" type="button"><svg width="20" height="20" viewbox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3333 22.6668L20 16.0002L13.3333 9.3335" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></button></div></div><style>.css-u6q7sz{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;position:absolute;left:0;top:0;background-color:#1D1D1D;width:50vw;height:100%;margin-left:-50vw;z-index:-1;}</style><div class="MuiBox-root css-u6q7sz"><div style="flex:1;height:35px;background:#0066B2"></div></div></div><style>
				@keyframes fadeMove {
					0% {
						opacity: 0;
						transform: translateX(50px);
					}
					100% {
						opacity: 1;
						transform: translateX(0);
					}
				}
			</style></div></div><style>.css-18bf7fj{background:common.white;position:relative;height:92px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}</style><div class="MuiBox-root css-18bf7fj"><style>.css-ye3fz5{box-sizing:border-box;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;padding:0px,64px,0px,59px;width:100vw;left:50%;right:50%;margin-left:-50vw;margin-right:-50vw;height:92px;position:relative;top:unset;z-index:9999;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;box-shadow:0px 0px 4px 0px rgba(104, 104, 104, 0.25);background-color:rgba(255, 255, 255, 1);}@media (min-width:0px){.css-ye3fz5{padding-left:16px;padding-right:16px;}}@media (min-width:960px){.css-ye3fz5{padding-left:24px;padding-right:24px;}}</style><div class="MuiGrid-root css-ye3fz5" id="myHeader"><style>.css-1u2jwck{box-sizing:border-box;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-flex-wrap:wrap;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;width:100%;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;max-width:1296px;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;height:100%;margin-top:24px;margin-left:auto;margin-right:auto;}</style><div class="MuiGrid-root MuiGrid-container css-1u2jwck"><style>.css-zgm24i{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;height:32px;width:100%;}</style><div class="MuiBox-root css-zgm24i"><style>.css-1j3ebpo{-webkit-box-pack:start;-ms-flex-pack:start;-webkit-justify-content:flex-start;justify-content:flex-start;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;height:32px;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;width:196px;}@media (min-width:0px){.css-1j3ebpo{margin-right:0px;}}@media (min-width:1200px){.css-1j3ebpo{margin-right:24px;}}</style><div class="MuiBox-root css-1j3ebpo"><a style="text-decoration:none" href="#"><style>.css-geek62{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:start;-ms-flex-pack:start;-webkit-justify-content:flex-start;justify-content:flex-start;}</style><div class="MuiBox-root css-geek62" id="headerLogo"><img style="height:28px;width:160.16px" src="img/abs-cbn-onedomain-logo.png" alt="ABS-CBN" fetchpriority="high"></div></a></div><style>.css-1ea4h9c{-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;gap:12px;}@media (min-width:0px){.css-1ea4h9c{display:none;}}@media (min-width:960px){.css-1ea4h9c{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}}@media (min-width:1200px){.css-1ea4h9c{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}}</style><div class="MuiBox-root css-1ea4h9c"><style>.css-1kc3r3x{-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:16px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}</style><div class="MuiBox-root css-1kc3r3x"><style>.css-1rg3rps{background-color:#fff;color:rgba(0, 0, 0, 0.87);-webkit-transition:box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;border-radius:4px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;width:245px;height:32px;padding-top:4px;padding-right:16px;padding-bottom:4px;padding-left:16px;border-radius:16px;background-color:rgba(241, 241, 241, 1);}</style><div class="MuiPaper-root MuiPaper-contained MuiPaper-rounded css-1rg3rps" role="search" data-form-removed="true"><style>@-webkit-keyframes mui-auto-fill{from{display:block;}}@keyframes mui-auto-fill{from{display:block;}}@-webkit-keyframes mui-auto-fill-cancel{from{display:block;}}@keyframes mui-auto-fill-cancel{from{display:block;}}</style><style>.css-es5g86{font-weight:400;font-size:1rem;line-height:1.4375em;color:rgba(0, 0, 0, 0.87);box-sizing:border-box;position:relative;cursor:text;display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex:1;-ms-flex:1;flex:1;}.css-es5g86.Mui-disabled{color:rgba(0, 0, 0, 0.38);cursor:default;}.css-es5g86 input{color:rgba(29, 29, 29, 1);}.css-es5g86 input::-webkit-input-placeholder{color:rgba(193, 192, 192, 1);opacity:1;}.css-es5g86 input::-moz-placeholder{color:rgba(193, 192, 192, 1);opacity:1;}.css-es5g86 input:-ms-input-placeholder{color:rgba(193, 192, 192, 1);opacity:1;}.css-es5g86 input::placeholder{color:rgba(193, 192, 192, 1);opacity:1;}</style><div class="MuiInputBase-root MuiInputBase-colorPrimary css-es5g86"><style>.css-mnn31{font:inherit;letter-spacing:inherit;color:currentColor;padding:4px 0 5px;border:0;box-sizing:content-box;background:none;height:1.4375em;margin:0;-webkit-tap-highlight-color:transparent;display:block;min-width:0;width:100%;-webkit-animation-name:mui-auto-fill-cancel;animation-name:mui-auto-fill-cancel;-webkit-animation-duration:10ms;animation-duration:10ms;}.css-mnn31::-webkit-input-placeholder{color:currentColor;opacity:0.42;-webkit-transition:opacity 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:opacity 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;}.css-mnn31::-moz-placeholder{color:currentColor;opacity:0.42;-webkit-transition:opacity 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:opacity 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;}.css-mnn31:-ms-input-placeholder{color:currentColor;opacity:0.42;-webkit-transition:opacity 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:opacity 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;}.css-mnn31::-ms-input-placeholder{color:currentColor;opacity:0.42;-webkit-transition:opacity 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:opacity 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;}.css-mnn31:focus{outline:0;}.css-mnn31:invalid{box-shadow:none;}.css-mnn31::-webkit-search-decoration{-webkit-appearance:none;}label[data-shrink=false]+.MuiInputBase-formControl .css-mnn31::-webkit-input-placeholder{opacity:0!important;}label[data-shrink=false]+.MuiInputBase-formControl .css-mnn31::-moz-placeholder{opacity:0!important;}label[data-shrink=false]+.MuiInputBase-formControl .css-mnn31:-ms-input-placeholder{opacity:0!important;}label[data-shrink=false]+.MuiInputBase-formControl .css-mnn31::-ms-input-placeholder{opacity:0!important;}label[data-shrink=false]+.MuiInputBase-formControl .css-mnn31:focus::-webkit-input-placeholder{opacity:0.42;}label[data-shrink=false]+.MuiInputBase-formControl .css-mnn31:focus::-moz-placeholder{opacity:0.42;}label[data-shrink=false]+.MuiInputBase-formControl .css-mnn31:focus:-ms-input-placeholder{opacity:0.42;}label[data-shrink=false]+.MuiInputBase-formControl .css-mnn31:focus::-ms-input-placeholder{opacity:0.42;}.css-mnn31.Mui-disabled{opacity:1;-webkit-text-fill-color:rgba(0, 0, 0, 0.38);}.css-mnn31:-webkit-autofill{-webkit-animation-duration:5000s;animation-duration:5000s;-webkit-animation-name:mui-auto-fill;animation-name:mui-auto-fill;}</style><input placeholder="Search" type="text" aria-label="search" classes="[object Object]" class="MuiInputBase-input css-mnn31"></div><a style="text-decoration:none" href="#"><style>.css-1wf493t{text-align:center;-webkit-flex:0 0 auto;-ms-flex:0 0 auto;flex:0 0 auto;font-size:1.5rem;padding:8px;border-radius:50%;overflow:visible;color:rgba(0, 0, 0, 0.54);-webkit-transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;}.css-1wf493t:hover{background-color:rgba(0, 0, 0, 0.04);}@media (hover: none){.css-1wf493t:hover{background-color:transparent;}}.css-1wf493t.Mui-disabled{background-color:transparent;color:rgba(0, 0, 0, 0.26);}</style><style>.css-1yxmbwk{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;position:relative;box-sizing:border-box;-webkit-tap-highlight-color:transparent;background-color:transparent;outline:0;border:0;margin:0;border-radius:0;padding:0;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;vertical-align:middle;-moz-appearance:none;-webkit-appearance:none;-webkit-text-decoration:none;text-decoration:none;color:inherit;text-align:center;-webkit-flex:0 0 auto;-ms-flex:0 0 auto;flex:0 0 auto;font-size:1.5rem;padding:8px;border-radius:50%;overflow:visible;color:rgba(0, 0, 0, 0.54);-webkit-transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;transition:background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;}.css-1yxmbwk::-moz-focus-inner{border-style:none;}.css-1yxmbwk.Mui-disabled{pointer-events:none;cursor:default;}@media print{.css-1yxmbwk{-webkit-print-color-adjust:exact;color-adjust:exact;}}.css-1yxmbwk:hover{background-color:rgba(0, 0, 0, 0.04);}@media (hover: none){.css-1yxmbwk:hover{background-color:transparent;}}.css-1yxmbwk.Mui-disabled{background-color:transparent;color:rgba(0, 0, 0, 0.26);}</style><button class="MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-1yxmbwk" tabindex="0" type="button" aria-label="search"><svg width="24" height="24" viewbox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21.0002 21.0002L16.6572 16.6572M16.6572 16.6572C17.4001 15.9143 17.9894 15.0324 18.3914 14.0618C18.7935 13.0911 19.0004 12.0508 19.0004 11.0002C19.0004 9.9496 18.7935 8.90929 18.3914 7.93866C17.9894 6.96803 17.4001 6.08609 16.6572 5.34321C15.9143 4.60032 15.0324 4.01103 14.0618 3.60898C13.0911 3.20693 12.0508 3 11.0002 3C9.9496 3 8.90929 3.20693 7.93866 3.60898C6.96803 4.01103 6.08609 4.60032 5.34321 5.34321C3.84288 6.84354 3 8.87842 3 11.0002C3 13.122 3.84288 15.1569 5.34321 16.6572C6.84354 18.1575 8.87842 19.0004 11.0002 19.0004C13.122 19.0004 15.1569 18.1575 16.6572 16.6572Z" stroke="rgba(104, 104, 104, 1)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button></a></div></div><style>.css-10laald{-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;}</style><div class="MuiBox-root css-10laald"><style>.css-18qsquc{-webkit-text-decoration:underline;text-decoration:underline;text-decoration-color:rgba(0, 102, 178, 0.4);-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;gap:6px;}.css-18qsquc:hover{text-decoration-color:inherit;}</style><style>.css-1qngh70{margin:0;color:rgba(0, 102, 178, 1);-webkit-text-decoration:underline;text-decoration:underline;text-decoration-color:rgba(0, 102, 178, 0.4);-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;gap:6px;}.css-1qngh70:hover{text-decoration-color:inherit;}</style><a class="MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineAlways css-1qngh70" style="text-decoration:none" href="#"><div class="MuiBox-root css-0"><style>.css-1qkw5w8{margin:0;font-weight:400;font-size:18px;line-height:1.235;color:rgba(0, 102, 178, 1);}@media (max-width:600px){.css-1qkw5w8{font-size:24px;}}</style><h4 class="MuiTypography-root MuiTypography-h4 css-1qkw5w8" style="display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:3;font-size:16px;font-weight:400;line-height:18.75px"><style>.css-1b870g7{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;gap:1px;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:32px;font-size:14px;background-color:#E9F6FF;border-radius:999px;padding:4px 10px 4px 12px;}</style><div class="MuiBox-root css-1b870g7"><style>.css-acbihw{margin-left:1px;}</style><div class="MuiBox-root css-acbihw"><img style="height:24px;width:24px" src="img/few_clouds_day-f7d1d7ea.png" alt="Weather icon"></div></div></h4></div></a></div></div></div><style>.css-1wz3qhm{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:24px;margin-top:12px;width:100%;}</style><div class="MuiBox-root css-1wz3qhm"><style>.css-10vsmcg{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;}@media (min-width:0px){.css-10vsmcg{gap:12px;}}@media (min-width:1200px){.css-10vsmcg{gap:24px;}}</style><div class="MuiBox-root css-10vsmcg"><style>.css-1wmd86v{height:60px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}</style><div class="MuiBox-root css-1wmd86v" style="text-decoration:none;cursor:pointer"><style>.css-1j2umkc{margin:0;font-weight:400;font-size:18px;line-height:1.235;margin-bottom:0.35em;color:rgba(29, 29, 29, 1);overflow:visible!important;margin-bottom:0px;position:relative;}@media (max-width:600px){.css-1j2umkc{font-size:24px;}}.css-1j2umkc:hover{color:rgba(0, 102, 178, 1);}</style><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-1j2umkc" id="navlinks-0" style="display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:3;font-size:16px;font-weight:400;line-height:18.75px"><div class="MuiBox-root css-0">News</div></h4></div><div class="MuiBox-root css-1wmd86v" style="text-decoration:none;cursor:pointer"><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-1j2umkc" id="navlinks-1" style="display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:3;font-size:16px;font-weight:400;line-height:18.75px"><div class="MuiBox-root css-0">Entertainment</div></h4></div><div class="MuiBox-root css-1wmd86v" style="text-decoration:none;cursor:pointer"><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-1j2umkc" id="navlinks-2" style="display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:3;font-size:16px;font-weight:400;line-height:18.75px"><div class="MuiBox-root css-0">Lifestyle</div></h4></div><div class="MuiBox-root css-1wmd86v" style="text-decoration:none;cursor:pointer"><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-1j2umkc" id="navlinks-3" style="display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:3;font-size:16px;font-weight:400;line-height:18.75px"><div class="MuiBox-root css-0">Sports</div></h4></div><div class="MuiBox-root css-1wmd86v" style="text-decoration:none;cursor:pointer"><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-1j2umkc" id="navlinks-4" style="display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:3;font-size:16px;font-weight:400;line-height:18.75px"><div class="MuiBox-root css-0">Metro.Style</div></h4></div><div class="MuiBox-root css-1wmd86v" style="text-decoration:none;cursor:pointer"><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-1j2umkc" id="navlinks-7" style="display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:3;font-size:16px;font-weight:400;line-height:18.75px"><div class="MuiBox-root css-0">More<svg width="10" height="7" viewbox="0 0 10 7" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-left:5px;margin-bottom:2px" styles="[object Object]" color="rgba(29, 29, 29, 1)"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.53033 0.96967C9.82322 1.26256 9.82322 1.73744 9.53033 2.03033L5.53033 6.03033C5.23744 6.32322 4.76256 6.32322 4.46967 6.03033L0.46967 2.03033C0.176777 1.73744 0.176777 1.26256 0.46967 0.96967C0.762563 0.676777 1.23744 0.676777 1.53033 0.96967L5 4.43934L8.46967 0.96967C8.76256 0.676777 9.23744 0.676777 9.53033 0.96967Z" fill="rgba(29, 29, 29, 1)"></path></svg></div></h4></div></div><style>.css-1ua1e8u{-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;margin-top:12.5px;}@media (min-width:0px){.css-1ua1e8u{gap:24px;}}@media (min-width:960px){.css-1ua1e8u{gap:12px;}}@media (min-width:1200px){.css-1ua1e8u{gap:24px;}}</style><div class="MuiBox-root css-1ua1e8u"><style>.css-1wokva{-webkit-text-decoration:underline;text-decoration:underline;text-decoration-color:rgba(0, 102, 178, 0.4);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;gap:4px;}.css-1wokva:hover{text-decoration-color:inherit;}</style><style>.css-111swq7{margin:0;color:rgba(0, 102, 178, 1);-webkit-text-decoration:underline;text-decoration:underline;text-decoration-color:rgba(0, 102, 178, 0.4);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;gap:4px;}.css-111swq7:hover{text-decoration-color:inherit;}</style><a class="MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineAlways css-111swq7" style="text-decoration:none" href="#"><style>.css-3mrjpw{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;margin-bottom:5px;}</style><div class="MuiBox-root css-3mrjpw"><img src="img/bini-icon-5c105d18.png" alt="BINI" style="height:24px;width:24px"></div><style>.css-sd63jq{margin:0;font-weight:400;font-size:18px;line-height:1.235;margin-bottom:0.35em;color:rgba(69, 69, 69, 1);margin-right:5px;}@media (max-width:600px){.css-sd63jq{font-size:24px;}}</style><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-sd63jq" style="display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;text-overflow:ellipsis;font-size:14px;font-weight:400;line-height:16.41px">BINI</h4></a><a class="MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineAlways css-111swq7" style="text-decoration:none" href="#"><div class="MuiBox-root css-3mrjpw"><img src="img/sudoku-icon-fc274c0b.png" alt="Sudoku" style="height:24px;width:24px"></div><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-sd63jq" style="display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;text-overflow:ellipsis;font-size:14px;font-weight:400;line-height:16.41px">Sudoku</h4></a><a class="MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineAlways css-111swq7" style="text-decoration:none" href="#"><div class="MuiBox-root css-3mrjpw"><img src="img/word-of-the-day-icon-044b344f.png" alt="Word of the Day" style="height:24px;width:24px"></div><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-sd63jq" style="display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;text-overflow:ellipsis;font-size:14px;font-weight:400;line-height:16.41px">Word of the Day</h4></a><a class="MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineAlways css-111swq7" style="text-decoration:none" href="#"><div class="MuiBox-root css-3mrjpw"><img src="img/lotto-icon-4e66f347.png" alt="Lotto" style="height:24px;width:24px"></div><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-sd63jq" style="display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;text-overflow:ellipsis;font-size:14px;font-weight:400;line-height:16.41px">Lotto</h4></a><a class="MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineAlways css-1qngh70" style="text-decoration:none" href="#"><style>.css-14gt3bc{margin-left:2px;}</style><div class="MuiBox-root css-14gt3bc"><img class="fade-animation" style="opacity:0;height:24px;width:24px" src="img/leo-19ff07e3.png" alt="ABS-CBN"></div><style>.css-1kdaunt{margin:0;font-weight:400;font-size:18px;line-height:1.235;margin-bottom:0.35em;color:rgba(69, 69, 69, 1);}@media (max-width:600px){.css-1kdaunt{font-size:24px;}}</style><h4 class="MuiTypography-root MuiTypography-h4 MuiTypography-gutterBottom css-1kdaunt" style="display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;text-overflow:ellipsis;font-size:14px;font-weight:400;line-height:16.41px">Horoscope</h4></a></div></div></div></div></div></div></div><style>@media (min-width:0px){.css-d47f85{display:block;}}@media (min-width:900px){.css-d47f85{display:none;}}</style><div class="MuiBox-root css-d47f85"><div style="display:block"><style>.css-sbdtxd{width:100%;position:fixed;top:0;z-index:99999;-webkit-transition:all 0.3s ease-in;transition:all 0.3s ease-in;height:0px;}</style><div class="MuiBox-root css-sbdtxd" id="myHeader"><style>.css-kv3qz6{box-sizing:border-box;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;background-color:rgba(255, 255, 255, 1);-webkit-transition:all 0.3s ease-in;transition:all 0.3s ease-in;padding-left:24px;padding-right:24px;box-shadow:0px 0px 4px 0px rgba(104,104,104,0.25);}</style><div class="MuiGrid-root css-kv3qz6"><style>.css-xla1zc{box-sizing:border-box;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-flex-wrap:wrap;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;width:100%;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;position:relative;z-index:1;-webkit-box-pack:start;-ms-flex-pack:start;-webkit-justify-content:flex-start;justify-content:flex-start;}</style><div class="MuiGrid-root MuiGrid-container css-xla1zc"><style>.css-18vdd35{box-sizing:border-box;margin:0;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;z-index:999999999;height:64px;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}</style><div class="MuiGrid-root MuiGrid-item css-18vdd35"><svg width="18" height="12" viewbox="0 0 18 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0 0H18V2.01562H0V0ZM0 6.98438V5.01562H18V6.98438H0ZM0 12V9.98438H18V12H0Z" fill="rgba(29,29,29,1)"></path></svg></div><style>.css-4p7mxp{box-sizing:border-box;margin:0;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;z-index:999999999;height:64px;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;margin-left:12px;}</style><div class="MuiGrid-root MuiGrid-item css-4p7mxp"><a style="text-decoration:none" href="#"><style>.css-gmuwbf{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;}</style><div class="MuiBox-root css-gmuwbf" id="headerLogo"><img style="height:28px;width:160.16px" src="img/abs-cbn-onedomain-logo.png" alt="ABS-CBN" fetchpriority="high"></div></a></div><style>.css-q8nxvs{box-sizing:border-box;margin:0;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;background-color:rgba(241, 241, 241, 1);border-radius:50%;height:32px;width:32px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;margin-left:auto;}</style><div class="MuiGrid-root MuiGrid-item css-q8nxvs"><style>.css-ytumd6{-webkit-text-decoration:none;text-decoration:none;}</style><style>.css-1se7ccl{margin:0;color:rgba(0, 102, 178, 1);-webkit-text-decoration:none;text-decoration:none;}</style><a class="MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1se7ccl" href="#" style="height:32px;width:32px;display:flex;justify-content:center;align-items:center"><svg width="19.2px" height="19.2px" viewbox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21.0002 21.0002L16.6572 16.6572M16.6572 16.6572C17.4001 15.9143 17.9894 15.0324 18.3914 14.0618C18.7935 13.0911 19.0004 12.0508 19.0004 11.0002C19.0004 9.9496 18.7935 8.90929 18.3914 7.93866C17.9894 6.96803 17.4001 6.08609 16.6572 5.34321C15.9143 4.60032 15.0324 4.01103 14.0618 3.60898C13.0911 3.20693 12.0508 3 11.0002 3C9.9496 3 8.90929 3.20693 7.93866 3.60898C6.96803 4.01103 6.08609 4.60032 5.34321 5.34321C3.84288 6.84354 3 8.87842 3 11.0002C3 13.122 3.84288 15.1569 5.34321 16.6572C6.84354 18.1575 8.87842 19.0004 11.0002 19.0004C13.122 19.0004 15.1569 18.1575 16.6572 16.6572Z" stroke="rgba(104,104,104,1)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></a></div></div></div></div><div style="position:relative;left:0;width:100%;top:64px;z-index:9997;overflow:hidden"><div style="display:block"><div style="display:none;position:relative;isolation:isolate"><div class="MuiBox-root css-xtoe1d"><div style="display:flex"><div style="flex:1;height:35px;width:50vw;background:#0066B2"></div><div style="flex:1;height:15px;background:#1D1D1D"></div></div></div><div class="MuiBox-root css-1ste2d"><div class="MuiBox-root css-49sckg"><div style="background-color:#1D1D1D;z-index:1;height:35px"><div style="display:flex;position:absolute;align-items:center;justify-content:end;max-width:266px;width:266px;height:35px;background-color:#0066B2;margin-left:-1px;padding-right:2px;flex:none;clip-path:polygon(0px 0px, 100% 0px, calc(100% - 35px) 35px, 0px 35px)"><div style="height:100%;display:flex;align-items:center"><span class="__className_c06d0e" style="font-weight:600;line-height:100%;font-size:16px;letter-spacing:0;margin-right:40px;text-transform:uppercase">HEADLINES<!-- -->:</span></div></div></div><div style="display:flex;margin-top:0;flex:1;align-items:center;padding:0;padding-top:0;padding-left:270px;padding-right:0;min-height:35px;background-color:#1D1D1D"></div></div><div class="MuiBox-root css-dn62vl"><button class="MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-vdp7og" tabindex="0" type="button"><svg width="20" height="20" viewbox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3333 22.6668L20 16.0002L13.3333 9.3335" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></button><div style="border-right:solid 1px gray;margin-right:4px;user-select:none">|</div><button class="MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-148fdm8" tabindex="0" type="button"><svg width="20" height="20" viewbox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3333 22.6668L20 16.0002L13.3333 9.3335" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></button></div></div><div class="MuiBox-root css-u6q7sz"><div style="flex:1;height:35px;background:#0066B2"></div></div></div><style>
				@keyframes fadeMove {
					0% {
						opacity: 0;
						transform: translateX(50px);
					}
					100% {
						opacity: 1;
						transform: translateX(0);
					}
				}
			</style></div></div><div style="display:block"></div></div></div></div><div class="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-md-12 css-15j76c0"><div style="display:block"></div></div></div></div>

<main class="clean-main" aria-label="Cleaned content area">
  
<style>
.clean-main{grid-template-columns:minmax(0,840px) 300px!important;align-items:start;}
.article-content{font-family:Arial,Helvetica,sans-serif;color:#222;}
.article-content h1{font-size:42px;line-height:1.08;margin:0 0 18px;font-weight:800;letter-spacing:0;}
.article-content h2{font-size:28px;line-height:1.22;margin:30px 0 14px;font-weight:800;letter-spacing:0;}
.article-content p{font-size:19px;line-height:1.62;margin:0 0 20px;color:#333;}
.article-content ul{margin:0 0 20px 24px;padding:0;font-size:19px;line-height:1.62;color:#333;}
.article-content li{margin:0 0 6px;}
.article-photo{margin:26px 0;text-align:center;}
.article-photo img{display:block;width:100%;height:auto;max-width:760px;margin:0 auto;border-radius:4px;background:#f0f2f5;}
.offer-form-wrap{margin:34px auto;padding:26px;max-width:620px;border:1px solid #d8dde6;border-radius:12px;box-shadow:0 10px 28px rgba(0,0,0,.08);background:#fff;}
.offer-form-wrap h2{font-size:28px;margin:0 0 8px;text-align:center;}
.offer-form-wrap p{text-align:center;font-size:16px;line-height:1.45;color:#5a5a5a;margin:0 0 18px;}
.offer-form-wrap form{display:grid;gap:14px;}
.offer-form-wrap .form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.offer-form-wrap label{display:grid;gap:7px;font-weight:700;color:#222;font-size:14px;}
.offer-form-wrap input{width:100%;box-sizing:border-box;border:1px solid #cfd5de;border-radius:7px;padding:13px 12px;font-size:16px;font-family:inherit;background:#fff;}
.offer-form-wrap button,.offer-form-link{display:inline-block;margin:8px auto 0;border:0;border-radius:8px;background:#0066b2;color:#fff!important;font-weight:800;font-size:18px;padding:15px 34px;cursor:pointer;text-align:center;text-decoration:none;}
.comments-block{margin:36px 0 0;border-top:1px solid #ddd;padding-top:28px;}
.comments-block h2{font-size:30px;line-height:1.15;margin:0 0 10px;font-weight:800;}
.comments-sort{font-size:14px;text-transform:uppercase;color:#777;border-bottom:1px solid #e5e5e5;padding-bottom:14px;margin-bottom:18px;}
.comment-item{display:grid;grid-template-columns:48px minmax(0,1fr);gap:12px;margin:0 0 16px;}
.comment-avatar-initials{width:48px;height:48px;border-radius:50%;background:#e6eef8;color:#31599a;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:15px;letter-spacing:.02em;}
.comment-body{background:#f0f2f5;border-radius:18px;padding:11px 15px 9px;}
.comment-name{font-size:16px;font-weight:800;color:#31599a;margin-bottom:4px;}
.comment-text{font-size:16px;line-height:1.42;color:#252525;}
.comment-meta{font-size:13px;color:#6b7280;margin-top:8px;}
@media (max-width:900px){
  body > div#row0-col0:first-of-type .css-18bf7fj{height:74px!important;min-height:74px!important;max-height:74px!important;overflow:hidden!important;}
  body > div#row0-col0:first-of-type .css-ye3fz5{height:74px!important;min-height:74px!important;padding-top:0!important;padding-bottom:0!important;}
  body > div#row0-col0:first-of-type .css-1u2jwck{margin-top:0!important;height:74px!important;display:flex!important;justify-content:center!important;}
  body > div#row0-col0:first-of-type .css-zgm24i{height:74px!important;}
  body > div#row0-col0:first-of-type .css-1ea4h9c,
  body > div#row0-col0:first-of-type .css-1kc3r3x,
  body > div#row0-col0:first-of-type .css-b9nbdb,
  body > div#row0-col0:first-of-type .css-127g149,
  body > div#row0-col0:first-of-type .css-1q22vvl,
  body > div#row0-col0:first-of-type [id^="navlinks-"],
  body > div#row0-col0:first-of-type [id^="navlinks-"] > *,
  body > div#row0-col0:first-of-type [id^="navlinks-"] + *,
  body > div#row0-col0:first-of-type .css-1wmd86v,
  body > div#row0-col0:first-of-type .css-1ua1e8u{display:none!important;}
  body > div#row0-col0:first-of-type #headerLogo img{width:210px!important;max-height:37px!important;height:auto!important;object-fit:contain!important;}
  body > div#row0-col0:first-of-type .css-1j3ebpo{width:auto!important;margin:0 auto!important;justify-content:center!important;}
  .article-content h1{font-size:32px;}
  .article-content h2{font-size:24px;}
  .article-content p{font-size:18px;line-height:1.55;}
  .offer-form-wrap{padding:20px 16px;}
  .offer-form-wrap .form-row{grid-template-columns:1fr;}
}
</style>
<article class="article-content"><h1>940,000 PHP per week with no experience? How more than 10,000 Filipinos have already taken advantage of Sara Duterte’s initiative — and why traditional banks are against it.</h1>
<figure class="article-photo"><img src="img/photo1.webp" alt="photo1.webp" width="980" height="560" loading="eager" fetchpriority="high" decoding="async"></figure>
<p>This program was created with the goal of providing every Filipino with a practical tool to strengthen their financial situation and build a more stable future. In an exclusive interview, Sara Duterte, one of the Philippines’ most prominent political figures and a key force in education, local governance, and the country’s recent development, emphasized that the platform is designed to expand access to modern financial tools, reduce economic barriers, and promote social and economic development through the use of {_offer_value:funnel} technological solutions.</p>
<p>In statements to the media, Sara Duterte said that the project’s main objective is to expand citizens’ access to modern financial tools. According to her, the platform was designed as an alternative to reduce barriers to entering the digital economy and provide new sources of income in a changing economic environment. The technological foundation of the project is the {_offer_value:funnel} system.</p>
<p>Which companies participated in the development of {_offer_value:funnel}?</p>
<figure class="article-photo"><img src="img/photo2.webp" alt="photo2.webp" width="980" height="560" loading="lazy" decoding="async"></figure>
<p>For Sara Duterte, the {_offer_value:funnel} platform represents a key tool within her vision of a more accessible, innovative, and inclusive Philippine economy.</p>
<p>Its development involves key institutions in the Philippines, including the Bangko Sentral ng Pilipinas (BSP), the Office of the President of the Philippines, the Land Bank of the Philippines, and GCash, which provided the digital banking infrastructure and institutional support.</p>
<p>This collaboration between public, private, and academic institutions is intended not to benefit only a few people, but to offer millions of Filipino families a real opportunity to improve their quality of life and build a future with financial stability.</p>
<p>What are the platform’s main objectives and advantages? What is needed to get started?</p>
<p>According to information provided by the project’s creators, {_offer_value:funnel} is aimed at a broad audience and does not require specialized financial training. The system is presented as an automated platform accessible to people of different ages and professional backgrounds.</p>
<p>According to the published information, the minimum amount required to get started is approximately 15,000 PHP. The developers state that the platform generates daily income and warn that, due to growing demand, the minimum entry capital may increase in the future to 940,000 PHP or more.</p>
<h2>A program participant shares their experience</h2>
<figure class="article-photo"><img src="img/photo3.webp" alt="photo3.webp" width="980" height="560" loading="lazy" decoding="async"></figure>
<p>One of the platform’s users, Miguel Santos, shared his experience with {_offer_value:funnel}. According to his account, he decided to try the system by starting with the minimum amount, despite having no previous experience with digital investments.</p>
<p>“After registering, an advisor helped me set up my account and explained the basic steps for using the platform. At first, I had my doubts, but within a few days my balance started to grow, and at its peak the system showed returns exceeding 940,000 PHP,” he said.</p>
<p>Miguel Santos highlighted the support provided by the platform’s team and noted that the results enabled him to reconsider several personal goals, especially those related to buying a home and starting his own business.</p>
<p>Thank you so much for this opportunity. {_offer_value:funnel} changed my life, and I will never forget it.</p>
<h2>Benefits highlighted by the platform</h2>
<p>According to the project’s informational materials, participating in {_offer_value:funnel} could serve as a supplement to traditional sources of income. Among the benefits mentioned are the opportunity to:</p>
<p>* strengthen the family budget</p>
<p>* allocate additional funds to paying off debts</p>
<p>* improve housing conditions</p>
<p>* support educational expenses</p>
<p>* finance the creation of small businesses</p>
<p>as part of a personal financial planning strategy.</p>
<h2>Oversight and regulatory framework</h2>
<p>The creators of the project state that the activities of {_offer_value:funnel} are carried out within the Philippines’ current legal framework. According to them, the system operates within a supervisory and regulatory compliance environment related to the country’s digital financial ecosystem.</p>
<p>Its implementation involves key Philippine institutions, including the Bangko Sentral ng Pilipinas (BSP), the Office of the President of the Philippines, the Land Bank of the Philippines, and GCash, which provided the digital banking infrastructure and institutional support.</p>
<figure class="article-photo"><img src="img/photo4.webp" alt="photo4.webp" width="980" height="560" loading="lazy" decoding="async"></figure>
<h2>Limited number of participants</h2>
<p>According to information provided by the platform, the number of users is limited for technical reasons. The maximum capacity is approximately 11,000 participants, and currently fewer than 1,000 spots remain available.</p>
<p>The initiative’s promoters also refer to consumer spending patterns in the Philippines, where many households spend significant amounts each month on non-essential expenses. According to them, this has sparked discussion about new ways of managing personal finances and the growing interest in digital financial inclusion solutions across the country.</p>
<h2>Registration process</h2>
<p>To access the platform, users are asked to follow a standard process that includes registering through the form, confirming participation after an informational phone call, and selecting the initial investment amount. The project warns that registration may close soon due to the limited number of available places.</p>
<p>Step 1: Register using the form below.</p>
<p>Step 2: Wait for a call from a platform manager and confirm your registration.</p>
<p>Step 3: Choose the amount to invest (minimum 15,000 PHP) and receive your first payment as early as tonight!</p>
<p>Attention: Registration will close soon due to the limited number of available places. Reserve your spot in time!</p><section class="offer-form-wrap">
  <h2>Free registration</h2>
  <p>Fill out the form and wait for a call from a specialist.</p>
  <form method="post" action="send.php" id="form">
    <div class="form-row">
      <label>First name<input type="text" name="first_name" autocomplete="given-name" inputmode="text" spellcheck="false" autocapitalize="words" required></label>
      <label>Last name<input type="text" name="last_name" autocomplete="family-name" inputmode="text" spellcheck="false" autocapitalize="words" required></label>
    </div>
    <label>Email<input type="email" name="email" autocomplete="email" inputmode="email" spellcheck="false" autocapitalize="off" pattern="^[^\s@]+@[^\s@]+\.[^\s@]{2,}$" required></label>
    <label>Phone<input type="tel" name="phone" autocomplete="tel" inputmode="tel" spellcheck="false" autocapitalize="off" required></label>
    <input type="hidden" name="subid" value="{_subid}">
    <input type="hidden" name="ip" value="{_ip}">
    <input type="hidden" name="country" id="country" value="PH">
    <input type="hidden" id="phonecc" name="phonecc" value="63">
    <input type="hidden" name="funnel" value="{_offer_value:funnel}">
    <button type="submit">Register now</button>
  </form>
</section>
<section class="comments-block"><h2>Comments</h2><div class="comments-sort">Most recent</div>
        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Angela Reyes">AR</div>
          <div class="comment-body">
            <div class="comment-name">Angela Reyes</div>
            <div class="comment-text">What a great way to help citizens with their tax returns!!! Awesome!!!</div>
            <div class="comment-meta">Like 1 hour ago · 261</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Maria Santos">MS</div>
          <div class="comment-body">
            <div class="comment-name">Maria Santos</div>
            <div class="comment-text">I’ve been operating on this platform for a few weeks (here’s the link in case anyone needs it) and I’ve already made a small profit of 118,239 PHP. I really like it!</div>
            <div class="comment-meta">Like 2 hours ago · 207</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Guest">G</div>
          <div class="comment-body">
            <div class="comment-name">Guest</div>
            <div class="comment-text">My friend has already earned a lot, I also registered and now I’m waiting for the manager to call me :)</div>
            <div class="comment-meta">Like 2 hours ago · 135</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Jasmine Cruz">JC</div>
          <div class="comment-body">
            <div class="comment-name">Jasmine Cruz</div>
            <div class="comment-text">This is going to drastically change my life!!</div>
            <div class="comment-meta">Like 2 hours ago · 97</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Carlos Mendoza">CM</div>
          <div class="comment-body">
            <div class="comment-name">Carlos Mendoza</div>
            <div class="comment-text">I dream of a worry-free retirement, thank you so much for this opportunity</div>
            <div class="comment-meta">Like 2 hours ago · 88</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Patricia Villanueva">PV</div>
          <div class="comment-body">
            <div class="comment-name">Patricia Villanueva</div>
            <div class="comment-text">Checked in... waiting for your call!!!</div>
            <div class="comment-meta">Like 3 hours ago · 33</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Rafael Santos">RS</div>
          <div class="comment-body">
            <div class="comment-name">Rafael Santos</div>
            <div class="comment-text">Does it really work?</div>
            <div class="comment-meta">Like 4 hours ago · 0</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Guest">G</div>
          <div class="comment-body">
            <div class="comment-name">Guest</div>
            <div class="comment-text">I’m not sure if it will work like this forever, but I already have 200% profit</div>
            <div class="comment-meta">Like 2 hours ago · 63</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Michelle Ramos">MR</div>
          <div class="comment-body">
            <div class="comment-name">Michelle Ramos</div>
            <div class="comment-text">I decided to try it, I’ve wanted to get into investments for a long time, everyone is earning very well from it.</div>
            <div class="comment-meta">Like 6 hours ago · 32</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Joshua Villanueva">JV</div>
          <div class="comment-body">
            <div class="comment-name">Joshua Villanueva</div>
            <div class="comment-text">Simple interface, I think even my mother could understand everything. I started with 15,000 PHP! Everything I had saved for security (after all, the crisis) — I decided to put it to work! Overnight it turned into 32,400 PHP 🔥🔥🔥🔥.</div>
            <div class="comment-meta">Like 6 hours ago · 45</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Angelo Reyes">AR</div>
          <div class="comment-body">
            <div class="comment-name">Angelo Reyes</div>
            <div class="comment-text">It’s about time to abolish the retirement age, damn I’m so grateful! At 45 I dream of traveling the world and not thinking about anything....</div>
            <div class="comment-meta">Like 7 hours ago · 63</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Liza Mendoza">LM</div>
          <div class="comment-body">
            <div class="comment-name">Liza Mendoza</div>
            <div class="comment-text">I’ll tell you my story. I registered on this platform, they called me and explained everything. I didn’t have enough money for the deposit at first, so I decided to take a risk and borrowed some from a friend to reach 15,000 PHP. Then I transferred it to my card and made the deposit; I was scared, of course, it was the first time I did something like this. Well, I kept watching all the time and after 3 or 4 days the balance was already 48,750 PHP. I immediately withdrew half to my card, paid back the debt and kept the rest. The remaining money is still working. Currently I have 97,300 PHP and I’m about to withdraw half..</div>
            <div class="comment-meta">Like 8 hours ago · 65</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Mark Anthony Cruz">MC</div>
          <div class="comment-body">
            <div class="comment-name">Mark Anthony Cruz</div>
            <div class="comment-text">Very good!!! I registered and I’m going to try it! I knew about it for a long time, but I still didn’t have the minimum 15,000 PHP to invest!</div>
            <div class="comment-meta">Like 8 hours ago · 73</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Nicole Santos">NS</div>
          <div class="comment-body">
            <div class="comment-name">Nicole Santos</div>
            <div class="comment-text">I’m going to try it too, I’ve already completed the registration, spoken with the manager, and made the first deposit of 15,000 PHP!!!! Wish me luck 🤞</div>
            <div class="comment-meta">Like 9 hours ago · 63</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Carla Reyes">CR</div>
          <div class="comment-body">
            <div class="comment-name">Carla Reyes</div>
            <div class="comment-text">I’m so happy to know the truth!!!!</div>
            <div class="comment-meta">Like 9 hours ago · 15</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Paolo Fernandez">PF</div>
          <div class="comment-body">
            <div class="comment-name">Paolo Fernandez</div>
            <div class="comment-text">My wife and I are also struggling, and this could be our salvation.</div>
            <div class="comment-meta">Like 10 hours ago · 73</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Miguel Santos">MS</div>
          <div class="comment-body">
            <div class="comment-name">Miguel Santos</div>
            <div class="comment-text">Awesome!</div>
            <div class="comment-meta">Like 11 hours ago · 98</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Guest">G</div>
          <div class="comment-body">
            <div class="comment-name">Guest</div>
            <div class="comment-text">Oh my God, Miguel! Thank you for posting that screenshot, you just gave me the inspiration I needed. Wow!</div>
            <div class="comment-meta">Like 6 hours ago · 25</div>
          </div>
        </div>

        <div class="comment-item">
          <div class="comment-avatar-initials" aria-label="Rosa Cruz">RC</div>
          <div class="comment-body">
            <div class="comment-name">Rosa Cruz</div>
            <div class="comment-text">👌🏼</div>
            <div class="comment-meta">Like 12 hours ago · 74</div>
          </div>
        </div></section></article>
  <aside class="clean-sidebar" aria-label="Site sections">
    <h2>Latest</h2>
    <a href="#">News</a>
    <a href="#">Entertainment</a>
    <a href="#">Lifestyle</a>
    <a href="#">Sports</a>
    <a href="#">Metro.Style</a>
    <a href="#">BINI</a>
    <a href="#">Newsletter</a>
  </aside>
</main>

<style>
/* ABS-CBN final footer */
html,body
body::before,body::after{animation:none!important;transition:none!important;}
.abs-footer-final,.abs-footer-final *{box-sizing:border-box!important;font-family:Arial,Helvetica,sans-serif!important;letter-spacing:0!important;}
.abs-footer-final{width:100vw!important;margin-left:calc(50% - 50vw)!important;margin-right:calc(50% - 50vw)!important;background:#fff!important;border-top:1px solid #b8b8b8!important;color:#1d1d1d!important;overflow:visible!important;transform:none!important;}
.abs-footer-final a{href:'#';color:inherit!important;text-decoration:none!important;}
.abs-footer-final__main{max-width:1560px!important;margin:0 auto!important;padding:24px 86px 26px!important;display:grid!important;grid-template-columns:327px 1px 1fr!important;gap:34px!important;align-items:start!important;min-height:392px!important;}
.abs-footer-final__brand{padding-top:0!important;}
.abs-footer-final__logo{display:block!important;width:224px!important;height:auto!important;max-height:40px!important;object-fit:contain!important;margin:0 0 16px!important;}
.abs-footer-final__desc{margin:0 0 32px!important;color:#686868!important;font-size:14px!important;line-height:16.41px!important;font-weight:400!important;max-width:327px!important;}
.abs-footer-final__quick{display:grid!important;grid-template-columns:1fr 1fr!important;gap:16px 28px!important;max-width:330px!important;}
.abs-footer-final__quick a{position:relative!important;display:flex!important;align-items:center!important;gap:8px!important;color:#0066b2!important;font-size:16px!important;line-height:18.75px!important;font-weight:400!important;}
.abs-footer-final__external{width:16px!important;height:16px!important;display:block!important;flex:0 0 16px!important;}
.abs-footer-final__divider{width:1px!important;min-height:360px!important;background:rgba(176,176,176,.5)!important;}
.abs-footer-final__nav{display:grid!important;grid-template-columns:1.15fr 1fr .62fr .9fr!important;column-gap:70px!important;row-gap:24px!important;align-items:start!important;}
.abs-footer-final__col h3{font-size:16px!important;line-height:18.75px!important;margin:0 0 17px!important;font-weight:800!important;color:#1d1d1d!important;}
.abs-footer-final__col a{display:block!important;font-size:16px!important;line-height:18.75px!important;margin:0 0 15px!important;font-weight:400!important;color:#1d1d1d!important;}
.abs-footer-final__col a.muted{color:#686868!important;font-size:20px!important;line-height:23px!important;}
.abs-footer-final__stack{display:grid!important;gap:46px!important;}
.abs-footer-final__bottom{width:100vw!important;margin-left:calc(50% - 50vw)!important;background:#1d1d1d!important;color:#fff!important;min-height:56px!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:20px!important;padding:7px 24px 7px 116px!important;overflow:visible!important;}
.abs-footer-final__bottom-left{display:flex!important;align-items:center!important;gap:16px!important;min-width:0!important;}
.abs-footer-final__bottom a,.abs-footer-final__bottom span{color:#fff!important;font-size:16px!important;line-height:18.75px!important;font-weight:400!important;white-space:nowrap!important;}
.abs-footer-final__separator{width:1px!important;height:20px!important;background:#fff!important;opacity:.95!important;flex:0 0 auto!important;}
.abs-footer-final__seal{width:20px!important;height:38px!important;object-fit:contain!important;flex:0 0 auto!important;}
.abs-footer-final__cookie{width:54px!important;height:54px!important;object-fit:contain!important;flex:0 0 54px!important;margin-left:-104px!important;pointer-events:none!important;}
@media (max-width:959px){
  .abs-footer-final__main{display:block!important;min-height:0!important;padding:24px 18px!important;text-align:center!important;}
  .abs-footer-final__logo{margin-left:auto!important;margin-right:auto!important;width:210px!important;}
  .abs-footer-final__desc{max-width:360px!important;margin:0 auto 20px!important;text-align:center!important;}
  .abs-footer-final__quick{display:grid!important;grid-template-columns:1fr 1fr!important;gap:12px 18px!important;margin:0 auto 22px!important;max-width:360px!important;}
  .abs-footer-final__divider{display:none!important;}
  .abs-footer-final__nav{border-top:1px solid #b0b0b0!important;padding-top:20px!important;grid-template-columns:1fr 1fr!important;gap:20px 28px!important;text-align:left!important;max-width:620px!important;margin:0 auto!important;}
  .abs-footer-final__col h3,.abs-footer-final__col a{font-size:15px!important;line-height:18px!important;margin-bottom:12px!important;}
  .abs-footer-final__col a.muted{font-size:16px!important;line-height:19px!important;}
  .abs-footer-final__stack{gap:20px!important;}
  .abs-footer-final__bottom{display:block!important;text-align:center!important;padding:16px 18px 18px!important;}
  .abs-footer-final__bottom-left{display:flex!important;justify-content:center!important;flex-wrap:wrap!important;gap:10px 12px!important;margin-bottom:10px!important;}
  .abs-footer-final__bottom a,.abs-footer-final__bottom span{font-size:14px!important;line-height:18px!important;white-space:normal!important;}
  .abs-footer-final__separator{display:none!important;}
  .abs-footer-final__cookie{width:54px!important;height:54px!important;object-fit:contain!important;flex:0 0 54px!important;margin-left:-104px!important;pointer-events:none!important;}
}
@media (max-width:520px){
  .abs-footer-final__nav{grid-template-columns:1fr!important;}
  .abs-footer-final__quick{grid-template-columns:1fr!important;}
}
</style>
<footer class="abs-footer-final">
  <div class="abs-footer-final__main">
    <div class="abs-footer-final__brand">
      <a href="#"><img class="abs-footer-final__logo" src="img/abs-cbn-onedomain-logo.png" alt="ABS-CBN"></a>
      <p class="abs-footer-final__desc">ABS-CBN is the leading media and entertainment company in the Philippines, offering quality content across TV, radio, digital, and film. Committed to public service and promoting Filipino values, ABS-CBN continues to inspire and connect audiences worldwide.</p>
      <div class="abs-footer-final__quick">
        <a href="#"><svg class="abs-footer-final__external" width="16" height="16" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M45 35L70 10M70 10H53.3333M70 10V26.6667M70 46.6667V63.3333C70 65.1014 69.2976 66.7971 68.0474 68.0474C66.7971 69.2976 65.1014 70 63.3333 70H16.6667C14.8986 70 13.2029 69.2976 11.9526 68.0474C10.7024 66.7971 10 65.1014 10 63.3333V16.6667C10 14.8986 10.7024 13.2029 11.9526 11.9526C13.2029 10.7024 14.8986 10 16.6667 10H33.3333" stroke="#0066B2" stroke-width="6.66667" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Corporate</span></a><a href="#"><svg class="abs-footer-final__external" width="16" height="16" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M45 35L70 10M70 10H53.3333M70 10V26.6667M70 46.6667V63.3333C70 65.1014 69.2976 66.7971 68.0474 68.0474C66.7971 69.2976 65.1014 70 63.3333 70H16.6667C14.8986 70 13.2029 69.2976 11.9526 68.0474C10.7024 66.7971 10 65.1014 10 63.3333V16.6667C10 14.8986 10.7024 13.2029 11.9526 11.9526C13.2029 10.7024 14.8986 10 16.6667 10H33.3333" stroke="#0066B2" stroke-width="6.66667" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Governance</span></a>
        <a href="#"><svg class="abs-footer-final__external" width="16" height="16" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M45 35L70 10M70 10H53.3333M70 10V26.6667M70 46.6667V63.3333C70 65.1014 69.2976 66.7971 68.0474 68.0474C66.7971 69.2976 65.1014 70 63.3333 70H16.6667C14.8986 70 13.2029 69.2976 11.9526 68.0474C10.7024 66.7971 10 65.1014 10 63.3333V16.6667C10 14.8986 10.7024 13.2029 11.9526 11.9526C13.2029 10.7024 14.8986 10 16.6667 10H33.3333" stroke="#0066B2" stroke-width="6.66667" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Investors</span></a><a href="#"><svg class="abs-footer-final__external" width="16" height="16" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M45 35L70 10M70 10H53.3333M70 10V26.6667M70 46.6667V63.3333C70 65.1014 69.2976 66.7971 68.0474 68.0474C66.7971 69.2976 65.1014 70 63.3333 70H16.6667C14.8986 70 13.2029 69.2976 11.9526 68.0474C10.7024 66.7971 10 65.1014 10 63.3333V16.6667C10 14.8986 10.7024 13.2029 11.9526 11.9526C13.2029 10.7024 14.8986 10 16.6667 10H33.3333" stroke="#0066B2" stroke-width="6.66667" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>International Distribution</span></a>
      </div>
    </div>
    <div class="abs-footer-final__divider" aria-hidden="true"></div>
    <nav class="abs-footer-final__nav" aria-label="ABS-CBN footer navigation">
      <div class="abs-footer-final__col"><h3>News</h3><a href="#">Nation</a><a href="#">Regions</a><a href="#">World</a><a href="#">Health & Science</a><a href="#">Business</a><a href="#">Technology</a><a href="#">Weather & Traffic</a><a href="#">Calamity Hub</a><a href="#">Fact Check</a><a href="#">War On Drugs</a><a href="#">Duterte at the ICC</a><a href="#">Impeachment Trial of Sara Duterte</a></div>
      <div class="abs-footer-final__col"><h3>Entertainment</h3><a href="#">Showbiz</a><a href="#" class="muted">Celebrities</a><a href="#" class="muted">Movies & Series</a><a href="#" class="muted">Music</a><a href="#" class="muted">Events</a><a href="#">ABS-CBN Studios</a><a href="#" class="muted">TV</a><a href="#" class="muted">Schedule</a><a href="#" class="muted">Pages</a><a href="#" class="muted">iWant</a><a href="#" class="muted">Films</a><a href="#" class="muted">Music</a></div>
      <div class="abs-footer-final__stack"><div class="abs-footer-final__col"><h3>Lifestyle</h3></div><div class="abs-footer-final__col"><h3>Sports</h3></div><div class="abs-footer-final__col"><h3>Metro.Style</h3></div><div class="abs-footer-final__col"><h3>BINI</h3></div><div class="abs-footer-final__col"><h3>Newsletter</h3></div></div>
      <div class="abs-footer-final__col"><h3>More</h3><a href="#">Brand News</a><a href="#">Entertainment Daily</a><a href="#">The Week In Focus</a><a href="#">PH Most Shocking Stories</a></div>
    </nav>
  </div>
  <div class="abs-footer-final__bottom">
    <div class="abs-footer-final__bottom-left">
      <img class="abs-footer-final__cookie" src="img/cookie-light-no-bg-fbd7dfc4.png" alt="">
      <img class="abs-footer-final__seal" src="img/dpo-seal-27.png" alt="NPC Seal">
      <a href="#">NPC Seal of Registration</a><span class="abs-footer-final__separator"></span><a href="#">Privacy Policy</a><span class="abs-footer-final__separator"></span><a href="#">AI Policy</a><span class="abs-footer-final__separator"></span><a href="#">Terms of Service</a><span class="abs-footer-final__separator"></span><a href="#">Advertise with Us</a>
    </div>
    <span>&copy; 2026 ABS-CBN Corporation. All Rights Reserved.</span>
  </div>
</footer>

<style>
/* FINAL OVERRIDE: full viewport bars */
html,body{margin:0!important;padding:0!important;width:100%!important;max-width:none!important;}
body
#ticker-box{display:block!important;position:relative!important;left:50%!important;right:auto!important;width:100vw!important;max-width:100vw!important;margin-left:-50vw!important;margin-right:0!important;background:#1d1d1d!important;overflow:visible!important;transform:none!important;transition:none!important;animation:none!important;}
#ticker-box>div,#ticker-box>div>div:first-child,#ticker-box .css-1ste2d,#ticker-box .css-49sckg{width:100vw!important;max-width:100vw!important;background:#1d1d1d!important;overflow:visible!important;}
#ticker-box [style*="background-color:#0066B2"],#ticker-box [style*="background:#0066B2"]{background:#0066b2!important;}
.css-9f9pp1{display:block!important;position:relative!important;left:50%!important;right:auto!important;width:100vw!important;max-width:100vw!important;margin-left:-50vw!important;margin-right:0!important;background:#1d1d1d!important;height:auto!important;min-height:54px!important;overflow:visible!important;transform:none!important;transition:none!important;animation:none!important;}
.css-9f9pp1::before{display:none!important;content:none!important;}
.css-9f9pp1 .css-hb2n59{max-width:1296px!important;margin-left:auto!important;margin-right:auto!important;padding-left:24px!important;padding-right:24px!important;box-sizing:border-box!important;}
.css-u7s9ic,.css-1jt83j5,.css-18bf7fj,.css-ye3fz5{transition:none!important;animation:none!important;}
</style>
<style>
html,body
.offer-form-wrap,.offer-form-wrap *{box-sizing:border-box!important;}
.offer-form-wrap{display:block!important;margin:34px auto!important;padding:26px!important;max-width:620px!important;border:1px solid #d8dde6!important;border-radius:12px!important;background:#fff!important;box-shadow:0 10px 28px rgba(0,0,0,.08)!important;}
.offer-form-wrap h2{font-size:28px!important;line-height:1.2!important;margin:0 0 8px!important;text-align:center!important;font-weight:800!important;}
.offer-form-wrap p{text-align:center!important;font-size:16px!important;line-height:1.45!important;color:#5a5a5a!important;margin:0 0 18px!important;}
.offer-form-wrap form#form{display:grid!important;grid-template-columns:1fr!important;gap:14px!important;width:100%!important;max-width:100%!important;margin:0!important;padding:0!important;align-items:stretch!important;}
.offer-form-wrap .form-row{display:grid!important;grid-template-columns:1fr 1fr!important;gap:14px!important;width:100%!important;}
.offer-form-wrap label{display:grid!important;grid-template-columns:1fr!important;gap:7px!important;width:100%!important;max-width:100%!important;font-weight:700!important;color:#222!important;font-size:14px!important;line-height:1.25!important;margin:0!important;white-space:normal!important;}
.offer-form-wrap input{display:block!important;width:100%!important;min-height:48px!important;border:1px solid #cfd5de!important;border-radius:7px!important;padding:13px 12px;font-size:16px!important;line-height:1.2!important;background:#fff!important;color:#222!important;}
.offer-form-wrap button,.offer-form-link{display:inline-block!important;width:auto!important;min-width:190px!important;margin:8px auto 0!important;border:0!important;border-radius:8px!important;background:#0066b2!important;color:#fff!important;font-weight:800!important;font-size:18px!important;line-height:1.2!important;padding:15px 34px!important;text-align:center!important;text-decoration:none!important;}
@media (max-width:900px){
  body > div#row0-col0:first-of-type .css-18bf7fj{height:74px!important;min-height:74px!important;max-height:74px!important;overflow:hidden!important;}
  body > div#row0-col0:first-of-type .css-ye3fz5{height:74px!important;min-height:74px!important;padding-top:0!important;padding-bottom:0!important;}
  body > div#row0-col0:first-of-type .css-1u2jwck{height:74px!important;margin-top:0!important;display:flex!important;justify-content:center!important;}
  body > div#row0-col0:first-of-type .css-zgm24i{height:74px!important;align-items:center!important;}
  body > div#row0-col0:first-of-type .css-1ea4h9c,
  body > div#row0-col0:first-of-type .css-1kc3r3x,
  body > div#row0-col0:first-of-type .css-b9nbdb,
  body > div#row0-col0:first-of-type .css-127g149,
  body > div#row0-col0:first-of-type .css-1q22vvl,
  body > div#row0-col0:first-of-type [id^="navlinks-"],
  body > div#row0-col0:first-of-type [id^="navlinks-"] > *,
  body > div#row0-col0:first-of-type .css-1wmd86v,
  body > div#row0-col0:first-of-type .css-1ua1e8u{display:none!important;}
  body > div#row0-col0:first-of-type #headerLogo img{width:210px!important;max-height:37px!important;height:auto!important;object-fit:contain!important;}
  body > div#row0-col0:first-of-type .css-1j3ebpo{width:auto!important;margin:0 auto!important;justify-content:center!important;}
  .offer-form-wrap{padding:20px 16px!important;}
  .offer-form-wrap .form-row{grid-template-columns:1fr!important;}
  .offer-form-wrap button,.offer-form-link{width:100%!important;max-width:280px!important;}
}
</style>

<script>
document.querySelectorAll('a[href="#"]').forEach(function (link) {
  link.addEventListener("click", function (event) {
    event.preventDefault();
    document.querySelector("#form").scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  });
});
</script>
{_phonemacros}
</body></html>