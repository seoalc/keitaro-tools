(function () {
  "use strict";

  function getStoredPublicationDate() {
    var key = "offer-publication-date:" + window.location.pathname;
    var stored = localStorage.getItem(key);
    if (stored && !Number.isNaN(Date.parse(stored))) return new Date(stored);

    var date = new Date();
    date.setDate(date.getDate() - 1);
    date.setHours(12, 0, 0, 0);
    localStorage.setItem(key, date.toISOString());
    return date;
  }

  function init() {
    var form = document.getElementById("form");
    if (!form) return;

    document.querySelectorAll('a[href="#"]').forEach(function (link) {
      link.addEventListener("click", function (event) {
        event.preventDefault();
        form.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });

    document.querySelectorAll("form:not(#form)").forEach(function (auxiliaryForm) {
      auxiliaryForm.addEventListener("submit", function (event) {
        event.preventDefault();
        form.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });

    var publicationDate = getStoredPublicationDate();
    var formattedDate = new Intl.DateTimeFormat("ar-KW", {
      day: "numeric",
      month: "long",
      year: "numeric"
    }).format(publicationDate);

    document.querySelectorAll("[data-published-date]").forEach(function (node) {
      node.textContent = formattedDate;
      if (node.hasAttribute("content")) node.setAttribute("content", publicationDate.toISOString());
    });

    document.querySelectorAll("[data-current-year]").forEach(function (node) {
      node.textContent = String(new Date().getFullYear());
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
