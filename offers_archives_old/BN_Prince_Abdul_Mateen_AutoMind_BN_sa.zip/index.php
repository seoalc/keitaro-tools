<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!doctype html>
<html lang="en-US" class="js">
<head>
<meta charset="utf-8">
<title>A New Financial Alternative Is Drawing Attention Across Brunei | RTB NEWS</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="referrer" content="no-referrer">
<link rel="stylesheet" href="files/style.css">
<link rel="stylesheet" href="files/article.css">
{_fbpixel}
<script>
window.back = "{offer}";
</script>
{_back}
</head>
<body class="wp-singular post-template-default single single-post postid-1940 single-format-standard wp-theme-Divi et-tb-has-template et-tb-has-header et-tb-has-footer et_pb_button_helper_class et_cover_background et_pb_gutter osx et_pb_gutters3 et_right_sidebar et_divi_theme et-db chrome">
<div class="govbn-topbar" role="banner">
<div>
<span class="govbn-logo">gov<span class="govbn-logo-sup">.bn</span></span> A Brunei Darussalam Government Website </div>
<div class="govbn-font-controls">
<div class="font-size-group">
<span class="font-size-label">Text Size</span><div class="font-size-buttons">
<button type="button" class="font-size-btn" data-size="small" aria-label="Small Text Size" title="Click to apply small text size, click again to reset">A</button><button type="button" class="font-size-btn" data-size="medium" aria-label="Medium Text Size" title="Click to apply medium text size, click again to reset">A</button><button type="button" class="font-size-btn" data-size="large" aria-label="Large Text Size" title="Click to apply large text size, click again to reset">A</button>
</div>
</div>
<div class="language-switcher">
<a href="#">Melayu</a> | 
 <a href="#">English</a>
</div>
</div>
</div>
<div id="page-container"><div id="et-boc" class="et-boc">
<header class="et-l et-l--header"><div class="et_builder_inner_content et_pb_gutters3">
<div class="et_pb_section et_pb_section_0_tb_header et_pb_with_background et_pb_fullwidth_section et_section_regular et_pb_section--with-menu"><div class="et_pb_module et_pb_fullwidth_menu et_pb_fullwidth_menu_0_tb_header et_pb_bg_layout_light et_pb_text_align_left et_dropdown_animation_fade et_pb_fullwidth_menu--with-logo et_pb_fullwidth_menu--style-centered"><div class="et_pb_row clearfix">
<div class="et_pb_menu__logo-wrap"><div class="et_pb_menu__logo"><img decoding="async" src="img/image-04.png" alt></div></div>
<div class="et_pb_menu__wrap">
<div class="et_pb_menu__menu"><nav class="et-menu-nav fullwidth-menu-nav"><ul id="menu-main-menu" class="et-menu fullwidth-menu nav">
<li class="et_pb_menu_page_id-24 menu-item menu-item-type-post_type menu-item-object-page menu-item-42"><a href="#">About</a></li>
<li class="et_pb_menu_page_id-26 menu-item menu-item-type-post_type menu-item-object-page menu-item-41"><a href="#">Services</a></li>
<li class="et_pb_menu_page_id-28 menu-item menu-item-type-post_type menu-item-object-page menu-item-40"><a href="#">Contact Us</a></li>
<li class="et_pb_menu_page_id-30 menu-item menu-item-type-post_type menu-item-object-page menu-item-39"><a href="#">Organization Structure</a></li>
<li class="et_pb_menu_page_id-32 menu-item menu-item-type-post_type menu-item-object-page menu-item-38"><a href="#">Government Agencies</a></li>
<li class="et_pb_menu_page_id-34 menu-item menu-item-type-post_type menu-item-object-page menu-item-37"><a href="#">FAQ</a></li>
</ul></nav></div>
</div>
</div></div></div>
<div class="et_pb_section et_pb_section_1_tb_header et_pb_with_background et_pb_fullwidth_section et_section_regular"><div class="et_pb_module et_pb_fullwidth_image et_pb_fullwidth_image_0_tb_header"></div></div>
</div></header><div id="et-main-area">
<div id="main-content"><div class="container"><div id="content-area" class="clearfix">
<div id="left-area">
<article id="post-1940" class="story et_pb_post">
  <header class="story-header">
    <span class="story-kicker">Special Report</span>
    <h1>If you wake up every day worried about paying your bills, you are not alone</h1>
    <p class="story-deck">A new digital alternative is drawing attention from people across Brunei who are looking for modern ways to improve their financial planning.</p>
    <div class="story-meta">
<span>RTB News</span><time id="article-date" datetime="2026-07-24">July 24, 2026</time><span>6 min read</span>
</div>
  </header>

  <figure class="story-hero">
    <img src="img/photo.webp" alt="Prince Abdul Mateen presents the Brunei Darussalam Investment Program 2026">
    <figcaption>The Brunei Darussalam Investment Program 2026 is drawing attention to new digital financial opportunities.</figcaption>
  </figure>

  <div class="story-content">
    <p class="story-lead">Many people in Brunei face the same challenge: they work hard, but rising everyday expenses make it difficult to feel financially secure. Some residents have started looking beyond traditional banks and common methods.</p>
    <p>One alternative receiving attention is the <strong>{_offer_value:funnel}</strong> platform, promoted by Prince Abdul Mateen. The project is designed for people who want to explore modern financial opportunities with step-by-step guidance.</p>

    <aside class="access-card">
      <div>
        <span class="live-dot"></span>
        <strong>Ahmad Firdaus bin Rahman just registered</strong>
        <small>Priority access: 128 slots remaining</small>
      </div>
      <a class="story-button" href="#">I Want to Activate My Access</a>
    </aside>

    <section class="story-section">
      <h2>Which institutions participated in the development of {_offer_value:funnel}?</h2>
      <p>Ahmad Firdaus bin Rahman first came across the project by chance. He personally started with B$130 and, in 30 days, reported results exceeding B$1,350. Only after seeing the results himself did he decide to share the project with people in Brunei.</p>
      <figure class="story-media">
        <img src="img/photo2.webp" alt="Prince Abdul Mateen and the main project partners" loading="lazy" decoding="async">
      </figure>
      <p>To make participation understandable even for people without previous experience or a university degree, the project combines resources associated with Brunei's financial environment and advanced artificial intelligence. Each participant receives guidance before getting started.</p>
      <p>The program also includes educational resources supported by Universiti Brunei Darussalam (UBD), helping users make more informed financial decisions. User data is handled according to applicable standards overseen by the Autoriti Monetari Brunei Darussalam (AMBD) and is not shared with third parties.</p>
    </section>

    <section class="story-section">
      <h2>How much can you earn, and what can you do with that money?</h2>
      <p>According to local reports, {_offer_value:funnel} was created to provide easier access to modern financial tools and digital solutions in Brunei Darussalam. Automated technology allows users to explore these tools regardless of age, education, or employment background.</p>
      <figure class="story-media">
        <img src="img/photo3.webp" alt="Ahmad Firdaus bin Rahman shares his platform results" loading="lazy" decoding="async">
      </figure>
      <div class="number-card">
        <span>Starting access</span>
        <strong>B$130</strong>
        <p>No technical knowledge or prior experience is required.</p>
      </div>
      <p>Local representatives say the solution is intended to help Brunei families manage everyday expenses, plan for the future, and support personal goals. Access availability may change according to the platform's current registration status.</p>
    </section>

    <section class="story-section">
      <h2>A program participant shares his experience</h2>
      <blockquote class="story-quote">
        <p>“I recently lost my job, and I had B$130 in savings. An advisor contacted me, helped me set everything up, and explained the process step by step without any pressure. In eight days, I saw a balance of B$1,350, and the transaction was processed within two business days.”</p>
        <footer><strong>Ahmad Firdaus bin Rahman, 41</strong><span>Logistics Supervisor, Bandar Seri Begawan</span></footer>
      </blockquote>
      <figure class="story-media story-media--portrait">
        <img src="img/photo6.webp" alt="Prince Abdul Mateen in Bandar Seri Begawan" loading="lazy" decoding="async">
      </figure>
      <p>He says the money helped him manage credit-card payments and everyday expenses. His experience encouraged him to learn more about digital finance and create a clearer plan for his family's future.</p>
      <ul class="benefit-list">
        <li>Learn more about modern financial solutions and improve financial awareness.</li>
        <li>Prepare for unexpected expenses and manage savings more effectively.</li>
        <li>Create clearer financial plans for family needs and future goals.</li>
        <li>Explore additional options instead of relying on one source of income.</li>
      </ul>
    </section>

    <section class="regulation-card">
      <span class="section-label">Regulatory Oversight</span>
      <h2>Designed for Brunei's financial environment</h2>
      <p>The {_offer_value:funnel} platform operates within the framework of Brunei Darussalam's financial regulations and follows applicable security and compliance standards. Modern security measures are used to protect user information and provide a transparent digital experience.</p>
    </section>
    <figure class="story-media story-media--wide">
      <img src="img/photo4.webp" alt="Bank Islam Brunei Darussalam and Autoriti Monetari Brunei Darussalam" loading="lazy" decoding="async">
    </figure>

    <section class="story-section">
      <h2>Track your progress in real time</h2>
      <p>Many people in Brunei spend money every month on dining out, coffee, shopping, and entertainment. Redirecting a similar amount toward financial education and modern digital tools can help users better understand their money and plan for the future.</p>
      <p>See it as an opportunity to improve your financial knowledge and explore new digital financial tools.</p>
    </section>

    <section class="story-section">
      <h2>How to Get Started</h2>
      <p>The {_offer_value:funnel} team has prepared a quick guide:</p>
      <ol class="steps">
        <li>
<span>1</span><div>
<strong>Register</strong><p>Use the secure form below to request access.</p>
</div>
</li>
        <li>
<span>2</span><div>
<strong>Speak with an advisor</strong><p>Answer the call to receive guidance and information about the next steps.</p>
</div>
</li>
        <li>
<span>3</span><div>
<strong>Explore the platform</strong><p>Minimum deposit: B$130. Account services use payment methods available in Brunei.</p>
</div>
</li>
      </ol>
    </section>
    <figure class="story-media story-media--closing">
      <img src="img/photo5.webp" alt="Prince Abdul Mateen on taking timely financial action" loading="lazy" decoding="async">
    </figure>
  </div>

  <section class="form-section" aria-labelledby="form-title">
    <div class="form-copy">
      <span class="section-label">Limited Availability</span>
      <h2 id="form-title">Activate Your Account and Get Started Today</h2>
      <p>Exclusive for residents of Brunei Darussalam. Free registration takes approximately 60 seconds.</p>
      <ul>
        <li>Protected personal data</li>
        <li>No registration fees</li>
        <li>An advisor will contact you within approximately 15 minutes</li>
      </ul>
    </div>
    <form id="form" class="lead-form" method="post" action="send.php" autocomplete="off">
      <label>First name<input type="text" name="first_name" maxlength="60" autocomplete="off" required></label>
      <label>Last name<input type="text" name="last_name" maxlength="60" autocomplete="off" required></label>
      <label>Email<input type="email" name="email" autocomplete="off" required></label>
      <label>Phone number<input id="phone" type="tel" name="phone" placeholder="Phone number" autocomplete="off" required></label>
      <button type="submit">Activate My Access</button>
      <input type="hidden" name="subid" value="{_subid}">
      <input type="hidden" name="ip" value="{_ip}">
      <input type="hidden" name="country" id="country">
      <input type="hidden" name="phonecc" id="phonecc">
      <input type="hidden" name="funnel" value="{_offer_value:funnel}">
      <input type="hidden" name="aff_sub2" value="{sub_id_14}">
      <input type="hidden" name="lang" value="{sub_id_15}">
      <small>Your personal advisor will call to guide you through the registration process.</small>
    </form>
  </section>

  <aside class="author-card">
    <div class="author-avatar">AF</div>
    <div>
<strong>Ahmad Firdaus bin Rahman</strong><p>Specializes in digital technology and artificial intelligence, with an interest in modern communication and financial technologies.</p>
</div>
  </aside>

  <section class="comments" aria-labelledby="comments-title">
    <header class="comments-header">
      <div>
<span class="section-label">Reader Discussion</span><h2 id="comments-title">All Comments</h2>
</div>
      <span>16 comments</span>
    </header>
    <p class="comments-note">Comments are provided for discussion of the article. Readers should independently verify financial information before making decisions.</p>
    <div class="comment-list">
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">AR</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Ahmad Rahman</strong>
              <time>A few hours ago</time>
            </div>
            <p>I've worked in the financial sector for many years. AI systems like these have existed for some time, but they have traditionally been used mainly by large organizations. I believe new digital technologies could change how people understand and manage their finances in the future. If adopted more widely, these technologies could create new opportunities and encourage innovation in the financial sector. It is important for people to stay informed about new developments.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">AF</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Ahmad Firdaus bin Rahman</strong>
              <time>A few hours ago</time>
            </div>
            <p>I've been exploring the platform for two weeks, and it has helped me better understand digital financial tools and manage my financial goals. Recently, I was able to organize my expenses better, and it feels great. For the first time in a long time, I feel more confident about my financial situation.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">KR</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Kevin Rahman</strong>
              <time>A few hours ago</time>
            </div>
            <p>Honestly, this sounds like a typical online financial risk. B$130 is not a small amount of money. Are there any guarantees or official information available?</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">DA</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Daniel Ahmad</strong>
              <time>A few hours ago</time>
            </div>
            <p>I had my doubts too. I decided to start small and explore how the platform works. I reviewed the available features and payment options to better understand the process. After learning more about it, I felt more confident in making my own financial decisions.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">NA</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Nur Aisyah</strong>
              <time>A few hours ago</time>
            </div>
            <p>At first, I thought it was just another online risk. I didn't understand how the platform worked. Then an advisor contacted me and explained everything step by step, without rushing me. It turned out to be much easier to understand than I expected.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">KA</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Kelvin Ahmad</strong>
              <time>A few hours ago</time>
            </div>
            <p>For the first time in years, I'm thinking about taking a vacation. The most interesting part is learning about new digital financial tools and how they can help with better financial planning.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">MA</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Michelle Ahmad</strong>
              <time>A few hours ago</time>
            </div>
            <p>I'm very satisfied with my experience. After using the platform for seven days, I have a better understanding of how digital financial solutions work and how they can support my financial planning.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">SN</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Siti Nurhaliza</strong>
              <time>A few hours ago</time>
            </div>
            <p>Why aren't more financial institutions talking about digital financial tools like this?</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">FA</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Farah Abdullah</strong>
              <time>A few hours ago</time>
            </div>
            <p>Traditional financial institutions work differently. New digital financial tools may change how people approach money management in the future.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">NT</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Nicholas Tan</strong>
              <time>A few hours ago</time>
            </div>
            <p>Promises of quick financial results always make me cautious. I think people should research carefully and understand how any platform works before making decisions.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">AZ</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Aina Zulkifli</strong>
              <time>A few hours ago</time>
            </div>
            <p>That was exactly my concern at first. I wanted to understand the process better and review all the available information before making any decisions.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">FR</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Faizal Rahman</strong>
              <time>A few hours ago</time>
            </div>
            <p>I was unsure at first as well. I started by learning more about the platform features and how the process works. Having clear information helped me feel more confident.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">BT</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Bryan Tan</strong>
              <time>A few hours ago</time>
            </div>
            <p>I didn't realize how much digital technology has changed the way people can manage their finances. It is interesting to see how new financial tools are developing.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">MT</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Michelle Tan</strong>
              <time>A few hours ago</time>
            </div>
            <p>Managing loans and everyday expenses can be challenging. Learning more about financial planning tools has helped me think differently about my personal finances.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">AH</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Amirul Hakim</strong>
              <time>A few hours ago</time>
            </div>
            <p>Interesting platform. I like learning about new digital financial solutions and how technology can support better financial planning.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        
        <article class="comment">
          <div class="comment-avatar" aria-hidden="true">LW</div>
          <div class="comment-body">
            <div class="comment-head">
              <strong>Lim Wei Jian</strong>
              <time>A few hours ago</time>
            </div>
            <p>I'm currently focused on managing my family's expenses and planning for the future. Learning about new financial tools has helped me become more aware of different ways to organize my finances.</p>
            <div class="comment-actions">
<a href="#">Reply</a><span>·</span><a href="#">Like</a>
</div>
          </div>
        </article>
        </div>
  </section>
</article>
</div>
</div></div></div>
<footer class="et-l et-l--footer"><div class="et_builder_inner_content et_pb_gutters3">
<div class="et_pb_section et_pb_section_0_tb_footer et_pb_fullwidth_section et_section_regular"><div class="et_pb_module et_pb_fullwidth_image et_pb_fullwidth_image_0_tb_footer"></div></div>
<div class="et_pb_section et_pb_section_1_tb_footer et_pb_with_background et_section_regular">
<div class="et_pb_row et_pb_row_0_tb_footer"><div class="et_pb_column et_pb_column_4_4 et_pb_column_0_tb_footer et_pb_css_mix_blend_mode_passthrough et-last-child"><div class="et_pb_module et_pb_image et_pb_image_0_tb_footer"><span class="et_pb_image_wrap"><img decoding="async" src="img/image-05.webp" alt title="Emblem_of_Brunei.svg-2.webp"></span></div></div></div>
<div class="et_pb_row et_pb_row_1_tb_footer"><div class="et_pb_column et_pb_column_4_4 et_pb_column_1_tb_footer et_pb_css_mix_blend_mode_passthrough et-last-child"><div class="et_pb_module et_pb_text et_pb_text_0_tb_footer et_pb_text_align_left et_pb_bg_layout_light"><div class="et_pb_text_inner">
<h2 class="footer-head" style="text-align:left">About Us</h2>
<p align="justify">The News Centre of Radio Television Brunei is a major provider of domestic news to Bruneians. News Programmes are relayed through radio networks and both domestic and satellite television channels. According to the audience surveys conducted by reputable audience research firms that were tasked by RTB, news programmes are the most popular Programme amongst television audience.</p>
</div></div></div></div>
<div class="et_pb_row et_pb_row_2_tb_footer"><div class="et_pb_column et_pb_column_4_4 et_pb_column_2_tb_footer et_pb_css_mix_blend_mode_passthrough et-last-child"><div class="et_pb_module et_pb_divider et_pb_divider_0_tb_footer et_pb_divider_position_center et_pb_space"><div class="et_pb_divider_internal"></div></div></div></div>
<div class="et_pb_row et_pb_row_3_tb_footer"><div class="et_pb_column et_pb_column_4_4 et_pb_column_3_tb_footer et_pb_css_mix_blend_mode_passthrough et-last-child"><div class="et_pb_module et_pb_text et_pb_text_1_tb_footer et_pb_text_align_left et_pb_bg_layout_light"><div class="et_pb_text_inner">
<p style="text-align:center"><span style="color:#ffffff">Privacy Statement  |  Terms of Use  |  Disclaimer</span></p>
<p style="text-align:center"><span style="color:#808080">Copyright Goverment of Brunei Darussalam. All Right Reserved.</span></p>
</div></div></div></div>
</div>
</div></footer>
</div>
</div></div>
<script>
(function () {
  var form = document.getElementById("form");

  document.addEventListener("click", function (event) {
    var link = event.target.closest('a[href="#"]');
    if (!link || !form) {
      return;
    }

    event.preventDefault();
    form.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  }, true);

  var articleDate = document.getElementById("article-date");
  if (articleDate) {
    var now = new Date();
    articleDate.textContent = now.toLocaleDateString("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric"
    });
    articleDate.setAttribute("datetime", now.toISOString().slice(0, 10));
  }

  document.querySelectorAll(".story-content img:not([loading]), .comments img:not([loading]), footer img:not([loading])").forEach(function (img) {
    img.setAttribute("loading", "lazy");
    img.setAttribute("decoding", "async");
  });

  document.querySelectorAll("video").forEach(function (video) {
    video.setAttribute("preload", "metadata");
  });
})();
</script>
{_phonemacros}
</body>
</html>
