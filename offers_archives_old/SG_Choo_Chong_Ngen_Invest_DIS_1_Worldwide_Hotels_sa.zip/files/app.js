(function () {
	"use strict";

	/* ------------------------------------------- модалки шапки (#...modal--open) */
	function openModal(modal) {
		if (!modal) return;
		modal.classList.add("modal--open");
		document.body.classList.add("modal-open");
	}

	function closeModals() {
		document.querySelectorAll(".modal--open").forEach(function (modal) {
			modal.classList.remove("modal--open");
		});
		document.body.classList.remove("modal-open");
	}

	function bind(triggerSelector, modalId) {
		var modal = document.getElementById(modalId);
		document.querySelectorAll(triggerSelector).forEach(function (trigger) {
			trigger.setAttribute("data-ui", "");
			trigger.addEventListener("click", function (event) {
				event.preventDefault();
				if (modal && modal.classList.contains("modal--open")) closeModals();
				else { closeModals(); openModal(modal); }
			});
		});
	}

	// «All» открывает боковое меню разделов, лупа — модалку поиска
	bind(".all-section-menu", "all-section-menu-modal");
	bind(".header__search-trigger, .search-trigger, .header__primary .search", "algolia-search-modal");

	document.querySelectorAll(".modal__close, .modal .close").forEach(function (button) {
		button.setAttribute("data-ui", "");
		button.addEventListener("click", closeModals);
	});

	document.addEventListener("keydown", function (event) {
		if (event.key === "Escape") closeModals();
	});

	/* --------------------------- тени прокрутки у горизонтального меню разделов */
	document.querySelectorAll(".cnar-primary-menu-scrollable-wrapper").forEach(function (wrapper) {
		var scroller = wrapper.querySelector(".cnar-primary-menu--scrollable") || wrapper.firstElementChild;
		if (!scroller) return;

		function update() {
			var max = scroller.scrollWidth - scroller.clientWidth;
			wrapper.classList.toggle("cnar-primary-menu-scrollable-wrapper--scrollable-left", scroller.scrollLeft > 1);
			wrapper.classList.toggle("cnar-primary-menu-scrollable-wrapper--scrollable-right", scroller.scrollLeft < max - 1);
		}

		scroller.addEventListener("scroll", update);
		window.addEventListener("resize", update);
		window.addEventListener("load", update);
		// до загрузки веб-шрифтов ширина пунктов другая — пересчитываем после
		if (document.fonts && document.fonts.ready) document.fonts.ready.then(update);
		if (window.ResizeObserver) new ResizeObserver(update).observe(scroller);
		update();
	});

	/* ----------------------------------------------------- год в копирайте (§12) */
	document.querySelectorAll("[data-current-year]").forEach(function (node) {
		var year = String(new Date().getFullYear());
		if (/\b(19|20)\d{2}\b/.test(node.textContent)) {
			node.textContent = node.textContent.replace(/\b(19|20)\d{2}\b/, year);
		} else {
			node.textContent = year;
		}
	});

	document.querySelectorAll("[data-current-date]").forEach(function (node) {
		node.textContent = new Date().toLocaleDateString("en-SG", {
			day: "numeric",
			month: "long",
			year: "numeric"
		});
	});

	/* -------------------------------- служебные формы никуда не отправляются */
	document.querySelectorAll("form:not(#form)").forEach(function (form) {
		form.addEventListener("submit", function (event) {
			event.preventDefault();
		});
	});

	/* --------------------------------------------- плавная прокрутка к форме (§6) */
	/* элементы управления интерфейсом прокрутку не вызывают */
	document.querySelectorAll('a[href="#"]:not([data-ui])').forEach(function (link) {
		link.addEventListener("click", function (event) {
			event.preventDefault();
			var form = document.querySelector("#form");
			if (form) {
				form.scrollIntoView({
					behavior: "smooth",
					block: "start"
				});
			}
		});
	});
})();
