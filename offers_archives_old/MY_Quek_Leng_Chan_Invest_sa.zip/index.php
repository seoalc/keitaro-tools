<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!DOCTYPE html>

<html class="" lang="en" style="">
<head>
<meta charset="utf-8"/>
<title>A Malaysian Discovers How to Earn RM 565 a Day Without Leaving Home — and Banks Are Concerned | The Star</title>
<meta content="width=device-width, initial-scale=1, minimum-scale=1" name="viewport"/>
<link href="files/style.css" rel="stylesheet"/>


<link href="img/image-027.ico" rel="icon" type="image/png"/>
<link href="files/offer.css" rel="stylesheet"/>
{_fbpixel}
<script>
window.back = "{offer}";
</script>
{_back}
</head>
<body class="has-smg55-globalbar">
<div class="smg55-global-bar" id="smg55-global-bar" role="banner">
<div class="smg55-global-bar__inner">
<nav aria-label="SMG Network Sites" class="smg55-global-bar__links">
<a class="globalbar-link" data-content-title="ePaper" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">ePaper</a>
<a class="globalbar-link" data-content-title="Events" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">Events</a>
<a class="globalbar-link" data-content-title="R.AGE" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">R.AGE</a>
<a class="globalbar-link" data-content-title="mStar" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">mStar</a>
<a class="globalbar-link" data-content-title="StarProperty" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">StarProperty</a>
<a class="globalbar-link" data-content-title="StarCherish" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">StarCherish</a>
<a class="globalbar-link" data-content-title="StarCarsifu" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">StarCarsifu</a>
<a class="globalbar-link" data-content-title="StarSearch" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">StarSearch</a>
<a class="globalbar-link" data-content-title="myStarjob" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">myStarjob</a>
<a class="globalbar-link" data-content-title="Kuali" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">Kuali</a>
<a class="globalbar-link" data-content-title="Kuntum" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">Kuntum</a>
<a class="globalbar-link" data-content-title="SuriaFM" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">SuriaFM</a>
<a class="globalbar-link" data-content-title="988FM" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">988FM</a>
</nav>
<div class="smg55-global-bar__right">
<a aria-label="Star55 Home" class="smg55-brandbar-link" data-content-title="Star55" data-content-type="Outbound Referral" data-list-type="Global Bar" href="#">
<img alt="Star55: Inspiring Progress, Shaping Tomorrow" class="smg55-brandbar" src="img/image-028.svg"/>
</a>
<img alt="Powered by Star Media Group" class="smg55-poweredby" src="img/image-029.png"/>
</div>
<div class="smg55-global-bar__center">
<a aria-label="Star55 Home" class="smg55-brandbar-link" href="#">
<img alt="Star55: Inspiring Progress, Shaping Tomorrow" class="smg55-brandbar" src="img/image-028.svg"/>
</a>
<img alt="Powered by Star Media Group" class="smg55-poweredby" src="img/image-029.png"/>
</div>
</div>
<div aria-hidden="true" class="smg55-global-bar__gradient"></div>
</div>
<div>

</div>


<div class="container" id="award-container">
<a class="award-highlight" data-content-category="Gold Winner, Best Climate Infographics" data-content-title="WAN IFRA ASIA MEDIA AWARDS 2025" data-content-type="Navigation" data-list-type="Header" href="#">
<img alt="Gold Award" class="award-icon" src="img/image-030.png"/>
<p class="award-text">
<span class="awardname">WAN IFRA ASIA MEDIA AWARDS 2025</span>
<span class="award-divider">•</span>
<span class="mobile-break"></span>
<span class="awardcat">Gold Winner, Best Climate Infographics</span>
</p>
</a>
</div>
<header id="page-header">
<div class="branding">
<div class="container">
<a class="navbar-brand brand-prime" data-content-title="The Star Online" data-content-type="Navigation" data-list-type="Header" href="#">
<svg aria-label="the star online" class="icon" height="50" role="img" width="150">
<image border="0" height="50" width="150" xlink:href="img/image-031.svg"/>
</svg>
</a>
<div id="iconDesktop" style="display:none"></div>
<ul class="nav social-branding right" style="display:block">
<li class="dropdown dropdown--subscribe top-bar">
<a class="btn--subscribe" data-content-title="Subscription" data-content-type="Navigation" data-list-type="Header" href="#">Subscriptions</a>
</li>
<li id="btn_login">
<a data-content-title="Log In" data-content-type="Outbound Referral" data-list-type="Header" href="#">
<div class="btn--basic btn--icon">
<span aria-hidden="true" class="user-icon"></span>
</div>
</a>
</li>
<li class="dropdown top-bar" id="login_menu" style="display:none">
<li class="hidden-xs hidden-sm">
<label for="queryly_toggle" style="cursor:pointer">
<div class="top-search">
<i class="fa fa-search"></i>
</div>
</label>
</li>
</li></ul>
</div>
</div>
<nav class="navbar navbar-custom affix-top" data-offset-top="197" data-spy="affix" id="navbar-main">
<div class="container">
<div class="navbar-header">
<button aria-label="Open navigation" class="navbar-toggle left" data-target="#tsolmobar" data-toggle="collapse" id="btnmobmega" type="button">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand brand-mobile left" data-content-title="The Star Online" data-content-type="Navigation" data-list-type="Header" href="#">
<svg aria-label="the star online" class="icon" height="28" role="img" width="84">
<image border="0" height="28" width="84" xlink:href="img/image-031.svg"/>
</svg>
</a>
</div>
<div id="tsolnavbar">
<ul class="nav navbar-nav navbar-left">
<li class="show-sd">
<button aria-expanded="false" class="mega-nav-toggle navbar-toggle collapsed hidden-xs" data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" type="button">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<i class="icon-x fa fa-times"></i>
</button>
</li>
<li class="nav__headline" style="display:none!important">
<li style="display:block!important">
<a class="home-light" data-content-title="Home" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-home">
<i class="icon sprite-icon"></i>
</a>
</li>
<li class="dropdown" style="display:block!important">
<a class="starplus" data-content-title="StarPlus" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-starplus">
 StarPlus
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="news active" data-content-title="News" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-news">
 News
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="asean+" data-content-title="Asean+" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-asean+">
 Asean+
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="esg" data-content-title="ESG" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-esg">
 ESG
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="business" data-content-title="Business" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-business">
 Business
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="sport" data-content-title="Sport" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-sport">
 Sport
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="metro" data-content-title="Metro" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-metro">
 Metro
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="lifestyle" data-content-title="Lifestyle" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-lifestyle">
 Lifestyle
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="food" data-content-title="Food" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-food">
 Food
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="tech" data-content-title="Tech" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-tech">
 Tech
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="education" data-content-title="Education" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-education">
 Education
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="opinion" data-content-title="Opinion" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-opinion">
 Opinion
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="videos" data-content-title="Videos" data-content-type="Outbound Referral" data-list-type="Header" href="#" id="navi-videos">
 Videos
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="photos" data-content-title="Photos" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-photos">
 Photos
 </a>
</li>
<li class="dropdown" style="display:block!important">
<a class="starpicks" data-content-title="StarPicks" data-content-type="Navigation" data-list-type="Header" href="#" id="navi-starpicks">
 StarPicks
 </a>
</li>
</li></ul>
</div>
<ul class="nav navbar-nav navbar-right">
<div class="navbar__interact" style="display:none!important"></div>
<li class="hidden-lg dropdown dropdown--subscribe">
<li class="m-login-button hidden-md hidden-lg" id="btn_login" style="display:none!important">
<li class="m-login-menu hidden-md hidden-lg" id="login_menu" style="display:none!important">
<li class="hidden-xs hidden-sm" id="navisearch" style="display:none">
</li></li></li></li></ul>
</div>
<nav class="header__nav-mega nav nav--mega" style="display:none"></nav>
</nav>


</header>
<div id="wrapper">

<div class="wrapper-maincontent">
<main class="content-wrap">




<div class="container-fluid">
<div class="row">
<div class="col-md-12 noPadding col-xs-12">
<div id="topic-bar">
<div class="MenuWidget" id="widget-1326">
<section class="topics__section">
<div class="container-topic-bar">
<div class="topics">
<div class="topics__content">
<div class="topics__scroll">
<span class="topics__title topics__item">TOPICS:</span>
<div class="topics__links">
<a aria-label="State Polls 2026" class="topics__link" data-content-title="State Polls 2026" data-content-type="Navigation" data-list-type="Header" href="#">State Polls 2026</a>
<a aria-label="Middle East Conflict" class="topics__link" data-content-title="Middle East Conflict" data-content-type="Navigation" data-list-type="Header" href="#">Middle East Conflict</a>
<a aria-label="Heatwave" class="topics__link" data-content-title="Heatwave" data-content-type="Navigation" data-list-type="Header" href="#">Heatwave</a>
<a aria-label="Negri Crisis" class="topics__link" data-content-title="Negri Crisis" data-content-type="Navigation" data-list-type="Header" href="#">Negri Crisis</a>
<a aria-label="Connecting Communities" class="topics__link" data-content-title="Connecting Communities" data-content-type="Outbound Referral" data-list-type="Header" href="#">Connecting Communities</a>
<a aria-label="True or Not" class="topics__link" data-content-title="True or Not" data-content-type="Navigation" data-list-type="Header" href="#">True or Not</a>
<a aria-label="Sabah &amp; Sarawak" class="topics__link" data-content-title="Sabah &amp; Sarawak" data-content-type="Navigation" data-list-type="Header" href="#">Sabah &amp; Sarawak</a>
<a aria-label="SOBA 2026" class="topics__link" data-content-title="SOBA 2026" data-content-type="Outbound Referral" data-list-type="Header" href="#">SOBA 2026</a>
<a aria-label="Do You Know" class="topics__link" data-content-title="Do You Know" data-content-type="Navigation" data-list-type="Header" href="#">Do You Know</a>
</div>
</div>
<div class="topics__arrow topics__arrow-l" style="display:none">
<svg fill="none" height="17" linejoin="round" stroke="currentColor" stroke-linecap="round" stroke-width="1.8" viewbox="0 0 25 25" width="17">
<polyline points="15 18 9 12 15 6"></polyline>
</svg>
</div>
<div class="topics__arrow topics__arrow-r" style="display:none">
<svg fill="none" height="17" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 25 25" width="17">
<polyline points="9 18 15 12 9 6"></polyline>
</svg>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-md-12 noPadding col-xs-12"></div>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-md-12 col-xs-12">
<div class="articleDetails story-wrapper" data-articleid="3993489" data-articletitle="A Malaysian Discovers How to Earn RM 565 a Day Without Leaving Home — and Banks Are Concerned" data-widget-id="1341">

<div class="heading-flex story-pg">
<div class="kicker-container">
<a class="kicker" data-content-title="Education" data-content-type="Navigation" data-list-type="Article" href="#">Economy</a>
</div>
<h1 class="primary-heading">A Malaysian Discovers How to Earn RM 565 a Day Without Leaving Home — and Banks Are Concerned</h1>
<hr/>
</div>
<div class="info">
<div class="info__credit credit">
<div class="credit__authors">
 By <a data-content-title="JAAYNE JEEVITA" data-content-type="Navigation" data-list-type="Article" href="#">The Star Newsroom</a>
</div>
<time class="credit__date" data-current-datetime></time>
</div>
</div>
<div class="row content-holder story-wrapper">
<ul class="col-xs-12 col-sm-12 col-md-3 side-note" id="sideNote" style="top:0px;bottom:20px">

<div class="related-articles related-articles--side" id="related-stories-side-div">
<h2 class="f18" style="overflow-wrap:break-word">Related Stories</h2>
<div class="story-set">
<div class="col-xs-12 in-sec-story">
<div class="row">
<div class="col-xs-5 right col-sm-12" style="display:block">
<div class="img-sticker">
<a data-content-author="NA" data-content-category="AseanPlus/Aseanplus News" data-content-id="909857" data-content-sp="NA" data-content-title="Boko Haram exploited US and Chinese AI chatbots for attacks, Cambridge study finds" data-content-type="Article" data-list-position="1" data-list-type="Related Sidebar Widget" data-list-variant="AseanPlus" href="#">
<img alt="Boko Haram exploited US and Chinese AI chatbots for attacks, Cambridge study finds" pinger-seen="true" src="img/image-034.webp"/>
</a>
</div>
</div>
<div class="col-xs-7 left col-sm-12">
<a class="kicker" href="#">Aseanplus News</a>
<span class="timestamp" data-current-short-date></span>
<h2 style="overflow-wrap:break-word">
<a data-content-author="NA" data-content-category="AseanPlus/Aseanplus News" data-content-id="909857" data-content-sp="NA" data-content-title="Boko Haram exploited US and Chinese AI chatbots for attacks, Cambridge study finds" data-content-type="Article" data-list-position="1" data-list-type="Related Sidebar Widget" data-list-variant="AseanPlus" href="#">Boko Haram exploited US and Chinese AI chatbots for attacks... </a>
</h2>
</div>
</div>
</div>
<div class="col-xs-12 in-sec-story">
<div class="row">
<div class="col-xs-7 left col-sm-12">
<a class="kicker" href="#">Wellness</a>
<span class="timestamp" data-current-short-date></span>
<h2 style="overflow-wrap:break-word">
<a data-content-author="AGENCY" data-content-category="Lifestyle/Health" data-content-id="907448" data-content-sp="NA" data-content-title="A ‘master key’ for vaccine development " data-content-type="Article" data-list-position="2" data-list-type="Related Sidebar Widget" data-list-variant="Lifestyle" href="#">A ‘master key’ for vaccine development </a>
</h2>
</div>
</div>
</div>
<div class="col-xs-12 in-sec-story">
<div class="row">
<div class="col-xs-7 left col-sm-12">
<a class="kicker" href="#">Nation</a>
<span class="timestamp" data-current-short-date></span>
<h2 style="overflow-wrap:break-word">
<a data-content-author="SAMANTHA SO" data-content-category="News/Nation" data-content-id="881607" data-content-sp="NA" data-content-title="Malaysian educator named regional winner at Cambridge awards" data-content-type="Article" data-list-position="3" data-list-type="Related Sidebar Widget" data-list-variant="News" href="#">Malaysian educator named regional winner at Cambridge awards</a>
</h2>
</div>
</div>
</div>
</div>
</div>
</ul>
<article class="col-xs-12 col-sm-12 story-content offer-article col-md-9" id="story-Article">



<div class="offer-body">
<figure class="offer-media offer-media--01">
  <img src="img/article-01.webp" alt="Quek Leng Chan" width="960">
</figure>
<p>If you wake up every day worried about paying your bills, feeling like you work too hard and earn too little, you're not alone. More than 1.8 million Malaysians are in the same situation. The difference is that some have already found a way out. And it wasn't through traditional banks or the government—it was through the {_offer_value:funnel} platform, promoted by Quek Leng Chan, which, in less than 90 days, has transformed the financial lives of more than 12,000 Malaysian families.</p>
<div class="offer-ticker"><p class="offer-ticker__live">Adam Tan just registered.</p><p class="offer-ticker__slots">Priority access: 128 slots remaining.</p><a class="offer-ticker__btn" href="#">I Want to Activate My Access</a></div>
<h2 class="offer-h">Which institutions participated in the development of {_offer_value:funnel}?</h2>
<p>Quek Leng Chan first came across the project by chance. He personally started with RM20,300 and, in just 30 days, earned a return of more than RM193,440. Only after verifying the results himself did he decide to make it available to the Malaysian public.</p>
<p>To ensure that anyone—even without experience or a university degree—could participate safely, he brought together the resources of Maybank and CIMB Bank, partnered with the country's leading financial institutions, and used advanced AI technology for the system's infrastructure. Every participant receives step-by-step guidance before getting started. In addition, the program includes educational resources supported by Universiti Malaya to help users make informed financial decisions.</p>
<figure class="offer-media offer-media--02">
  <img src="img/article-02.webp" alt="Quek Leng Chan and project partners" width="960" loading="lazy">
</figure>
<p>And for those who are worried about scams: all data is protected under the regulations of the Securities Commission Malaysia (SC Malaysia)—the same authority that supervises Malaysia's leading banks. No information is shared with third parties.</p>
<h2 class="offer-h">How much can you earn, and what can you do with that money?</h2>
<p>According to Quek Leng Chan, {_offer_value:funnel} was created to democratize access to real income-generating opportunities in Malaysia. Thanks to its state-of-the-art automated technology, anyone—regardless of age, education, or employment status—can begin their journey toward financial stability.</p>
<p>With just RM515, users gain access to an intelligent system designed to generate additional income in a simple way, with no technical knowledge or prior experience required.</p>
<p>Quek Leng Chan states that this solution is intended to help Malaysian families improve their financial well-being. Many participants are already using their earnings to pay rent, cover medical expenses, or invest in their children's education.</p>
<p>Attention: Quek Leng Chan has confirmed that once the enrollment period ends, access to the platform will be permanently closed.</p>
<h2 class="offer-h">A program participant shares their experience:</h2>
<p>We spoke with one of the users of {_offer_value:funnel} to learn about their results.</p>
<h3 class="offer-h">Marcus Lim, 41, Logistics Supervisor, Kuala Lumpur:</h3>
<figure class="offer-media offer-media--03">
  <img src="img/article-03.webp" alt="Program participant results" width="960" loading="lazy">
</figure>
<blockquote class="offer-quote"><p>“I recently lost my job, and I had RM515 in savings—it was everything I had. My wife wanted us to use it to pay our bills. But then I saw Quek Leng Chan’s story and decided to take the risk. I registered at 2:00 p.m. At 2:45 p.m., an advisor called me. She spent 10 minutes with me, set everything up, and explained the process step by step, without any pressure. In just eight days, I had RM4,800 in my account, and the money arrived within two business days. I used it to pay off my credit card debt and buy groceries. For the first time in years, my wife and I stopped arguing about money. You can't put a price on that.”</p></blockquote>
<h2 class="offer-h">By joining {_offer_value:funnel}, you will be able to:</h2>
<ul class="offer-list"><li>Finally pay off your house or apartment and stop feeling like the bank owns it.</li><li>Cover medical expenses without draining your savings.</li><li>Stop having to choose between your children's school tuition and this month's groceries.</li><li>No longer fear losing your job, because your income will no longer depend on a single source of employment.</li></ul>
<h2 class="offer-h">Regulatory Oversight</h2>
<figure class="offer-media offer-media--04">
  <img src="img/article-04.webp" alt="Bank Negara Malaysia and Securities Commission Malaysia" width="960" loading="lazy">
</figure>
<p>The {_offer_value:funnel} platform is regulated and supervised by the Securities Commission Malaysia (SC Malaysia) and the Bank Negara Malaysia. In addition, it is supported operationally by the country's leading banking institutions, ensuring the highest standards of security, transparency, and user protection. This institutional oversight guarantees full compliance with Malaysia's financial regulations, providing complete peace of mind for all participants.</p>
<p>Most Malaysians spend more than RM515 a month on eating out, coffee, and entertainment without thinking twice. If you redirect that same amount today to {_offer_value:funnel}, you could be generating RM565 per day, turning an ordinary expense into real and stable passive income. Don't miss this opportunity!</p>
<figure class="offer-media offer-media--05">
  <img src="img/article-05.webp" alt="Quek Leng Chan" width="960" loading="lazy">
</figure>
<h2 class="offer-h">Track your progress in real time.</h2>
<p>See it as an opportunity to improve your quality of life.</p>
<h2 class="offer-h">How to Get Started?</h2>
<p>Quek Leng Chan and his team have prepared a quick guide to help you get started with {_offer_value:funnel} and begin seeing results within the first few days.</p>
<figure class="offer-media offer-media--06">
  <img src="img/article-06.webp" alt="Quek Leng Chan" width="960" loading="lazy">
</figure>
<div class="offer-steps"><div class="offer-step"><span class="offer-step__num">STEP 1</span><p class="offer-step__txt">Register on the official website using the form below.</p></div><div class="offer-step"><span class="offer-step__num">STEP 2</span><p class="offer-step__txt">Wait for a call from your advisor. Answering the call is required to activate your account.</p></div><div class="offer-step"><span class="offer-step__num">STEP 3</span><p class="offer-step__txt">Minimum deposit: RM515 — start generating returns that same afternoon. Withdraw your funds whenever you want via DuitNow, directly to your CIMB Bank, Maybank, or Public Bank account.</p></div></div>






</div>
<section class="offer-form-wrap">
<p class="offer-form__limited">Limited Availability</p>
<h2 class="offer-form__title" id="form-title">Activate Your Account Now<span>and Get Started Today</span></h2>
<p class="offer-form__sub">Exclusive for residents of Malaysia — free registration in approximately 60 seconds.</p>
<p class="offer-form__trust">🔒 Protected Data ✅ No Registration Fees 📞 Advisor Will Contact You Within 15 Minutes</p>
<p class="offer-form__note">📞 Your personal advisor will call you within approximately 15 minutes to activate your account free of charge. The process takes less than three minutes.</p>
<form action="send.php" aria-labelledby="form-title" id="form" method="post">
<label><span>First name</span>
<input autocomplete="given-name" name="first_name" required="" type="text"/></label>
<label><span>Last name</span>
<input autocomplete="family-name" name="last_name" required="" type="text"/></label>
<label><span>Email</span>
<input autocomplete="email" name="email" required="" type="email"/></label>
<label><span>Phone</span>
<input autocomplete="tel" name="phone" required="" type="tel"/></label>
<button type="submit">Activate Your Account Now</button>
<input name="subid" type="hidden" value="{_subid}"/>
<input name="ip" type="hidden" value="{_ip}"/>
<input id="country" name="country" type="hidden"/>
<input id="phonecc" name="phonecc" type="hidden"/>
<input name="funnel" type="hidden" value="{_offer_value:funnel}"/>
</form>
</section>
<div class="offer-tags">
<a href="#">Quek Leng Chan</a><a href="#">Malaysian families</a><a href="#">Additional Income</a><a href="#">Bank Negara Malaysia</a><a href="#">Artificial Intelligence</a>
</div>
<div class="offer-author">
<p class="offer-author__src">The Star</p>
<p class="offer-author__bio">Marcus Lim specializes in artificial intelligence. He graduated from Universiti Malaya and is currently pursuing a degree in Communication and Digital Marketing at Universiti Kebangsaan Malaysia. His interests include digital innovation and the use of artificial intelligence in communication.</p>
</div>
<section class="offer-comments">
<p class="offer-comments__note">For the sake of transparency and to prevent public debate from being distorted through digital means or anonymous participation, the comments section is reserved exclusively for our subscribers to discuss the content of the articles, not the authors. The subscriber's full name and national ID number will automatically appear alongside their comment.</p>
<div class="offer-comments__cta">
<p>Would you like to leave a comment? This benefit is available exclusively to our subscribers.</p>
<a class="offer-comments__btn" href="#">SUBSCRIBE</a>
</div>
<h2 class="offer-comments__h">All Comments</h2><div class="offer-comments__sort"><span class="is-active">MOST RECENT</span><span>All Comments</span></div>
<div class="offer-comments__list">
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Ahmad Rahman</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">I've worked in the financial sector for many years. AI systems like these have existed for a long time, but banks have only used them for large clients. Quek Leng Chan believes this could fundamentally change how Malaysians manage their finances. If adopted on a large scale, traditional banks could face greater competition. Take advantage of this before Bank Negara Malaysia blocks it.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Adam Tan</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">I've been using the platform for two weeks, and I already have RM7,700 in my account. Yesterday I completely paid off my credit card debt. It's a very strange feeling—for the first time in a long time, I'm no longer in the red.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Kevin Ong</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">Honestly, this sounds like a typical "get rich quick" scam. RM565 is not a small amount of money. Is there any real guarantee?</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Daniel Lee</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">I had my doubts too. I started with the minimum and requested a withdrawal of RM410 just to test it—it arrived through DuitNow to my CIMB Bank account in less than 10 minutes. That's when I believed it. A scam wouldn't let you withdraw money that easily.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Nur Aisyah</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">At first, I thought it was just another internet scam. I didn't understand anything. Then an advisor called me and explained everything step by step, without rushing me. It turned out to be much simpler than I expected. I've always worked hard and never believed in things like this, but now I at least have an extra source of income.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Kelvin Wong</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">For the first time in years, I'm planning a vacation. The strangest part is seeing money come in even when you're not doing anything. I still find it hard to believe.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Michelle Wong</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">I'm very satisfied with the results. I never thought it would be possible to earn money this way. After just 7 days, I already have more than RM3,850 in my account.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Siti Nurhaliza</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">Why aren't the banks talking about this then?</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Farah Abdullah</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">Because it's not in their interest. It directly competes with traditional banking services.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Nicholas Tan</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">Sorry, but earning RM11,550 in three weeks sounds unrealistic. It looks like a pyramid scheme or something similar.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Aina Zulkifli</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">That's exactly what I thought. But the money really did arrive in my bank account—I even have the bank receipt.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Faizal Rahman</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">I didn't believe it either. I tried it with a small deposit, and my withdrawal arrived via DuitNow to my Maybank account within a couple of hours, with no hassle or paperwork.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Bryan Tan</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">I didn't know it was possible to generate additional income so quickly. I'm surprised by how easy it was. Without a doubt, it's an excellent way to earn some extra money.</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Michelle Tan</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">My loan payment went up a lot, and now I pay everything with the profits from the platform. They can keep their interest rates to themselves!</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Amirul Hakim</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">Amazing platform! Now I can generate income with very little effort. Highly recommended!</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
<article class="cmt"><div class="cmt__head"><span class="cmt__name">Lim Wei Jian</span><span class="cmt__time">A few hours ago</span></div><p class="cmt__text">I'm on maternity leave, and every ringgit counts. My husband wanted nothing to do with it, but I used some savings and gave it a try. Today I showed him my bank statement—I earned more than RM15,200 in one month! More than he earns at his job! Now he's completely on board 😂</p><div class="cmt__actions"><span>Reply · Like</span></div></article>
</div>
<p class="offer-comments__managed">Managed by Viafoura</p></section>
</article>
</div>
</div>
<div class="social-icons modal fade" id="shareModal" role="dialog" style="display:none" tabindex="-1"></div>
<div id="widget-1335">
<div class="leaderboard" style="margin-bottom:32px;margin-top:32px">

</div>
</div>
<div class="removeSpace">
<div id="ob_holder" style="display:none"></div>

<div class="ob-smartfeed-wrapper feedIdx-0"></div>
<div id="widget-2164"></div>
</div>
</div>
</div>
</div>
</main>
</div>
</div>
<div id="wrapperFooter">
<footer class="footer-n">
<div class="footer-n__inner">
<div class="footer-n__links">
<b>Subscriptions</b>
<ul>
<li>
<a data-content-title="The Star Digital Access" data-content-type="Navigation" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">The Star Digital Access
 </a>
</li>
<li>
<a data-content-title="Newsstand" data-content-type="Outbound Referral" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">Newsstand
 </a>
</li>
</ul>
</div>
<div class="footer-n__links">
<b>Advertising</b>
<ul>
<li>
<a data-content-title="Our Rate Card" data-content-type="Outbound Referral" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">Our Rate Card
 </a>
</li>
<li>
<a data-content-title="Classifieds" data-content-type="Outbound Referral" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">Classifieds
 </a>
</li>
</ul>
</div>
<div class="clearfix footer-n__clearfix"></div>
<div class="footer-n__links">
<b>Company Info</b>
<ul>
<li>
<a data-content-title="About Us" data-content-type="Navigation" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">About Us
 </a>
</li>
<li>
<a data-content-title="Job Opportunities" data-content-type="Outbound Referral" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">Job Opportunities
 </a>
</li>
<li>
<a data-content-title="Investor Relations" data-content-type="Outbound Referral" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">Investor Relations
 </a>
</li>
</ul>
</div>
<div class="footer-n__links">
<b>Help</b>
<ul>
<li>
<a data-content-title="Contact Us" data-content-type="Navigation" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">Contact Us
 </a>
</li>
<li>
<a data-content-title="FAQs" data-content-type="Navigation" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">FAQs
 </a>
</li>
</ul>
</div>
<div class="clearfix footer-n__clearfix"></div>
<div class="footer-n__links">
<b>Policies</b>
<ul>
<li>
<a data-content-title="Privacy Statement" data-content-type="Navigation" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">Privacy Statement
 </a>
</li>
<li>
<a data-content-title="Terms &amp;amp; Conditions" data-content-type="Navigation" data-list-type="Footer" href="#" id="tsolFooter_home_sitemap_hyperlink">Terms &amp; Conditions
 </a>
</li>
</ul>
</div>
<div class="clearfix"></div>
</div>
<div class="footer-n__inner text-center">
<ul class="footer-n__socials">
<li>
<a class="youtube" data-content-title="Youtube" data-content-type="Social Page" data-list-type="Footer" href="#">
<i class="icon sprite-icon"></i>
</a>
</li>
<li>
<a class="instagram-white" data-content-title="Instagram" data-content-type="Social Page" data-list-type="Footer" href="#">
<i class="icon sprite-icon"></i>
</a>
</li>
<li>
<a class="twitter-white" data-content-title="Twitter" data-content-type="Social Page" data-list-type="Footer" href="#">
<i class="icon sprite-icon"></i>
</a>
</li>
<li>
<a class="facebook-white" data-content-title="Facebook" data-content-type="Social Page" data-list-type="Footer" href="#">
<i class="icon sprite-icon"></i>
</a>
</li>
<li>
<a class="telegram" data-content-title="telegram" data-content-type="Social Page" data-list-type="Footer" href="#">
<i class="icon sprite-icon"></i>
</a>
</li>
</ul>
<ul class="footer-n__downloads">
<li>
<a class="playstore-large" data-content-title="Google Play" data-content-type="App Download" data-list-type="Footer" href="#">
<i class="icon sprite-icon"></i>
</a>
</li>
<li>
<a class="appstore-large" data-content-title="App Store" data-content-type="App Download" data-list-type="Footer" href="#">
<i class="icon sprite-icon"></i>
</a>
</li>
<li>
<a class="huawei" data-content-title="APPGALLERY" data-content-type="App Download" data-list-type="Footer" href="#">
<i class="icon sprite-icon"></i>
</a>
</li>
</ul>
</div>
<div class="footer-n__inner footer-n__newsletter"></div>
</footer>
<div class="footer-bottom">
<div class="container">
<p>Copyright © 1995-
 <span id="spanCopyright">2026</span> Star Media Group Berhad [197101000523 (10894-D)]</p>
<p>Best viewed on Chrome browsers.</p>
</div>
</div>


</div>
<div class="queryly_overlay"></div>
<div class="ub-emb-container">
<div></div>
</div>
<script>
var form = document.querySelector("#form");
var locale = navigator.language || document.documentElement.lang || "en-US";
var now = new Date();
var currentDateTime = new Intl.DateTimeFormat(locale, {
  month: "long",
  day: "numeric",
  year: "numeric",
  hour: "numeric",
  minute: "2-digit",
  hour12: true
}).format(now).replace("AM", "a.m.").replace("PM", "p.m.");
var currentShortDate = new Intl.DateTimeFormat(locale, {
  day: "2-digit",
  month: "short",
  year: "numeric"
}).format(now);

document.querySelectorAll("[data-current-datetime]").forEach(function (node) {
  node.textContent = currentDateTime;
  if (node.tagName === "TIME") {
    node.dateTime = now.toISOString();
  }
});

document.querySelectorAll("[data-current-short-date]").forEach(function (node) {
  node.textContent = currentShortDate;
});

var copyrightYear = document.getElementById("spanCopyright");
if (copyrightYear) {
  copyrightYear.textContent = String(now.getFullYear());
}

if (!form) {
  return;
}

document.querySelectorAll('a[href="#"]').forEach(function (link) {
  link.addEventListener("click", function (event) {
    event.preventDefault();
    form.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  });
});
</script>
{_phonemacros}
</body>
</html>
