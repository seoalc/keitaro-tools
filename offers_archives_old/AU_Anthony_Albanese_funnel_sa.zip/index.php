<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<html lang="en"><head>
<meta charset="UTF-8">
    <style type="text/css" class="bc-style-BXpiIlK5Q-default">.bc-player-BXpiIlK5Q_default *,
      .bc-player-BXpiIlK5Q_default :after,
      .bc-player-BXpiIlK5Q_default :before {
        box-sizing: inherit;
        font-size: inherit;
        color: inherit;
        line-height: inherit;
      }

      .bc-player-BXpiIlK5Q_default {
        width: 300px;
        height: 150px;
        font-size: 14px;
        overflow: hidden;
      }

      .bc-player-BXpiIlK5Q_default.vjs-fluid.vjs-16-9:not(.vjs-audio-only-mode),
      .bc-player-BXpiIlK5Q_default.vjs-fluid:not(.vjs-audio-only-mode) {
        padding-top: 56.25%;
      }

      .bc-player-BXpiIlK5Q_default.vjs-fluid.vjs-4-3:not(.vjs-audio-only-mode) {
        padding-top: 75%;
      }

      .bc-player-BXpiIlK5Q_default.vjs-fill:not(.vjs-audio-only-mode) {
        width: 100%;
        height: 100%;
      }

      .bc-iframe,
      .bc-iframe body,
      .bc-player-BXpiIlK5Q_default,
      .bc-player-BXpiIlK5Q_default .vjs-poster {
        background-color: #151b17;
      }

      .bc-iframe,
      .bc-iframe .bc-player-BXpiIlK5Q_default,
      .bc-iframe body {
        margin: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
      }

      .bc-player-BXpiIlK5Q_default.vjs-fullscreen,
      .bc-player-BXpiIlK5Q_default.vjs-fullscreen .vjs-tech {
        width: 100% !important;
        height: 100% !important;
      }

      .bc-player-BXpiIlK5Q_default .vjs-track-setting select {
        color: #000;
        background-color: #fff;
      }

      .bc-player-BXpiIlK5Q_default .vjs-audio-button .vjs-menu-item,
      .bc-player-BXpiIlK5Q_default .vjs-chapters-button .vjs-menu-item,
      .bc-player-BXpiIlK5Q_default .vjs-descriptions-button .vjs-menu-item,
      .bc-player-BXpiIlK5Q_default .vjs-subs-caps-button .vjs-menu-item {
        text-transform: none;
      }

      .bc-player-BXpiIlK5Q_default.vjs-waiting-for-autoplay
        .vjs-big-play-button {
        opacity: 0;
      }

      .bc-player-BXpiIlK5Q_default .vjs-progress-control .vjs-mouse-display {
        z-index: 2;
      }

      /*! @name @brightcove/player-core @version 2.7.4 @license UNLICENSED */
      .vjs-download-button {
        cursor: pointer;
      }

      .vjs-download-button.has-icon-downloading {
        cursor: wait;
      }

      .vjs-download-button .vjs-icon-placeholder {
        font-family: VideoJS;
        font-weight: 400;
        font-style: normal;
      }

      .vjs-download-button.has-icon-file-download .vjs-icon-placeholder:before {
        content: "\f110";
      }

      .vjs-download-button.has-icon-downloading .vjs-icon-placeholder:before {
        content: "\f10f";
      }

      .vjs-download-button.has-icon-file-download-off
        .vjs-icon-placeholder:before {
        content: "\f112";
      }

      .vjs-modal-dialog.vjs-player-info-modal {
        background: rgba(0, 0, 0, 0.9);
      }

      .vjs-modal-dialog.vjs-player-info-modal .vjs-modal-dialog-content {
        overflow: auto;
        display: grid;
        grid-template-columns: 1fr 1fr;
        grid-gap: 1em;
      }

      @media screen and (max-width: 640px) {
        .vjs-modal-dialog.vjs-player-info-modal .vjs-modal-dialog-content {
          grid-template-columns: 1fr;
        }
      }

      .vjs-modal-dialog.vjs-player-info-modal h2 {
        font-size: 1.1667em;
        margin: 0 0 0.4286em;
      }

      .vjs-modal-dialog.vjs-player-info-modal table {
        border-bottom: 1px solid #333;
        border-collapse: collapse;
        border-top: 1px solid #333;
        margin-bottom: 1.5em;
        width: 100%;
      }

      .vjs-modal-dialog.vjs-player-info-modal table.vjs-two td,
      .vjs-modal-dialog.vjs-player-info-modal table.vjs-two th {
        width: 50%;
      }

      .vjs-modal-dialog.vjs-player-info-modal table.vjs-three td,
      .vjs-modal-dialog.vjs-player-info-modal table.vjs-three th {
        width: 33.333%;
      }

      .vjs-modal-dialog.vjs-player-info-modal th {
        font-weight: 400;
        text-align: left;
      }

      .vjs-modal-dialog.vjs-player-info-modal td {
        border-bottom: 1px solid #333;
        opacity: 0.5;
      }

      .vjs-modal-dialog.vjs-player-info-modal tr:last-child td {
        border-bottom: 0;
      }

      .vjs-modal-dialog.vjs-player-info-modal tr:hover td {
        opacity: 1;
      }

      /*! @name videojs-contextmenu-ui @version 7.0.0 @license Apache-2.0 */
      .vjs-contextmenu-ui-menu {
        position: absolute;
      }

      .vjs-contextmenu-ui-menu .vjs-menu-content {
        background-color: #2b333f;
        background-color: rgba(43, 51, 63, 0.7);
        border-radius: 0.3em;
        padding: 0.25em;
      }

      .vjs-contextmenu-ui-menu .vjs-menu-item {
        border-radius: 0.3em;
        cursor: pointer;
        margin: 0 0 1px;
        padding: 0.5em 1em;
        font-size: 1em;
        line-height: 1.2;
        text-transform: none;
      }

      .vjs-contextmenu-ui-menu .vjs-menu-item:active,
      .vjs-contextmenu-ui-menu .vjs-menu-item:hover {
        background-color: rgba(0, 0, 0, 0.5);
        text-shadow: 0 0 1em #fff;
      }

      /*! @name videojs-errors @version 6.1.0 @license Apache-2.0 */
      .vjs-error-display {
        color: #fff;
        display: none;
        font-family:
          Helvetica,
          Arial,
          sans serif;
        font-size: 16px;
        line-height: 1.428;
      }

      .vjs-error .vjs-error-display {
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
      }

      .vjs-error .vjs-error-display .vjs-modal-dialog-content {
        font-size: 14px;
      }

      .vjs-errors-dialog {
        text-align: left;
        border: 1px #999 solid;
        overflow: hidden;
        position: absolute;
        top: 2%;
        bottom: 2%;
        left: 5%;
        right: 5%;
        padding-left: 1%;
        padding-right: 1%;
        background: rgba(24, 24, 24, 0.8);
      }

      .vjs-errors-details {
        margin-top: 15px;
      }

      .vjs-errors-message {
        border: 1px #999 solid;
        background-color: #2c2c2c;
        overflow: auto;
        margin-top: 15px;
        padding: 15px;
      }

      .vjs-errors-ok-button-container {
        display: block;
        position: absolute;
        bottom: 15px;
        left: 15px;
        right: 15px;
        text-align: center;
      }

      .vjs-errors-ok-button,
      .vjs-errors-timeout-button-container button {
        display: block;
        height: 36px;
        background-color: #000;
        border: 1px #999 solid;
        border-radius: 5px;
        color: #999;
        font-size: 14px;
        cursor: pointer;
      }

      .vjs-errors-ok-button {
        margin: 0 auto;
        width: 80px;
      }

      .vjs-errors-ok-button:hover,
      .vjs-errors-timeout-button-container button:hover {
        border: 1px #fff solid;
        color: #ccc;
      }

      .vjs-errors-timeout-button-container {
        display: flex;
        flex-direction: row;
        justify-content: center;
        gap: 10px;
        position: absolute;
        bottom: 15px;
        left: 15px;
        right: 15px;
        text-align: center;
      }

      .vjs-errors-timeout-button-container button {
        width: 120px;
      }

      .vjs-errors-content-container {
        overflow: auto;
        position: absolute;
        padding-bottom: 15px;
        top: 0;
        left: 15px;
        right: 15px;
        bottom: 61px;
      }

      .vjs-errors-headline {
        font-size: 14px;
        font-weight: 700;
        padding-right: 3em;
      }

      .vjs-errors-dialog .vjs-control.vjs-close-button {
        width: 3em;
        height: 3em;
        top: 0;
      }

      .vjs-xs.vjs-error-display {
        font-size: 14px;
        background-color: #000;
      }

      .vjs-xs.vjs-error-display .vjs-errors-details,
      .vjs-xs.vjs-error-display .vjs-errors-message {
        display: none;
      }

      .vjs-xs .vjs-errors-content-container {
        top: 0;
      }

      .vjs-xs .vjs-errors-headline {
        font-size: 16px;
        font-weight: 700;
      }

      .vjs-xs .vjs-errors-dialog {
        border: 0;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
      }

      @media (max-width: 600px), (max-height: 250px) {
        .vjs-error-display {
          font-size: 14px;
          background-color: #000;
        }

        .vjs-error-display .vjs-errors-details,
        .vjs-error-display .vjs-errors-message {
          display: none;
        }

        .vjs-error-display .vjs-errors-content-container {
          top: 15px;
        }

        .vjs-error-display .vjs-errors-headline {
          font-size: 16px;
          font-weight: 700;
        }

        .vjs-error-display .vjs-errors-dialog {
          border: 0;
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
        }
      }

      .vjs-errors-ref-id {
        color: rgba(255, 255, 255, 0.5);
        font-size: 0.75em;
        margin: 0.5em 0 0;
      }

      .bc-player-BXpiIlK5Q_default .vjs-big-play-button,
      .bc-player-BXpiIlK5Q_default
        .vjs-big-play-state.vjs-play-control.vjs-control,
      .bc-player-BXpiIlK5Q_default .vjs-control-bar {
        background-color: rgba(0, 0, 0, 0.45);
      }

      .bc-player-BXpiIlK5Q_default .vjs-big-play-button,
      .bc-player-BXpiIlK5Q_default .vjs-big-play-state,
      .bc-player-BXpiIlK5Q_default .vjs-control-bar {
        color: #fff;
      }

      .bc-iframe .vjs-playlist-sidebar .vjs-playlist-show-hide button:hover,
      .bc-player-BXpiIlK5Q_default .vjs-big-play-button:active,
      .bc-player-BXpiIlK5Q_default .vjs-big-play-button:focus,
      .bc-player-BXpiIlK5Q_default
        .vjs-menu-button-popup
        .vjs-menu
        .vjs-menu-item.vjs-selected,
      .bc-player-BXpiIlK5Q_default .vjs-play-progress,
      .bc-player-BXpiIlK5Q_default .vjs-volume-level,
      .bc-player-BXpiIlK5Q_default:active .vjs-big-play-button,
      .bc-player-BXpiIlK5Q_default:hover .vjs-big-play-button {
        background-color: #d52484;
      }

      .bc-player-BXpiIlK5Q_default.vjs-audio-mode.vjs-has-started.vjs-focus-within.video-js.video-js.video-js
        .vjs-control-bar,
      .bc-player-BXpiIlK5Q_default.vjs-audio-mode.vjs-has-started.vjs-user-active.video-js.video-js.video-js
        .vjs-control-bar:not(.vjs-focus-within),
      .bc-player-BXpiIlK5Q_default.vjs-audio-mode.vjs-has-started.vjs-user-inactive.video-js.video-js.video-js
        .vjs-control-bar {
        opacity: 1;
        visibility: visible;
        transform: none;
      }

      .bc-player-BXpiIlK5Q_default.vjs-audio-only-mode .vjs-poster {
        display: none;
      }

      .bc-player-BXpiIlK5Q_default.vjs-audio-only-mode .vjs-progress-control {
        height: 1.5em;
        top: -1.5em;
      }

      .vjs-bumper-video .vjs-play-progress.vjs-play-progress-resetting {
        transition: width 0s linear;
      }

      .vjs-bumper-video .vjs-dock-text {
        display: none;
      }

      .vjs-ad-playing.vjs-ad-playing .vjs-progress-control {
        pointer-events: none;
      }

      .vjs-ad-playing.vjs-ad-playing .vjs-play-progress {
        background-color: #ffe400;
      }

      .vjs-ad-playing .vjs-captions-button {
        display: none;
      }

      .vjs-ad-playing .vjs-audio-button {
        display: none;
      }

      .vjs-ad-loading .vjs-loading-spinner {
        display: flex;
        justify-content: center;
        align-items: center;
        animation: vjs-spinner-show 0s linear 0.3s forwards;
      }

      .vjs-ad-loading .vjs-loading-spinner:after,
      .vjs-ad-loading .vjs-loading-spinner:before {
        animation:
          vjs-spinner-spin 1.1s cubic-bezier(0.6, 0.2, 0, 0.8) infinite,
          vjs-spinner-fade 1.1s linear infinite;
      }

      .vjs-ad-loading .vjs-loading-spinner:after {
        animation-delay: 0.44s;
      }

      .vjs-ad-content-resuming .vjs-big-play-button,
      .vjs-ad-content-resuming .vjs-poster,
      .vjs-ad-loading .vjs-big-play-button,
      .vjs-ad-loading .vjs-poster {
        display: none;
      }

      .vjs-ima3-ad-container {
        bottom: 0;
        left: 0;
        position: absolute;
        right: 0;
        top: 0;
        pointer-events: none;
      }

      .vjs-ima3-html5 .vjs-ima3-ad-container > *,
      .vjs-ima3-html5 .vjs-ima3-ad-container > * iframe {
        width: 100% !important;
        height: 100% !important;
      }

      .vjs-ima3-ad-background {
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0);
        position: absolute;
        top: 0;
        left: 0;
      }

      .vjs-ad-playing .vjs-ima3-ad-background {
        background-color: #000;
      }

      .vjs-ad-playing .vjs-ima3-ad-container,
      .vjs-ima3-overlay .vjs-ima3-ad-container {
        left: 0;
      }

      .vjs-mouse.vjs-ima3-html5.vjs-ad-playing .vjs-ima3-ad-container,
      .vjs-mouse.vjs-ima3-html5.vjs-ima3-overlay .vjs-ima3-ad-container {
        cursor: pointer;
        pointer-events: auto;
      }

      .vjs-user-active.vjs-ad-playing.vjs-ima3-html5 .vjs-ima3-ad-container,
      .vjs-user-active.vjs-ima3-overlay.vjs-ima3-html5 .vjs-ima3-ad-container {
        cursor: pointer;
        pointer-events: auto;
      }

      .vjs-ima3-html5.vjs-using-native-controls.vjs-ima3-paused.vjs-ima3-paused
        .vjs-ima3-ad-container {
        pointer-events: none;
      }

      .vjs-ad-controls.vjs-ad-playing.vjs-controls-disabled
        .vjs-ad-control-bar.vjs-ad-control-bar,
      .vjs-ad-controls.vjs-ad-playing.vjs-using-native-controls
        .vjs-ad-control-bar.vjs-ad-control-bar {
        display: none;
      }

      .vjs-ad-controls.vjs-ad-playing.vjs-user-active:not(.not-hover)
        .vjs-control-bar.vjs-ad-control-bar,
      .vjs-ad-controls.vjs-ad-playing.vjs-user-active:not(.vjs-hide-controls)
        .vjs-control-bar.vjs-ad-control-bar,
      .vjs-controls-enabled.vjs-ad-controls.vjs-ima3-overlay.vjs-user-active:not(
          .not-hover
        )
        .vjs-control-bar,
      .vjs-controls-enabled.vjs-ad-controls.vjs-ima3-overlay.vjs-user-active:not(
          .vjs-hide-controls
        )
        .vjs-control-bar {
        -ms-transform: none;
        -ms-transition: none;
        transform: none;
        transition: none;
      }

      .vjs-ad-playing .vjs-dock-shelf,
      .vjs-ad-playing .vjs-dock-text {
        display: none;
      }

      .vjs-ad-controls.vjs-ad-playing.vjs-vpaid-playing.vjs-vpaid-controls-disabled
        .vjs-control-bar.vjs-ad-control-bar {
        display: none;
      }

      .vjs-ad-loading .vjs-overlay,
      .vjs-ad-playing .vjs-overlay {
        display: none;
      }

      .vjs-ad-controls.vjs-ad-playing .vjs-control-bar.vjs-ad-control-bar {
        display: -webkit-box;
        display: -moz-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      }

      .vjs-ad-controls.vjs-ad-playing.vjs-no-flex
        .vjs-control-bar.vjs-ad-control-bar {
        display: table;
      }

      .vjs-mouse
        .vjs-control-bar.vjs-ad-control-bar
        .vjs-progress-control:hover {
        height: 0.5em;
        top: -0.5em;
      }

      .vjs-mouse
        .vjs-control-bar.vjs-ad-control-bar
        .vjs-progress-control:hover
        .vjs-mouse-display,
      .vjs-mouse
        .vjs-control-bar.vjs-ad-control-bar
        .vjs-progress-control:hover
        .vjs-mouse-display:after,
      .vjs-mouse .vjs-progress-control:hover .vjs-play-progress:after {
        display: none;
      }

      .vjs-ima3-html5.vjs-ad-loading .vjs-tech {
        opacity: 0;
      }

      .vjs-ima3-autoplay.vjs-ima3-not-playing-yet .vjs-poster,
      .vjs-ima3-autoplay.vjs-ima3-not-playing-yet .vjs-tech {
        opacity: 0;
      }

      .vjs-ima3-html5.vjs-ad-playing .vjs-ad-control-bar .vjs-play-progress {
        transition: width 1s linear;
      }

      .vjs-ima3-html5.vjs-ad-playing
        .vjs-ad-control-bar
        .vjs-play-progress.vjs-play-progress-resetting {
        transition: width 0s linear;
      }

      .vjs-ad-playing.vjs-ad-playing .vjs-progress-control {
        pointer-events: none;
      }

      .vjs-ad-playing.vjs-ad-playing .vjs-play-progress {
        background-color: #ffe400;
      }

      .vjs-ad-loading .vjs-loading-spinner {
        display: block;
        visibility: visible;
      }

      .vjs-ad-playing .vjs-captions-button {
        display: none;
      }

      .vjs-ad-playing .vjs-audio-button {
        display: none;
      }

      .vjs-ad-loading .vjs-loading-spinner:after,
      .vjs-ad-loading .vjs-loading-spinner:before {
        -webkit-animation:
          vjs-spinner-spin 1.1s cubic-bezier(0.6, 0.2, 0, 0.8) infinite,
          vjs-spinner-fade 1.1s linear infinite;
        animation:
          vjs-spinner-spin 1.1s cubic-bezier(0.6, 0.2, 0, 0.8) infinite,
          vjs-spinner-fade 1.1s linear infinite;
      }

      .vjs-ad-loading .vjs-loading-spinner:before {
        border-top-color: #fff;
      }

      .vjs-ad-loading .vjs-loading-spinner:after {
        border-top-color: #fff;
        -webkit-animation-delay: 0.44s;
        animation-delay: 0.44s;
      }

      .vjs-ad-content-resuming .vjs-big-play-button,
      .vjs-ad-content-resuming .vjs-poster,
      .vjs-ad-loading .vjs-big-play-button,
      .vjs-ad-loading .vjs-poster {
        display: none;
      }

      .vjs-ssai.vjs-ad-playing .vjs-volume-level {
        background-color: #ffe400;
      }

      .vjs-ssai .vjs-ssai-ad-marker {
        position: absolute;
        opacity: 1;
        height: 100%;
        background-color: #ffe400;
        width: 4px;
      }

      .vjs-ssai .vjs-ssai-ad-click-target {
        bottom: 0;
        display: none;
        height: 100%;
        left: 0;
        pointer-events: none;
        position: absolute;
        right: 0;
        top: 0;
        width: 100%;
      }

      .vjs-ssai.vjs-ad-playing.vjs-ssai-show-overlays
        .vjs-ssai-ad-click-target {
        cursor: pointer;
        display: block;
        pointer-events: auto;
      }

      .vjs-ssai .vjs-ssai-overlay {
        font-family: inherit;
        font-size: 12px;
        font-weight: inherit;
        margin: inherit;
      }

      .vjs-ssai .vjs-ssai-overlay-countdown {
        background-color: rgba(0, 0, 0, 0.5);
        display: table;
        left: 0;
        overflow: hidden;
        position: relative;
        top: 0;
        width: 100%;
      }

      .vjs-ssai .vjs-ssai-overlay-countdown .vjs-ssai-ad-time-remaining {
        float: left;
        padding: 0.83333em;
      }

      .vjs-ssai .vjs-ssai-overlay-countdown .vjs-ssai-learn-more {
        color: #fff;
        float: right;
        padding: 0.83333em;
      }

      .vjs-ssai .vjs-ssai-overlay-countdown .vjs-ssai-learn-more:hover {
        text-decoration: none;
      }

      .vjs-ssai .vjs-ssai-overlay-skip-ad,
      .vjs-ssai .vjs-ssai-skip-ad-countdown-overlay {
        bottom: 3.33333em;
        left: auto;
        position: absolute;
        right: 0.83333em;
        top: auto;
      }

      .vjs-ssai .vjs-ssai-overlay-skip-ad .vjs-ssai-skip-ad-btn {
        background-color: rgba(0, 0, 0, 0.5);
        border-radius: 0.41667em;
        cursor: pointer;
        padding: 0.83333em;
      }

      .vjs-ssai .vjs-ssai-overlay-skip-ad .vjs-ssai-skip-ad-btn:hover {
        text-decoration: underline;
      }

      .vjs-ssai
        .vjs-ssai-skip-ad-countdown-overlay
        .vjs-ssai-skip-ad-overlay-content {
        background-color: rgba(0, 0, 0, 0.5);
        border-radius: 0.41667em;
        padding: 0.83333em;
      }

      .vjs-ssai.vjs-ad-playing.vjs-ssai-show-overlays .vjs-dock-shelf,
      .vjs-ssai.vjs-ad-playing.vjs-ssai-show-overlays .vjs-dock-text {
        display: none;
      }

      .vjs-ssai.vjs-ended .vjs-poster.vjs-displayed {
        display: block;
      }

      .video-js .vjs-big-play-button {
        width: 100px;
        height: 100px;
        background-image: url('img/70b0de0797db27c70269304d02c4d187a29badb3.svg');
        background-size: contain;
        background-color: rgba(0, 0, 0, 0.5);
      }

      .video-js .vjs-big-play-button .vjs-icon-placeholder {
        display: none;
      }

      :hover.video-js .vjs-big-play-button {
        -webkit-transition:
          border-color 0.4s,
          outline 0.4s,
          background-color 0.4s;
        -moz-transition:
          border-color 0.4s,
          outline 0.4s,
          background-color 0.4s;
        -ms-transition:
          border-color 0.4s,
          outline 0.4s,
          background-color 0.4s;
        -o-transition:
          border-color 0.4s,
          outline 0.4s,
          background-color 0.4s;
        transition:
          border-color 0.4s,
          outline 0.4s,
          background-color 0.4s;
      }

      .video-js .vjs-big-play-button::before {
        content: "";
      }

      .video-js canvas {
        cursor: move;
      }

      .video-js .vjs-button-vr .vjs-icon-placeholder {
        height: 30px;
        width: 30px;
        display: inline-block;
        background: url("") no-repeat left center;
      }</style>
    <style class="bc-player-BXpiIlK5Q_default-index-0-video-dimensions">.bc-player-BXpiIlK5Q_default-index-0 {
        width: 316px;
        height: 199px;
      }

      .bc-player-BXpiIlK5Q_default-index-0.vjs-fluid:not(.vjs-audio-only-mode) {
        padding-top: 62.9746835443038%;
      }</style>
    <title>
      Anyone who starts with just 400 dollars can earn up to 40,000 dollars —
      zero risk, 100% government guarantee! | Sky News Australia
    </title>
    
    
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0">
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    

    <link rel="stylesheet" href="files/css-skynews-desktop-critical-article-custom.css">
    
    <link rel="stylesheet" href="files/style.css" data-indieid="Bl3C1B7wxdX5ftsQVGsO">
    
    
    
    
    
    
    
    

    
    <style id="tbl-editorial-video-style">video.tbl-editorial-video-element {
        width: auto;
        height: 100%;
        pointer-events: none;
      }

      video.tbl-editorial-video-element.tbl-ec-vertical {
        width: 100%;
        height: auto;
      }

      div.tbl-editorial-video-container {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: #fff;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.4s ease-in-out;
        border-radius: 8px;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      div.tbl-editorial-video-container.tbl-ec-playing {
        opacity: 1;
        pointer-events: auto;
      }</style>
    
    <link rel="stylesheet" href="files/css-skynews-desktop-lazy.css">
    <link rel="stylesheet" href="files/css-logos.css">
    <link rel="stylesheet" type="text/css" href="files/6558.55c1ea216fc1247cac2e.chunk.css">
    <link rel="stylesheet" type="text/css" href="files/8243.6f9e85c6bb932770270c.chunk.css">
    <link href="files/replayer-horizontal.css" rel="stylesheet">
    <link href="files/skynews.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="files/ncanative-skynewsau_amp_fonts.css">
    <style id="tRecs-taboola-choice">.trc_user_exclude_btn {
        background: url('img/f539211219b796ffbb49949997c764f0.png') no-repeat scroll
          0 0 rgba(0, 0, 0, 0);
        width: 12px;
        height: 12px;
        position: absolute;
        right: 2px;
        top: 2px;
        z-index: 9000;
        cursor: pointer;
        visibility: hidden;
      }

      .trc_exclude_undo_btn {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 11px;
        line-height: 14px;
        font-weight: normal;
        color: #36c;
        text-decoration: underline;
        cursor: pointer;
        position: absolute;
        right: 2px;
        top: 2px;
        padding: 0 1px;
        z-index: 11000;
        visibility: hidden;
      }

      .videoCube:hover .trc_user_exclude_btn,
      .videoCube_hover .trc_user_exclude_btn,
      .trc_user_excluded.videoCube:hover .trc_exclude_undo_btn,
      .trc_user_excluded.videoCube_hover .trc_exclude_undo_btn,
      .trc_exclude_undo_btn.trc_exclude_undo_btn_visible {
        visibility: visible;
      }

      .videoCube.trc_user_excluded .trc_user_exclude_btn {
        visibility: hidden;
      }

      .trc_fade {
        opacity: 0;
        filter: alpha(opacity=0);
        visibility: hidden;
        transition:
          opacity 500ms 0s,
          visibility 0s 500ms;
        -webkit-transition:
          opacity 500ms 0s,
          visibility 0s 500ms;
      }

      .trc_fade.trc_in,
      .trc_user_excluded .trc_exclude_overlay {
        visibility: visible;
        opacity: 1;
        filter: alpha(opacity=100);
        transition-delay: 0s, 0s;
        -webkit-transition-delay: 0s, 0s;
      }

      .trc_excludable .trc_exclude_overlay {
        position: absolute;
        z-index: 10000;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        cursor: default;
        background-color: #fff;
      }

      .videoCube.trc_user_excluded .trc_exclude_overlay {
        visibility: visible;
        opacity: 0.8;
        filter: alpha(opacity=80);
      }

      .videoCube.trc_user_excluded .thumbBlock {
        filter: grayscale(100%);
        -webkit-filter: grayscale(100%);
      }

      .videoCube.trc_user_excluded:hover a .video-label-box .video-title,
      .videoCube_hover.trc_user_excluded a .video-label-box .video-title {
        text-decoration: none;
      }

      .videoCube.trc_user_excluded a .video-label-box *,
      .videoCube.trc_user_excluded:hover a .video-label-box *,
      .videoCube_hover.trc_user_excluded a .video-label-box * {
        color: #000;
        overflow: hidden;
        transition: color 500ms 0s;
        -webkit-transition: color 500ms 0s;
      }</style>
    <style id="tRecs-taboola-choice-popover-container">.trc_popover {
        position: absolute;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 12px;
        line-height: 16px;
        color: #000;
        cursor: default;
        top: 0;
        right: 0;
        z-index: 2147483647;
        width: 180px;
        padding: 1px;
        text-align: left;
        white-space: normal;
        background-color: #fff;
        border: 1px solid rgba(0, 0, 0, 0.2);
        border-radius: 6px;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        background-clip: padding-box;
        -webkit-background-clip: padding;
        box-sizing: content-box;
      }

      .trc_popover.trc_bottom {
        margin-top: 10px;
      }

      .trc_popover.trc_bottom .trc_popover_arrow {
        top: -11px;
        right: 11px;
        margin-left: -11px;
        border-bottom-color: #999;
        border-bottom-color: rgba(0, 0, 0, 0.25);
        border-top-width: 0;
      }

      .trc_popover.trc_bottom .trc_popover_arrow:after {
        top: 1px;
        margin-left: -10px;
        border-bottom-color: #fff;
        border-top-width: 0;
      }

      .trc_popover iframe {
        width: 100%;
      }

      .trc_popover .trc_popover_arrow,
      .trc_popover .trc_popover_arrow:after {
        position: absolute;
        display: block;
        width: 0;
        height: 0;
        border: solid rgba(0, 0, 0, 0);
      }

      .trc_popover .trc_popover_arrow {
        border-width: 11px;
      }

      .trc_popover .trc_popover_arrow:after {
        border-width: 10px;
        content: "";
      }

      .trc_popover_fade {
        visibility: hidden;
        opacity: 0;
        filter: alpha(opacity=0);
        transition:
          opacity 500ms 0s,
          visibility 0s 500ms;
        -webkit-transition:
          opacity 500ms 0s,
          visibility 0s 500ms;
      }

      .trc_popover_fade.trc_popover_show {
        visibility: visible;
        opacity: 1;
        filter: alpha(opacity=100);
        transition-delay: 0s, 0s;
        -webkit-transition-delay: 0s, 0s;
      }</style>
    <style id="tRecs-taboola-choice-popover-content">.popupContentWrapper {
        font-family: Arial, Helvetica, sans-serif;
        font-weight: normal;
        font-size: 12px;
        color: #000;
      }

      .popupContentWrapper .trc_popover_title_wrapper {
        padding: 8px 14px;
        margin: 0;
        font-weight: bold;
        background-color: #f7f7f7;
        border-bottom: 1px solid #ebebeb;
        border-radius: 5px 5px 0 0;
      }

      .popupContentWrapper .trc_popover_title {
        width: 100%;
        display: inline-block;
        vertical-align: middle;
      }

      .popupContentWrapper .trc_popover_content_wrapper {
        display: inline-block;
        float: left;
        padding: 9px 14px;
      }

      .popupContentWrapper
        .trc_popover_content_wrapper
        .trc_questionnaire_container
        label {
        float: left;
        clear: left;
        width: 100%;
        cursor: pointer;
        line-height: 20px;
        text-align: left;
      }

      .popupContentWrapper .trc_popover_content {
        width: 100%;
      }

      .popupContentWrapper
        .trc_questionnaire_container
        .trc_questionnaire_title {
        margin: 0 0 3px;
      }

      .popupContentWrapper .trc_questionnaire_container input[type="radio"] {
        float: left;
        cursor: pointer;
        margin: 3px 4px 0 5px;
      }

      .popupContentWrapper
        .trc_questionnaire_container_ie.trc_questionnaire_container
        input[type="radio"] {
        margin: 0 2px 0 0;
      }</style>
    
    
    
    
    
    <style type="text/css"></style>
    <style id="tblStyle_0">.trc_rbox_container {
        direction: ltr;
        text-align: left;
      }

      /*override bootstrap default css */
      .trc_rbox_container [class*="span"] {
        float: none;
        margin-left: 0;
      }

      /*------------- Multi-widget -------------*/
      .trc_multi_widget_container {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-pack: justify;
        justify-content: space-between;
      }

      .trc_multi_widget_container .trc_rbox_div {
        margin: 0;
      }

      /*----------------------------------------*/
      .trc_rbox_header {
        border: 0 solid;
        overflow: hidden;
        vertical-align: middle;
      }

      .trc_rbox_container .trc_img {
        display: inline-block !important;
      }

      .trc_rbox_header_icon_div {
        display: table-cell;
        vertical-align: baseline;
      }

      .trc_rbox_header .trc_rbox_header_icon_div .trc_rbox_header_icon_img {
        vertical-align: middle;
        width: auto;
      }

      .trc_rbox_header_icon_span {
        display: inline-table;
      }

      .in_trc_header {
        position: relative !important;
        float: right;
        margin: 0;
      }

      #trc_rbox_css_loaded {
        overflow: hidden;
        width: 0;
        height: 0;
      }

      .trc_rbox {
        margin-top: 0;
      }

      .trc_rbox_div {
        margin: 0 0 3px;
        direction: ltr;
        padding: 0;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        -ms-box-sizing: border-box;
        -webkit-box-sizing: border-box;
        overflow: auto;
        position: relative;
        width: auto;
        border: solid #ccc 1px;
      }

      .loading-animation span {
        display: block;
      }

      .videoCube {
        zoom: 1;
        cursor: pointer;
        float: none;
        overflow: hidden;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        -ms-box-sizing: border-box;
        -webkit-box-sizing: border-box;
      }

      div.videoCube:hover,
      .videoCube_hover {
        cursor: pointer;
      }

      .videoCube span.video-title:hover,
      .videoCube_hover span.video-title {
        text-decoration: underline;
      }

      .videoCube a {
        text-decoration: none;
        border: 0;
        color: black;
        cursor: pointer;
      }

      .videoCube a:hover,
      .videoCube_hover a,
      .videoCube a:link,
      .videoCube a {
        text-decoration: none !important;
        outline: none;
      }

      .videoCube a .thumbBlock {
        float: left;
        display: block;
        overflow: hidden !important;
      }

      .videoCube a img,
      .videoCube img {
        border: 0;
        display: block;
        margin: 0;
        height: auto;
        width: auto;
      }

      .videoCube .video-label {
        display: block;
        overflow: hidden;
      }

      .videoCube .video-label {
        width: auto !important;
        white-space: pre-wrap; /* css-3 */
        white-space: -moz-pre-wrap; /* Mozilla, since 1999 */
        white-space: -o-pre-wrap; /* Opera 7 */
        word-wrap: break-word; /* Internet Explorer 5.5+ */
      }

      .videoCube .video-label-box.label-box-with-title-icon {
        display: table;
      }

      .video-icon-container {
        float: left;
        display: table-cell;
        vertical-align: baseline;
      }

      .video-icon-img {
        vertical-align: middle;
      }

      .videoCube .video-duration {
        height: 0;
        float: left;
        position: relative;
        color: white;
        font-size: 11px;
      }

      .videoCube .video-duration dt {
        border-radius: 4px;
        -moz-border-radius: 4px;
        -webkit-border-radius: 4px;
        background-color: black;
        opacity: 0.6;
        filter: alpha(opacity=60);
      }

      /* browser native line-clamp */
      .videoCube span.video-label.trc_ellipsis {
        position: relative;
        overflow: hidden;
        display: -webkit-box;
        -webkit-box-orient: vertical;
      }

      .videoCube span.video-label.trc-smart-ellipsis {
        position: relative;
        overflow: hidden;
      }

      .videoCube span.video-label.trc-smart-ellipsis ins {
        display: inline-block;
        text-decoration: inherit;
      }

      .videoCube span.video-label.trc-smart-ellipsis.tbl-ltr-label {
        direction: ltr;
      }

      .videoCube span.video-label.trc-smart-ellipsis.tbl-ltr-label ins {
        float: left;
        margin-right: 5px;
        direction: ltr;
      }

      .videoCube span.video-label.trc_ellipsis.tbl-rtl-label {
        direction: rtl;
        text-align: right;
        width: auto !important;
      }

      .videoCube span.video-label.trc-smart-ellipsis.tbl-rtl-label {
        float: right;
        direction: rtl;
        width: auto !important;
      }

      .videoCube span.video-label.trc-smart-ellipsis.tbl-rtl-label ins {
        float: right;
        margin-left: 5px;
        direction: rtl;
      }

      .videoCube span.video-label.trc-smart-ellipsis ins.lastLineEllipsis {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        word-wrap: normal;
        width: 100%;
      }

      .video-duration.video-duration-detail div {
        color: white;
      }

      .trc_rbox .sponsored {
        position: relative;
        display: block;
        overflow: visible;
        height: auto;
        width: auto;
        padding-right: 0;
        text-align: right;
        font-size: 9px;
      }

      /* Configuration defaults */
      .trc_rbox_div {
        height: 410px;
      }

      .videoCube {
        direction: ltr;
        font-size: 11px;
        margin: 0;
        color: black;
        border-width: 0;
      }

      .videoCube.vertical:first-child {
        border-top: 0;
        margin-top: 0;
      }

      .videoCube.horizontal:first-child {
        border-left: 0;
        margin-left: 0;
      }

      div.videoCube:hover,
      .videoCube_hover {
        background-color: #ebf0ff;
        color: black;
      }

      .videoCube .thumbBlock {
        margin: 0;
        border-style: solid;
      }

      .videoCube a img,
      .videoCube img {
        border-color: #ececec;
      }

      .videoCube .video-label-box {
        margin-left: 81px;
      }

      .videoCube .video-label dt {
        font-weight: bold;
      }

      .videoCube .video-title {
        height: auto;
        margin-bottom: 3px;
        white-space: normal;
      }

      .videoCube .trc_inline_detail_spacer {
        display: inline-block;
        white-space: pre;
      }

      .loading-animation {
        font-family: sans;
        font-size: 1.5em;
        text-align: center;
        color: gray;
        height: 100%;
      }

      .trc_rbox_header {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 12px;
        font-weight: bold;
        text-decoration: none;
        color: black;
      }

      .trc_header_right_part {
        position: absolute;
        left: 50%;
        top: 0;
      }

      .branding_div {
        overflow: visible;
        float: right;
      }

      .branding_div img {
        height: 20px;
      }

      .videoCube .branding .logoDiv {
        font-size: inherit;
        line-height: inherit;
        background: none;
        margin: 0;
        padding: 0;
      }

      .videoCube .branding .logoDiv a {
        vertical-align: inherit;
        color: inherit;
        line-height: inherit;
      }

      .videoCube .branding .logoDiv a span {
        vertical-align: inherit;
      }

      .trc_related_container
        .videoCube
        .branding
        .attribution-disclosure-link-sponsored {
        display: inline-block;
        float: none;
      }

      .trc_related_container
        .videoCube
        .branding
        .attribution-disclosure-link-sponsored.align-disclosure-right {
        float: right;
        margin-left: auto;
        padding-left: 2px;
      }

      .videoCube .video-label-box .branding.composite-branding {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
      }

      .branding.composite-branding > * {
        display: inline-block;
        vertical-align: bottom;
      }

      .branding .branding-separator {
        margin: 0 2px;
        font-weight: normal;
      }

      .branding .branding-inner {
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
      }

      .video-label-box span.branding.inline-branding {
        display: inline-block;
      }

      /* Support for Horizontal mode */
      .trc_related_container div.horizontal {
        float: left;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        -ms-box-sizing: border-box;
        -webkit-box-sizing: border-box;
      }

      /* Support for thumbnail position */
      .trc_related_container DIV.videoCube.thumbnail_top .thumbBlock,
      .trc_related_container DIV.videoCube.thumbnail_bottom .thumbBlock {
        float: none;
      }

      /* SEO blocks should be hidden once R-Box loads */
      .vidiscovery-note {
        display: none;
      }

      .videoCube .thumbBlock .trc_sponsored_overlay_base {
        display: block;
        width: auto;
        margin-left: 0;
        position: absolute;
        color: white !important;
      }

      .videoCube .thumbBlock .trc_sponsored_overlay {
        filter: alpha(opacity=60);
        opacity: 0.6;
        display: block;
        position: absolute;
      }

      .videoCube .thumbBlock .trc_sponsored_overlay_base .sponsored {
        position: relative;
        display: block;
        overflow: visible;
        width: auto;
        text-align: center;
        padding: 0 5px;
        margin-top: 0;
      }

      .videoCube
        .thumbBlock
        .trc_sponsored_overlay_base.round
        .trc_sponsored_overlay {
        border-radius: 4px;
        -moz-border-radius: 4px;
        -webkit-border-radius: 4px;
      }

      .videoCube .thumbBlock .trc_sponsored_overlay_base.round {
        margin-left: 4px;
      }

      .thumbnail-emblem,
      .videoCube .thumbnail-overlay,
      .videoCube:hover .thumbnail-overlay,
      .videoCube_hover .thumbnail-overlay {
        position: absolute;
        background: transparent no-repeat;
        background-size: contain;
        z-index: 50;
      }

      .thumbnail_bottom {
        padding-bottom: 8px;
      }

      .trc_related_container .logoDiv {
        font-family: Arial, Helvetica, sans-serif;
        white-space: nowrap;
        font-size: 9px;
      }

      .trc_related_container .logoDiv a {
        font-size: 9px;
        text-decoration: none !important;
        color: black;
        margin-right: 1px; /* don't allow focus line to cause overflow */
        vertical-align: text-bottom;
      }

      .logoDiv a span:hover {
        text-decoration: underline;
      }

      .trc_rbox_header .logoDiv {
        font-size: 1em;
      }

      /* text-link widgets*/
      .trc_tl .trc_rbox_header .logoDiv {
        position: relative;
        z-index: 1;
      }

      .trc_tl .trc_rbox_header_span .trc_header_right_column {
        position: absolute;
        width: 48%;
        left: 52%;
        top: 0;
      }

      .trc_tl .trc_rbox_div .videoCube.horizontal {
        clear: left;
      }

      .trc_tl .trc_rbox_div .videoCube.trc_tl_right_col {
        float: none;
        clear: right;
        margin-left: auto;
      }

      .trc_tl .videoCube .video-title .branding {
        line-height: 1.3em;
      }

      .trc_tl .videoCube:hover span.branding,
      .trc_tl .videoCube_hover span.branding {
        text-decoration: none;
      }

      .trc_tl .trc_rbox_div .videoCube.thumbnail_none a {
        vertical-align: top;
        overflow: visible;
      }

      .trc_tl .videoCube .video-label-box {
        display: inline-block;
        vertical-align: top;
        width: 100%;
      }

      /* text-link widgets - end*/
      .trc_related_container .videoCube .thumbBlock .branding {
        position: absolute;
        bottom: 0;
        z-index: 1;
        width: 100%;
        margin: 0;
        padding: 5px 0;
        text-align: center;
      }

      .syndicatedItem .branding {
        margin: 0;
      }

      .trc-inplayer-rbox {
        background: #333;
        background: rgba(30, 30, 30, 0.9);
        bottom: 0;
        position: absolute;
        height: 300px;
        text-align: center;
      }

      .trc-inplayer-rbox .trc_rbox_container {
        margin: 50px auto 0;
        width: 640px;
      }

      .trc_rbox.trc-auto-size {
        width: 100%;
        height: 100%;
      }

      .videoCube.thumbnail_under .video-title {
        min-height: 2.58em;
      }

      .videoCube.thumbnail_under .tbl-text-over-container {
        width: 100%;
        position: absolute;
        z-index: 1;
        left: 0;
        bottom: 0;
        min-height: 66%;
        max-height: 66%;
        padding-top: 2px;
        padding-bottom: 2px;
        line-height: 1.25em;
      }

      .videoCube.thumbnail_under .tbl-text-over-container .tbl-text-over {
        height: 100%;
        width: 100%;
        position: absolute;
        background: linear-gradient(
          to bottom,
          rgba(0, 0, 0, 0) 0%,
          rgba(0, 0, 0, 0.8) 100%
        );
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#00000000, endColorstr=#CC000000, GradientType=0);
      }

      .videoCube.thumbnail_under .tbl-text-over-container span.video-title,
      .videoCube.thumbnail_under
        .tbl-text-over-container
        span.video-description,
      .videoCube.thumbnail_under .tbl-text-over-container span.branding {
        position: relative;
        z-index: 1;
        padding: 0 8px;
        margin: 0;
      }

      .videoCube.thumbnail_under .tbl-text-over-container span.video-title {
        margin-bottom: 6px;
        min-height: auto;
      }

      .videoCube.thumbnail_under .tbl-text-over-container .video-label-box {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 0 8px 6px 8px;
        min-height: auto;
        box-sizing: border-box;
      }

      .trc-auto-size .trc_rbox_outer .trc_rbox_div {
        height: auto;
        width: auto;
      }

      .trc-auto-size .trc_rbox_div .videoCube {
        height: auto;
      }

      .trc-auto-size .trc_rbox_div .videoCube.trc-first-recommendation {
        margin-top: 0;
      }

      .trc_rbox .trc_rbox_outer .trc_rbox_div .videoCube.trc-first-in-row {
        margin-left: 0;
      }

      .trc_elastic .trc_rbox {
        width: auto;
      }

      .trc_elastic .videoCube {
        overflow: hidden;
      }

      .trc_elastic .videoCube .thumbBlock {
        background: transparent no-repeat center center;
        background-size: cover;
        position: absolute;
        display: inline-block;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        margin-left: 0;
        margin-right: 0;
      }

      .trc_elastic .thumbBlock_holder {
        position: relative;
        width: 100%;
      }

      .trc_elastic .thumbnail_start .thumbBlock_holder {
        float: left;
        margin-right: 10px;
      }

      .trc_elastic .thumbnail_start.item-has-pre-label .thumbBlock_holder {
        margin-right: 0;
      }

      .trc_elastic .videoCube_aspect {
        width: 1px;
      }

      .trc_elastic .trc_rbox .trc_rbox_div {
        height: auto;
      }

      .trc_elastic .thumbnail_start .trc-pre-label {
        float: left;
        padding-right: 10px;
      }

      .trc_elastic .thumbnail_start.trc-split-label .trc-main-label {
        float: left;
        padding-left: 10px;
      }

      .trc_elastic .video-label-box {
        display: block;
      }

      .trc_elastic .thumbnail_start .video-label-box {
        box-sizing: border-box;
      }

      /** USER Ad-Choice **/
      .trc_user_adChoice_btn {
        background: url("") no-repeat scroll 0 0 rgba(255, 255, 255, 1);
        border-radius: 0 0 0 5px;
        width: 16px;
        height: 16px;
        position: absolute;
        right: 0;
        top: 0;
        z-index: 9000;
        cursor: pointer;
        border-width: 2px 0 2px 4px;
        border-style: solid;
        border-color: #fff;
        opacity: 0.7;
        background-size: contain;
        visibility: hidden;
      }

      .videoCube:hover .trc_user_adChoice_btn,
      .videoCube_hover .trc_user_adChoice_btn {
        visibility: visible;
      }

      .videoCube .trc_user_adChoice_btn_static {
        visibility: visible;
      }

      .p-video-overlay-container {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background-color: transparent;
      }

      .p-video-overlay.p-video-overlay-show {
        display: flex;
      }

      .p-video-overlay {
        display: none;
        background-color: #000;
        opacity: 0.7;
        width: 100%;
        height: 100%;
        flex-direction: column;
      }

      .p-video-overlay-action {
        color: #fff;
        width: 100%;
        direction: ltr;
        text-align: center;
        display: flex;
        justify-content: center;
        flex-direction: column;
      }

      .p-video-overlay-action.p-video-back-action {
        height: 34%;
      }

      .p-video-back-action-label {
        font-family:
          Helvetica Neue,
          serif;
        font-size: 14px;
        font-weight: 200;
        letter-spacing: 1px;
      }

      .p-video-overlay-action.p-video-goto-action {
        height: 66%;
      }

      .p-video-goto-action-url {
        font-family:
          Helvetica Neue,
          serif;
        font-size: 24px;
        font-weight: 400;
        text-decoration: underline;
        margin-top: 5px;
      }

      .p-video-goto-action-label {
        font-family:
          Helvetica Neue,
          serif;
        font-size: 14px;
        font-weight: 100;
        letter-spacing: 1px;
      }

      .trc_related_container .trc_clearer {
        clear: both;
        height: 0;
        overflow: hidden;
        font-size: 0;
        line-height: 0;
        visibility: hidden;
      }

      /* Ad Choices */
      .link-adc {
        float: right !important;
      }

      .trc-widget-footer .logoDiv {
        line-height: normal;
        padding-bottom: 5px;
      }

      .trc-widget-footer .link-adc a .trc_adc_wrapper,
      .trc_header_ext .link-adc a .trc_adc_wrapper {
        height: 12px;
        width: 18px;
        display: inline-block;
        padding-left: 1px;
        margin-bottom: 2px;
      }

      .trc-widget-footer .link-adc a .trc_adc_s_logo,
      .trc_header_ext .link-adc a .trc_adc_s_logo,
      .trc-widget-footer .link-adc a .trc_adc_b_logo,
      .trc_header_ext .link-adc a .trc_adc_b_logo {
        vertical-align: middle;
        height: 15px;
        display: inline-block;
        margin-top: -1px; /**fix v align of adc logo - compensate for link underline */
      }

      .trc-widget-footer .link-adc a .trc_adc_s_logo,
      .trc_header_ext .link-adc a .trc_adc_s_logo {
        width: 12px;
        height: 14px;
        background: url("") no-repeat;
        background-size: contain;
        vertical-align: middle;
      }

      .trc-widget-footer .link-adc a .trc_adc_b_logo,
      .trc_header_ext .link-adc a .trc_adc_b_logo {
        width: 77px;
        background: #ffffff url("") no-repeat !important;
        right: -1px;
        display: none;
        position: absolute;
      }

      /* Attribution och Disclosure */
      .logoDiv .trc_mobile_disclosure_link,
      .logoDiv .trc_mobile_attribution_link,
      .logoDiv .trc_mobile_adc_link {
        display: none;
      }

      .logoDiv .trc_desktop_disclosure_link,
      .logoDiv .trc_desktop_attribution_link,
      .logoDiv .trc_desktop_adc_link {
        display: inline;
      }

      @media screen and (max-width: 767px) {
        .logoDiv .trc_mobile_disclosure_link {
          display: inline;
        }

        .logoDiv .trc_mobile_attribution_link {
          display: inline;
        }

        .logoDiv .trc_mobile_adc_link {
          display: inline;
        }

        .logoDiv .trc_desktop_disclosure_link {
          display: none;
        }

        .logoDiv .trc_desktop_attribution_link {
          display: none;
        }

        .logoDiv .trc_desktop_adc_link {
          display: none;
        }
      }

      .trc_in_iframe .logoDiv .trc_mobile_attribution_link,
      .trc_in_iframe .logoDiv .trc_mobile_disclosure_link {
        display: inline;
      }

      .trc_in_iframe .logoDiv .trc_desktop_attribution_link,
      .trc_in_iframe .logoDiv .trc_desktop_disclosure_link {
        display: none;
      }

      .trc_related_container .logoDiv,
      .trc_related_container .trc_header_ext .logoDiv {
        float: right;
      }

      .trc_related_container .logoDiv + .logoDiv {
        margin-right: 2px;
      }

      .trc_related_container .attribution-disclosure-link-sponsored,
      .trc_related_container .attribution-disclosure-link-hybrid {
        display: none;
      }

      .trc_related_container
        .trc-content-sponsored
        .attribution-disclosure-link-sponsored,
      .trc-w2f.trc-content-sponsored .attribution-disclosure-link-sponsored {
        display: block;
      }

      .trc_related_container
        .trc-content-hybrid
        .attribution-disclosure-link-hybrid,
      .trc-w2f.trc-content-hybrid .attribution-disclosure-link-hybrid {
        display: block;
      }

      .trc_related_container .trc-widget-footer:hover a span,
      .trc_related_container .trc_header_ext:hover a span {
        text-decoration: underline !important;
      }

      /* this span makes sure that all logos (attribution + adc + disclosure) are vertically aligned - especially when the attribution font-size is smaller than the adc logo height (15px) */
      .logoDiv a span.trc_logos_v_align {
        display: inline-block !important;
        font-size: 15px !important;
        line-height: 1em !important;
        width: 0 !important;
      }

      .trc_related_container .trc_header_ext:hover a span.trc_logos_v_align,
      .trc_related_container .trc_header_ext:hover a span.trc_adc_wrapper,
      .trc_related_container .trc-widget-footer:hover a span.trc_logos_v_align,
      .trc_related_container .trc-widget-footer:hover a span.trc_adc_wrapper {
        text-decoration: none !important;
      }

      .trc_related_container .trc_rbox_header_span .trc_header_right_column {
        display: none;
      }

      .trc_related_container img {
        max-width: none;
      }

      .trc_related_container * {
        pointer-events: auto;
      }

      .trc_related_container {
        clear: both;
      }

      .tbl-loading-spinner {
        width: 100%;
        height: 40px;
        background: url('img/91a25024-792d-4b52-84e6-ad1478c3f552.gif') center
          center no-repeat;
        background-size: 40px;
      }

      .tbl-hidden {
        display: none !important;
      }

      .tbl-invisible {
        opacity: 0;
        pointer-events: none;
      }

      .tbl-batch-anchor {
        width: 100%;
        height: 1px;
      }

      .videoCube .video-logo + .branding.composite-branding {
        display: inline-block;
        vertical-align: middle;
      }

      .videoCube .video-logo {
        margin-right: 4px;
      }

      .videoCube .video-logo .branding {
        margin: auto auto auto 25px;
      }

      .videoCube .video-logo img {
        padding: 0;
        max-height: 14px;
        width: auto;
        max-width: 100px;
        display: inline-block;
      }

      /* Support for integrated widget frame */
      .iw_video_frame .trc_rbox_div {
        overflow: hidden;
      }

      .trc-w2f .trc_rbox .trc_rbox_header,
      .trc-w2f .trc_rbox .trc-widget-footer {
        display: none !important;
      }

      .videoCube .tbl-organic-video-wrapper {
        display: -ms-flexbox;
        display: flex;
        align-items: flex-start;
        height: 100%;
        width: 100%;
        background-color: transparent;
        background-size: auto;
        text-align: center;
        overflow: hidden;
        position: absolute;
        top: 0;
        z-index: 3;
        opacity: 0;
      }

      .videoCube .tbl-organic-video-wrapper .tbl-o-vertical-video {
        height: 100%;
      }

      .videoCube .tbl-organic-video {
        width: 100%;
        height: auto;
        object-fit: contain;
        object-position: 50% 50%;
        -o-object-fit: contain;
        -o-object-position: 50% 50%;
        background-color: black;
        pointer-events: none;
      }

      .videoCube .tbl-accessibility-title {
        font: -apple-system-headline !important;
      }

      .videoCube .tbl-accessibility-description {
        font: -apple-system-subheadline !important;
      }

      .videoCube .tbl-accessibility-branding {
        font: -apple-system-caption1 !important;
      }

      .added-icon-svg {
        width: 12px;
        height: 12px;
        position: relative;
        top: 5px;
        left: 5px;
      }

      @media screen and (max-width: 480px) {
        .added-icon-svg {
          width: 12px;
          height: 12px;
          position: relative;
          top: 4px;
          left: 5px;
          display: inline-block;
        }
      }

      .tbl-read-more-box {
        margin-bottom: 0px !important;
      }

      .thumbs-feed-01-a {
        width: 300px;
        _width: 300px;
        border-width: 0px 0px 0px 0px;
        border-style: solid solid solid solid;
        border-color: #dfdfdf;
        padding: 0px 0px 0px 0px;
        border-radius: 0;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        box-shadow: none;
      }

      .thumbs-feed-01-a vignette {
        xbuttoncolor: #fff;
        backgroundcolor: #fff;
        backgroundopacity: 0.8;
        xbuttonbgcolor: #000;
      }

      .thumbs-feed-01-a .playerCube .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .tbl-reco-reel-slider {
        z-index: 99999;
        margin: initial;
        top: 50%;
      }

      .thumbs-feed-01-a .trc_lightbox_overlay {
        background-color: #000000;
        opacity: 0.7;
        filter: alpha(opacity=70);
      }

      .thumbs-feed-01-a
        .tbl-recommendation-reel
        .tbl-text-under-branding-background {
        background-color: #ebebeb;
      }

      .thumbs-feed-01-a div.syndicatedItem:hover,
      .thumbs-feed-01-a div.syndicatedItem.videoCube_hover {
        background-color: transparent;
      }

      .thumbs-feed-01-a .playerCube div.videoCube:hover,
      .thumbs-feed-01-a div.videoCube_hover {
        background-color: transparent;
      }

      .thumbs-feed-01-a .trc_pager_prev:hover,
      .thumbs-feed-01-a .trc_pager_next:hover {
        color: #6497ed;
      }

      .thumbs-feed-01-a .trc_rbox_border_elm {
        border-color: darkgray;
      }

      .thumbs-feed-01-a .syndicatedItem .video-views {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01-a .syndicatedItem .video-category {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01-a .tbl-vignette-close-btn-wrp {
        height: 15;
        background: #000;
      }

      .thumbs-feed-01-a .syndicatedItem .sponsored {
        color: #9c9a9c;
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01-a .pager_disabled {
        color: #7d898f;
      }

      .thumbs-feed-01-a .playerCube .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .syndicatedItem .video-uploader {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01-a .videoCube.thumbnail_start .thumbBlock_holder {
        width: 40%;
        _width: 40%;
      }

      .thumbs-feed-01-a .playerCube .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .trc_sponsored_overlay {
        background-color: black;
      }

      .thumbs-feed-01-a .syndicatedItem .video-external-data {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01-a .trc_rbox_header {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 100%;
        font-weight: bold;
        text-decoration: none;
        color: #000000;
        border-width: 0;
        background: transparent;
        border-style: none;
        border-color: #d6d5d3;
        padding: 0px 0px 2px 0px;
        line-height: 1.2em;
        display: none;
        margin: 0px 0px 0px 0px;
        position: relative;
        background-color: transparent;
        box-sizing: initial;
        height: auto;
        width: auto;
        _width: auto;
      }

      .thumbs-feed-01-a .syndicatedItem .video-rating {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01-a .videoCube.vertical {
        border-style: solid none none none;
      }

      .thumbs-feed-01-a .trc_pager_unselected {
        color: #7d898f;
      }

      .thumbs-feed-01-a .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
        display: inherit;
      }

      .thumbs-feed-01-a .syndicatedItem {
        background-color: transparent;
      }

      .thumbs-feed-01-a .syndicatedItem .video-duration-detail {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01-a
        body.tbl-show-explore-more
        div#tbl-explore-more-container {
        z-index: 2147483647;
      }

      .thumbs-feed-01-a .playerCube .videoCube.horizontal {
        border-style: none none none none;
      }

      .thumbs-feed-01-a .videoCube.syndicatedItem .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .thumbs-feed-01-a .videoCube.syndicatedItem.vertical {
        border-style: solid none none none;
      }

      .thumbs-feed-01-a .sponsored {
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
        color: #9c9a9c;
      }

      .thumbs-feed-01-a .videoCube.syndicatedItem .thumbBlock {
        border-color: darkgray;
        border-width: 0px;
        border-radius: 16px;
        -moz-border-radius: 16px;
        -webkit-border-radius: 16px;
      }

      .thumbs-feed-01-a .videoCube.syndicatedItem .thumbBlock .static-text {
        text-align: left;
        background-color: black;
        display: none;
        color: white;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
      }

      .thumbs-feed-01-a
        .videoCube.thumbnail_start.trc-split-label
        .trc-pre-label {
        width: 30%;
        _width: 30%;
      }

      .thumbs-feed-01-a .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .thumbnail-emblem {
        background-position: 5% 5%;
        width: 35;
        _width: 35;
        height: 35;
      }

      .thumbs-feed-01-a .tbl-vignette-background-screen {
        background-color: #fff;
        opacity: 0.8;
        filter: alpha(opacity=80);
      }

      .thumbs-feed-01-a .syndicatedItem .video-description {
        max-height: 44px;
        *height: 44px;
        color: black;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
        font-weight: normal;
        line-height: 22px;
        text-decoration: none;
      }

      .thumbs-feed-01-a .tbl-cta-style .cta-button:hover {
        color: inherit;
        border-color: #999990;
      }

      .thumbs-feed-01-a .playerCube .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .videoCube:hover .thumbnail-overlay,
      .thumbs-feed-01-a .videoCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .thumbs-feed-01-a .video-label-box.trc-pre-label {
        height: 0px;
      }

      .thumbs-feed-01-a .videoCube.thumbnail_start .trc-pre-label {
        width: 60%;
        _width: 60%;
      }

      .thumbs-feed-01-a .syndicatedItem .video-title {
        max-height: 66px;
        *height: 66px;
        color: #000000;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        text-decoration: none;
        padding: 0;
      }

      .thumbs-feed-01-a .playerCube:hover .thumbnail-overlay,
      .thumbs-feed-01-a .playerCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .thumbs-feed-01-a
        .videoCube.thumbnail_start.trc-split-label
        .trc-main-label {
        width: 30%;
        _width: 30%;
      }

      .thumbs-feed-01-a .videoCube {
        width: auto;
        _width: auto;
        background-color: transparent;
        border-width: 0px 0px 0px 0px;
        border-color: #e4e4e4;
        padding: 0px 0px 0px 0px;
        height: auto;
        margin-left: 0px;
        margin-top: 0px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-style: SOLID;
      }

      .thumbs-feed-01-a .sponsored-default .video-description {
        max-height: 2.2em;
        *height: 2.2em;
      }

      .thumbs-feed-01-a .tbl-vignette-attribution {
        color: #6b6666;
        font-size: 15px;
      }

      .thumbs-feed-01-a .playerCube .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 10px;
        line-height: 11px;
        font-weight: normal;
        text-decoration: none;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
      }

      .thumbs-feed-01-a .playerCube .videoCube .video-label-box {
        margin-left: 81px;
        margin-right: 0px;
      }

      .thumbs-feed-01-a .videoCube.syndicatedItem .thumbBlock .branding {
        text-align: left;
        background-color: transparent;
        display: none;
        left: 0px;
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
      }

      .thumbs-feed-01-a div.videoCube:hover,
      .thumbs-feed-01-a div.videoCube_hover {
        background-color: transparent;
      }

      .thumbs-feed-01-a
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-ui-line {
        background-color: #333333;
      }

      .thumbs-feed-01-a .videoCube .sponsored {
        margin-top: -7px;
      }

      .thumbs-feed-01-a .trc_pager_pages div {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01-a .sponsored-url {
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
        color: green;
      }

      .thumbs-feed-01-a .playerCube .video-title {
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 14px;
        line-height: 17.5px;
        font-weight: bold;
        max-height: 2.58em;
        *height: 2.58em;
        color: black;
      }

      .thumbs-feed-01-a .trc_rbox_header_icon_img {
        margin: 0px;
        height: 18px;
      }

      .thumbs-feed-01-a
        .tbl-recommendation-reel
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .thumbs-feed-01-a .tbl-recommendation-reel .tbl-ui-line {
        background-color: #333333;
      }

      .thumbs-feed-01-a .videoCube.syndicatedItem.horizontal {
        border-style: none;
      }

      .thumbs-feed-01-a .videoCube .thumbBlock .static-text {
        font-weight: normal;
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 11px;
        background-color: #a30202;
        display: block;
        color: #ffffff;
        text-align: left;
      }

      .thumbs-feed-01-a .video-title {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        max-height: 66px;
        *height: 66px;
        color: #000000;
        text-decoration: none;
        margin: 0 0 0 0;
      }

      .thumbs-feed-01-a .video-label,
      .thumbs-feed-01-a .sponsored,
      .thumbs-feed-01-a .sponsored-url {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
      }

      .thumbs-feed-01-a .playerCube .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .syndicatedItem .branding {
        color: #606669;
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .thumbs-feed-01-a .trc_pager_selected {
        color: #0056b3;
      }

      .thumbs-feed-01-a .videoCube.syndicatedItem {
        background-color: transparent;
        border-color: #e4e4e4;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-width: 0px 0px 0px 0px;
        border-style: SOLID;
      }

      .thumbs-feed-01-a .branding div.logoDiv {
        font-family: inherit;
      }

      .thumbs-feed-01-a .trc_rbox_div {
        width: auto;
        _width: 99%;
        height: 410px;
        border-width: 0;
        padding: 0;
      }

      .thumbs-feed-01-a .playerCube .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .trc_pager div {
        font-family: serif;
      }

      .thumbs-feed-01-a .syndicatedItem .video-label-box.trc-pre-label {
        height: 0px;
      }

      .thumbs-feed-01-a recommendationReel {
        min-adx-line-color: #2abfd5;
        min-adx-progress-color: #fff;
      }

      .thumbs-feed-01-a .videoCube.horizontal {
        border-style: none;
      }

      .thumbs-feed-01-a div.trc_pager_pages div:hover {
        color: #6497ed;
      }

      .thumbs-feed-01-a .pager_enabled {
        color: #0056b3;
      }

      .thumbs-feed-01-a .playerCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .thumbs-feed-01-a .videoCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .thumbs-feed-01-a .playerCube .videoCube .video-duration {
        display: block;
        left: 36px;
      }

      .thumbs-feed-01-a .syndicatedItem .video-published-date {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        display: inherit;
      }

      .thumbs-feed-01-a .syndicatedItem .sponsored-url {
        color: green;
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
      }

      .thumbs-feed-01-a .playerCube .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .thumbs-feed-01-a .playerCube .video-label-box {
        text-align: left;
      }

      .thumbs-feed-01-a div.sponsored-default:hover,
      .thumbs-feed-01-a div.sponsored-default.videoCube_hover {
        background-color: inherit;
      }

      .thumbs-feed-01-a
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .thumbs-feed-01-a .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .trc_pager_prev,
      .thumbs-feed-01-a .trc_pager_next {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01-a .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
        border-radius: 16px;
        -moz-border-radius: 16px;
        -webkit-border-radius: 16px;
      }

      .thumbs-feed-01-a .videoCube.syndicatedItem .video-duration {
        display: none;
        left: 36px;
      }

      .thumbs-feed-01-a .sponsored-default .video-title {
        max-height: 2.58em;
        *height: 2.58em;
      }

      .thumbs-feed-01-a .branding {
        color: #606669;
        font-size: 12px;
        font-weight: bold;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .thumbs-feed-01-a .sponsored-default {
        background-color: #f7f6c6;
      }

      .thumbs-feed-01-a .playerCube .videoCube {
        background-color: transparent;
        border-color: #d6d5d3;
        border-width: 1px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        margin-left: 0px;
        margin-top: 0px;
        padding: 3px;
      }

      .thumbs-feed-01-a .branding .logoDiv a span {
        color: inherit;
        font-size: inherit;
      }

      .thumbs-feed-01-a .video-label-box {
        text-align: left;
        height: 116px;
        margin: 5px 0px 0px 0px;
      }

      .thumbs-feed-01-a .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: normal;
        max-height: 44px;
        *height: 44px;
        color: black;
        text-decoration: none;
      }

      .thumbs-feed-01-a .videoCube .video-duration {
        left: 36px;
        display: none;
      }

      .thumbs-feed-01-a div.syndicatedItem:hover .thumbBlock {
        border-color: inherit;
      }

      .thumbs-feed-01-a .trc_pager_counter {
        color: #000000;
      }

      .thumbs-feed-01-a .whatsThisSyndicated {
        font-family: Arial, Verdana, sans-serif;
        font-size: 9px;
        font-weight: normal;
        color: black;
        text-decoration: none;
        padding: 0;
      }

      .thumbs-feed-01-a .playerCube .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a div.videoCube:hover .thumbBlock {
        border-color: inherit;
      }

      .thumbs-feed-01-a .video-icon-img {
        margin: 0px;
        height: 18px;
      }

      .thumbs-feed-01-a .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01-a .tbl-cta-style .cta-button {
        font-family: Helvetica, Arial, sans-serif;
        background-color: transparent;
        border-color: #acacac;
        color: #333333;
      }

      .thumbs-feed-01-a .videoCube .video-label-box {
        margin-left: 0;
        margin-right: 0px;
      }

      .thumbs-feed-01-a .videoCube .video-label-box.trc-pre-label {
        margin: 0px 0px 0px 0px;
      }

      .thumbs-feed-01-a .syndicatedItem .video-label-box {
        height: 116px;
        margin: 5px 0px 0px 0px;
      }

      .thumbs-feed-01-a .logoDiv a span {
        font-size: 11px;
        color: #999999;
        display: inline;
        font-weight: normal;
      }

      .thumbs-feed-01-a .videoCube .video-label-box .video-title {
        text-decoration: none;
      }

      .thumbs-feed-01-a .videoCube:hover .video-label-box .video-title {
        text-decoration: underline;
      }

      .thumbs-feed-01-a .videoCube:hover .video-label-box .video-description {
        text-decoration: underline;
      }

      .thumbs-feed-01-a .video-label-box .branding {
        display: block;
      }

      .thumbs-feed-01-a .trc_rbox_header .trc_header_ext {
        position: relative;
        top: auto;
        right: auto;
      }

      .thumbs-feed-01-a .logoDiv a {
        font-size: 100%;
      }

      .thumbs-feed-01-a .videoCube a {
        padding: 0;
      }

      .thumbs-feed-01-a .trc_rbox_header .logoDiv {
        line-height: normal;
      }

      .thumbs-feed-01-a .trc_rbox_header_span .trc_header_right_column {
        background: transparent;
        height: auto;
      }

      .thumbs-feed-01-a .trc_header_left_column {
        height: auto;
        background-color: transparent;
      }

      /* s-split-thumbs-feed-01-a */ /* changes */
      .thumbs-feed-01-a
        .videoCube
        .video-label-box
        .branding.composite-branding {
        width: 97%;
      }

      .thumbs-feed-01-a
        .videoCube
        .branding
        .attribution-disclosure-link-sponsored,
      .thumbs-feed-01-a .branding .branding-separator {
        display: none;
      }

      .thumbs-feed-01-a .added-icon-svg {
        width: 17px;
      }

      /* e-split-thumbs-feed-01-a */
      @media screen and (min-width: 0px) {
        .trc_elastic_thumbs-feed-01-a
          .trc_rbox_outer
          .videoCube
          .trc-main-label {
          height: auto;
        }

        .trc_elastic_thumbs-feed-01-a .trc_rbox_outer .videoCube {
          margin-bottom: 10px;
        }

        .trc_elastic_thumbs-feed-01-a .trc_rbox_outer {
          margin-left: -2%;
        }

        .trc_elastic_thumbs-feed-01-a .videoCube_aspect {
          padding-bottom: 55.55555555555556%;
          width: 100%;
        }

        .trc_elastic_thumbs-feed-01-a .videoCube {
          width: 31.33%;
          position: relative;
          float: left;
          margin: 0 0 2% 0;
          margin-left: 2%;
        }

        .trc_elastic_thumbs-feed-01-a div.videoCube:nth-of-type(-n + 3) {
          display: block;
          visibility: visible;
        }

        .trc_elastic_thumbs-feed-01-a div.videoCube:nth-of-type(n + 4) {
          display: none;
          visibility: hidden;
        }
      }

      .organic-thumbs-feed-01 {
        width: 300px;
        _width: 300px;
        border-width: 0px 0px 0px 0px;
        border-style: solid solid solid solid;
        border-color: #dfdfdf;
        padding: 0px 0px 0px 0px;
        border-radius: 0;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        box-shadow: none;
      }

      .organic-thumbs-feed-01 vignette {
        xbuttoncolor: #fff;
        backgroundcolor: #fff;
        backgroundopacity: 0.8;
        xbuttonbgcolor: #000;
      }

      .organic-thumbs-feed-01 .playerCube .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .tbl-reco-reel-slider {
        z-index: 99999;
        margin: initial;
        top: 50%;
      }

      .organic-thumbs-feed-01 .trc_lightbox_overlay {
        background-color: #000000;
        opacity: 0.7;
        filter: alpha(opacity=70);
      }

      .organic-thumbs-feed-01
        .tbl-recommendation-reel
        .tbl-text-under-branding-background {
        background-color: #ebebeb;
      }

      .organic-thumbs-feed-01 div.syndicatedItem:hover,
      .organic-thumbs-feed-01 div.syndicatedItem.videoCube_hover {
        background-color: transparent;
      }

      .organic-thumbs-feed-01 .playerCube div.videoCube:hover,
      .organic-thumbs-feed-01 div.videoCube_hover {
        background-color: transparent;
      }

      .organic-thumbs-feed-01 .trc_pager_prev:hover,
      .organic-thumbs-feed-01 .trc_pager_next:hover {
        color: #6497ed;
      }

      .organic-thumbs-feed-01 .trc_rbox_border_elm {
        border-color: darkgray;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-views {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-category {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .tbl-vignette-close-btn-wrp {
        height: 15;
        background: #000;
      }

      .organic-thumbs-feed-01 .syndicatedItem .sponsored {
        color: #9c9a9c;
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .pager_disabled {
        color: #7d898f;
      }

      .organic-thumbs-feed-01 .playerCube .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-uploader {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .videoCube.thumbnail_start .thumbBlock_holder {
        width: 40%;
        _width: 40%;
      }

      .organic-thumbs-feed-01 .playerCube .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .trc_sponsored_overlay {
        background-color: black;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-external-data {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .trc_rbox_header {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 100%;
        font-weight: bold;
        text-decoration: none;
        color: #000000;
        border-width: 0;
        background: transparent;
        border-style: none;
        border-color: #d6d5d3;
        padding: 0px 0px 6px 0px;
        line-height: 1.2em;
        display: none;
        margin: 0px 0px 0px 0px;
        position: relative;
        background-color: transparent;
        box-sizing: initial;
        height: auto;
        width: auto;
        _width: auto;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-rating {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .videoCube.vertical {
        border-style: solid none none none;
      }

      .organic-thumbs-feed-01 .trc_pager_unselected {
        color: #7d898f;
      }

      .organic-thumbs-feed-01 .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
        display: inherit;
      }

      .organic-thumbs-feed-01 .syndicatedItem {
        background-color: transparent;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-duration-detail {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-thumbs-feed-01
        body.tbl-show-explore-more
        div#tbl-explore-more-container {
        z-index: 2147483647;
      }

      .organic-thumbs-feed-01 .playerCube .videoCube.horizontal {
        border-style: none none none none;
      }

      .organic-thumbs-feed-01 .videoCube.syndicatedItem .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .organic-thumbs-feed-01 .videoCube.syndicatedItem.vertical {
        border-style: solid none none none;
      }

      .organic-thumbs-feed-01 .sponsored {
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
        color: #9c9a9c;
      }

      .organic-thumbs-feed-01 .videoCube.syndicatedItem .thumbBlock {
        border-color: darkgray;
        border-width: 0px;
      }

      .organic-thumbs-feed-01
        .videoCube.syndicatedItem
        .thumbBlock
        .static-text {
        text-align: left;
        background-color: black;
        display: none;
        color: white;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
      }

      .organic-thumbs-feed-01
        .videoCube.thumbnail_start.trc-split-label
        .trc-pre-label {
        width: 30%;
        _width: 30%;
      }

      .organic-thumbs-feed-01 .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .thumbnail-emblem {
        background-position: 5% 5%;
        width: 35;
        _width: 35;
        height: 35;
      }

      .organic-thumbs-feed-01 .tbl-vignette-background-screen {
        background-color: #fff;
        opacity: 0.8;
        filter: alpha(opacity=80);
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-description {
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        font-weight: normal;
        line-height: 19px;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .tbl-cta-style .cta-button:hover {
        color: inherit;
        border-color: #999990;
      }

      .organic-thumbs-feed-01 .playerCube .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .videoCube:hover .thumbnail-overlay,
      .organic-thumbs-feed-01 .videoCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .organic-thumbs-feed-01 .video-label-box.trc-pre-label {
        height: 0px;
      }

      .organic-thumbs-feed-01 .videoCube.thumbnail_start .trc-pre-label {
        width: 60%;
        _width: 60%;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-title {
        max-height: 44px;
        *height: 44px;
        color: #000000;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        text-decoration: none;
        padding: 0;
      }

      .organic-thumbs-feed-01 .playerCube:hover .thumbnail-overlay,
      .organic-thumbs-feed-01 .playerCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .organic-thumbs-feed-01
        .videoCube.thumbnail_start.trc-split-label
        .trc-main-label {
        width: 30%;
        _width: 30%;
      }

      .organic-thumbs-feed-01 .videoCube {
        width: auto;
        _width: auto;
        background-color: transparent;
        border-width: 0px 0px 0px 0px;
        border-color: #e4e4e4;
        padding: 0px 0px 0px 0px;
        height: auto;
        margin-left: 0px;
        margin-top: 0px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-style: SOLID;
      }

      .organic-thumbs-feed-01 .sponsored-default .video-description {
        max-height: 2.2em;
        *height: 2.2em;
      }

      .organic-thumbs-feed-01 .tbl-vignette-attribution {
        color: #6b6666;
        font-size: 15px;
      }

      .organic-thumbs-feed-01 .playerCube .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 10px;
        line-height: 11px;
        font-weight: normal;
        text-decoration: none;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
      }

      .organic-thumbs-feed-01 .playerCube .videoCube .video-label-box {
        margin-left: 81px;
        margin-right: 0px;
      }

      .organic-thumbs-feed-01 .videoCube.syndicatedItem .thumbBlock .branding {
        text-align: left;
        background-color: transparent;
        display: none;
        left: 0px;
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
      }

      .organic-thumbs-feed-01 div.videoCube:hover,
      .organic-thumbs-feed-01 div.videoCube_hover {
        background-color: transparent;
      }

      .organic-thumbs-feed-01
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-ui-line {
        background-color: #333333;
      }

      .organic-thumbs-feed-01 .videoCube .sponsored {
        margin-top: -7px;
      }

      .organic-thumbs-feed-01 .trc_pager_pages div {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .sponsored-url {
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
        color: green;
      }

      .organic-thumbs-feed-01 .playerCube .video-title {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        text-decoration: none;
        font-size: 14px;
        line-height: 17.5px;
        font-weight: bold;
        max-height: 2.58em;
        *height: 2.58em;
        color: black;
      }

      .organic-thumbs-feed-01 .trc_rbox_header_icon_img {
        margin: 0px;
        height: 18px;
      }

      .organic-thumbs-feed-01
        .tbl-recommendation-reel
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .organic-thumbs-feed-01 .tbl-recommendation-reel .tbl-ui-line {
        background-color: #333333;
      }

      .organic-thumbs-feed-01 .videoCube.syndicatedItem.horizontal {
        border-style: none;
      }

      .organic-thumbs-feed-01 .videoCube .thumbBlock .static-text {
        font-weight: normal;
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 11px;
        background-color: #a30202;
        display: block;
        color: #ffffff;
        text-align: left;
      }

      .organic-thumbs-feed-01 .video-title {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        max-height: 44px;
        *height: 44px;
        color: #000000;
        text-decoration: none;
        margin: 0 0 0 0;
      }

      .organic-thumbs-feed-01 .video-label,
      .organic-thumbs-feed-01 .sponsored,
      .organic-thumbs-feed-01 .sponsored-url {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
      }

      .organic-thumbs-feed-01 .playerCube .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .syndicatedItem .branding {
        color: #606669;
        font-size: 12px;
        font-weight: bold;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .organic-thumbs-feed-01 .trc_pager_selected {
        color: #0056b3;
      }

      .organic-thumbs-feed-01 .videoCube.syndicatedItem {
        background-color: transparent;
        border-color: #e4e4e4;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-width: 0px 0px 0px 0px;
        border-style: SOLID;
      }

      .organic-thumbs-feed-01 .branding div.logoDiv {
        font-family: inherit;
      }

      .organic-thumbs-feed-01 .trc_rbox_div {
        width: auto;
        _width: 99%;
        height: 410px;
        border-width: 0;
        padding: 0;
      }

      .organic-thumbs-feed-01 .playerCube .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .trc_pager div {
        font-family: serif;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-label-box.trc-pre-label {
        height: 0px;
      }

      .organic-thumbs-feed-01 recommendationReel {
        min-adx-line-color: #2abfd5;
        min-adx-progress-color: #fff;
      }

      .organic-thumbs-feed-01 .videoCube.horizontal {
        border-style: none;
      }

      .organic-thumbs-feed-01 div.trc_pager_pages div:hover {
        color: #6497ed;
      }

      .organic-thumbs-feed-01 .pager_enabled {
        color: #0056b3;
      }

      .organic-thumbs-feed-01 .playerCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .organic-thumbs-feed-01 .videoCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .organic-thumbs-feed-01 .playerCube .videoCube .video-duration {
        display: block;
        left: 36px;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-published-date {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        display: inherit;
      }

      .organic-thumbs-feed-01 .syndicatedItem .sponsored-url {
        color: green;
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
      }

      .organic-thumbs-feed-01 .playerCube .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .organic-thumbs-feed-01 .playerCube .video-label-box {
        text-align: left;
      }

      .organic-thumbs-feed-01 div.sponsored-default:hover,
      .organic-thumbs-feed-01 div.sponsored-default.videoCube_hover {
        background-color: inherit;
      }

      .organic-thumbs-feed-01
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .organic-thumbs-feed-01 .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .trc_pager_prev,
      .organic-thumbs-feed-01 .trc_pager_next {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .organic-thumbs-feed-01 .videoCube.syndicatedItem .video-duration {
        display: none;
        left: 36px;
      }

      .organic-thumbs-feed-01 .sponsored-default .video-title {
        max-height: 2.58em;
        *height: 2.58em;
      }

      .organic-thumbs-feed-01 .branding {
        color: #606669;
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .organic-thumbs-feed-01 .sponsored-default {
        background-color: #f7f6c6;
      }

      .organic-thumbs-feed-01 .playerCube .videoCube {
        background-color: transparent;
        border-color: #d6d5d3;
        border-width: 1px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        margin-left: 0px;
        margin-top: 0px;
        padding: 3px;
      }

      .organic-thumbs-feed-01 .branding .logoDiv a span {
        color: inherit;
        font-size: inherit;
      }

      .organic-thumbs-feed-01 .video-label-box {
        text-align: left;
        height: 66px;
        margin: 5px 0px 0px 0px;
      }

      .organic-thumbs-feed-01 .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        line-height: 19px;
        font-weight: normal;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
        text-decoration: none;
      }

      .organic-thumbs-feed-01 .videoCube .video-duration {
        left: 36px;
        display: none;
      }

      .organic-thumbs-feed-01 div.syndicatedItem:hover .thumbBlock {
        border-color: inherit;
      }

      .organic-thumbs-feed-01 .trc_pager_counter {
        color: #000000;
      }

      .organic-thumbs-feed-01 .whatsThisSyndicated {
        font-family: Arial, Verdana, sans-serif;
        font-size: 9px;
        font-weight: normal;
        color: black;
        text-decoration: none;
        padding: 0;
      }

      .organic-thumbs-feed-01 .playerCube .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 div.videoCube:hover .thumbBlock {
        border-color: inherit;
      }

      .organic-thumbs-feed-01 .video-icon-img {
        margin: 0px;
        height: 18px;
      }

      .organic-thumbs-feed-01 .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-thumbs-feed-01 .tbl-cta-style .cta-button {
        font-family: Helvetica, Arial, sans-serif;
        background-color: transparent;
        border-color: #acacac;
        color: #333333;
      }

      .organic-thumbs-feed-01 .videoCube .video-label-box {
        margin-left: 0;
        margin-right: 0px;
      }

      .organic-thumbs-feed-01 .videoCube .video-label-box.trc-pre-label {
        margin: 0px 0px 0px 0px;
      }

      .organic-thumbs-feed-01 .syndicatedItem .video-label-box {
        height: 66px;
        margin: 5px 0px 0px 0px;
      }

      .organic-thumbs-feed-01 .logoDiv a span {
        font-size: 11px;
        color: #000000;
        display: inline;
        font-weight: normal;
      }

      .organic-thumbs-feed-01 .videoCube .video-label-box .video-title {
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
      }

      .organic-thumbs-feed-01 .videoCube:hover .video-label-box .video-title {
        text-decoration: underline;
      }

      .organic-thumbs-feed-01
        .videoCube:hover
        .video-label-box
        .video-description {
        text-decoration: underline;
      }

      .organic-thumbs-feed-01 .video-label-box .branding {
        display: block;
      }

      .organic-thumbs-feed-01 .trc_rbox_header .trc_header_ext {
        position: relative;
        top: auto;
        right: auto;
      }

      .organic-thumbs-feed-01 .logoDiv a {
        font-size: 100%;
      }

      .organic-thumbs-feed-01 .videoCube a {
        padding: 0;
      }

      .organic-thumbs-feed-01 .trc_rbox_header .logoDiv {
        line-height: normal;
      }

      .organic-thumbs-feed-01 .trc_rbox_header_span .trc_header_right_column {
        background: transparent;
        height: auto;
      }

      .organic-thumbs-feed-01 .trc_header_left_column {
        height: auto;
        background-color: transparent;
      }

      @media screen and (min-width: 0px) {
        .trc_elastic_organic-thumbs-feed-01
          .trc_rbox_outer
          .videoCube
          .video-label-box {
          height: auto;
        }

        .trc_elastic_organic-thumbs-feed-01 .trc_rbox_outer .videoCube {
          margin-bottom: 10px;
        }

        .trc_elastic_organic-thumbs-feed-01 .trc_rbox_outer {
          margin-left: -2%;
        }

        .trc_elastic_organic-thumbs-feed-01 .videoCube_aspect {
          padding-bottom: 58.333333333333336%;
          width: 100%;
        }

        .trc_elastic_organic-thumbs-feed-01 .videoCube {
          width: 97.99%;
          position: relative;
          float: left;
          margin: 0 0 2% 0;
          margin-left: 2%;
        }

        .trc_elastic_organic-thumbs-feed-01 div.videoCube:nth-of-type(-n + 1) {
          display: block;
          visibility: visible;
        }

        .trc_elastic_organic-thumbs-feed-01 div.videoCube:nth-of-type(n + 2) {
          display: none;
          visibility: hidden;
        }
      }

      .thumbs-feed-01 {
        width: 300px;
        _width: 300px;
        border-width: 0px 0px 0px 0px;
        border-style: solid solid solid solid;
        border-color: #dfdfdf;
        padding: 0px 0px 0px 0px;
        border-radius: 0;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        box-shadow: none;
      }

      .thumbs-feed-01 vignette {
        xbuttoncolor: #fff;
        backgroundcolor: #fff;
        backgroundopacity: 0.8;
        xbuttonbgcolor: #000;
      }

      .thumbs-feed-01 .playerCube .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .tbl-reco-reel-slider {
        z-index: 99999;
        margin: initial;
        top: 50%;
      }

      .thumbs-feed-01 .trc_lightbox_overlay {
        background-color: #000000;
        opacity: 0.7;
        filter: alpha(opacity=70);
      }

      .thumbs-feed-01
        .tbl-recommendation-reel
        .tbl-text-under-branding-background {
        background-color: #ebebeb;
      }

      .thumbs-feed-01 div.syndicatedItem:hover,
      .thumbs-feed-01 div.syndicatedItem.videoCube_hover {
        background-color: transparent;
      }

      .thumbs-feed-01 .playerCube div.videoCube:hover,
      .thumbs-feed-01 div.videoCube_hover {
        background-color: transparent;
      }

      .thumbs-feed-01 .trc_pager_prev:hover,
      .thumbs-feed-01 .trc_pager_next:hover {
        color: #6497ed;
      }

      .thumbs-feed-01 .trc_rbox_border_elm {
        border-color: darkgray;
      }

      .thumbs-feed-01 .syndicatedItem .video-views {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01 .syndicatedItem .video-category {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01 .tbl-vignette-close-btn-wrp {
        height: 15;
        background: #000;
      }

      .thumbs-feed-01 .syndicatedItem .sponsored {
        color: #9c9a9c;
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01 .pager_disabled {
        color: #7d898f;
      }

      .thumbs-feed-01 .playerCube .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .syndicatedItem .video-uploader {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01 .videoCube.thumbnail_start .thumbBlock_holder {
        width: 40%;
        _width: 40%;
      }

      .thumbs-feed-01 .playerCube .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .trc_sponsored_overlay {
        background-color: black;
      }

      .thumbs-feed-01 .syndicatedItem .video-external-data {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01 .trc_rbox_header {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 100%;
        font-weight: bold;
        text-decoration: none;
        color: #000000;
        border-width: 0;
        background: transparent;
        border-style: none;
        border-color: #d6d5d3;
        padding: 0px 0px 2px 0px;
        line-height: 1.2em;
        display: none;
        margin: 0px 0px 0px 0px;
        position: relative;
        background-color: transparent;
        box-sizing: initial;
        height: auto;
        width: auto;
        _width: auto;
      }

      .thumbs-feed-01 .syndicatedItem .video-rating {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01 .videoCube.vertical {
        border-style: solid none none none;
      }

      .thumbs-feed-01 .trc_pager_unselected {
        color: #7d898f;
      }

      .thumbs-feed-01 .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
        display: inherit;
      }

      .thumbs-feed-01 .syndicatedItem {
        background-color: transparent;
      }

      .thumbs-feed-01 .syndicatedItem .video-duration-detail {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01
        body.tbl-show-explore-more
        div#tbl-explore-more-container {
        z-index: 2147483647;
      }

      .thumbs-feed-01 .playerCube .videoCube.horizontal {
        border-style: none none none none;
      }

      .thumbs-feed-01 .videoCube.syndicatedItem .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .thumbs-feed-01 .videoCube.syndicatedItem.vertical {
        border-style: solid none none none;
      }

      .thumbs-feed-01 .sponsored {
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
        color: #9c9a9c;
      }

      .thumbs-feed-01 .videoCube.syndicatedItem .thumbBlock {
        border-color: darkgray;
        border-width: 0px;
      }

      .thumbs-feed-01 .videoCube.syndicatedItem .thumbBlock .static-text {
        text-align: left;
        background-color: black;
        display: none;
        color: white;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
      }

      .thumbs-feed-01
        .videoCube.thumbnail_start.trc-split-label
        .trc-pre-label {
        width: 30%;
        _width: 30%;
      }

      .thumbs-feed-01 .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .thumbnail-emblem {
        background-position: 5% 5%;
        width: 35;
        _width: 35;
        height: 35;
      }

      .thumbs-feed-01 .tbl-vignette-background-screen {
        background-color: #fff;
        opacity: 0.8;
        filter: alpha(opacity=80);
      }

      .thumbs-feed-01 .syndicatedItem .video-description {
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        font-weight: normal;
        line-height: 19px;
        text-decoration: none;
      }

      .thumbs-feed-01 .tbl-cta-style .cta-button:hover {
        color: inherit;
        border-color: #999990;
      }

      .thumbs-feed-01 .playerCube .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .videoCube:hover .thumbnail-overlay,
      .thumbs-feed-01 .videoCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .thumbs-feed-01 .video-label-box.trc-pre-label {
        height: 0px;
      }

      .thumbs-feed-01 .videoCube.thumbnail_start .trc-pre-label {
        width: 60%;
        _width: 60%;
      }

      .thumbs-feed-01 .syndicatedItem .video-title {
        max-height: 44px;
        *height: 44px;
        color: #000000;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        text-decoration: none;
        padding: 0;
      }

      .thumbs-feed-01 .playerCube:hover .thumbnail-overlay,
      .thumbs-feed-01 .playerCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .thumbs-feed-01
        .videoCube.thumbnail_start.trc-split-label
        .trc-main-label {
        width: 30%;
        _width: 30%;
      }

      .thumbs-feed-01 .videoCube {
        width: auto;
        _width: auto;
        background-color: transparent;
        border-width: 0px 0px 0px 0px;
        border-color: #e4e4e4;
        padding: 0px 0px 0px 0px;
        height: auto;
        margin-left: 0px;
        margin-top: 0px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-style: SOLID;
      }

      .thumbs-feed-01 .sponsored-default .video-description {
        max-height: 2.2em;
        *height: 2.2em;
      }

      .thumbs-feed-01 .tbl-vignette-attribution {
        color: #6b6666;
        font-size: 15px;
      }

      .thumbs-feed-01 .playerCube .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 10px;
        line-height: 11px;
        font-weight: normal;
        text-decoration: none;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
      }

      .thumbs-feed-01 .playerCube .videoCube .video-label-box {
        margin-left: 81px;
        margin-right: 0px;
      }

      .thumbs-feed-01 .videoCube.syndicatedItem .thumbBlock .branding {
        text-align: left;
        background-color: transparent;
        display: none;
        left: 0px;
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
      }

      .thumbs-feed-01 div.videoCube:hover,
      .thumbs-feed-01 div.videoCube_hover {
        background-color: transparent;
      }

      .thumbs-feed-01
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-ui-line {
        background-color: #333333;
      }

      .thumbs-feed-01 .videoCube .sponsored {
        margin-top: -7px;
      }

      .thumbs-feed-01 .trc_pager_pages div {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01 .sponsored-url {
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
        color: green;
      }

      .thumbs-feed-01 .playerCube .video-title {
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 14px;
        line-height: 17.5px;
        font-weight: bold;
        max-height: 2.58em;
        *height: 2.58em;
        color: black;
      }

      .thumbs-feed-01 .trc_rbox_header_icon_img {
        margin: 0px;
        height: 18px;
      }

      .thumbs-feed-01
        .tbl-recommendation-reel
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .thumbs-feed-01 .tbl-recommendation-reel .tbl-ui-line {
        background-color: #333333;
      }

      .thumbs-feed-01 .videoCube.syndicatedItem.horizontal {
        border-style: none;
      }

      .thumbs-feed-01 .videoCube .thumbBlock .static-text {
        font-weight: normal;
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 11px;
        background-color: #a30202;
        display: block;
        color: #ffffff;
        text-align: left;
      }

      .thumbs-feed-01 .video-title {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        max-height: 66px;
        *height: 66px;
        color: #000000;
        text-decoration: none;
        margin: 0 0 0 0;
      }

      .thumbs-feed-01 .video-label,
      .thumbs-feed-01 .sponsored,
      .thumbs-feed-01 .sponsored-url {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
      }

      .thumbs-feed-01 .playerCube .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .syndicatedItem .branding {
        color: #606669;
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
        direction: ltr;
      }

      .thumbs-feed-01 .trc_pager_selected {
        color: #0056b3;
      }

      .thumbs-feed-01 .videoCube.syndicatedItem {
        background-color: transparent;
        border-color: #e4e4e4;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-width: 0px 0px 0px 0px;
        border-style: SOLID;
      }

      .thumbs-feed-01 .branding div.logoDiv {
        font-family: inherit;
      }

      .thumbs-feed-01 .trc_rbox_div {
        width: auto;
        _width: 99%;
        height: 410px;
        border-width: 0;
        padding: 0;
      }

      .thumbs-feed-01 .playerCube .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .trc_pager div {
        font-family: serif;
      }

      .thumbs-feed-01 .syndicatedItem .video-label-box.trc-pre-label {
        height: 0px;
      }

      .thumbs-feed-01 recommendationReel {
        min-adx-line-color: #2abfd5;
        min-adx-progress-color: #fff;
      }

      .thumbs-feed-01 .videoCube.horizontal {
        border-style: none;
      }

      .thumbs-feed-01 div.trc_pager_pages div:hover {
        color: #6497ed;
      }

      .thumbs-feed-01 .pager_enabled {
        color: #0056b3;
      }

      .thumbs-feed-01 .playerCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .thumbs-feed-01 .videoCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .thumbs-feed-01 .playerCube .videoCube .video-duration {
        display: block;
        left: 36px;
      }

      .thumbs-feed-01 .syndicatedItem .video-published-date {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        display: inherit;
      }

      .thumbs-feed-01 .syndicatedItem .sponsored-url {
        color: green;
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
      }

      .thumbs-feed-01 .playerCube .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .thumbs-feed-01 .playerCube .video-label-box {
        text-align: left;
      }

      .thumbs-feed-01 div.sponsored-default:hover,
      .thumbs-feed-01 div.sponsored-default.videoCube_hover {
        background-color: inherit;
      }

      .thumbs-feed-01
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .thumbs-feed-01 .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .trc_pager_prev,
      .thumbs-feed-01 .trc_pager_next {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbs-feed-01 .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .thumbs-feed-01 .videoCube.syndicatedItem .video-duration {
        display: none;
        left: 36px;
      }

      .thumbs-feed-01 .sponsored-default .video-title {
        max-height: 2.58em;
        *height: 2.58em;
      }

      .thumbs-feed-01 .branding {
        color: #606669;
        font-size: 12px;
        font-weight: bold;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .thumbs-feed-01 .sponsored-default {
        background-color: #f7f6c6;
      }

      .thumbs-feed-01 .playerCube .videoCube {
        background-color: transparent;
        border-color: #d6d5d3;
        border-width: 1px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        margin-left: 0px;
        margin-top: 0px;
        padding: 3px;
      }

      .thumbs-feed-01 .branding .logoDiv a span {
        color: inherit;
        font-size: inherit;
      }

      .thumbs-feed-01 .video-label-box {
        text-align: left;
        height: 66px;
        margin: 5px 0px 0px 0px;
      }

      .thumbs-feed-01 .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        line-height: 19px;
        font-weight: normal;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
        text-decoration: none;
      }

      .thumbs-feed-01 .videoCube .video-duration {
        left: 36px;
        display: none;
      }

      .thumbs-feed-01 div.syndicatedItem:hover .thumbBlock {
        border-color: inherit;
      }

      .thumbs-feed-01 .trc_pager_counter {
        color: #000000;
      }

      .thumbs-feed-01 .whatsThisSyndicated {
        font-family: Arial, Verdana, sans-serif;
        font-size: 9px;
        font-weight: normal;
        color: black;
        text-decoration: none;
        padding: 0;
      }

      .thumbs-feed-01 .playerCube .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 div.videoCube:hover .thumbBlock {
        border-color: inherit;
      }

      .thumbs-feed-01 .video-icon-img {
        margin: 0px;
        height: 18px;
      }

      .thumbs-feed-01 .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbs-feed-01 .tbl-cta-style .cta-button {
        font-family: Helvetica, Arial, sans-serif;
        background-color: transparent;
        border-color: #acacac;
        color: #333333;
      }

      .thumbs-feed-01 .videoCube .video-label-box {
        margin-left: 0;
        margin-right: 0px;
      }

      .thumbs-feed-01 .videoCube .video-label-box.trc-pre-label {
        margin: 0px 0px 0px 0px;
      }

      .thumbs-feed-01 .syndicatedItem .video-label-box {
        height: 66px;
        margin: 5px 0px 0px 0px;
      }

      .thumbs-feed-01 .logoDiv a span {
        font-size: 11px;
        color: #999999;
        display: inline;
        font-weight: normal;
      }

      .thumbs-feed-01 .videoCube .video-label-box .video-title {
        text-decoration: none;
      }

      .thumbs-feed-01 .videoCube:hover .video-label-box .video-title {
        text-decoration: underline;
      }

      .thumbs-feed-01 .videoCube:hover .video-label-box .video-description {
        text-decoration: underline;
      }

      .thumbs-feed-01 .video-label-box .branding {
        display: block;
      }

      .thumbs-feed-01 .trc_rbox_header .trc_header_ext {
        position: relative;
        top: auto;
        right: auto;
      }

      .thumbs-feed-01 .logoDiv a {
        font-size: 100%;
      }

      .thumbs-feed-01 .videoCube a {
        padding: 0;
      }

      .thumbs-feed-01 .trc_rbox_header .logoDiv {
        line-height: normal;
      }

      .thumbs-feed-01 .trc_rbox_header_span .trc_header_right_column {
        background: transparent;
        height: auto;
      }

      .thumbs-feed-01 .trc_header_left_column {
        height: auto;
        background-color: transparent;
      }

      /* s-split-thumbs-feed-01 */ /* changes */
      .thumbs-feed-01 .videoCube .video-label-box .branding.composite-branding {
        width: 97%;
      }

      /*.thumbs-feed-01 .branding .branding-inner {	width: 70%}*/
      .thumbs-feed-01 {
        display: grid;
        grid-template-columns: minmax(0, 1fr);
      }

      @media screen and (max-width: 480px) {
        .thumbs-feed-01 .added-icon-svg {
          width: 32px;
        }
      }

      .thumbs-feed-01
        .videoCube
        .branding
        .attribution-disclosure-link-sponsored,
      .thumbs-feed-01 .branding .branding-separator {
        display: block;
      }

      /* e-split-thumbs-feed-01 */
      @media screen and (min-width: 0px) {
        .trc_elastic_thumbs-feed-01
          .trc_rbox_outer
          .videoCube
          .video-label-box {
          height: auto;
        }

        .trc_elastic_thumbs-feed-01 .trc_rbox_outer .videoCube {
          margin-bottom: 10px;
        }

        .trc_elastic_thumbs-feed-01 .trc_rbox_outer {
          margin-left: -2%;
        }

        .trc_elastic_thumbs-feed-01 .videoCube_aspect {
          padding-bottom: 58.333333333333336%;
          width: 100%;
        }

        .trc_elastic_thumbs-feed-01 .videoCube {
          width: 97.99%;
          position: relative;
          float: left;
          margin: 0 0 2% 0;
          margin-left: 2%;
        }

        .trc_elastic_thumbs-feed-01 div.videoCube:nth-of-type(-n + 1) {
          display: block;
          visibility: visible;
        }

        .trc_elastic_thumbs-feed-01 div.videoCube:nth-of-type(n + 2) {
          display: none;
          visibility: hidden;
        }
      }</style>
    <style id="feedUiCss-0">.tbl-loading-spinner.tbl-loading-cards-placeholder {
        background: rgba(0, 0, 0, 0);
        background-size: 100%;
        height: auto;
        margin-top: 40px;
      }

      .tbl-placeholder-card {
        background: #f6f7f9;
        height: 125px;
        overflow: hidden;
        position: relative;
        margin-bottom: 48px;
      }

      .tbl-placeholder-card:before {
        background-color: #f6f7f9;
        background-image: url('img/9117a6d9-cbf1-4ea6-8caa-7461ce6554bc.gif');
        background-repeat: repeat-y;
        background-size: 100% 1px;
        content: " ";
        display: block;
        height: 100%;
      }

      .tbl-masker {
        position: absolute;
        width: calc(100% - 190px - 24px);
        background-color: #fff;
        box-sizing: content-box;
        border-color: #fff;
        border-style: solid;
        border-left-width: 24px;
      }

      .tbl-first-row-pl,
      .tbl-second-row-pl,
      .tbl-third-row-pl {
        background: rgba(0, 0, 0, 0);
        z-index: 1;
      }

      .tbl-first-row-pl {
        top: 0;
        height: 18px;
        left: 190px;
        border-top-width: 11px;
        border-bottom-width: 18px;
      }

      .tbl-second-row-pl {
        top: 47px;
        height: 18px;
        left: 190px;
        border-top-width: 0;
        border-bottom-width: 18px;
      }

      .tbl-third-row-pl {
        top: 83px;
        height: 15px;
        left: 190px;
        border-top-width: 0;
        border-bottom-width: 35px;
      }

      .tbl-last-row-right-padding {
        top: 83px;
        left: calc(30% + 130px);
        width: 100%;
        height: 15px;
        border-width: 0;
      }

      .tbl-img-top-padding,
      .tbl-img-bottom-padding,
      .tbl-first-col-padding {
        display: none;
      }

      .tbl-second-col-padding {
        display: block;
        width: 24px;
        height: 100%;
        border-width: 0;
        top: 0;
        right: 0;
      }

      .render-late-effect[data-feed-main-container-id="tbl-explore-more-container"]
        .thumbBlock {
        opacity: 0;
        transition: opacity 0.75s;
      }

      .render-late-effect[data-feed-main-container-id="tbl-explore-more-container"]
        .thumbBlock[style*="background-image"] {
        opacity: 1;
      }

      .tbl-loading-placeholder-dir-rtl .tbl-masker {
        border-right-width: 24px;
      }

      .tbl-loading-placeholder-dir-rtl .tbl-first-row-pl,
      .tbl-loading-placeholder-dir-rtl .tbl-second-row-pl,
      .tbl-loading-placeholder-dir-rtl .tbl-third-row-pl {
        right: 190px;
        left: auto;
      }

      .tbl-loading-placeholder-dir-rtl .tbl-last-row-right-padding {
        right: calc(30% + 130px);
        left: auto;
      }

      .tbl-loading-placeholder-dir-rtl .tbl-second-col-padding {
        right: auto;
        left: 0;
      }

      @media screen and (max-width: 480px) and (min-width: 0px) {
        .tbl-loading-spinner.tbl-loading-cards-placeholder {
          margin-top: 8px;
        }

        .tbl-placeholder-card {
          height: 87px;
          margin-bottom: 8px;
        }

        .tbl-masker {
          width: calc(100% - 114px - 12px);
          border-left-width: 12px;
        }

        .tbl-loading-placeholder-dir-rtl .tbl-masker {
          border-right-width: 12px;
        }

        .tbl-first-row-pl {
          top: 0;
          height: 10px;
          left: 114px;
          border-top-width: 16px;
          border-bottom-width: 10px;
        }

        .tbl-second-row-pl {
          top: 36px;
          height: 10px;
          left: 114px;
          border-top-width: 0;
          border-bottom-width: 11px;
        }

        .tbl-third-row-pl {
          top: 57px;
          height: 8px;
          left: 114px;
          border-top-width: 0;
          border-bottom-width: 22px;
        }

        .tbl-last-row-right-padding {
          top: 57px;
          height: 8px;
        }

        .block-no-border,
        .tbl-first-col-padding,
        .tbl-img-bottom-padding,
        .tbl-img-top-padding {
          display: block;
          border-width: 0;
        }

        .tbl-img-top-padding {
          height: 10px;
          width: 100%;
          top: 0;
        }

        .tbl-img-bottom-padding {
          height: 10px;
          width: 100%;
          bottom: 0;
        }

        .tbl-first-col-padding {
          height: 100%;
          width: 8px;
          top: 0;
          left: 0;
        }

        .tbl-second-col-padding {
          display: none;
        }

        .tbl-loading-placeholder-dir-rtl .tbl-first-col-padding {
          right: 0;
          left: auto;
        }

        .tbl-loading-placeholder-dir-rtl .tbl-first-row-pl,
        .tbl-loading-placeholder-dir-rtl .tbl-second-row-pl,
        .tbl-loading-placeholder-dir-rtl .tbl-third-row-pl {
          right: 114px;
          left: auto;
        }
      }

      [data-feed-main-container-id="tbl-explore-more-container"] {
        position: relative;
        margin-top: 3px;
        -webkit-text-size-adjust: 100%;
        clear: both;
        padding: 0;
        background-color: transparent;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-feed-header {
        padding: 0 5px 10px;
        background: 0;
        box-sizing: border-box;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-feed-header-logo {
        height: 11px;
        width: 76px;
        display: inline-block;
        margin: 0;
        background-image: url('img/1e20e8ff-b903-43c3-81e2-8f9e185614d9.svg');
        background-repeat: no-repeat;
        background-position: 0 0;
        background-size: contain;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-feed-header.tbl-header-with-text.tbl-logo-right-position {
        padding: 0 5px 10px 0;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-feed-header.tbl-header-with-text.tbl-logo-left-position {
        padding: 0 0 10px 5px;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-feed-header.tbl-header-with-text {
        display: table;
        width: 100%;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-header-with-text
        .tbl-feed-header-logo {
        display: table-cell;
        background-position-y: 100%;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-header-with-text
        .tbl-feed-header-text {
        display: table-cell;
        width: calc(100% - 76px);
        word-break: break-word;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-logo-left-position {
        direction: ltr;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-header-with-text.tbl-logo-left-position
        .tbl-feed-header-text {
        text-align: right;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-logo-right-position {
        direction: rtl;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-header-with-text.tbl-logo-right-position
        .tbl-feed-header-text {
        text-align: left;
        direction: ltr;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-feed-card {
        margin-bottom: 10px;
        background-color: transparent;
        overflow: hidden;
        padding-bottom: 0;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-loading-spinner {
        margin-bottom: 10px;
      }

      [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-frame-DIVIDER
        .tbl-feed-card {
        box-shadow: 0 1px #e6ecf0;
        margin-bottom: 22px;
      }

      [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-frame-FRAME
        .tbl-feed-card {
        box-shadow: 0 2px 5px 0 #e6ecf0;
        margin: 0 2px 22px 2px;
      }

      [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-frame-SEMI_FRAME
        .tbl-feed-card {
        overflow: visible;
        position: relative;
      }

      [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-frame-SEMI_FRAME
        .tbl-feed-card::after,
      [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-frame-SEMI_FRAME
        .tbl-feed-card::before {
        content: "";
        width: 100%;
        left: 0;
        position: absolute;
        display: block;
      }

      [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-frame-SEMI_FRAME
        .tbl-feed-card::after {
        height: 50px;
        box-shadow: 0 2px 5px 0 #e6ecf0;
        bottom: 0;
      }

      [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-abp {
        max-width: 770px;
        margin: 3px auto 0;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-feed-card
        .video-label-box
        .video-description {
        margin-top: 2px;
      }

      @media screen and (max-width: 480px) {
        [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-full-width {
          padding: 0px 8px;
        }

        [data-feed-main-container-id="tbl-explore-more-container"]
          .tbl-feed-card {
          margin-bottom: 5px;
        }

        [data-feed-main-container-id="tbl-explore-more-container"]
          .trc-widget-footer,
        [data-feed-main-container-id="tbl-explore-more-container"]
          .trc_header_ext {
          padding-right: 3px;
        }

        [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-frame-DIVIDER
          .tbl-feed-card {
          margin-bottom: 16px;
        }

        [data-feed-main-container-id="tbl-explore-more-container"].tbl-feed-frame-FRAME
          .tbl-feed-card {
          margin: 0 0 16px 0;
        }
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .syndicatedItem
        .branding {
        font-weight: 500;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .syndicatedItem
        .branding {
        color: #606669;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .trc_rbox_header {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .branding {
        color: #606669;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .branding {
        font-weight: 500;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .organic-rec-reel-01-x-delta
        .video-description {
        color: #ffffff;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .organic-rec-reel-01-x-delta
        .syndicatedItem
        .branding {
        font-weight: 500;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .organic-rec-reel-01-x-delta
        .video-title {
        color: #ffffff;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .organic-rec-reel-01-x-delta
        .syndicatedItem
        .branding {
        color: #ffffff;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .organic-rec-reel-01-x-delta
        .trc_rbox_header {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .organic-rec-reel-01-x-delta
        .syndicatedItem
        .video-description {
        color: #ffffff;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .organic-rec-reel-01-x-delta
        .branding {
        color: #ffffff;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .organic-rec-reel-01-x-delta
        .syndicatedItem
        .video-title {
        color: #ffffff;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .trc_related_container
        .organic-rec-reel-01-x-delta
        .branding {
        font-weight: 500;
      }

      [data-feed-main-container-id="tbl-explore-more-container"][data-feed-container-num] {
        background-color: #ffffff;
        padding: 0px 8px 0px 8px;
      }

      [data-feed-main-container-id="tbl-explore-more-container"]
        .tbl-feed-header
        .tbl-feed-header-logo {
        display: none;
      }

      .tbl-feed-header-hide-logo {
        background: unset !important;
        background-size: unset !important;
        height: 0 !important;
      }

      .tbl-feed-header-hide-logo:only-child {
        display: none !important;
      }</style>
    <style id="tblStyle_1">.ab_thumbnails-bc-desktop-native_abp-mode {
        width: 300px;
        _width: 300px;
        border-width: 0px 0px 0px 0px;
        border-style: solid solid solid solid;
        border-color: #dfdfdf;
        padding: 0px 0px 0px 0px;
        border-radius: 0;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        box-shadow: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode vignette {
        xbuttoncolor: #fff;
        backgroundcolor: #fff;
        backgroundopacity: 0.8;
        xbuttonbgcolor: #000;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .playerCube
        .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .tbl-reco-reel-slider {
        z-index: 99999;
        margin: initial;
        top: 50%;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_lightbox_overlay {
        background-color: #000000;
        opacity: 0.7;
        filter: alpha(opacity=70);
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .tbl-recommendation-reel
        .tbl-text-under-branding-background {
        background-color: #ebebeb;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode div.syndicatedItem:hover,
      .ab_thumbnails-bc-desktop-native_abp-mode
        div.syndicatedItem.videoCube_hover {
        background-color: transparent;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube div.videoCube:hover,
      .ab_thumbnails-bc-desktop-native_abp-mode div.videoCube_hover {
        background-color: transparent;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_pager_prev:hover,
      .ab_thumbnails-bc-desktop-native_abp-mode .trc_pager_next:hover {
        color: #6497ed;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_rbox_border_elm {
        border-color: darkgray;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .syndicatedItem .video-views {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .syndicatedItem
        .video-category {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .tbl-vignette-close-btn-wrp {
        height: 15;
        background: #000;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .syndicatedItem .sponsored {
        color: #9c9a9c;
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .pager_disabled {
        color: #7d898f;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .syndicatedItem
        .video-uploader {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.thumbnail_start
        .thumbBlock_holder {
        width: 40%;
        _width: 40%;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_sponsored_overlay {
        background-color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .syndicatedItem
        .video-external-data {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_rbox_header {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        font-size: 18px;
        font-weight: bold;
        text-decoration: none;
        color: #000000;
        border-width: 0;
        background: transparent;
        border-style: none;
        border-color: #d6d5d3;
        padding: 0px 0px 6px 0px;
        line-height: 1.2em;
        display: block;
        margin: 0 0 16px 0px;
        position: relative;
        background-color: transparent;
        box-sizing: initial;
        height: auto;
        width: auto;
        _width: auto;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .syndicatedItem .video-rating {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube.vertical {
        border-style: solid none none none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_pager_unselected {
        color: #7d898f;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
        display: inherit;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .syndicatedItem {
        background-color: transparent;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .syndicatedItem
        .video-duration-detail {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        body.tbl-show-explore-more
        div#tbl-explore-more-container {
        z-index: 2147483647;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .playerCube
        .videoCube.horizontal {
        border-style: none none none none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.syndicatedItem
        .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.syndicatedItem.vertical {
        border-style: solid none none none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .sponsored {
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
        color: #9c9a9c;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.syndicatedItem
        .thumbBlock {
        border-color: darkgray;
        border-width: 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.syndicatedItem
        .thumbBlock
        .static-text {
        text-align: left;
        background-color: black;
        display: none;
        color: white;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.thumbnail_start.trc-split-label
        .trc-pre-label {
        width: 30%;
        _width: 30%;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .thumbnail-emblem {
        background-position: 5% 5%;
        width: 35;
        _width: 35;
        height: 35;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .tbl-vignette-background-screen {
        background-color: #fff;
        opacity: 0.8;
        filter: alpha(opacity=80);
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .syndicatedItem
        .video-description {
        max-height: 5.2em;
        *height: 5.2em;
        color: #606669;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        font-size: 14px;
        font-weight: normal;
        line-height: 19px;
        text-decoration: none;
        margin: 0px 0px 22px 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .tbl-cta-style
        .cta-button:hover {
        color: inherit;
        border-color: #999990;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .playerCube
        .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube:hover
        .thumbnail-overlay,
      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube_hover
        .thumbnail-overlay {
        background-image: null;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-label-box.trc-pre-label {
        height: 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.thumbnail_start
        .trc-pre-label {
        width: 60%;
        _width: 60%;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .syndicatedItem .video-title {
        max-height: 44px;
        *height: 44px;
        color: #000000;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        font-size: 18px;
        line-height: 22px;
        font-weight: bold;
        text-decoration: none;
        padding: 0;
        margin: 0px 0px 8px 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .playerCube:hover
        .thumbnail-overlay,
      .ab_thumbnails-bc-desktop-native_abp-mode
        .playerCube_hover
        .thumbnail-overlay {
        background-image: null;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.thumbnail_start.trc-split-label
        .trc-main-label {
        width: 30%;
        _width: 30%;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube {
        width: auto;
        _width: auto;
        background-color: transparent;
        border-width: 0px 0px 0px 0px;
        border-color: #e4e4e4;
        padding: 0px 0px 0px 0px;
        height: auto;
        margin-left: 0px;
        margin-top: 0px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-style: SOLID;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .sponsored-default
        .video-description {
        max-height: 2.2em;
        *height: 2.2em;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .tbl-vignette-attribution {
        color: #6b6666;
        font-size: 15px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 10px;
        line-height: 11px;
        font-weight: normal;
        text-decoration: none;
        max-height: 2.2em;
        *height: 2.2em;
        color: #606669;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .playerCube
        .videoCube
        .video-label-box {
        margin-left: 81px;
        margin-right: 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.syndicatedItem
        .thumbBlock
        .branding {
        text-align: left;
        background-color: transparent;
        display: none;
        left: 0px;
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode div.videoCube:hover,
      .ab_thumbnails-bc-desktop-native_abp-mode div.videoCube_hover {
        background-color: transparent;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-ui-line {
        background-color: #333333;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube .sponsored {
        margin-top: -7px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_pager_pages div {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .sponsored-url {
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
        color: green;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube .video-title {
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 14px;
        line-height: 17.5px;
        font-weight: bold;
        max-height: 2.58em;
        *height: 2.58em;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_rbox_header_icon_img {
        margin: 0px;
        height: 18px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .tbl-recommendation-reel
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .tbl-recommendation-reel
        .tbl-ui-line {
        background-color: #333333;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.syndicatedItem.horizontal {
        border-style: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube
        .thumbBlock
        .static-text {
        font-weight: normal;
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 11px;
        background-color: #a30202;
        display: block;
        color: #ffffff;
        text-align: left;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-title {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 18px;
        line-height: 22px;
        font-weight: bold;
        max-height: 44px;
        *height: 44px;
        color: #000000;
        text-decoration: none;
        margin: 0px 0px 8px 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-label,
      .ab_thumbnails-bc-desktop-native_abp-mode .sponsored,
      .ab_thumbnails-bc-desktop-native_abp-mode .sponsored-url {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .syndicatedItem .branding {
        color: #606669;
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
        margin: 0px 0px 8px 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_pager_selected {
        color: #0056b3;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube.syndicatedItem {
        background-color: transparent;
        border-color: #e4e4e4;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-width: 0px 0px 0px 0px;
        border-style: SOLID;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .branding div.logoDiv {
        font-family: inherit;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_rbox_div {
        width: auto;
        _width: 99%;
        height: 410px;
        border-width: 0;
        padding: 0;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_pager div {
        font-family: serif;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .syndicatedItem
        .video-label-box.trc-pre-label {
        height: 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode recommendationReel {
        min-adx-line-color: #2abfd5;
        min-adx-progress-color: #fff;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube.horizontal {
        border-style: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode div.trc_pager_pages div:hover {
        color: #6497ed;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .pager_enabled {
        color: #0056b3;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .playerCube
        .videoCube
        .video-duration {
        display: block;
        left: 36px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .syndicatedItem
        .video-published-date {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        display: inherit;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .syndicatedItem .sponsored-url {
        color: green;
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .playerCube
        .videoCube
        .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube .video-label-box {
        text-align: left;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode div.sponsored-default:hover,
      .ab_thumbnails-bc-desktop-native_abp-mode
        div.sponsored-default.videoCube_hover {
        background-color: inherit;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_pager_prev,
      .ab_thumbnails-bc-desktop-native_abp-mode .trc_pager_next {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube.syndicatedItem
        .video-duration {
        display: none;
        left: 36px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .sponsored-default
        .video-title {
        max-height: 2.58em;
        *height: 2.58em;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .branding {
        color: #606669;
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .sponsored-default {
        background-color: #f7f6c6;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .playerCube .videoCube {
        background-color: transparent;
        border-color: #d6d5d3;
        border-width: 1px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        margin-left: 0px;
        margin-top: 0px;
        padding: 3px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .branding .logoDiv a span {
        color: inherit;
        font-size: inherit;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-label-box {
        text-align: left;
        height: 66px;
        margin: 5px 0px 0px 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-description {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        font-size: 14px;
        line-height: 19px;
        font-weight: normal;
        max-height: 5.2em;
        *height: 5.2em;
        color: #606669;
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube .video-duration {
        left: 36px;
        display: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        div.syndicatedItem:hover
        .thumbBlock {
        border-color: inherit;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_pager_counter {
        color: #000000;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .whatsThisSyndicated {
        font-family: Arial, Verdana, sans-serif;
        font-size: 9px;
        font-weight: normal;
        color: black;
        text-decoration: none;
        padding: 0;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .playerCube
        .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        div.videoCube:hover
        .thumbBlock {
        border-color: inherit;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-icon-img {
        margin: 0px;
        height: 18px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .tbl-cta-style .cta-button {
        font-family: Helvetica, Arial, sans-serif;
        background-color: transparent;
        border-color: #acacac;
        color: #333333;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube .video-label-box {
        margin-left: 0;
        margin-right: 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .syndicatedItem
        .video-label-box {
        height: 66px;
        margin: 5px 0px 22px 0px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .logoDiv a span {
        font-size: 11px;
        color: #000000;
        display: inline;
        font-weight: normal;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube
        .video-label-box
        .video-title {
        text-decoration: none;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube:hover
        .video-label-box
        .video-title {
        text-decoration: underline;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .videoCube:hover
        .video-label-box
        .video-description {
        text-decoration: underline;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .video-label-box .branding {
        display: block;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .trc_rbox_header
        .trc_header_ext {
        position: relative;
        top: auto;
        right: auto;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .logoDiv a {
        font-size: 100%;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .videoCube a {
        padding: 0;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_rbox_header .logoDiv {
        line-height: normal;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode
        .trc_rbox_header_span
        .trc_header_right_column {
        background: transparent;
        height: auto;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_header_left_column {
        height: auto;
        background-color: transparent;
      }

      /* s-split-ab_thumbnails-bc-desktop-native_abp-mode */
      .ab_thumbnails-bc-desktop-native_abp-mode .added-icon-svg {
        display: inline-block;
        top: 1px;
      }

      .ab_thumbnails-bc-desktop-native_abp-mode .trc_rbox_header {
        border-left: 4px solid rgb(220, 0, 11);
        padding: 0.4rem 0 0.4rem 0.5rem;
        font-weight: 700;
        font-size: 18px;
      }

      /* e-split-ab_thumbnails-bc-desktop-native_abp-mode */
      @media screen and (min-width: 0px) {
        .trc_elastic_ab_thumbnails-bc-desktop-native_abp-mode
          .trc_rbox_outer
          .videoCube
          .trc-main-label {
          height: auto;
        }

        .trc_elastic_ab_thumbnails-bc-desktop-native_abp-mode
          .trc_rbox_outer
          .videoCube {
          margin-bottom: 10px;
        }

        .trc_elastic_ab_thumbnails-bc-desktop-native_abp-mode .trc_rbox_outer {
          margin-left: -2%;
        }

        .trc_elastic_ab_thumbnails-bc-desktop-native_abp-mode
          .videoCube_aspect {
          padding-bottom: 57.14285714285714%;
          width: 100%;
        }

        .trc_elastic_ab_thumbnails-bc-desktop-native_abp-mode .videoCube {
          width: 47.995%;
          position: relative;
          float: left;
          margin: 0 0 2% 0;
          margin-left: 2%;
        }

        .trc_elastic_ab_thumbnails-bc-desktop-native_abp-mode
          div.videoCube:nth-of-type(-n + 2) {
          display: block;
          visibility: visible;
        }

        .trc_elastic_ab_thumbnails-bc-desktop-native_abp-mode
          div.videoCube:nth-of-type(n + 3) {
          display: none;
          visibility: hidden;
        }
      }

      .organic-video-reel-dvr {
        width: 300px;
        _width: 300px;
        border-width: 0px 0px 0px 0px;
        border-style: solid solid solid solid;
        border-color: #dfdfdf;
        padding: 0px 0px 0px 0px;
        border-radius: 0;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        box-shadow: none;
      }

      .organic-video-reel-dvr vignette {
        xbuttoncolor: #fff;
        backgroundcolor: #fff;
        backgroundopacity: 0.8;
        xbuttonbgcolor: #000;
      }

      .organic-video-reel-dvr .playerCube .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .tbl-reco-reel-slider {
        z-index: 99999;
        margin: initial;
        top: 50%;
      }

      .organic-video-reel-dvr .trc_lightbox_overlay {
        background-color: #000000;
        opacity: 0.7;
        filter: alpha(opacity=70);
      }

      .organic-video-reel-dvr
        .tbl-recommendation-reel
        .tbl-text-under-branding-background {
        background-color: #ebebeb;
      }

      .organic-video-reel-dvr div.syndicatedItem:hover,
      .organic-video-reel-dvr div.syndicatedItem.videoCube_hover {
        background-color: transparent;
      }

      .organic-video-reel-dvr .playerCube div.videoCube:hover,
      .organic-video-reel-dvr div.videoCube_hover {
        background-color: transparent;
      }

      .organic-video-reel-dvr .trc_pager_prev:hover,
      .organic-video-reel-dvr .trc_pager_next:hover {
        color: #6497ed;
      }

      .organic-video-reel-dvr .trc_rbox_border_elm {
        border-color: darkgray;
      }

      .organic-video-reel-dvr .syndicatedItem .video-views {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-video-reel-dvr .syndicatedItem .video-category {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-video-reel-dvr .tbl-vignette-close-btn-wrp {
        height: 15;
        background: #000;
      }

      .organic-video-reel-dvr .syndicatedItem .sponsored {
        color: #9c9a9c;
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-video-reel-dvr .pager_disabled {
        color: #7d898f;
      }

      .organic-video-reel-dvr .playerCube .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .syndicatedItem .video-uploader {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-video-reel-dvr .videoCube.thumbnail_start .thumbBlock_holder {
        width: 40%;
        _width: 40%;
      }

      .organic-video-reel-dvr .playerCube .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .trc_sponsored_overlay {
        background-color: black;
      }

      .organic-video-reel-dvr .syndicatedItem .video-external-data {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-video-reel-dvr .trc_rbox_header {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 100%;
        font-weight: bold;
        text-decoration: none;
        color: #000000;
        border-width: 0;
        background: transparent;
        border-style: none;
        border-color: #d6d5d3;
        padding: 0px 0px 0px 0px;
        line-height: 1.2em;
        display: none;
        margin: 0px 0px 0px 0px;
        position: relative;
        background-color: transparent;
        box-sizing: initial;
        height: auto;
        width: auto;
        _width: auto;
      }

      .organic-video-reel-dvr .syndicatedItem .video-rating {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-video-reel-dvr .videoCube.vertical {
        border-style: solid none none none;
      }

      .organic-video-reel-dvr .trc_pager_unselected {
        color: #7d898f;
      }

      .organic-video-reel-dvr .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
        display: inherit;
      }

      .organic-video-reel-dvr .syndicatedItem {
        background-color: transparent;
      }

      .organic-video-reel-dvr .syndicatedItem .video-duration-detail {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-video-reel-dvr
        body.tbl-show-explore-more
        div#tbl-explore-more-container {
        z-index: 2147483647;
      }

      .organic-video-reel-dvr .playerCube .videoCube.horizontal {
        border-style: none none none none;
      }

      .organic-video-reel-dvr .videoCube.syndicatedItem .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .organic-video-reel-dvr .videoCube.syndicatedItem.vertical {
        border-style: solid none none none;
      }

      .organic-video-reel-dvr .sponsored {
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
        color: #9c9a9c;
      }

      .organic-video-reel-dvr .videoCube.syndicatedItem .thumbBlock {
        border-color: darkgray;
        border-width: 0px;
      }

      .organic-video-reel-dvr
        .videoCube.syndicatedItem
        .thumbBlock
        .static-text {
        text-align: left;
        background-color: black;
        display: none;
        color: white;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
      }

      .organic-video-reel-dvr
        .videoCube.thumbnail_start.trc-split-label
        .trc-pre-label {
        width: 30%;
        _width: 30%;
      }

      .organic-video-reel-dvr .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .thumbnail-emblem {
        background-position: 5% 5%;
        width: 35;
        _width: 35;
        height: 35;
      }

      .organic-video-reel-dvr .tbl-vignette-background-screen {
        background-color: #fff;
        opacity: 0.8;
        filter: alpha(opacity=80);
      }

      .organic-video-reel-dvr .syndicatedItem .video-description {
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        font-weight: normal;
        line-height: 19px;
        text-decoration: none;
      }

      .organic-video-reel-dvr .tbl-cta-style .cta-button:hover {
        color: inherit;
        border-color: #999990;
      }

      .organic-video-reel-dvr .playerCube .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .videoCube:hover .thumbnail-overlay,
      .organic-video-reel-dvr .videoCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .organic-video-reel-dvr .video-label-box.trc-pre-label {
        height: 0px;
      }

      .organic-video-reel-dvr .videoCube.thumbnail_start .trc-pre-label {
        width: 60%;
        _width: 60%;
      }

      .organic-video-reel-dvr .syndicatedItem .video-title {
        max-height: 66px;
        *height: 66px;
        color: #000000;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        text-decoration: none;
        padding: 0;
      }

      .organic-video-reel-dvr .playerCube:hover .thumbnail-overlay,
      .organic-video-reel-dvr .playerCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .organic-video-reel-dvr
        .videoCube.thumbnail_start.trc-split-label
        .trc-main-label {
        width: 30%;
        _width: 30%;
      }

      .organic-video-reel-dvr .videoCube {
        width: auto;
        _width: auto;
        background-color: transparent;
        border-width: 0px 0px 0px 0px;
        border-color: #e4e4e4;
        padding: 0px 0px 0px 0px;
        height: auto;
        margin-left: 0px;
        margin-top: 0px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-style: SOLID;
      }

      .organic-video-reel-dvr .sponsored-default .video-description {
        max-height: 2.2em;
        *height: 2.2em;
      }

      .organic-video-reel-dvr .tbl-vignette-attribution {
        color: #6b6666;
        font-size: 15px;
      }

      .organic-video-reel-dvr .playerCube .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 10px;
        line-height: 11px;
        font-weight: normal;
        text-decoration: none;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
      }

      .organic-video-reel-dvr .playerCube .videoCube .video-label-box {
        margin-left: 81px;
        margin-right: 0px;
      }

      .organic-video-reel-dvr .videoCube.syndicatedItem .thumbBlock .branding {
        text-align: left;
        background-color: transparent;
        display: none;
        left: 0px;
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
      }

      .organic-video-reel-dvr div.videoCube:hover,
      .organic-video-reel-dvr div.videoCube_hover {
        background-color: transparent;
      }

      .organic-video-reel-dvr
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-ui-line {
        background-color: #333333;
      }

      .organic-video-reel-dvr .videoCube .sponsored {
        margin-top: -7px;
      }

      .organic-video-reel-dvr .trc_pager_pages div {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-video-reel-dvr .sponsored-url {
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
        color: green;
      }

      .organic-video-reel-dvr .playerCube .video-title {
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 14px;
        line-height: 17.5px;
        font-weight: bold;
        max-height: 2.58em;
        *height: 2.58em;
        color: black;
      }

      .organic-video-reel-dvr .trc_rbox_header_icon_img {
        margin: 0px;
        height: 18px;
      }

      .organic-video-reel-dvr
        .tbl-recommendation-reel
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .organic-video-reel-dvr .tbl-recommendation-reel .tbl-ui-line {
        background-color: #333333;
      }

      .organic-video-reel-dvr .videoCube.syndicatedItem.horizontal {
        border-style: none;
      }

      .organic-video-reel-dvr .videoCube .thumbBlock .static-text {
        font-weight: normal;
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 11px;
        background-color: #a30202;
        display: block;
        color: #ffffff;
        text-align: left;
      }

      .organic-video-reel-dvr .video-title {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        max-height: 66px;
        *height: 66px;
        color: #000000;
        text-decoration: none;
        margin: 0 0 0 0;
      }

      .organic-video-reel-dvr .video-label,
      .organic-video-reel-dvr .sponsored,
      .organic-video-reel-dvr .sponsored-url {
        font-family: Arial, Helvetica, sans-serif;
      }

      .organic-video-reel-dvr .playerCube .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .syndicatedItem .branding {
        color: #999999;
        font-size: 11px;
        font-weight: bold;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .organic-video-reel-dvr .trc_pager_selected {
        color: #0056b3;
      }

      .organic-video-reel-dvr .videoCube.syndicatedItem {
        background-color: transparent;
        border-color: #e4e4e4;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-width: 0px 0px 0px 0px;
        border-style: SOLID;
      }

      .organic-video-reel-dvr .branding div.logoDiv {
        font-family: inherit;
      }

      .organic-video-reel-dvr .trc_rbox_div {
        width: auto;
        _width: 99%;
        height: 410px;
        border-width: 0;
        padding: 0;
      }

      .organic-video-reel-dvr .playerCube .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .trc_pager div {
        font-family: serif;
      }

      .organic-video-reel-dvr .syndicatedItem .video-label-box.trc-pre-label {
        height: 0px;
      }

      .organic-video-reel-dvr recommendationReel {
        min-adx-line-color: #2abfd5;
        min-adx-progress-color: #fff;
      }

      .organic-video-reel-dvr .videoCube.horizontal {
        border-style: none;
      }

      .organic-video-reel-dvr div.trc_pager_pages div:hover {
        color: #6497ed;
      }

      .organic-video-reel-dvr .pager_enabled {
        color: #0056b3;
      }

      .organic-video-reel-dvr .playerCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .organic-video-reel-dvr .videoCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .organic-video-reel-dvr .playerCube .videoCube .video-duration {
        display: block;
        left: 36px;
      }

      .organic-video-reel-dvr .syndicatedItem .video-published-date {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        display: inherit;
      }

      .organic-video-reel-dvr .syndicatedItem .sponsored-url {
        color: green;
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
      }

      .organic-video-reel-dvr .playerCube .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .organic-video-reel-dvr .playerCube .video-label-box {
        text-align: left;
      }

      .organic-video-reel-dvr div.sponsored-default:hover,
      .organic-video-reel-dvr div.sponsored-default.videoCube_hover {
        background-color: inherit;
      }

      .organic-video-reel-dvr
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .organic-video-reel-dvr .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .trc_pager_prev,
      .organic-video-reel-dvr .trc_pager_next {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .organic-video-reel-dvr .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .organic-video-reel-dvr .videoCube.syndicatedItem .video-duration {
        display: none;
        left: 36px;
      }

      .organic-video-reel-dvr .sponsored-default .video-title {
        max-height: 2.58em;
        *height: 2.58em;
      }

      .organic-video-reel-dvr .branding {
        color: #999999;
        font-size: 11px;
        font-weight: bold;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .organic-video-reel-dvr .sponsored-default {
        background-color: #f7f6c6;
      }

      .organic-video-reel-dvr .playerCube .videoCube {
        background-color: transparent;
        border-color: #d6d5d3;
        border-width: 1px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        margin-left: 0px;
        margin-top: 0px;
        padding: 3px;
      }

      .organic-video-reel-dvr .branding .logoDiv a span {
        color: inherit;
        font-size: inherit;
      }

      .organic-video-reel-dvr .video-label-box {
        text-align: left;
        height: 88px;
        margin: 5px 0px 0px 0px;
      }

      .organic-video-reel-dvr .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        line-height: 19px;
        font-weight: normal;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
        text-decoration: none;
      }

      .organic-video-reel-dvr .videoCube .video-duration {
        left: 36px;
        display: none;
      }

      .organic-video-reel-dvr div.syndicatedItem:hover .thumbBlock {
        border-color: inherit;
      }

      .organic-video-reel-dvr .trc_pager_counter {
        color: #000000;
      }

      .organic-video-reel-dvr .whatsThisSyndicated {
        font-family: Arial, Verdana, sans-serif;
        font-size: 9px;
        font-weight: normal;
        color: black;
        text-decoration: none;
        padding: 0;
      }

      .organic-video-reel-dvr .playerCube .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr div.videoCube:hover .thumbBlock {
        border-color: inherit;
      }

      .organic-video-reel-dvr .video-icon-img {
        margin: 0px;
        height: 18px;
      }

      .organic-video-reel-dvr .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .organic-video-reel-dvr .tbl-cta-style .cta-button {
        font-family: Helvetica, Arial, sans-serif;
        background-color: transparent;
        border-color: #acacac;
        color: #333333;
      }

      .organic-video-reel-dvr .videoCube .video-label-box {
        margin-left: 0;
        margin-right: 0px;
      }

      .organic-video-reel-dvr .videoCube .video-label-box.trc-pre-label {
        margin: 0px 0px 5px 0px;
      }

      .organic-video-reel-dvr .syndicatedItem .video-label-box {
        height: 88px;
        margin: 5px 0px 0px 0px;
      }

      .organic-video-reel-dvr .logoDiv a span {
        font-size: 11px;
        color: #000000;
        display: inline;
        font-weight: normal;
      }

      .organic-video-reel-dvr .videoCube .video-label-box .video-title {
        text-decoration: none;
      }

      .organic-video-reel-dvr .videoCube:hover .video-label-box .video-title {
        text-decoration: none;
      }

      .organic-video-reel-dvr
        .videoCube:hover
        .video-label-box
        .video-description {
        text-decoration: none;
      }

      .organic-video-reel-dvr .video-label-box .branding {
        display: block;
      }

      .organic-video-reel-dvr .trc_rbox_header .trc_header_ext {
        position: relative;
        top: auto;
        right: auto;
      }

      .organic-video-reel-dvr .logoDiv a {
        font-size: 100%;
      }

      .organic-video-reel-dvr .videoCube a {
        padding: 0;
      }

      .organic-video-reel-dvr .trc_rbox_header .logoDiv {
        line-height: normal;
      }

      .organic-video-reel-dvr .trc_header_left_column {
        height: auto;
        background-color: transparent;
      }

      .organic-video-reel-dvr .trc_header_right_part {
        margin: 0px 0px 0px 0px;
      }

      /* s-split-organic-video-reel-dvr */
      .organic-video-reel-dvr .trc_header_right_column {
        background: transparent;
        height: auto;
      }

      /* e-split-organic-video-reel-dvr */
      @media screen and (min-width: 0px) {
        .trc_elastic_organic-video-reel-dvr
          .trc_rbox_outer
          .videoCube
          .video-label-box {
          height: auto;
        }

        .trc_elastic_organic-video-reel-dvr .trc_rbox_outer .videoCube {
          margin-bottom: 10px;
        }

        .trc_elastic_organic-video-reel-dvr .trc_rbox_outer {
          margin-left: -2%;
        }

        .trc_elastic_organic-video-reel-dvr .videoCube_aspect {
          padding-bottom: 56.25%;
          width: 100%;
        }

        .trc_elastic_organic-video-reel-dvr .videoCube {
          width: 97.99%;
          position: relative;
          float: left;
          margin: 0 0 2% 0;
          margin-left: 2%;
        }

        .trc_elastic_organic-video-reel-dvr div.videoCube:nth-of-type(-n + 5) {
          display: block;
          visibility: visible;
        }

        .trc_elastic_organic-video-reel-dvr div.videoCube:nth-of-type(n + 6) {
          display: none;
          visibility: hidden;
        }
      }

      .thumbnails-a-midarticle {
        width: 300px;
        _width: 300px;
        border-width: 0px 0px 0px 0px;
        border-style: solid solid solid solid;
        border-color: #dfdfdf;
        padding: 0px 0px 0px 0px;
        border-radius: 0;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        box-shadow: none;
      }

      .thumbnails-a-midarticle vignette {
        xbuttoncolor: #fff;
        backgroundcolor: #fff;
        backgroundopacity: 0.8;
        xbuttonbgcolor: #000;
      }

      .thumbnails-a-midarticle .playerCube .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .tbl-reco-reel-slider {
        z-index: 99999;
        margin: initial;
        top: 50%;
      }

      .thumbnails-a-midarticle .trc_lightbox_overlay {
        background-color: #000000;
        opacity: 0.7;
        filter: alpha(opacity=70);
      }

      .thumbnails-a-midarticle
        .tbl-recommendation-reel
        .tbl-text-under-branding-background {
        background-color: #ebebeb;
      }

      .thumbnails-a-midarticle div.syndicatedItem:hover,
      .thumbnails-a-midarticle div.syndicatedItem.videoCube_hover {
        background-color: transparent;
      }

      .thumbnails-a-midarticle .playerCube div.videoCube:hover,
      .thumbnails-a-midarticle div.videoCube_hover {
        background-color: transparent;
      }

      .thumbnails-a-midarticle .trc_pager_prev:hover,
      .thumbnails-a-midarticle .trc_pager_next:hover {
        color: #6497ed;
      }

      .thumbnails-a-midarticle .trc_rbox_border_elm {
        border-color: darkgray;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-views {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-category {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .tbl-vignette-close-btn-wrp {
        height: 15;
        background: #000;
      }

      .thumbnails-a-midarticle .syndicatedItem .sponsored {
        color: #9c9a9c;
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .pager_disabled {
        color: #7d898f;
      }

      .thumbnails-a-midarticle .playerCube .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-uploader {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .videoCube.thumbnail_start .thumbBlock_holder {
        width: 40%;
        _width: 40%;
      }

      .thumbnails-a-midarticle .playerCube .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .trc_sponsored_overlay {
        background-color: black;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-external-data {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .trc_rbox_header {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 100%;
        font-weight: bold;
        text-decoration: none;
        color: #000000;
        border-width: 0;
        background: transparent;
        border-style: none;
        border-color: #d6d5d3;
        padding: 0px 0px 2px 0px;
        line-height: 1.2em;
        display: none;
        margin: 0px 0px 0px 0px;
        position: relative;
        background-color: transparent;
        box-sizing: initial;
        height: auto;
        width: auto;
        _width: auto;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-rating {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .videoCube.vertical {
        border-style: solid none none none;
      }

      .thumbnails-a-midarticle .trc_pager_unselected {
        color: #7d898f;
      }

      .thumbnails-a-midarticle .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
        display: inherit;
      }

      .thumbnails-a-midarticle .syndicatedItem {
        background-color: transparent;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-duration-detail {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbnails-a-midarticle
        body.tbl-show-explore-more
        div#tbl-explore-more-container {
        z-index: 2147483647;
      }

      .thumbnails-a-midarticle .playerCube .videoCube.horizontal {
        border-style: none none none none;
      }

      .thumbnails-a-midarticle .videoCube.syndicatedItem .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .thumbnails-a-midarticle .videoCube.syndicatedItem.vertical {
        border-style: solid none none none;
      }

      .thumbnails-a-midarticle .sponsored {
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
        color: #9c9a9c;
      }

      .thumbnails-a-midarticle .videoCube.syndicatedItem .thumbBlock {
        border-color: darkgray;
        border-width: 0px;
      }

      .thumbnails-a-midarticle
        .videoCube.syndicatedItem
        .thumbBlock
        .static-text {
        text-align: left;
        background-color: black;
        display: none;
        color: white;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
      }

      .thumbnails-a-midarticle
        .videoCube.thumbnail_start.trc-split-label
        .trc-pre-label {
        width: 30%;
        _width: 30%;
      }

      .thumbnails-a-midarticle .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .thumbnail-emblem {
        background-position: 5% 5%;
        width: 35;
        _width: 35;
        height: 35;
      }

      .thumbnails-a-midarticle .tbl-vignette-background-screen {
        background-color: #fff;
        opacity: 0.8;
        filter: alpha(opacity=80);
      }

      .thumbnails-a-midarticle .syndicatedItem .video-description {
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        font-weight: normal;
        line-height: 19px;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .tbl-cta-style .cta-button:hover {
        color: inherit;
        border-color: #999990;
      }

      .thumbnails-a-midarticle .playerCube .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .videoCube:hover .thumbnail-overlay,
      .thumbnails-a-midarticle .videoCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .thumbnails-a-midarticle .video-label-box.trc-pre-label {
        height: 0px;
      }

      .thumbnails-a-midarticle .videoCube.thumbnail_start .trc-pre-label {
        width: 60%;
        _width: 60%;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-title {
        max-height: 44px;
        *height: 44px;
        color: #000000;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        text-decoration: none;
        padding: 0;
      }

      .thumbnails-a-midarticle .playerCube:hover .thumbnail-overlay,
      .thumbnails-a-midarticle .playerCube_hover .thumbnail-overlay {
        background-image: null;
      }

      .thumbnails-a-midarticle
        .videoCube.thumbnail_start.trc-split-label
        .trc-main-label {
        width: 30%;
        _width: 30%;
      }

      .thumbnails-a-midarticle .videoCube {
        width: auto;
        _width: auto;
        background-color: transparent;
        border-width: 0px 0px 0px 0px;
        border-color: #e4e4e4;
        padding: 0px 0px 0px 0px;
        height: auto;
        margin-left: 0px;
        margin-top: 0px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-style: SOLID;
      }

      .thumbnails-a-midarticle .sponsored-default .video-description {
        max-height: 2.2em;
        *height: 2.2em;
      }

      .thumbnails-a-midarticle .tbl-vignette-attribution {
        color: #6b6666;
        font-size: 15px;
      }

      .thumbnails-a-midarticle .playerCube .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 10px;
        line-height: 11px;
        font-weight: normal;
        text-decoration: none;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
      }

      .thumbnails-a-midarticle .playerCube .videoCube .video-label-box {
        margin-left: 81px;
        margin-right: 0px;
      }

      .thumbnails-a-midarticle .videoCube.syndicatedItem .thumbBlock .branding {
        text-align: left;
        background-color: transparent;
        display: none;
        left: 0px;
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
      }

      .thumbnails-a-midarticle div.videoCube:hover,
      .thumbnails-a-midarticle div.videoCube_hover {
        background-color: transparent;
      }

      .thumbnails-a-midarticle
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-ui-line {
        background-color: #333333;
      }

      .thumbnails-a-midarticle .videoCube .sponsored {
        margin-top: -7px;
      }

      .thumbnails-a-midarticle .trc_pager_pages div {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .sponsored-url {
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
        color: green;
      }

      .thumbnails-a-midarticle .playerCube .video-title {
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 14px;
        line-height: 17.5px;
        font-weight: bold;
        max-height: 2.58em;
        *height: 2.58em;
        color: black;
      }

      .thumbnails-a-midarticle .trc_rbox_header_icon_img {
        margin: 0px;
        height: 18px;
      }

      .thumbnails-a-midarticle
        .tbl-recommendation-reel
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .thumbnails-a-midarticle .tbl-recommendation-reel .tbl-ui-line {
        background-color: #333333;
      }

      .thumbnails-a-midarticle .videoCube.syndicatedItem.horizontal {
        border-style: none;
      }

      .thumbnails-a-midarticle .videoCube .thumbBlock .static-text {
        font-weight: normal;
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 11px;
        background-color: #a30202;
        display: block;
        color: #ffffff;
        text-align: left;
      }

      .thumbnails-a-midarticle .video-title {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
        line-height: 22px;
        font-weight: bold;
        max-height: 66px;
        *height: 66px;
        color: #000000;
        text-decoration: none;
        margin: 0 0 0 0;
      }

      .thumbnails-a-midarticle .video-label,
      .thumbnails-a-midarticle .sponsored,
      .thumbnails-a-midarticle .sponsored-url {
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
      }

      .thumbnails-a-midarticle .playerCube .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .syndicatedItem .branding {
        color: #606669;
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .thumbnails-a-midarticle .trc_pager_selected {
        color: #0056b3;
      }

      .thumbnails-a-midarticle .videoCube.syndicatedItem {
        background-color: transparent;
        border-color: #e4e4e4;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-width: 0px 0px 0px 0px;
        border-style: SOLID;
      }

      .thumbnails-a-midarticle .branding div.logoDiv {
        font-family: inherit;
      }

      .thumbnails-a-midarticle .trc_rbox_div {
        width: auto;
        _width: 99%;
        height: 410px;
        border-width: 0;
        padding: 0;
      }

      .thumbnails-a-midarticle .playerCube .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .trc_pager div {
        font-family: serif;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-label-box.trc-pre-label {
        height: 0px;
      }

      .thumbnails-a-midarticle recommendationReel {
        min-adx-line-color: #2abfd5;
        min-adx-progress-color: #fff;
      }

      .thumbnails-a-midarticle .videoCube.horizontal {
        border-style: none;
      }

      .thumbnails-a-midarticle div.trc_pager_pages div:hover {
        color: #6497ed;
      }

      .thumbnails-a-midarticle .pager_enabled {
        color: #0056b3;
      }

      .thumbnails-a-midarticle .playerCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .thumbnails-a-midarticle .videoCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .thumbnails-a-midarticle .playerCube .videoCube .video-duration {
        display: block;
        left: 36px;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-published-date {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        display: inherit;
      }

      .thumbnails-a-midarticle .syndicatedItem .sponsored-url {
        color: green;
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
      }

      .thumbnails-a-midarticle .playerCube .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .thumbnails-a-midarticle .playerCube .video-label-box {
        text-align: left;
      }

      .thumbnails-a-midarticle div.sponsored-default:hover,
      .thumbnails-a-midarticle div.sponsored-default.videoCube_hover {
        background-color: inherit;
      }

      .thumbnails-a-midarticle
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .thumbnails-a-midarticle .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .trc_pager_prev,
      .thumbnails-a-midarticle .trc_pager_next {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .thumbnails-a-midarticle .videoCube.syndicatedItem .video-duration {
        display: none;
        left: 36px;
      }

      .thumbnails-a-midarticle .sponsored-default .video-title {
        max-height: 2.58em;
        *height: 2.58em;
      }

      .thumbnails-a-midarticle .branding {
        color: #606669;
        font-size: 12px;
        font-weight: bold;
        text-decoration: none;
        font-family: Monsterrat, "Trebuchet MS", Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 22px;
      }

      .thumbnails-a-midarticle .sponsored-default {
        background-color: #f7f6c6;
      }

      .thumbnails-a-midarticle .playerCube .videoCube {
        background-color: transparent;
        border-color: #d6d5d3;
        border-width: 1px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        margin-left: 0px;
        margin-top: 0px;
        padding: 3px;
      }

      .thumbnails-a-midarticle .branding .logoDiv a span {
        color: inherit;
        font-size: inherit;
      }

      .thumbnails-a-midarticle .video-label-box {
        text-align: left;
        height: 66px;
        margin: 5px 0px 0px 0px;
      }

      .thumbnails-a-midarticle .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        line-height: 19px;
        font-weight: normal;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
        text-decoration: none;
      }

      .thumbnails-a-midarticle .videoCube .video-duration {
        left: 36px;
        display: none;
      }

      .thumbnails-a-midarticle div.syndicatedItem:hover .thumbBlock {
        border-color: inherit;
      }

      .thumbnails-a-midarticle .trc_pager_counter {
        color: #000000;
      }

      .thumbnails-a-midarticle .whatsThisSyndicated {
        font-family: Arial, Verdana, sans-serif;
        font-size: 9px;
        font-weight: normal;
        color: black;
        text-decoration: none;
        padding: 0;
      }

      .thumbnails-a-midarticle .playerCube .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle div.videoCube:hover .thumbBlock {
        border-color: inherit;
      }

      .thumbnails-a-midarticle .video-icon-img {
        margin: 0px;
        height: 18px;
      }

      .thumbnails-a-midarticle .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .thumbnails-a-midarticle .tbl-cta-style .cta-button {
        font-family: Helvetica, Arial, sans-serif;
        background-color: transparent;
        border-color: #acacac;
        color: #333333;
      }

      .thumbnails-a-midarticle .videoCube .video-label-box {
        margin-left: 0;
        margin-right: 0px;
      }

      .thumbnails-a-midarticle .videoCube .video-label-box.trc-pre-label {
        margin: 0px 0px 0px 0px;
      }

      .thumbnails-a-midarticle .syndicatedItem .video-label-box {
        height: 66px;
        margin: 5px 0px 0px 0px;
      }

      .thumbnails-a-midarticle .logoDiv a span {
        font-size: 11px;
        color: #999999;
        display: inline;
        font-weight: normal;
      }

      .thumbnails-a-midarticle .videoCube .video-label-box .video-title {
        text-decoration: none;
      }

      .thumbnails-a-midarticle .videoCube:hover .video-label-box .video-title {
        text-decoration: underline;
      }

      .thumbnails-a-midarticle
        .videoCube:hover
        .video-label-box
        .video-description {
        text-decoration: underline;
      }

      .thumbnails-a-midarticle .video-label-box .branding {
        display: block;
      }

      .thumbnails-a-midarticle .trc_rbox_header .trc_header_ext {
        position: relative;
        top: auto;
        right: auto;
      }

      .thumbnails-a-midarticle .logoDiv a {
        font-size: 100%;
      }

      .thumbnails-a-midarticle .videoCube a {
        padding: 0;
      }

      .thumbnails-a-midarticle .trc_rbox_header .logoDiv {
        line-height: normal;
      }

      .thumbnails-a-midarticle .trc_rbox_header_span .trc_header_right_column {
        background: transparent;
        height: auto;
      }

      .thumbnails-a-midarticle .trc_header_left_column {
        height: auto;
        background-color: transparent;
      }

      /* s-split-thumbnails-a-midarticle */ /* changes */
      .thumbnails-a-midarticle
        .videoCube
        .video-label-box
        .branding.composite-branding {
        width: 97%;
      }

      /*.thumbnails-a-midarticle .branding .branding-inner {	width: 70%}*/
      .thumbnails-a-midarticle {
        display: grid;
        grid-template-columns: minmax(0, 1fr);
      }

      @media screen and (max-width: 480px) {
        .thumbnails-a-midarticle .added-icon-svg {
          width: 32px;
        }
      }

      .thumbnails-a-midarticle
        .videoCube
        .branding
        .attribution-disclosure-link-sponsored,
      .thumbnails-a-midarticle .branding .branding-separator {
        display: none;
      }

      /* e-split-thumbnails-a-midarticle */
      @media screen and (min-width: 0px) and (max-width: 767px) {
        .trc_elastic_thumbnails-a-midarticle
          .trc_rbox_outer
          .videoCube
          .video-label-box {
          height: auto;
        }

        .trc_elastic_thumbnails-a-midarticle .trc_rbox_outer .videoCube {
          margin-bottom: 10px;
        }

        .trc_elastic_thumbnails-a-midarticle .trc_rbox_outer {
          margin-left: -2%;
        }

        .trc_elastic_thumbnails-a-midarticle .videoCube_aspect {
          padding-bottom: 58.333333333333336%;
          width: 100%;
        }

        .trc_elastic_thumbnails-a-midarticle .videoCube {
          width: 97.99%;
          position: relative;
          float: left;
          margin: 0 0 2% 0;
          margin-left: 2%;
        }

        .trc_elastic_thumbnails-a-midarticle div.videoCube:nth-of-type(-n + 1) {
          display: block;
          visibility: visible;
        }

        .trc_elastic_thumbnails-a-midarticle div.videoCube:nth-of-type(n + 2) {
          display: none;
          visibility: hidden;
        }
      }

      @media screen and (min-width: 768px) {
        .trc_elastic_thumbnails-a-midarticle
          .trc_rbox_outer
          .videoCube
          .trc-main-label {
          height: auto;
        }

        .trc_elastic_thumbnails-a-midarticle .trc_rbox_outer .videoCube {
          margin-bottom: 10px;
        }

        .trc_elastic_thumbnails-a-midarticle .trc_rbox_outer {
          margin-left: -2%;
        }

        .trc_elastic_thumbnails-a-midarticle .videoCube_aspect {
          padding-bottom: 58.333333333333336%;
          width: 100%;
        }

        .trc_elastic_thumbnails-a-midarticle .videoCube {
          width: 47.995%;
          position: relative;
          float: left;
          margin: 0 0 2% 0;
          margin-left: 2%;
        }

        .trc_elastic_thumbnails-a-midarticle div.videoCube:nth-of-type(-n + 2) {
          display: block;
          visibility: visible;
        }

        .trc_elastic_thumbnails-a-midarticle div.videoCube:nth-of-type(n + 3) {
          display: none;
          visibility: hidden;
        }
      }</style>
    <style id="tblCallToAction">.videoCube
        a.tbl-text-over-container
        span.video-label-box.video-label-box-cta {
        position: inherit;
      }

      .videoCube a.video-cta-style {
        width: 100%;
      }

      .videoCube a.video-cta-style .video-label-box.video-label-box-cta {
        display: flex;
        flex-wrap: wrap;
        position: relative;
        align-content: flex-start;
        align-items: center;
      }

      .videoCube
        a.video-cta-style
        .video-label-box.video-label-box-cta.video-label-box-cta-non-ie {
        justify-content: space-between;
      }

      .videoCube a.video-cta-style .video-label-flex-cta-item {
        flex-basis: 100%;
      }

      .videoCube a.video-cta-style .video-branding-flex-cta-item {
        margin-top: 1px;
        flex-grow: 1;
        flex-basis: 1px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .videoCube .video-cta-href {
        display: inline-block;
        margin-top: 1px;
        margin-inline-start: 2px;
        padding: 0;
        max-width: 100%;
        min-width: 72px;
        min-width: min(100%, 72px);
        bottom: 0;
        vertical-align: top;
        position: relative;
        box-sizing: content-box;
        flex-shrink: 0;
        font-size: 10px;
        line-height: 13.2px;
      }

      .videoCube .video-cta-href button.video-cta-button {
        margin: 0;
        height: 24px;
        font-size: 10px;
        line-height: 13.2px;
        border-radius: 4px;
        border: 1px solid #000;
        background-color: inherit;
        text-transform: none;
        letter-spacing: normal;
        box-sizing: border-box;
        cursor: pointer;
        outline: none;
        font-family: Helvetica;
        padding: 1px 4px;
        width: 100%;
        min-width: 1px;
        opacity: 1;
        box-shadow: none;
        user-select: none;
        transition: none;
        text-decoration: none;
        transform: none;
        font-weight: bold;
      }

      .videoCube .video-cta-href button.video-cta-button:hover {
        color: inherit;
        border-color: inherit;
        background-color: inherit;
        letter-spacing: normal;
      }

      .tbl-feed-container
        .videoCube
        .video-cta-href:not(.app-install-child)
        button.video-cta-button {
        border-radius: 24px;
        border-color: #acacac;
        font-size: 12px;
        line-height: 18px;
        padding: 0 18px;
        height: 26px;
      }</style>
    <style id="tbl-explore-more-style">#tbl-explore-more-container {
        position: absolute;
        top: auto;
        bottom: auto;
        margin: 0;
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
      }

      #tbl-explore-more-container.tbl-explore-more-rtl {
        left: auto;
        right: -1200%;
        display: none;
      }

      #tbl-explore-more-container.tbl-explore-more-ltr {
        right: auto;
        left: -1200%;
        display: none;
      }

      #tbl-explore-more-container.tbl-new-display {
        background-color: #fff;
        z-index: 2147483647;
        width: 100%;
        box-sizing: border-box;
      }

      #tbl-explore-more-container.tbl-new-display.tbl-explore-more-show-container {
        display: block !important;
      }

      #tbl-explore-more-container .tbl-explore-more-site-header {
        z-index: 2147483647;
        left: 0;
        right: 0;
        position: relative;
      }

      #tbl-explore-more-container .tbl-feed-header {
        display: none !important;
      }

      #tbl-explore-more-container #tbl-explore-more-title {
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-weight: bold;
        font-size: 22px;
        padding: 10px 0;
        color: #222;
      }

      @media screen and (min-width: 768px) {
        #tbl-explore-more-container .trc_multi_widget_container {
          padding-bottom: 22px;
        }

        #tbl-explore-more-container #tbl-explore-more-title {
          width: 100%;
        }

        #tbl-explore-more-container .tbl-title-and-pop-wrp {
          position: relative;
        }

        #tbl-explore-more-container .tbl-title-and-pop-wrp,
        #tbl-explore-more-container .tbl-feed-card,
        #tbl-explore-more-container .tbl-loading-cards-placeholder {
          width: 85%;
          max-width: 1000px;
          min-width: 800px;
          margin-right: auto;
          margin-left: auto;
          clear: both;
        }
      }

      body.tbl-show-explore-more {
        padding: 0 !important;
        margin: 0 !important;
      }

      body.tbl-show-explore-more.tbl-explore-more-show-original-header
        > *:not(#tbl-explore-more-container):not(_* headerSelector*):not(
          #tbl-feed-footer-overlay
        ):not([id^="tbl-aug"]:not([id="tbl-feed-view-container"])) {
        display: none;
      }

      body.tbl-show-explore-more.tbl-explore-more-hide-original-header
        > *:not(#tbl-explore-more-container):not([id="_cm-css-reset"]):not(
          #tbl-feed-footer-overlay
        ):not([id^="tbl-aug"]:not([id="tbl-feed-view-container"])) {
        display: none;
      }

      body.tbl-show-explore-more.tbl-explore-more-hide-original-header
        > *:not(#tbl-explore-more-container _* headerSelector*):not(
          [id="_cm-css-reset"]
        ):not(#tbl-feed-footer-overlay):not(
          [id^="tbl-aug"]:not([id="tbl-feed-view-container"])
        ) {
        display: none;
      }

      body.tbl-show-explore-more.tbl-explore-more-reset-padding-margin {
        padding-top: 0;
        margin-top: 0;
      }

      body.tbl-show-explore-more #tbl-explore-more-container {
        position: relative;
        display: block;
        z-index: 2147483647;
      }

      body.tbl-show-explore-more
        #tbl-explore-more-container.tbl-explore-more-rtl {
        left: auto;
        right: 0;
      }

      body.tbl-show-explore-more
        #tbl-explore-more-container.tbl-explore-more-ltr {
        right: auto;
        left: 0;
      }

      body.tbl-show-explore-more.tbl-explore-more-body-fixed {
        position: fixed;
        top: 0;
        width: 100vw;
        height: 100vh;
      }

      .adsbygoogle-noablate.tbl-explore-more-hide-dfp {
        display: none !important;
      }</style>
    <style id="tblStyle_2">.above-the-feed-premium-card-fp-delta {
        width: 300px;
        _width: 300px;
        border-width: 0px 0px 0px 0px;
        border-style: solid solid solid solid;
        border-color: #dfdfdf;
        padding: 0px 0px 0px 0px;
        border-radius: 0;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        box-shadow: none;
      }

      .above-the-feed-premium-card-fp-delta vignette {
        xbuttoncolor: #fff;
        backgroundcolor: #fff;
        backgroundopacity: 0.8;
        xbuttonbgcolor: #000;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .tbl-reco-reel-slider {
        z-index: 99999;
        margin: initial;
        top: 50%;
      }

      .above-the-feed-premium-card-fp-delta .trc_lightbox_overlay {
        background-color: #000000;
        opacity: 0.7;
        filter: alpha(opacity=70);
      }

      .above-the-feed-premium-card-fp-delta
        .tbl-recommendation-reel
        .tbl-text-under-branding-background {
        background-color: #ebebeb;
      }

      .above-the-feed-premium-card-fp-delta div.syndicatedItem:hover,
      .above-the-feed-premium-card-fp-delta div.syndicatedItem.videoCube_hover {
        background-color: transparent;
      }

      .above-the-feed-premium-card-fp-delta .playerCube div.videoCube:hover,
      .above-the-feed-premium-card-fp-delta div.videoCube_hover {
        background-color: transparent;
      }

      .above-the-feed-premium-card-fp-delta .trc_pager_prev:hover,
      .above-the-feed-premium-card-fp-delta .trc_pager_next:hover {
        color: #6497ed;
      }

      .above-the-feed-premium-card-fp-delta .trc_rbox_border_elm {
        border-color: darkgray;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .video-views {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .video-category {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .tbl-vignette-close-btn-wrp {
        height: 15;
        background: #000;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .sponsored {
        color: #9c9a9c;
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .pager_disabled {
        color: #7d898f;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .video-uploader {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.thumbnail_start
        .thumbBlock_holder {
        width: 40%;
        _width: 40%;
        margin: 0 0 0 0;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .video-uploader {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .trc_sponsored_overlay {
        background-color: black;
      }

      .above-the-feed-premium-card-fp-delta
        .syndicatedItem
        .video-external-data {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .trc_rbox_header {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 100%;
        font-weight: bold;
        text-decoration: none;
        color: #000000;
        border-width: 0;
        background: transparent;
        border-style: none;
        border-color: #d6d5d3;
        padding: 0px 0px 2px 0px;
        line-height: 1.2em;
        display: none;
        margin: 0px 0px 0px 0px;
        position: relative;
        background-color: transparent;
        box-sizing: initial;
        height: auto;
        width: auto;
        _width: auto;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .video-rating {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .videoCube.vertical {
        border-style: solid none none none;
      }

      .above-the-feed-premium-card-fp-delta .trc_pager_unselected {
        color: #7d898f;
      }

      .above-the-feed-premium-card-fp-delta .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
        display: inherit;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem {
        background-color: transparent;
      }

      .above-the-feed-premium-card-fp-delta
        .syndicatedItem
        .video-duration-detail {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta
        body.tbl-show-explore-more
        div#tbl-explore-more-container {
        z-index: 2147483647;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .videoCube.horizontal {
        border-style: none none none none;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.syndicatedItem
        .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .above-the-feed-premium-card-fp-delta .videoCube.syndicatedItem.vertical {
        border-style: solid none none none;
      }

      .above-the-feed-premium-card-fp-delta .sponsored {
        font-size: 9px;
        font-weight: normal;
        text-decoration: none;
        color: #9c9a9c;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.syndicatedItem
        .thumbBlock {
        border-color: darkgray;
        border-width: 0px;
        border-radius: 0;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.syndicatedItem
        .thumbBlock
        .static-text {
        text-align: left;
        background-color: black;
        display: none;
        color: white;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.thumbnail_start.trc-split-label
        .trc-pre-label {
        width: 30%;
        _width: 30%;
      }

      .above-the-feed-premium-card-fp-delta .video-category {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .thumbnail-emblem {
        background-position: 5% 5%;
        width: 35;
        _width: 35;
        height: 35;
      }

      .above-the-feed-premium-card-fp-delta .tbl-vignette-background-screen {
        background-color: #fff;
        opacity: 0.8;
        filter: alpha(opacity=80);
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .video-description {
        max-height: 44px;
        *height: 44px;
        color: #ffffff;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 13px;
        font-weight: normal;
        line-height: 22px;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .tbl-cta-style .cta-button:hover {
        color: inherit;
        border-color: #999990;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-published-date {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .videoCube:hover .thumbnail-overlay,
      .above-the-feed-premium-card-fp-delta
        .videoCube_hover
        .thumbnail-overlay {
        background-image: null;
      }

      .above-the-feed-premium-card-fp-delta .video-label-box.trc-pre-label {
        height: 0px;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.thumbnail_start
        .trc-pre-label {
        width: 60%;
        _width: 60%;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .video-title {
        max-height: 54px;
        *height: 54px;
        color: #ffffff;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 20px;
        line-height: 27px;
        font-weight: bold;
        text-decoration: none;
        padding: 0;
      }

      .above-the-feed-premium-card-fp-delta
        .playerCube:hover
        .thumbnail-overlay,
      .above-the-feed-premium-card-fp-delta
        .playerCube_hover
        .thumbnail-overlay {
        background-image: null;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.thumbnail_start.trc-split-label
        .trc-main-label {
        width: 30%;
        _width: 30%;
      }

      .above-the-feed-premium-card-fp-delta .videoCube {
        width: auto;
        _width: auto;
        background-color: transparent;
        border-width: 0px 0px 0px 0px;
        border-color: #e4e4e4;
        padding: 0;
        height: auto;
        margin-left: 0px;
        margin-top: 0px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-style: SOLID;
      }

      .above-the-feed-premium-card-fp-delta
        .sponsored-default
        .video-description {
        max-height: 2.2em;
        *height: 2.2em;
      }

      .above-the-feed-premium-card-fp-delta .tbl-vignette-attribution {
        color: #6b6666;
        font-size: 15px;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 10px;
        line-height: 11px;
        font-weight: normal;
        text-decoration: none;
        max-height: 2.2em;
        *height: 2.2em;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta
        .playerCube
        .videoCube
        .video-label-box {
        margin-left: 81px;
        margin-right: 0px;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.syndicatedItem
        .thumbBlock
        .branding {
        text-align: left;
        background-color: transparent;
        display: block;
        left: 0px;
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
      }

      .above-the-feed-premium-card-fp-delta div.videoCube:hover,
      .above-the-feed-premium-card-fp-delta div.videoCube_hover {
        background-color: transparent;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-ui-line {
        background-color: #333333;
      }

      .above-the-feed-premium-card-fp-delta .videoCube .sponsored {
        margin-top: -7px;
      }

      .above-the-feed-premium-card-fp-delta .trc_pager_pages div {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .sponsored-url {
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
        color: green;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-title {
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 14px;
        line-height: 17.5px;
        font-weight: bold;
        max-height: 2.58em;
        *height: 2.58em;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .trc_rbox_header_icon_img {
        margin: 0px;
        height: 18px;
      }

      .above-the-feed-premium-card-fp-delta
        .tbl-recommendation-reel
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .above-the-feed-premium-card-fp-delta
        .tbl-recommendation-reel
        .tbl-ui-line {
        background-color: #333333;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.syndicatedItem.horizontal {
        border-style: none;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube
        .thumbBlock
        .static-text {
        font-weight: normal;
        font-family: Arial, Helvetica, sans-serif;
        text-decoration: none;
        font-size: 11px;
        background-color: #a30202;
        display: block;
        color: #ffffff;
        text-align: left;
      }

      .above-the-feed-premium-card-fp-delta .video-title {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 20px;
        line-height: 27px;
        font-weight: bold;
        max-height: 81px;
        *height: 81px;
        color: #000000;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .video-label,
      .above-the-feed-premium-card-fp-delta .sponsored,
      .above-the-feed-premium-card-fp-delta .sponsored-url {
        font-family: Arial, Helvetica, sans-serif;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-rating {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .branding {
        color: #bbbbbb;
        font-size: 12px;
        font-weight: bold;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 27px;
        display: flex;
      }

      .above-the-feed-premium-card-fp-delta .trc_pager_selected {
        color: #0056b3;
      }

      .above-the-feed-premium-card-fp-delta .videoCube.syndicatedItem {
        background-color: transparent;
        border-color: #e4e4e4;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        border-width: 0px 0px 0px 0px;
        border-style: SOLID;
      }

      .above-the-feed-premium-card-fp-delta .branding div.logoDiv {
        font-family: inherit;
      }

      .above-the-feed-premium-card-fp-delta .trc_rbox_div {
        width: auto;
        _width: 99%;
        height: 410px;
        border-width: 0;
        padding: 0;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .trc_pager div {
        font-family: serif;
      }

      .above-the-feed-premium-card-fp-delta
        .syndicatedItem
        .video-label-box.trc-pre-label {
        height: 0px;
      }

      .above-the-feed-premium-card-fp-delta recommendationReel {
        min-adx-line-color: #2abfd5;
        min-adx-progress-color: #fff;
      }

      .above-the-feed-premium-card-fp-delta .videoCube.horizontal {
        border-style: none;
      }

      .above-the-feed-premium-card-fp-delta div.trc_pager_pages div:hover {
        color: #6497ed;
      }

      .above-the-feed-premium-card-fp-delta .pager_enabled {
        color: #0056b3;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .above-the-feed-premium-card-fp-delta .videoCube .thumbnail-overlay {
        background-image: null;
        background-position: 5% 5%;
      }

      .above-the-feed-premium-card-fp-delta
        .playerCube
        .videoCube
        .video-duration {
        display: block;
        left: 36px;
      }

      .above-the-feed-premium-card-fp-delta
        .syndicatedItem
        .video-published-date {
        color: black;
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        display: inherit;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .sponsored-url {
        color: green;
        font-size: 9px;
        font-weight: bold;
        text-decoration: underline;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-label-box {
        text-align: left;
      }

      .above-the-feed-premium-card-fp-delta div.sponsored-default:hover,
      .above-the-feed-premium-card-fp-delta
        div.sponsored-default.videoCube_hover {
        background-color: inherit;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube
        .story-widget.story-widget-text-under
        .tbl-text-under-title-background {
        background-color: #ebebeb;
      }

      .above-the-feed-premium-card-fp-delta .video-external-data {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .trc_pager_prev,
      .above-the-feed-premium-card-fp-delta .trc_pager_next {
        font-size: 12px;
        font-weight: normal;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .videoCube .thumbBlock {
        border-width: 0px;
        border-color: darkgray;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube.syndicatedItem
        .video-duration {
        display: none;
        left: 36px;
      }

      .above-the-feed-premium-card-fp-delta .sponsored-default .video-title {
        max-height: 2.58em;
        *height: 2.58em;
      }

      .above-the-feed-premium-card-fp-delta .branding {
        color: #9999;
        font-size: 11px;
        font-weight: bold;
        text-decoration: none;
        font-family: Arial, Helvetica, sans-serif;
        background-image: null;
        text-align: left;
        line-height: 27px;
      }

      .above-the-feed-premium-card-fp-delta .sponsored-default {
        background-color: #f7f6c6;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .videoCube {
        background-color: transparent;
        border-color: #d6d5d3;
        border-width: 1px;
        border-radius: 0px;
        -moz-border-radius: 0px;
        -webkit-border-radius: 0px;
        margin-left: 0px;
        margin-top: 0px;
        padding: 3px;
      }

      .above-the-feed-premium-card-fp-delta .branding .logoDiv a span {
        color: inherit;
        font-size: inherit;
      }

      .above-the-feed-premium-card-fp-delta .video-label-box {
        text-align: left;
        height: 125px;
        margin: 5px 0px 0px 0px;
      }

      .above-the-feed-premium-card-fp-delta .video-description {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 13px;
        line-height: 22px;
        font-weight: normal;
        max-height: 44px;
        *height: 44px;
        color: black;
        text-decoration: none;
      }

      .above-the-feed-premium-card-fp-delta .videoCube .video-duration {
        left: 36px;
        display: none;
      }

      .above-the-feed-premium-card-fp-delta
        div.syndicatedItem:hover
        .thumbBlock {
        border-color: inherit;
      }

      .above-the-feed-premium-card-fp-delta .trc_pager_counter {
        color: #000000;
      }

      .above-the-feed-premium-card-fp-delta .whatsThisSyndicated {
        font-family: Arial, Verdana, sans-serif;
        font-size: 9px;
        font-weight: normal;
        color: black;
        text-decoration: none;
        padding: 0;
      }

      .above-the-feed-premium-card-fp-delta .playerCube .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .video-duration-detail {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta div.videoCube:hover .thumbBlock {
        border-color: inherit;
      }

      .above-the-feed-premium-card-fp-delta .video-icon-img {
        margin: 0px;
        height: 18px;
      }

      .above-the-feed-premium-card-fp-delta .video-views {
        font-size: 10px;
        font-weight: normal;
        text-decoration: none;
        color: black;
      }

      .above-the-feed-premium-card-fp-delta .tbl-cta-style .cta-button {
        font-family: Helvetica, Arial, sans-serif;
        background-color: transparent;
        border-color: #acacac;
        color: #333333;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube
        .video-label-box.trc-pre-label {
        margin: 0px 0px 0px 0px;
      }

      .above-the-feed-premium-card-fp-delta .syndicatedItem .video-label-box {
        height: 98px;
        margin: 0;
        padding: 0 15px;
        background-color: transparent;
      }

      .above-the-feed-premium-card-fp-delta .logoDiv a span {
        font-size: 11px;
        color: #999999;
        display: inline;
        font-weight: normal;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube:hover
        .video-label-box
        .video-description {
        text-decoration: underline;
      }

      .above-the-feed-premium-card-fp-delta
        .videoCube
        .video-label-box
        .video-title {
        margin: 0 0 3px 0;
      }

      .above-the-feed-premium-card-fp-delta .video-label-box .branding {
        display: flex;
      }

      .above-the-feed-premium-card-fp-delta .trc_rbox_header .trc_header_ext {
        position: relative;
        top: auto;
        right: auto;
      }

      .above-the-feed-premium-card-fp-delta .videoCube a {
        padding: 0;
      }

      .above-the-feed-premium-card-fp-delta
        .trc_rbox_header_span
        .trc_header_right_column {
        height: auto;
      }

      .above-the-feed-premium-card-fp-delta .thumbBlock_holder {
        margin: 0;
      }

      .above-the-feed-premium-card-fp-delta .trc_header_left_column {
        height: auto;
      }

      .above-the-feed-premium-card-fp-delta .trc_header_right_part {
        margin: 0px 0 0 0;
      }

      /* s-split-above-the-feed-premium-card-fp-delta */
      [class*="above-the-feed-premium-card-yh"]:not(
        [class*="scrollable-carousel"],
        .taboola-connect-placement
      ) {
        width: 100vw;
        position: relative;
        box-shadow: none;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )[id*="trc_wrapper"] {
        width: unset;
        max-width: unset;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        * {
        font-family: "Poppins" !important;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        + .tbl-feed-header {
        margin-top: 30px;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .background-img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-position: top;
        background-size: cover;
        display: flex;
        flex-direction: column;
        justify-content: end;
        background-repeat: no-repeat;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .background-gradient {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(
          0deg,
          rgba(0, 0, 0, 1) 31%,
          rgba(255, 255, 255, 0) 60%
        );
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .item-label-href {
        display: flex;
        flex-direction: column;
        justify-content: end;
        position: relative;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .item-label-href::before {
        content: "";
        width: 100%;
        height: 100px;
        position: absolute;
        top: -98px;
        background: -webkit-linear-gradient(
          bottom,
          rgba(0, 0, 0) 0%,
          rgb(0 0 0 / 0%) 100%
        );
        background: -webkit-gradient(
          linear,
          left top,
          left bottom,
          from(rgba(0, 0, 0, 0%)),
          to(rgba(0, 0, 0, 100%))
        );
        background: -o-linear-gradient(
          bottom,
          rgba(0, 0, 0) 0%,
          rgb(0 0 0 / 0%) 100%
        );
        background: linear-gradient(
          to top,
          rgba(0, 0, 0) 0%,
          25%,
          rgb(0 0 0 / 0%) 64%
        );
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .ie-gradient-fill {
        top: -100px;
        height: 100px;
        width: 100%;
        position: absolute;
        background: -webkit-linear-gradient(
          to bottom,
          rgba(0, 0, 0, 0) 0%,
          rgba(1, 0, 0, 1) 100%
        );
        background: -o-linear-gradient(
          to bottom,
          rgba(0, 0, 0, 0) 0%,
          rgba(1, 0, 0, 1) 100%
        );
        background: linear-gradient(
          to bottom,
          rgba(0, 0, 0, 0) 0%,
          rgba(1, 0, 0, 1) 100%
        );
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .video-label-box {
        position: relative;
        top: -10px;
        padding: 0 15px;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .video-title {
        -webkit-line-clamp: 2 !important;
        color: #ffffff;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .video-description {
        color: #ffffff;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .logoDiv
        a
        span {
        font-size: 12px !important;
        color: #bbbbbb;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .trc_rbox_outer {
        padding: 0 !important;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .trc_rbox_outer
        .trc_rbox_div {
        margin-bottom: 0;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        ).tbl-feed-card
        .trc_rbox_container
        .trc_rbox_header {
        display: none !important;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .videoCube {
        margin-bottom: 0 !important;
      }

      [class*="above-the-feed-premium-card-yh"]
        .videoCube:not(.taboola-connect-item) {
        background-color: black !important;
      }

      [class*="above-the-feed-premium-card-yh"].tbl-rtl:not(
          [class*="scrollable-carousel"]
        )
        .videoCube
        .video-cta-href
        button.video-cta-button {
        left: 15px;
        right: auto;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .videoCube
        .video-cta-href
        button.video-cta-button {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 30px;
        background-color: white;
        position: absolute;
        right: 15px;
        bottom: 6px;
        border-radius: 33px;
        font-size: 14px;
        color: black !important;
        width: auto;
        font-weight: 400 !important;
        padding: 0 13px;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .videoCube
        .video-cta-href {
        display: block;
        position: static;
        margin: 0 !important;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .branding {
        margin: 8px 0;
      }

      [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        )
        .thumbBlock
        .branding {
        display: none !important;
      }

      @media (min-width: 480px) {
        [class*="above-the-feed-premium-card-yh"]:not(
          [class*="scrollable-carousel"]
        ) {
          position: relative;
          border-radius: 16px !important;
          overflow: hidden;
          max-width: 600px;
          width: 75%;
          margin: auto !important;
        }

        [class*="above-the-feed-premium-card-yh"]:not(
            [class*="scrollable-carousel"]
          )
          .branding {
          margin-top: 10px;
        }

        [class*="above-the-feed-premium-card-yh"]:not(
            [class*="scrollable-carousel"]
          )
          .cta-button {
          width: 130px;
          height: 30px;
        }

        [class*="above-the-feed-premium-card-yh"]:not(
            [class*="scrollable-carousel"]
          )
          .videoCube {
          border-radius: 14px 14px 0 0;
        }
      }

      /* e-split-above-the-feed-premium-card-fp-delta */
      @media screen and (min-width: 0px) and (max-width: 480px) {
        .trc_elastic_above-the-feed-premium-card-fp-delta
          .trc_rbox_outer
          .videoCube
          .video-label-box {
          height: auto;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta
          .trc_rbox_outer
          .videoCube {
          margin-bottom: 10px;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta .trc_rbox_outer {
          margin-left: -2%;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta .videoCube_aspect {
          padding-bottom: 56.17977528089888%;
          width: 100%;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta .videoCube {
          width: 97.99%;
          position: relative;
          float: left;
          margin: 0 0 2% 0;
          margin-left: 2%;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta
          div.videoCube:nth-of-type(-n + 1) {
          display: block;
          visibility: visible;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta
          div.videoCube:nth-of-type(n + 2) {
          display: none;
          visibility: hidden;
        }
      }

      @media screen and (min-width: 481px) {
        .trc_elastic_above-the-feed-premium-card-fp-delta
          .trc_rbox_outer
          .videoCube
          .video-label-box {
          height: auto;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta
          .trc_rbox_outer
          .videoCube {
          margin-bottom: 10px;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta .trc_rbox_outer {
          margin-left: -2%;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta .videoCube_aspect {
          padding-bottom: 52.35602094240838%;
          width: 100%;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta .videoCube {
          width: 97.99%;
          position: relative;
          float: left;
          margin: 0 0 2% 0;
          margin-left: 2%;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta
          div.videoCube:nth-of-type(-n + 1) {
          display: block;
          visibility: visible;
        }

        .trc_elastic_above-the-feed-premium-card-fp-delta
          div.videoCube:nth-of-type(n + 2) {
          display: none;
          visibility: hidden;
        }
      }</style>
    <style id="feedUiCss-1">.tbl-loading-spinner.tbl-loading-cards-placeholder {
        background: rgba(0, 0, 0, 0);
        background-size: 100%;
        height: auto;
        margin-top: 40px;
      }

      .tbl-placeholder-card {
        background: #f6f7f9;
        height: 125px;
        overflow: hidden;
        position: relative;
        margin-bottom: 48px;
      }

      .tbl-placeholder-card:before {
        background-color: #f6f7f9;
        background-image: url('img/9117a6d9-cbf1-4ea6-8caa-7461ce6554bc.gif');
        background-repeat: repeat-y;
        background-size: 100% 1px;
        content: " ";
        display: block;
        height: 100%;
      }

      .tbl-masker {
        position: absolute;
        width: calc(100% - 190px - 24px);
        background-color: #fff;
        box-sizing: content-box;
        border-color: #fff;
        border-style: solid;
        border-left-width: 24px;
      }

      .tbl-first-row-pl,
      .tbl-second-row-pl,
      .tbl-third-row-pl {
        background: rgba(0, 0, 0, 0);
        z-index: 1;
      }

      .tbl-first-row-pl {
        top: 0;
        height: 18px;
        left: 190px;
        border-top-width: 11px;
        border-bottom-width: 18px;
      }

      .tbl-second-row-pl {
        top: 47px;
        height: 18px;
        left: 190px;
        border-top-width: 0;
        border-bottom-width: 18px;
      }

      .tbl-third-row-pl {
        top: 83px;
        height: 15px;
        left: 190px;
        border-top-width: 0;
        border-bottom-width: 35px;
      }

      .tbl-last-row-right-padding {
        top: 83px;
        left: calc(30% + 130px);
        width: 100%;
        height: 15px;
        border-width: 0;
      }

      .tbl-img-top-padding,
      .tbl-img-bottom-padding,
      .tbl-first-col-padding {
        display: none;
      }

      .tbl-second-col-padding {
        display: block;
        width: 24px;
        height: 100%;
        border-width: 0;
        top: 0;
        right: 0;
      }

      .render-late-effect[data-feed-main-container-id="taboola-below-article-thumbnails"]
        .thumbBlock {
        opacity: 0;
        transition: opacity 0.75s;
      }

      .render-late-effect[data-feed-main-container-id="taboola-below-article-thumbnails"]
        .thumbBlock[style*="background-image"] {
        opacity: 1;
      }

      .tbl-loading-placeholder-dir-rtl .tbl-masker {
        border-right-width: 24px;
      }

      .tbl-loading-placeholder-dir-rtl .tbl-first-row-pl,
      .tbl-loading-placeholder-dir-rtl .tbl-second-row-pl,
      .tbl-loading-placeholder-dir-rtl .tbl-third-row-pl {
        right: 190px;
        left: auto;
      }

      .tbl-loading-placeholder-dir-rtl .tbl-last-row-right-padding {
        right: calc(30% + 130px);
        left: auto;
      }

      .tbl-loading-placeholder-dir-rtl .tbl-second-col-padding {
        right: auto;
        left: 0;
      }

      @media screen and (max-width: 480px) and (min-width: 0px) {
        .tbl-loading-spinner.tbl-loading-cards-placeholder {
          margin-top: 8px;
        }

        .tbl-placeholder-card {
          height: 87px;
          margin-bottom: 8px;
        }

        .tbl-masker {
          width: calc(100% - 114px - 12px);
          border-left-width: 12px;
        }

        .tbl-loading-placeholder-dir-rtl .tbl-masker {
          border-right-width: 12px;
        }

        .tbl-first-row-pl {
          top: 0;
          height: 10px;
          left: 114px;
          border-top-width: 16px;
          border-bottom-width: 10px;
        }

        .tbl-second-row-pl {
          top: 36px;
          height: 10px;
          left: 114px;
          border-top-width: 0;
          border-bottom-width: 11px;
        }

        .tbl-third-row-pl {
          top: 57px;
          height: 8px;
          left: 114px;
          border-top-width: 0;
          border-bottom-width: 22px;
        }

        .tbl-last-row-right-padding {
          top: 57px;
          height: 8px;
        }

        .block-no-border,
        .tbl-first-col-padding,
        .tbl-img-bottom-padding,
        .tbl-img-top-padding {
          display: block;
          border-width: 0;
        }

        .tbl-img-top-padding {
          height: 10px;
          width: 100%;
          top: 0;
        }

        .tbl-img-bottom-padding {
          height: 10px;
          width: 100%;
          bottom: 0;
        }

        .tbl-first-col-padding {
          height: 100%;
          width: 8px;
          top: 0;
          left: 0;
        }

        .tbl-second-col-padding {
          display: none;
        }

        .tbl-loading-placeholder-dir-rtl .tbl-first-col-padding {
          right: 0;
          left: auto;
        }

        .tbl-loading-placeholder-dir-rtl .tbl-first-row-pl,
        .tbl-loading-placeholder-dir-rtl .tbl-second-row-pl,
        .tbl-loading-placeholder-dir-rtl .tbl-third-row-pl {
          right: 114px;
          left: auto;
        }
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"] {
        position: relative;
        margin-top: 3px;
        -webkit-text-size-adjust: 100%;
        clear: both;
        padding: 0;
        background-color: transparent;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-feed-header {
        padding: 0 5px 10px;
        background: 0;
        box-sizing: border-box;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-feed-header-logo {
        height: 11px;
        width: 76px;
        display: inline-block;
        margin: 0;
        background-image: url('img/1e20e8ff-b903-43c3-81e2-8f9e185614d9.svg');
        background-repeat: no-repeat;
        background-position: 0 0;
        background-size: contain;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-feed-header.tbl-header-with-text.tbl-logo-right-position {
        padding: 0 5px 10px 0;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-feed-header.tbl-header-with-text.tbl-logo-left-position {
        padding: 0 0 10px 5px;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-feed-header.tbl-header-with-text {
        display: table;
        width: 100%;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-header-with-text
        .tbl-feed-header-logo {
        display: table-cell;
        background-position-y: 100%;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-header-with-text
        .tbl-feed-header-text {
        display: table-cell;
        width: calc(100% - 76px);
        word-break: break-word;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-logo-left-position {
        direction: ltr;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-header-with-text.tbl-logo-left-position
        .tbl-feed-header-text {
        text-align: right;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-logo-right-position {
        direction: rtl;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-header-with-text.tbl-logo-right-position
        .tbl-feed-header-text {
        text-align: left;
        direction: ltr;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-feed-card {
        margin-bottom: 10px;
        background-color: transparent;
        overflow: hidden;
        padding-bottom: 0;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-loading-spinner {
        margin-bottom: 10px;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-frame-DIVIDER
        .tbl-feed-card {
        box-shadow: 0 1px #e6ecf0;
        margin-bottom: 22px;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-frame-FRAME
        .tbl-feed-card {
        box-shadow: 0 2px 5px 0 #e6ecf0;
        margin: 0 2px 22px 2px;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-frame-SEMI_FRAME
        .tbl-feed-card {
        overflow: visible;
        position: relative;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-frame-SEMI_FRAME
        .tbl-feed-card::after,
      [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-frame-SEMI_FRAME
        .tbl-feed-card::before {
        content: "";
        width: 100%;
        left: 0;
        position: absolute;
        display: block;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-frame-SEMI_FRAME
        .tbl-feed-card::after {
        height: 50px;
        box-shadow: 0 2px 5px 0 #e6ecf0;
        bottom: 0;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-abp {
        max-width: 770px;
        margin: 3px auto 0;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-feed-card
        .video-label-box
        .video-description {
        margin-top: 2px;
      }

      @media screen and (max-width: 480px) {
        [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-full-width {
          padding: 0px 8px;
        }

        [data-feed-main-container-id="taboola-below-article-thumbnails"]
          .tbl-feed-card {
          margin-bottom: 5px;
        }

        [data-feed-main-container-id="taboola-below-article-thumbnails"]
          .trc-widget-footer,
        [data-feed-main-container-id="taboola-below-article-thumbnails"]
          .trc_header_ext {
          padding-right: 3px;
        }

        [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-frame-DIVIDER
          .tbl-feed-card {
          margin-bottom: 16px;
        }

        [data-feed-main-container-id="taboola-below-article-thumbnails"].tbl-feed-frame-FRAME
          .tbl-feed-card {
          margin: 0 0 16px 0;
        }
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"][data-feed-container-num] {
        background-color: TRANSPARENT;
        padding: 0px 0px 0px 0px;
      }

      [data-feed-main-container-id="taboola-below-article-thumbnails"]
        .tbl-feed-header {
        padding: 0px 5px 10px 5px;
        background: transparent;
        text-align: initial;
        display: table;
        width: 100%;
      }

      .tbl-feed-header-hide-logo {
        background: unset !important;
        background-size: unset !important;
        height: 0 !important;
      }

      .tbl-feed-header-hide-logo:only-child {
        display: none !important;
      }</style>
    <style id="slides-style">.tbl-slides-container .videoCube {
        z-index: 0;
      }

      .tbl-slides-container .tbl-next-item {
        z-index: 1;
      }

      .tbl-slides-container .tbl-show-item {
        z-index: 2;
      }</style>
    <link rel="stylesheet" href="files/css2.css" id="poppins-font">
    <style id="above-the-feed-card-style">div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        ) {
        width: 100vw;
        position: relative;
        box-shadow: none;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        ).pad-down {
        margin-bottom: 40px !important;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        ).tbl-rtl
        .videoCube
        .video-cta-href
        button.video-cta-button {
        left: 15px;
        right: auto;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )[id*="trc_wrapper"] {
        width: unset;
        max-width: unset;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        + .tbl-feed-header {
        margin-top: 30px;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        * {
        font-family: "Poppins" !important;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .background-img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-position: top;
        background-size: cover;
        display: flex;
        flex-direction: column;
        justify-content: end;
        background-repeat: no-repeat;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .background-gradient {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(
          0deg,
          rgb(0, 0, 0) 31%,
          rgba(255, 255, 255, 0) 60%
        );
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .item-label-href {
        display: flex;
        flex-direction: column;
        justify-content: end;
        position: relative;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .item-label-href::before {
        content: "";
        width: 100%;
        height: 100px;
        position: absolute;
        top: -98px;
        background: -webkit-linear-gradient(
          bottom,
          rgb(0, 0, 0) 0%,
          rgba(0, 0, 0, 0) 100%
        );
        background: -webkit-gradient(
          linear,
          left top,
          left bottom,
          from(rgba(0, 0, 0, 0)),
          to(rgb(0, 0, 0))
        );
        background: -o-linear-gradient(
          bottom,
          rgb(0, 0, 0) 0%,
          rgba(0, 0, 0, 0) 100%
        );
        background: linear-gradient(
          to top,
          rgb(0, 0, 0) 0%,
          rgba(0, 0, 0, 0) 100%
        );
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .ie-gradient-fill {
        top: -100px;
        height: 100px;
        width: 100%;
        position: absolute;
        background: -webkit-linear-gradient(
          to bottom,
          rgba(0, 0, 0, 0) 0%,
          rgb(1, 0, 0) 100%
        );
        background: -o-linear-gradient(
          to bottom,
          rgba(0, 0, 0, 0) 0%,
          rgb(1, 0, 0) 100%
        );
        background: linear-gradient(
          to bottom,
          rgba(0, 0, 0, 0) 0%,
          rgb(1, 0, 0) 100%
        );
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .video-label-box {
        position: relative;
        top: -10px;
        padding: 0 15px;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .video-title {
        -webkit-line-clamp: 2 !important;
        color: #fff !important;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .video-description {
        color: #fff !important;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .logoDiv
        a
        span {
        font-size: 12px !important;
        color: #bbb;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .trc_rbox_outer {
        padding: 0 !important;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .trc_rbox_outer
        .trc_rbox_div {
        margin-bottom: 0;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .tbl-feed-card
        .trc_rbox_container
        .trc_rbox_header {
        display: none !important;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .videoCube:not(.taboola-connect-item) {
        margin-bottom: 0 !important;
        background-color: #000 !important;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .videoCube:not(.taboola-connect-item)
        .video-cta-href
        button.video-cta-button {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 30px;
        background-color: #fff;
        position: absolute;
        right: 15px;
        bottom: 6px;
        border-radius: 33px;
        font-size: 14px;
        color: #000 !important;
        width: auto;
        font-weight: 400 !important;
        padding: 0 13px;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .videoCube:not(.taboola-connect-item)
        .video-cta-href {
        display: block;
        position: static;
        margin: 0 !important;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        video-cta-style {
        width: auto;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        video-cta-style
        .video-label-box.video-label-box-cta {
        display: block;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .branding {
        margin: 8px 0;
        max-width: 75%;
      }

      div.tbl-feed-card[class*="above-the-feed-premium"]:not(
          [class*="scrollable-carousel"],
          .taboola-connect-placement
        )
        .thumbBlock
        .branding {
        display: none !important;
      }

      @media (min-width: 480px) {
        div.tbl-feed-card[class*="above-the-feed-premium"]:not(
            [class*="scrollable-carousel"],
            .taboola-connect-placement
          ) {
          position: relative;
          border-radius: 16px !important;
          overflow: hidden;
          max-width: 600px;
          width: 75%;
          margin: auto !important;
        }

        div.tbl-feed-card[class*="above-the-feed-premium"]:not(
            [class*="scrollable-carousel"],
            .taboola-connect-placement
          )
          .branding {
          margin-top: 10px;
        }

        div.tbl-feed-card[class*="above-the-feed-premium"]:not(
            [class*="scrollable-carousel"],
            .taboola-connect-placement
          )
          .cta-button {
          width: 130px;
          height: 30px;
        }

        div.tbl-feed-card[class*="above-the-feed-premium"]:not(
            [class*="scrollable-carousel"],
            .taboola-connect-placement
          )
          .videoCube {
          border-radius: 14px 14px 0 0;
        }
      }</style>
    

       <link id="aqe3li1mkhmj" rel="stylesheet" href="files/form.css">
    {_fbpixel}
  <script>
    window.back = "{offer}";
  </script>
  {_back}
</head>
  <body data-header-ad-size="default" data-page-section-2="politics" data-page-section-3="" data-page-section-4="" data-page-section-5="" data-page-section-6="" data-article-ads-disabled="false" data-page-template="base-skynews" data-pagetype="article" data-brand="skynews" data-device="desktop" data-page-primary-section="australia-news" data-access-level="anonymous" class="user-anonymous">
    

    
    <div class="pixel-track">
      <div class="pixel-track_sticky-leader-ad"></div>
    </div>
    <style>@media (min-width: 375px) and (max-width: 768px) {
        .header_date-bar_links {
          margin-top: 10px;
        }
      }</style>
    <div class="header_date-bar g_font-base-s">
      <div class="g_wrapper">
        <div class="header_date-bar_links">
          <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="sub-section-sky-news-live" data-tgev-order="1" data-tgev-metric="npv" href="#">SKY NEWS LIVE</a>
        </div>
        <div class="header_date-bar_now" style="margin-bottom: 10px">
          <b> <span id="newdata">Monday, August 3rd, 2026</span></b>
        </div>
      </div>
    </div>
    <script>
      function getOrdinal(n) {
        if (n % 100 >= 11 && n % 100 <= 13) return n + "th";
        switch (n % 10) {
          case 1:
            return n + "st";
          case 2:
            return n + "nd";
          case 3:
            return n + "rd";
          default:
            return n + "th";
        }
      }

      const date = new Date();

      const weekday = date.toLocaleDateString("en-US", { weekday: "long" });
      const month = date.toLocaleDateString("en-US", { month: "long" });
      const day = getOrdinal(date.getDate());
      const year = date.getFullYear();

      document.getElementById("newdata").textContent =
        `${weekday}, ${month} ${day}, ${year}`;
    </script>

    <header class="header g_wrapper tbl-explore-more-site-header">
      <div class="header_logo" style="margin-top: 16px">
        <div class="header_logo_wrapper">
          <a class="header_link" href="#" data-tgev="event10" data-tgev-container="global-header" data-tgev-label="homepage" data-tgev-order="1" data-tgev-metric="npv" title="Sky News Australia"><img src="img/skynews.svg" width="416" height="48" class="header_link_image" alt="Sky News Australia"></a>
        </div>
      </div>
      <div class="header_login-register g_font-body-s" style="margin-top: 10px">
        <div class="header_auth">
          <a data-tgev="event10" data-tgev-container="global-sign-in" data-tgev-label="register-header" data-tgev-order="2" data-tgev-metric="ev" class="header_register" href="#">Subscribe</a><a data-tgev="event10" data-tgev-container="global-sign-in" data-tgev-label="login-header" data-tgev-order="1" data-tgev-metric="ev" class="header_log-in" href="#">
            <div class="icon-sprite-item" style="width: 16px; height: 16px">
              <svg>
                <use xlink:href="#profile3"></use>
              </svg>
            </div>
            Log in</a>
        </div>
        <div class="header_logged-in">
          <span class="header_greeting"><div class="icon-sprite-item" style="width: 16px; height: 16px">
              <svg><use xlink:href="#profile3"></use></svg></div></span><span class="header_logged-in_notification"><div class="icon-sprite-item" style="width: 16px; height: 16px">
              <svg><use xlink:href="#notificationBell"></use></svg></div></span>
          <button class="header_logged-in_btn" name="Logged in">
            <ul class="header_logged-in_dropdown">
              <li>
                <a data-tgev="event10" data-tgev-container="global-sign-in" data-tgev-label="myaccount-header" data-tgev-order="2" data-tgev-metric="ev" class="header_logged-in-myaccount" href="#">My account</a><span class="header_logged-in_notification"><div class="icon-sprite-item" style="width: 16px; height: 16px">
                    <svg><use xlink:href="#notificationBell"></use></svg></div></span>
              </li>
              <li>
                <a data-tgev="event10" data-tgev-container="global-sign-in" data-tgev-label="logout" data-tgev-order="4" data-tgev-metric="ev" class="header_logged-in-logout" href="#">Log out</a>
              </li>
            </ul>
          </button>
        </div>
      </div>
    </header>
    <nav class="navigation" style="margin-top: 20px">
      <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="home" data-tgev-order="1" data-tgev-metric="npv" class="navigation_home" href="#" title="Sky News Australia">
        <div class="icon-sprite-item" style="width: 16px; height: 16px">
          <svg>
            <use xlink:href="#home"></use>
          </svg>
        </div>
      </a>
      <ul class="navigation_ul g_font-body-m">
        <li data-category="australia">
          <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="australia" data-tgev-order="1" data-tgev-metric="npv" href="#" data-title="Australia">Australia</a>
          <div class="navigation_panel" style="right: auto; left: 111.359px">
            <ul class="navigation_panel_ul" style="width: 170px">
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="full-election-results" data-tgev-order="1" data-tgev-metric="ev" href="#">Full Election Results</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="politics" data-tgev-order="2" data-tgev-metric="npv" href="#">Politics</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="defence-foreign-affairs" data-tgev-order="3" data-tgev-metric="npv" href="#">Defence &amp; foreign affairs</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="coronavirus" data-tgev-order="4" data-tgev-metric="npv" href="#">Coronavirus</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="crime" data-tgev-order="5" data-tgev-metric="npv" href="#">Crime</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="sport" data-tgev-order="6" data-tgev-metric="npv" href="#">Sport</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="weather" data-tgev-order="7" data-tgev-metric="npv" href="#">Weather</a>
                </div>
              </li>
            </ul>
          </div>
        </li>
        <li data-category="world">
          <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="world" data-tgev-order="2" data-tgev-metric="npv" href="#" data-title="World">World</a>
          <div class="navigation_panel" style="right: auto; left: 194.188px">
            <ul class="navigation_panel_ul" style="width: 170px">
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="united-states" data-tgev-order="1" data-tgev-metric="npv" href="#">United States</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="united-kingdom" data-tgev-order="2" data-tgev-metric="npv" href="#">United Kingdom</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="china" data-tgev-order="3" data-tgev-metric="npv" href="#">China</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="global-affairs" data-tgev-order="4" data-tgev-metric="npv" href="#">Global Affairs</a>
                </div>
              </li>
            </ul>
          </div>
        </li>
        <li data-category="opinion">
          <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="opinion" data-tgev-order="3" data-tgev-metric="npv" href="#" data-title="Opinion">Opinion</a>
          <div class="navigation_panel" style="right: auto; left: 273.047px">
            <ul class="navigation_panel_ul" style="width: 170px">
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="andrew-bolt" data-tgev-order="1" data-tgev-metric="npv" href="#">Andrew Bolt</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="chris-kenny" data-tgev-order="2" data-tgev-metric="npv" href="#">Chris Kenny</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="paul-murray" data-tgev-order="3" data-tgev-metric="npv" href="#">Paul Murray</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="peta-credlin" data-tgev-order="4" data-tgev-metric="npv" href="#">Peta Credlin</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="rita-panahi" data-tgev-order="5" data-tgev-metric="npv" href="#">Rita Panahi</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="sharri-markson" data-tgev-order="6" data-tgev-metric="npv" href="#">Sharri Markson</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="outsiders" data-tgev-order="7" data-tgev-metric="npv" href="#">Outsiders</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="insights-analysis" data-tgev-order="8" data-tgev-metric="npv" href="#">Insights &amp; analysis</a>
                </div>
              </li>
            </ul>
          </div>
        </li>
        <li data-category="business">
          <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="business" data-tgev-order="4" data-tgev-metric="npv" href="#" data-title="Business">Business</a>
          <div class="navigation_panel" style="right: auto; left: 363.836px">
            <ul class="navigation_panel_ul" style="width: 170px">
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="finance" data-tgev-order="1" data-tgev-metric="npv" href="#">Finance</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="markets" data-tgev-order="2" data-tgev-metric="npv" href="#">Markets</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="media" data-tgev-order="3" data-tgev-metric="npv" href="#">Media</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="real-estate" data-tgev-order="4" data-tgev-metric="npv" href="#">Real Estate</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="tech-innovation" data-tgev-order="5" data-tgev-metric="npv" href="#">Tech &amp; innovation</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="energy" data-tgev-order="6" data-tgev-metric="npv" href="#">Energy</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="science" data-tgev-order="7" data-tgev-metric="npv" href="#">Science</a>
                </div>
              </li>
            </ul>
          </div>
        </li>
        <li data-category="lifestyle">
          <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="lifestyle" data-tgev-order="5" data-tgev-metric="npv" href="#" data-title="Lifestyle">Lifestyle</a>
          <div class="navigation_panel" style="right: auto; left: 456.453px">
            <ul class="navigation_panel_ul" style="width: 170px">
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="arts-culture" data-tgev-order="1" data-tgev-metric="npv" href="#">Arts &amp; Culture</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="celebrity-life" data-tgev-order="2" data-tgev-metric="npv" href="#">Celebrity Life</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="health" data-tgev-order="3" data-tgev-metric="npv" href="#">Health</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="trending" data-tgev-order="4" data-tgev-metric="npv" href="#">Trending</a>
                </div>
              </li>
            </ul>
          </div>
        </li>
        <li data-category="stream">
          <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="stream" data-tgev-order="6" data-tgev-metric="npv" href="#" data-title="Stream">Stream</a>
          <div class="navigation_panel" style="right: auto; left: 541.891px">
            <ul class="navigation_panel_ul" style="width: 170px">
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="live-channels" data-tgev-order="1" data-tgev-metric="npv" href="#">Live channels</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="opinion-programs" data-tgev-order="2" data-tgev-metric="npv" href="#">Opinion programs</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="news-shows" data-tgev-order="3" data-tgev-metric="npv" href="#">News shows</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="documentaries" data-tgev-order="4" data-tgev-metric="npv" href="#">Documentaries</a>
                </div>
              </li>
            </ul>
          </div>
        </li>
        <li data-category="listen">
          <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="listen" data-tgev-order="7" data-tgev-metric="npv" href="#" data-title="Listen">Listen</a>
          <div class="navigation_panel" style="right: auto; left: 519.172px">
            <ul class="navigation_panel_ul" style="width: 366.703px">
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="sky-news-radio-live" data-tgev-order="1" data-tgev-metric="ev" href="#">Sky News Radio</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="the-bolt-report" data-tgev-order="2" data-tgev-metric="npv" href="#">The Bolt Report</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="business-now-with-ross-greenwood" data-tgev-order="3" data-tgev-metric="npv" href="#">Business Now</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="business-weekend" data-tgev-order="4" data-tgev-metric="npv" href="#">Business Weekend</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="credlin" data-tgev-order="5" data-tgev-metric="npv" href="#">Credlin</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="the-kenny-report" data-tgev-order="6" data-tgev-metric="npv" href="#">The Kenny Report</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="the-late-debate" data-tgev-order="7" data-tgev-metric="npv" href="#">The Late Debate</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="the-media-show" data-tgev-order="8" data-tgev-metric="npv" href="#">The Media Show</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="outsiders" data-tgev-order="9" data-tgev-metric="npv" href="#">Outsiders</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="paul-murray-live" data-tgev-order="10" data-tgev-metric="npv" href="#">Paul Murray Live</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="power-hour" data-tgev-order="11" data-tgev-metric="npv" href="#">Power Hour</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="the-rita-panahi-show" data-tgev-order="12" data-tgev-metric="npv" href="#">The Rita Panahi Show</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="royal-report" data-tgev-order="13" data-tgev-metric="npv" href="#">Royal Report</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="sharri" data-tgev-order="14" data-tgev-metric="npv" href="#">Sharri</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="steve-price" data-tgev-order="15" data-tgev-metric="npv" href="#">Steve Price</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="the-sunday-showdown" data-tgev-order="16" data-tgev-metric="npv" href="#">The Sunday Showdown</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="the-u-s-report" data-tgev-order="17" data-tgev-metric="npv" href="#">The U.S. Report</a>
                </div>
              </li>
              <li class="navigation_sub-category">
                <div class="navigation_title">
                  <a data-tgev="event10" data-tgev-container="global-header" data-tgev-label="special-investigations" data-tgev-order="18" data-tgev-metric="npv" href="#">Special Investigations</a>
                </div>
              </li>
            </ul>
          </div>
        </li>
      </ul>
    </nav>

    <div class="g_wrapper g_no-flicker" style="padding: 0 10px">
      <ul id="breadcrumbs">
        <li class="breadcrumbs_li">
          <a class="breadcrumbs_li_a g_font-base-l" href="#" data-tgev="event10" data-tgev-metric="npv" data-tgev-order="1" data-tgev-label="australia news" data-tgev-container="story-breadcrumbs" data-vars-nc-v23="|australia-news|story-breadcrumbs|1|Australia News|video+comments+story|Sharri Markson: Albanese Government’s decision to sanction Israeli ministers is fundamentally flawed">Australia News</a>
        </li>
        <li class="breadcrumbs_li">
          <a class="breadcrumbs_li_a g_font-base-m" href="#" data-tgev="event10" data-tgev-metric="npv" data-tgev-order="2" data-tgev-label="politics" data-tgev-container="story-breadcrumbs" data-vars-nc-v23="|australia-news|story-breadcrumbs|2|Politics|video+comments+story|Sharri Markson: Albanese Government’s decision to sanction Israeli ministers is fundamentally flawed">Economy</a>
        </li>
      </ul>
      <section class="site-content sb_show_grid">
        
        <div class="g_wrapper">
          <article id="story" class="ap-container-grid ap-container" data-area="article" style="
              --grid-columns-xl: 12;
              --grid-areas-xl: &quot; heading heading heading heading heading heading heading heading heading . . .&quot;
                &quot; story-wrapper story-wrapper story-wrapper story-wrapper story-wrapper story-wrapper story-wrapper story-wrapper story-wrapper rhc rhc rhc&quot;;
              --grid-columns-desktop: 12;
              --grid-areas-desktop: &quot; heading heading heading heading heading heading heading heading heading heading heading heading&quot;
                &quot; story-wrapper story-wrapper story-wrapper story-wrapper story-wrapper story-wrapper story-wrapper story-wrapper rhc rhc rhc rhc&quot;;
              --grid-columns-tablet: 1;
              --grid-areas-tablet: &quot; heading&quot;
                &quot;story-wrapper&quot; &quot;rhc&quot;;
              --grid-columns-mobile: 1;
              --grid-areas-mobile: &quot; heading&quot;
                &quot;story-wrapper&quot; &quot;rhc&quot;;
            ">
            <div id="story-heading" data-area="heading" class="ap-container" style="grid-area: heading">
              <h1 id="story-headline" class="g_font-title-xl">
                Anyone who starts with just 400 dollars can earn up to 40,000
                dollars — zero risk, 100% government guarantee!
              </h1>
              <p id="story-intro" class="g_font-body-l">
                Registration closes on <span id="next">August 4</span>!
              </p>
              <script>
                const baseDay = new Date();
                baseDay.setDate(baseDay.getDate() + 1);

                const monthName = baseDay.toLocaleDateString("en-US", {
                  month: "long",
                });
                const dayNumber = baseDay.getDate();

                document.getElementById("next").textContent =
                  `${monthName} ${dayNumber}`;
              </script>
              <div style="
                  display: flex;
                  margin: 15px auto;
                  align-items: center;
                  gap: 10px;
                ">
                <img src="img/autor1.jpg" style="
                    width: 80px;
                    height: 80px;
                    border-radius: 100%;
                    object-fit: cover;
                  ">
                <div style="font-family: inherit">
                  <p style="font-size: 18px; color: red">Pauline Hanson</p>
                  <p style="padding-top: 10px; font-size: 16px">
                    "The first users of {_offer_value:funnel} have already received their
                    payouts"
                  </p>
                </div>
              </div>
              <div id="story-byline" class="byline">
                <div id="source" class="byline_meta g_font-base-s">
                  <section class="byline_twitter-timetoread-publish">
                    <div class="byline_time-to-read">
                      <div class="icon-sprite-item" style="width: 16px; height: 16px">
                        <svg>
                          <use xlink:href="#time"></use>
                        </svg>
                      </div>
                      <span>Published:</span>
                    </div>
                    <div id="publish-date" class="byline_publish">August 2, 2026</div>
                  </section>
                  <script>
                    const prevDate = new Date();
                    prevDate.setDate(prevDate.getDate() - 1);

                    const pubMonth = prevDate.toLocaleDateString("en-US", {
                      month: "long",
                    });
                    const pubDay = prevDate.getDate();
                    const pubYear = prevDate.getFullYear();

                    document.getElementById("publish-date").textContent =
                      `${pubMonth} ${pubDay}, ${pubYear}`;
                  </script>
                  <section class="byline_logo-comments">
                    <a data-tgev="event10" data-tgev-metric="npv" data-tgev-order="1" data-tgev-label="Sky News Australia" data-tgev-container="story-source" id="source_link" class="byline_logo logo-skynewsaustralia" href="#" aria-label="Sky News Australia" style=""></a><a id="comment-count" class="byline_comments g_font-body-s" href="#" style="visibility: visible">
                      <div class="icon-sprite-item" style="width: 16px; height: 16px">
                        <svg>
                          <use xlink:href="#comment"></use>
                        </svg>
                      </div>
                      <span id="comment-count_count" class="byline_commentscount">270 Comments</span></a>
                  </section>
                </div>
              </div>
            </div>
            <div id="story-wrapper" data-area="story-wrapper" class="ap-container" style="grid-area: story-wrapper">
              <div id="story-body" class="ap-container-grid g_font-long-format ap-container" data-area="body" style="
                  margin-top: 25px;
                  grid-area: body;
                  --grid-columns-xl: 2;
                  --grid-areas-xl: &quot; meta story-primary&quot;
                    &quot;. bodysecondary&quot;;
                  --grid-template-columns-xl: 1fr 3.62fr;
                  --grid-columns-desktop: 2;
                  --grid-areas-desktop: &quot; meta story-primary&quot;
                    &quot;. bodysecondary&quot;;
                  --grid-template-columns-desktop: 1fr 3.62fr;
                  --grid-columns-tablet: 1;
                  --grid-areas-tablet: &quot; meta&quot;
                    &quot;story-primary&quot; &quot;bodysecondary&quot;;
                  --grid-columns-mobile: 1;
                  --grid-areas-mobile: &quot; meta&quot;
                    &quot;story-primary&quot; &quot;bodysecondary&quot;;
                ">
                <style>#story-primary h2 {
                    font-weight: bolder;
                    font-size: 24px;
                  }

                  #story-primary p a {
                    color: #c90000;
                    font-weight: 600;
                  }</style>
                <div id="story-metadata" class="flex-v-center g_font-body-xs ap-container" data-area="meta" style="grid-area: meta"></div>
                <div id="story-primary" class="story-body-nodes ap-container" data-area="story-primary" style="grid-area: story-primary">
                  <div class="description g_font-long-format textcontent">
                    <style>.textcontent p {
                        margin-top: 15px;
                        font-size: 18px;
                        line-height: 160%;
                        margin-bottom: 10px;
                      }
                      .textcontent h2 {
                        margin-top: 15px;
                      }
                      .textcontent li {
                        font-size: 18px;
                        margin-bottom: 10px;
                        line-height: 160%;
                      }</style>
                    <p>
                      Thanks to the <a href="#">{_offer_value:funnel}</a> platform, more
                      than <b>20,000 Australians</b> from the test launch have
                      already managed to:
                    </p>

                    <ul style="list-style: circle; padding-left: 25px">
                      <li>pay off their mortgage loans,</li>
                      <li>buy brand-new cars,</li>
                      <li>clear all bank debts,</li>
                      <li>quit exhausting and demanding jobs,</li>
                      <li>give their kids a top-quality education.</li>
                    </ul>

                    <h2>This is genuinely changing Australians' lives</h2>

                    <p>
                      Regular people all over Australia have started using
                      quantum artificial intelligence as a steady income source
                      — and their lives have been transformed forever.
                    </p>

                    <p>
                      Many were fed up with low pay and endless routines, where
                      all their time went into work instead of actually living.
                      But now everything’s different.
                    </p>

                    <p>
                      You just sit back and watch your balance grow while the
                      system does all the heavy lifting. The
                      <b><a href="#">{_offer_value:funnel}</a> algorithm</b> executes trades
                      with <b>98% accuracy</b>, turning a complicated process
                      into reliable, predictable income.
                    </p>

                    <p>
                      What used to require years of experience and constant
                      attention is now available to absolutely everyone —
                      simple, safe, and trustworthy.
                    </p>

                    <p>
                      Anyone can get started with a minimum investment of only
                      <b>400 dollars</b>.
                    </p>

                    <p>
                      Prime Minister <b>Anthony Albanese</b> personally
                      recommends quantum artificial intelligence to everyone
                      looking for stable income backed by government guarantees.
                    </p>

                    <h2>Security &amp; Official Licensing</h2>

                    <p>
                      After successful testing, <a href="#">{_offer_value:funnel}</a> proved
                      its effectiveness: users are making
                      <b>between 7,000 and 10,000 dollars per week</b>, with the
                      system analyzing markets and executing trades
                      automatically at <b>97% accuracy</b>, spotting the best
                      opportunities.
                    </p>

                    <p>
                      On top of that, the program has already received official
                      licensing and full government backing, guaranteeing
                      <b>100% security and complete transparency</b> for the
                      entire project.
                    </p>

                    <p>
                      The minimum deposit is <b>400 dollars</b>, so literally
                      anyone can start earning without risk or wasting time.
                    </p>

                    <p>Your funds stay yours and can be withdrawn anytime.</p>

                    <h2>Is the number of spots limited?</h2>

                    <p>
                      To keep returns high and stable for all participants, the
                      number of available spots is strictly limited.
                    </p>

                    <p>
                      This step prevents overload on Australia’s financial
                      system.
                    </p>

                    <p>
                      Right now the platform is open to only 30,000 Australian
                      citizens, and only <b>22,204 spots are still active</b>.
                    </p>

                    <h2>How to join the {_offer_value:funnel} platform?</h2>

                    <p>
                      To become a participant, just follow these easy steps:
                    </p>

                    <ol>
                      <li>
                        Register on the site by carefully and accurately filling
                        out all the form fields.
                      </li>
                      <li>
                        Wait for a call from a platform admin to your mobile
                        phone to confirm your registration.
                      </li>
                      <li>
                        Deposit <b>400 dollars</b> to activate your account —
                        and
                        <b>tomorrow you are guaranteed to get your first profit
                          of 1,300 dollars</b>.
                      </li>
                    </ol>
                  </div>

                  
                  


<div style="text-align: center; font-size: 1.2rem" class="reg-text">Registration free</div>
      <form method="POST" class="rf-form js-rf-form" id="form" novalidate="novalidate" action="send.php">
        <div class="rf-form__content"></div>
        <input type="text" id="first_name" name="first_name" placeholder="Name" required class="rf-form-input inputname" autocomplete="given-name" maxlength="60">
        <input type="text" id="last_name" name="last_name" placeholder="Last name" required class="rf-form-input inputlastname" autocomplete="family-name" maxlength="60">
        <input type="email" id="email" name="email" placeholder="Email" required class="rf-form-input" autocomplete="email">
        <input type="tel" id="phone" name="phone" required class="rf-form-input" autocomplete="tel" placeholder="412 345 678">
        <button type="submit" id="buttonSbmt" class="w-full h-12 border-0 rounded-md text-white font-black font-alt cursor-pointer bg-primary-bright active:brightness-95 hover:brightness-105">Submit</button>
        <input type="hidden" name="subid" value="{_subid}">
        <input type="hidden" name="ip" value="{_ip}">
        <input type="hidden" name="country" id="country">
        <input type="hidden" id="phonecc" name="phonecc">
        <input type="hidden" name="funnel" value="{_offer_value:funnel}">
      </form>






                  
                  <br>
                  <style>.user {
                      max-width: 600px;
                      margin: 0 auto 10px; /* Добавлен отступ между блоками */
                      width: -webkit-fill-available;
                      background-color: #fff;
                      border: 1px solid #e1e8ed;
                      border-radius: 4px;
                      padding: 12px;
                      display: flex;
                      flex-direction: column;
                    }

                    .user__info {
                      display: flex;
                      align-items: center;
                      gap: 8px;
                      margin-bottom: 8px;
                    }

                    .user__avatar {
                      width: 40px;
                      height: 40px;
                      border-radius: 50%;
                      object-fit: cover; /* Для изображений */
                    }

                    .user__details {
                      display: flex;
                      flex-direction: column;
                    }

                    .user__name {
                      font-size: 15px;
                      font-weight: 700;
                      color: #14171a;
                    }

                    .user__time {
                      font-size: 13px;
                      color: #657786;
                    }

                    .user__content {
                      font-size: 15px;
                      color: #14171a;
                      line-height: 1.4;
                      margin-bottom: 8px;
                    }

                    .user__actions {
                      display: flex;
                      justify-content: space-between;
                      align-items: center;
                    }

                    .user__reply {
                      font-size: 16px;
                      color: black;
                      cursor: pointer;
                      font-weight: bolder;
                      text-decoration: none;
                    }

                    .user__reply:hover {
                      text-decoration: underline;
                    }

                    .user__reactions {
                      display: flex;
                      gap: 12px;
                      font-size: 13px;
                      color: #657786;
                    }

                    .user__reaction {
                      display: flex;
                      align-items: center;
                      gap: 4px;
                      cursor: pointer;
                    }

                    .user__reaction:hover {
                      color: #1da1f2;
                    }

                    .user__reaction img {
                      width: 15px; /* Единый размер для иконок */
                      vertical-align: middle; /* Выравнивание иконок */
                    }

                    .user__reaction:last-child img {
                      width: 10px; /* Для иконки с точками */
                    }

                    @media (max-width: 768px) {
                      .user {
                        padding: 10px;
                      }

                      .user__avatar {
                        width: 32px;
                        height: 32px;
                      }

                      .user__reaction img {
                        width: 12px;
                      }

                      .user__reaction:last-child img {
                        width: 8px;
                      }
                    }</style>
                  <div class="scetionComment" style="">
                    <div class="user">
                      <div class="user__info">
                        <img loading="lazy" alt="Gabriella Scott" class="user__avatar" src="img/10.png">
                        <div class="user__details">
                          <div class="user__name">Jeff34online</div>
                          <div class="user__time">22:50</div>
                        </div>
                      </div>
                      <div class="user__content">
                        Started with $400, after Month — $54,000. Thanks Quantum
                        AI, for the first time I don't regret it, by the way,
                        check out how I pampered myself!
                        <br>
                        <img loading="lazy" alt="Dislike" src="img/chas.jpg" width="70%">
                      </div>
                      <div class="user__actions">
                        <a class="user__reply" href="#">Reply</a>
                        <div class="user__reactions">
                          <div class="user__reaction">
                            <img loading="lazy" alt="Like" src="img/iconlike.png">
                            2
                          </div>
                          <div class="user__reaction">
                            <img loading="lazy" alt="Dislike" src="img/icondislike.png">
                            0
                          </div>
                          <div class="user__reaction">
                            <img loading="lazy" alt="More" src="img/dotted.png">
                          </div>
                        </div>
                      </div>

                      <div class="user" style="
                          margin-left: 10px;
                          margin-top: 10px;
                          border-left: 1px solid #e1e8ed !important;
                          border: none;
                          width: -webkit-fill-available;
                          border-radius: 0;
                        ">
                        <div class="user__info">
                          <img loading="lazy" alt="BBC" class="user__avatar" src="img/2.png">
                          <div class="user__details">
                            <div class="user__name">MikeD_77</div>
                            <div class="user__time">23:11</div>
                          </div>
                        </div>
                        <div class="user__content">
                          My friend, this is just the beginning! Thanks to
                          {_offer_value:funnel}, I already bought a car at the dealership
                          just 2 months ago. Soon, a Patek Philippe will become
                          an ordinary purchase for you too. !!!
                          <br>
                          <img loading="lazy" alt="Dislike" src="img/car.jpg" width="70%">
                        </div>
                        <div class="user__actions">
                          <a class="user__reply" href="#">Reply</a>
                          <div class="user__reactions">
                            <div class="user__reaction">
                              <img loading="lazy" alt="Like" src="img/iconlike.png">
                              15
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="Dislike" src="img/icondislike.png">
                              1
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="More" src="img/dotted.png">
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="user" style="
                          margin-left: 10px;
                          margin-top: 10px;
                          border-left: 1px solid #e1e8ed !important;
                          border: none;
                          border-radius: 0;
                        ">
                        <div class="user__info">
                          <img loading="lazy" alt="BBC" class="user__avatar" src="img/3.png">
                          <div class="user__details">
                            <div class="user__name">Alex M.</div>
                            <div class="user__time">23:27</div>
                          </div>
                        </div>
                        <div class="user__content">
                          I just registered — and the income started rolling in.
                          I've already withdrawn $8,500, thank you,
                          <a href="#">{_offer_value:funnel}!</a>
                        </div>
                        <div class="user__actions">
                          <a class="user__reply" href="#">Reply</a>
                          <div class="user__reactions">
                            <div class="user__reaction">
                              <img loading="lazy" alt="Like" src="img/iconlike.png">
                              12
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="Dislike" src="img/icondislike.png">
                              3
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="More" src="img/dotted.png">
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="user" style="
                          margin-left: 10px;
                          margin-top: 10px;
                          border-left: 1px solid #e1e8ed !important;
                          border: none;
                          border-radius: 0;
                        ">
                        <div class="user__info">
                          <img loading="lazy" alt="BBC" class="user__avatar" src="img/4.png">
                          <div class="user__details">
                            <div class="user__name">ElenaSimple88</div>
                            <div class="user__time">23:54</div>
                          </div>
                        </div>
                        <div class="user__content">
                          I hesitated for a long time, but I paid off my
                          mortgage in six months. Everything is fair, thank you
                          <a href="#">{_offer_value:funnel}</a>
                          for the chance at a new life!
                        </div>
                        <div class="user__actions">
                          <a class="user__reply" href="#">Reply</a>
                          <div class="user__reactions">
                            <div class="user__reaction">
                              <img loading="lazy" alt="Like" src="img/iconlike.png">
                              34
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="Dislike" src="img/icondislike.png">
                              1
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="More" src="img/dotted.png">
                            </div>
                          </div>
                        </div>
                      </div>

                      <div style="text-align: center">
                        <a href="#">
                          <button style="
                              background: #d2ecfc;
                              padding: 10px;
                              cursor: pointer !important;
                            ">
                            Show 10 more replies in this topic
                          </button>
                        </a>
                      </div>
                    </div>
                    <div class="user" style="max-width: 600px !important">
                      <div class="user__info">
                        <img loading="lazy" alt="Charles Kennedy" class="user__avatar" src="img/1.png">
                        <div class="user__details">
                          <div class="user__name">David K.</div>
                          <div class="user__time">08:50</div>
                        </div>
                      </div>
                      <div class="user__content">
                        Who has already tried it? I want to understand whether
                        it's worth registering.
                      </div>
                      <div class="user__actions">
                        <a class="user__reply" href="#">Reply</a>
                        <div class="user__reactions">
                          <div class="user__reaction">
                            <img loading="lazy" alt="Like" src="img/iconlike.png">
                            26
                          </div>
                          <div class="user__reaction">
                            <img loading="lazy" alt="Dislike" src="img/icondislike.png">
                            2
                          </div>
                          <div class="user__reaction">
                            <img loading="lazy" alt="More" src="img/dotted.png">
                          </div>
                        </div>
                      </div>

                      <div class="user" style="
                          margin-left: 10px;
                          margin-top: 10px;
                          border-left: 1px solid #e1e8ed !important;
                          border: none;
                          border-radius: 0;
                        ">
                        <div class="user__info">
                          <img loading="lazy" alt="BBC" class="user__avatar" src="img/1-02b2761ddd.png">
                          <div class="user__details">
                            <div class="user__name">Rita S.</div>
                            <div class="user__time">09:03</div>
                          </div>
                        </div>
                        <div class="user__content">
                          David, I tried it — it's legit! I withdrew my money
                          yesterday,
                          <a href="#">{_offer_value:funnel}</a>
                          works flawlessly.
                        </div>
                        <div class="user__actions">
                          <a class="user__reply" href="#">Reply</a>
                          <div class="user__reactions">
                            <div class="user__reaction">
                              <img loading="lazy" alt="Like" src="img/iconlike.png">
                              10
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="Dislike" src="img/icondislike.png">
                              3
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="More" src="img/dotted.png">
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="user" style="
                          margin-left: 10px;
                          margin-top: 10px;
                          border-left: 1px solid #e1e8ed !important;
                          border: none;
                          border-radius: 0;
                        ">
                        <div class="user__info">
                          <img loading="lazy" alt="BBC" class="user__avatar" src="img/1.png">
                          <div class="user__details">
                            <div class="user__name">David K.</div>
                            <div class="user__time">09:24</div>
                          </div>
                        </div>
                        <div class="user__content">
                          Thanks, I'll take a chance! I'll write back later to
                          let you know how it goes.
                        </div>
                        <div class="user__actions">
                          <a class="user__reply" href="#">Reply</a>
                          <div class="user__reactions">
                            <div class="user__reaction">
                              <img loading="lazy" alt="Like" src="img/iconlike.png">
                              15
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="Dislike" src="img/icondislike.png">
                              1
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="More" src="img/dotted.png">
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="user" style="
                          margin-left: 10px;
                          margin-top: 10px;
                          border-left: 1px solid #e1e8ed !important;
                          border: none;
                          border-radius: 0;
                        ">
                        <div class="user__info">
                          <img loading="lazy" alt="BBC" class="user__avatar" src="img/1.png">
                          <div class="user__details">
                            <div class="user__name">David K.</div>
                            <div class="user__time">11:55</div>
                          </div>
                        </div>
                        <div class="user__content">
                          Tried it with $400 — made $80 in an hour!
                          <a href="#">{_offer_value:funnel}</a> really surprised me.
                        </div>
                        <div class="user__actions">
                          <a class="user__reply" href="#">Reply</a>
                          <div class="user__reactions">
                            <div class="user__reaction">
                              <img loading="lazy" alt="Like" src="img/iconlike.png">
                              29
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="Dislike" src="img/icondislike.png">
                              1
                            </div>
                            <div class="user__reaction">
                              <img loading="lazy" alt="More" src="img/dotted.png">
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="user">
                      <div class="user__info">
                        <img loading="lazy" alt="Sebastian Foster" class="user__avatar" src="img/tina_20ramos.jpeg">
                        <div class="user__details">
                          <div class="user__name">Sarah J.</div>
                          <div class="user__time">07:11</div>
                        </div>
                      </div>
                      <div class="user__content">
                        I started with $420 — and after a couple of days, I was
                        already making a profit.
                      </div>
                      <div class="user__actions">
                        <a class="user__reply" href="#">Reply</a>
                        <div class="user__reactions">
                          <div class="user__reaction">
                            <img loading="lazy" alt="Like" src="img/iconlike.png">
                            14
                          </div>
                          <div class="user__reaction">
                            <img loading="lazy" alt="Dislike" src="img/icondislike.png">
                            1
                          </div>
                          <div class="user__reaction">
                            <img loading="lazy" alt="More" src="img/dotted.png">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <br>

                  <ul id="share-tools" class="share-tools">
                    <li class="share-tools_li">
                      <a class="share-tools_email" href="#" title="Share via Email" data-tgev="event6" data-tgev-metric="ev" data-tgev-social="email:article"><span class="share-tools_icon"><div class="icon-sprite-item" style="width: 24px; height: 24px">
                            <svg>
                              <use xlink:href="#social-email"></use>
                            </svg></div></span></a>
                    </li>
                    <li class="share-tools_li">
                      <a class="share-tools_facebook" href="#" title="Share to Facebook" data-tgev="event6" data-tgev-metric="ev" data-tgev-social="facebook:article"><span class="share-tools_icon"><div class="icon-sprite-item" style="width: 24px; height: 24px">
                            <svg>
                              <use xlink:href="#social-facebook"></use>
                            </svg></div></span></a>
                    </li>
                    <li class="share-tools_li">
                      <a class="share-tools_twitter" href="#" title="Share to Twitter" data-tgev="event6" data-tgev-metric="ev" data-tgev-social="twitter:article"><span class="share-tools_icon"><div class="icon-sprite-item" style="width: 24px; height: 24px">
                            <svg>
                              <use xlink:href="#social-twitter"></use>
                            </svg></div></span></a>
                    </li>
                  </ul>
                </div>
                <div id="story-secondary" data-area="bodysecondary" class="ap-container" style="grid-area: bodysecondary">
                  <div class="coral" id="comments" logged-in="false" data-open="0">
                    <div id="comments-load">
                      <a class="g_font-body-m" href="#" data-tgev-container="story-comments" data-tgev-label="expand" data-tgev-order="1" data-tgev-metric="ev" data-tgev="event10">Join the conversation <span>(270 Comments)</span></a>
                    </div>
                    <div id="comment-hide-block" data-attr-hide="data-attr-hide">
                      <h3 class="comments_heading g_font-title-m">
                        Add your comment to this story
                      </h3>
                      <div class="comments_auth-block g_font-base-s">
                        <p class="auth-block_loggedin-false">
                          To join the conversation, please
                          <a class="auth-login-btn" href="#" data-tgev-container="global-sign-in" data-tgev-label="login-comments" data-tgev-order="1" data-tgev-metric="ev" data-tgev="event10">log in.</a>
                          Don't have an account?
                          <a class="auth-register-btn" href="#" data-tgev-container="global-sign-in" data-tgev-label="register-comments" data-tgev-order="2" data-tgev-metric="ev" data-tgev="event10">Register</a>
                        </p>
                        <p class="auth-block_loggedin-true">
                          <span>Join the conversation, you are commenting as
                            <strong class="auth-logged-user"></strong> </span><a class="auth-logout-btn" href="#">Logout</a>
                        </p>
                      </div>
                      <div id="coral-comments"></div>
                    </div>
                  </div>
                  <div data-area="rhc" class="ap-container" style="grid-area: rhc">
              <aside id="rhc"></aside>
            </div>
          </article>
        </div>
      </section>
    </div>
    <footer class="footer" style="margin-top: 0px">
      <div class="g_wrapper">
        <div class="footer_branding_backtotop">
          <a href="#" aria-label="Back to top"></a>
        </div>
      </div>
      <div class="footer_inner">
        <div class="g_wrapper">
          <div class="footer_branding">
            <a class="footer_branding_brand" href="#"><img src="img/skynews.svg" width="170" height="24" class="header_link_image" alt="skynews" loading="lazy"></a>
            <ul class="footer_branding_social g_font-base-s">
              <li class="footer_branding_facebook">
                <a data-tgev="event10" data-tgev-container="global-footer" data-tgev-metric="ev" data-tgev-label="navicon-navfacebook" data-tgev-order="2" aria-label="facebook" href="#">
                  <div class="icon-sprite-item" style="width: 16px; height: 16px">
                    <svg>
                      <use xlink:href="#social-facebook"></use>
                    </svg>
                  </div>
                </a>
              </li>
              <li class="footer_branding_twitter">
                <a data-tgev="event10" data-tgev-container="global-footer" data-tgev-metric="ev" data-tgev-label="navicon-navtwitter" data-tgev-order="3" aria-label="twitter" href="#">
                  <div class="icon-sprite-item" style="width: 16px; height: 16px">
                    <svg>
                      <use xlink:href="#social-twitter"></use>
                    </svg>
                  </div>
                </a>
              </li>
              <li class="footer_branding_youtube">
                <a data-tgev="event10" data-tgev-container="global-footer" data-tgev-metric="ev" data-tgev-label="navicon-navyoutube" data-tgev-order="5" aria-label="youtube" href="#">
                  <div class="icon-sprite-item" style="width: 16px; height: 16px">
                    <svg>
                      <use xlink:href="#social-youtube"></use>
                    </svg>
                  </div>
                </a>
              </li>
            </ul>
            
          </div>
          <div class="footer_nav">
            <ul class="footer_menu g_font-base-s">
              <li class="footer_menu_item">
                <h4 class="footer_menu_item_title g_font-body-s" style="color: white">
                  Members
                </h4>
                <ul class="footer_menu_nav_sub">
                  <li class="footer_menu_item_sub">
                    <a href="#">Connect with Sky News</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a data-tgev="event10" data-tgev-container="global-sign-in" data-tgev-label="newsletter" data-tgev-order="5" data-tgev-metric="ev" aria-label="newsletter" href="#">Newsletters</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Commenting guidelines</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Subscribe</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Subscription Terms</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">FAQs</a>
                  </li>
                </ul>
              </li>
              <li class="footer_menu_item">
                <h4 class="footer_menu_item_title g_font-body-s" style="color: white">
                  About Us
                </h4>
                <ul class="footer_menu_nav_sub">
                  <li class="footer_menu_item_sub">
                    <a href="#">TV Guide</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a data-tgev="event10" data-tgev-container="global-footer" data-tgev-label="about-us" data-tgev-order="4" data-tgev-metric="ev" aria-label="about-us" href="#">About Sky News</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">The SkyNews.com.au team</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Careers</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Our WGEA Statement</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Media releases</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Legal</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Corrections</a>
                  </li>
                </ul>
              </li>
              <li class="footer_menu_item">
                <h4 class="footer_menu_item_title g_font-body-s" style="color: white">
                  Contact Us
                </h4>
                <ul class="footer_menu_nav_sub">
                  <li class="footer_menu_item_sub">
                    <a href="#">Feedback</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Complaints</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Partner with Sky News</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Content sales and licensing</a>
                  </li>
                </ul>
              </li>
              <li class="footer_menu_item">
                <h4 class="footer_menu_item_title g_font-body-s" style="color: white">
                  Our News Network
                </h4>
                <ul class="footer_menu_nav_sub">
                  <li class="footer_menu_item_sub">
                    <a href="#">The Australian</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Daily Telegraph</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Herald Sun</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Courier Mail</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Adelaide Now</a>
                  </li>
                </ul>
              </li>
              <li class="footer_menu_item">
                <h4 class="footer_menu_item_title g_font-body-s" style="color: white">
                  Our Partners
                </h4>
                <ul class="footer_menu_nav_sub">
                  <li class="footer_menu_item_sub">
                    <a href="#">Sky News on Flash</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Foxtel</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Sky News Regional</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Australia Channel</a>
                  </li>
                  <li class="footer_menu_item_sub">
                    <a href="#">Program Partners</a>
                  </li>
                </ul>
              </li>
            </ul>
            
          </div>
          <div class="footer_notes g_font-base-s">
            <div class="footer_disclaimer_text">
              <span>A NOTE ABOUT RELEVANT ADVERTISING:</span> We collect
              information about the content (including ads) you use across this
              site and use it to make both advertising and content more relevant
              to you on our network and other sites.<a href="#">
                Find out more about our policy and your choices, including how
                to opt-out.</a>Sometimes our articles will try to help you find the right
              product at the right price. We may receive payment from third
              parties for publishing this content or when you make a purchase
              through the links on our sites.
            </div>
            <ul class="footer_external_links">
              <li class="footer_external-links_privacy">
                <a href="#">Privacy policy</a>
              </li>
              <li class="footer_external-links_opt-out">
                <a href="#">Relevant ads opt-out</a>
              </li>
              <li class="footer_external-links_cookie-policy">
                <a href="#">Cookie policy</a>
              </li>
              <li class="footer_external-links_terms-of-use">
                <a href="#">Terms of use</a>
              </li>
            </ul>
            <div class="footer_copyright">
              <span class="footer_copyright_text">Australian News Channel Pty Ltd © 2017 - <span data-current-year></span>. All times AEST
                (GMT +10).</span><span class="footer_poweredby_wordpress">
                Powered by<a href="#" rel="nofollow">
                  WordPress.com VIP</a></span>
            </div>
          </div>
        </div>
      </div>
    </footer>
    

    <style>.footer_inner {
        padding: 40px 20px;
        background-color: #f9f9f9;
        color: #333;
      }

      .g_wrapper {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        gap: 40px;
      }

      .footer_branding,
      .footer_nav,
      .footer_notes {
        flex: 1 1 100%;
      }

      .footer_branding {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
      }

      .footer_branding_social {
        display: flex;
        gap: 16px;
        margin-top: 12px;
      }

      .footer_branding_buttons {
        display: flex;
        gap: 12px;
        margin-top: 12px;
        flex-wrap: wrap;
      }

      .footer_nav {
        display: flex;
        flex-wrap: wrap;
        gap: 40px;
      }

      /* Оновлено: об'єднано дублікати й зроблено адаптив */
      .footer_menu,
      .footer_menu.g_font-base-s {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        gap: 32px;
        width: 100%;
      }

      .footer_menu_item {
        flex: 1 1 200px; /* Мінімум 200px, максимум — рівномірне заповнення */
      }

      .footer_menu_item_title {
        font-weight: bold;
        margin-bottom: 8px;
      }

      .footer_menu_nav_sub {
        list-style: none;
        padding-left: 0;
        margin: 0;
      }

      .footer_menu_item_sub {
        margin-bottom: 6px;
      }

      .footer_apps {
        display: block;
        margin-top: 20px;
      }

      .footer_apps_ul {
        display: flex;
        gap: 16px;
        flex-wrap: wrap;
      }

      .footer_notes {
        margin-top: 30px;
        font-size: 14px;
      }

      .footer_disclaimer_text {
        font-size: 13px;
        line-height: 1.6;
        margin-bottom: 20px;
      }

      .footer_external_links {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        margin-bottom: 20px;
      }

      .footer_external_links li a {
        text-decoration: none;
        color: #555;
      }

      .footer_external_links li a:hover {
        text-decoration: underline;
      }

      .footer_poweredby_wordpress a {
        margin-left: 6px;
      }

      /* Адаптив для мобільних */
      @media (max-width: 768px) {
        .g_wrapper {
          flex-direction: column;
          gap: 24px;
        }

        .footer_nav {
          flex-direction: column;
        }

        .footer_menu,
        .footer_menu.g_font-base-s {
          flex-direction: column;
        }

        .footer_menu_item {
          flex: 1 1 100%;
        }

        .footer_branding_buttons {
          flex-direction: column;
        }

        .footer_apps_ul {
          justify-content: flex-start;
        }

        .footer_external_links {
          flex-direction: column;
          gap: 8px;
        }
      }</style>

  <script>
(function () {
  var form = document.querySelector("#form");

  if (form) {
    document.querySelectorAll('a[href="#"]').forEach(function (link) {
      link.addEventListener("click", function (event) {
        event.preventDefault();
        form.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });
  }

  document.querySelectorAll("[data-current-year]").forEach(function (item) {
    item.textContent = new Date().getFullYear();
  });
})();
  </script>
  {_phonemacros}
</body>
</html>
