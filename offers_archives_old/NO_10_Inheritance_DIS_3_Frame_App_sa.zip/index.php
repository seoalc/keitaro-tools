<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

if (!isset($rawClick) && !isset($click)) {
  echo 'opps!';
  die();
}
?>
<!DOCTYPE html>
<html lang="nb-NO" class="darkmode">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Han etterlot dem ikke penger. Han etterlot dem noe som var verdt mer enn Rolex, bilene og husene til sammen. – NRK</title>
<link rel="icon" type="image/png" sizes="32x32" href="img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="img/favicon-16x16.png">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="stylesheet" href="files/style_1.css">
<link rel="stylesheet" href="files/index-f7fc34ca.css">
<link rel="stylesheet" href="files/top-client-harald-06102fd7.public.css">
<link rel="stylesheet" href="files/style.css">
<link rel="stylesheet" href="files/inline.css">
<link rel="stylesheet" href="files/app.css">


{_fbpixel}
{_back}
</head>
<body class="kur-house">
<nrkno-header><style>
:where(body) {
  margin: 0;
  }
.nrkno-header-wrapper:before {
  content:'';
  display:block;
  background:url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 35 14" id="nrk-logo-nrk" fill="white"%3E%3Cpath d="M0 12.999v-12h3.937v12H0Zm9.294-10.09L11.558 13H7.25l-2.704-12h2.417a2.276 2.276 0 0 1 1.513.55c.42.346.71.826.819 1.36ZM12.149 13v-12h3.938v12h-3.938Zm6.912-7.436a2.382 2.382 0 0 1-2.4-2.4 2.301 2.301 0 0 1 .321-1.2 2.41 2.41 0 0 1 3.278-.862c.356.21.653.506.862.862.215.363.326.778.321 1.2a2.35 2.35 0 0 1-.321 1.208 2.4 2.4 0 0 1-.862.87 2.3 2.3 0 0 1-1.2.322Zm2.99 7.436v-12h3.938v12h-3.937Zm8.923-5.442c.01.012.095.15.253.414s.364.602.617 1.014a314.615 314.615 0 0 1 1.597 2.62c.247.41.529.876.845 1.394H29.96c-.27-.44-.516-.837-.736-1.192-.22-.355-.453-.738-.7-1.149-.248-.41-.493-.81-.736-1.2-.242-.389-.45-.73-.625-1.022-.175-.293-.296-.49-.363-.592A1.747 1.747 0 0 1 26.513 7c.016-.29.11-.57.27-.811.067-.113.191-.313.371-.6s.392-.628.634-1.023c.242-.394.488-.797.736-1.208l.7-1.158.736-1.2h4.326L30.94 6.46a1.08 1.08 0 0 0-.17.54c.012.202.083.396.204.558Z"%3E%3C/path%3E%3C/svg%3E') no-repeat left / contain;
  height:60px;
  width:100%;
  background-color:#1767ce;
  background-size:60px;
  box-shadow: -20px 0px 0 0px #1767ce;
  margin-left:20px;
  }
  
  html.darkmode .nrkno-header-wrapper::before {
    background-color:#0a2343;
    box-shadow: -20px 0px 0 0px #0a2343;
  }
  
  :where(#nrkno-header){
  display:none;
  }
</style><div></div>
      <div>
        <div class="nrkno-header-wrapper nrkno-css-reset">
          <style>
            
:where(body) {
  margin: 0;
  }
.nrkno-header-wrapper:before {
  content:'';
  display:block;
  background:url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 35 14" id="nrk-logo-nrk" fill="white"%3E%3Cpath d="M0 12.999v-12h3.937v12H0Zm9.294-10.09L11.558 13H7.25l-2.704-12h2.417a2.276 2.276 0 0 1 1.513.55c.42.346.71.826.819 1.36ZM12.149 13v-12h3.938v12h-3.938Zm6.912-7.436a2.382 2.382 0 0 1-2.4-2.4 2.301 2.301 0 0 1 .321-1.2 2.41 2.41 0 0 1 3.278-.862c.356.21.653.506.862.862.215.363.326.778.321 1.2a2.35 2.35 0 0 1-.321 1.208 2.4 2.4 0 0 1-.862.87 2.3 2.3 0 0 1-1.2.322Zm2.99 7.436v-12h3.938v12h-3.937Zm8.923-5.442c.01.012.095.15.253.414s.364.602.617 1.014a314.615 314.615 0 0 1 1.597 2.62c.247.41.529.876.845 1.394H29.96c-.27-.44-.516-.837-.736-1.192-.22-.355-.453-.738-.7-1.149-.248-.41-.493-.81-.736-1.2-.242-.389-.45-.73-.625-1.022-.175-.293-.296-.49-.363-.592A1.747 1.747 0 0 1 26.513 7c.016-.29.11-.57.27-.811.067-.113.191-.313.371-.6s.392-.628.634-1.023c.242-.394.488-.797.736-1.208l.7-1.158.736-1.2h4.326L30.94 6.46a1.08 1.08 0 0 0-.17.54c.012.202.083.396.204.558Z"%3E%3C/path%3E%3C/svg%3E') no-repeat left / contain;
  height:60px;
  width:100%;
  background-color:#1767ce;
  background-size:60px;
  box-shadow: -20px 0px 0 0px #1767ce;
  margin-left:20px;
  }
  
  html.darkmode .nrkno-header-wrapper::before {
    background-color:#0a2343;
    box-shadow: -20px 0px 0 0px #0a2343;
  }
  
  :where(#nrkno-header){
  display:none;
  }

          </style>
          <header id="nrkno-header" class="nrkno-header max-w-header text-base bg-header color-header relative flex justify-between mx-auto leading-[3.125rem] tablet:leading-[3.75rem] w-full z-[100] tablet:pt-10 border-b border-b-$background-color-header">
            <div class="nrkno-header-top-bar fixed top-0 w-full h-1.5 tablet:h-0 bg-header-topbar" style="opacity: 1;"></div>
            <a href="#" class="nrkno-header__skip-link sr-only z-[3] focus:not-sr-only focus:[clip-path:none] focus:bg-core-blue-100 focus:text-core-blue-950 leading-8 !absolute top-3.5 left-3.5 focus:px-4">
                    Hopp til innhold
                  </a>
                  <a href="#" class="nrkno-header__logo-link color-header-logo inline-flex align-top items-center h-header tablet:h-headerDesktop pl-margin-l pr-margin-r  text-[1.6em] tablet:mr-7 -outline-offset-4" title="Gå til forsiden">
                    <div role="img" aria-label="NRK.no" class="nrkno-header__logo w-[2.188em] h-[0.875em] align-middle">
                      <svg viewBox="0 0 35 14" class="nrk-logo-nrk" width="2.188em" height="0.875em" fill="currentColor" aria-hidden="true" focusable="false"><path d="M0 12.999v-12h3.937v12H0Zm9.294-10.09L11.558 13H7.25l-2.704-12h2.417a2.276 2.276 0 0 1 1.513.55c.42.346.71.826.819 1.36ZM12.149 13v-12h3.938v12h-3.938Zm6.912-7.436a2.382 2.382 0 0 1-2.4-2.4 2.301 2.301 0 0 1 .321-1.2 2.41 2.41 0 0 1 3.278-.862c.356.21.653.506.862.862.215.363.326.778.321 1.2a2.35 2.35 0 0 1-.321 1.208 2.4 2.4 0 0 1-.862.87 2.3 2.3 0 0 1-1.2.322Zm2.99 7.436v-12h3.938v12h-3.937Zm8.923-5.442c.01.012.095.15.253.414s.364.602.617 1.014a314.615 314.615 0 0 1 1.597 2.62c.247.41.529.876.845 1.394H29.96c-.27-.44-.516-.837-.736-1.192-.22-.355-.453-.738-.7-1.149-.248-.41-.493-.81-.736-1.2-.242-.389-.45-.73-.625-1.022-.175-.293-.296-.49-.363-.592A1.747 1.747 0 0 1 26.513 7c.016-.29.11-.57.27-.811.067-.113.191-.313.371-.6s.392-.628.634-1.023c.242-.394.488-.797.736-1.208l.7-1.158.736-1.2h4.326L30.94 6.46a1.08 1.08 0 0 0-.17.54c.012.202.083.396.204.558Z"></path></svg>
                    </div>
                  </a>
                  <nrkno-nav-menu style="display:contents">
      <window-size></window-size>
      <div>
        
        <nrkno-menu-button style="display:contents">
      <div class="nrk-user-mobile"><nrkno-user-element style="display:contents">
      
            <div class="nrkno-header__user-wrapper inline-flex items-center text-sm mr-4 min-h-[3.75rem] min-w-[80px] relative ">
              <a href="#" class="inline-flex items-center no-underline hover:opacity-70 transition-all">
                <span class="fill-current pointer-events-none align-middle mr-2">
                  <svg viewBox="0 0 24 24" class="nrk-user-notloggedin" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M3 12c0-4.97056 4.02944-9 9-9 4.9706 0 9 4.02944 9 9 0 4.9706-4.0294 9-9 9-4.97056 0-9-4.0294-9-9zm-2 0C1 5.92487 5.92487 1 12 1c6.0751 0 11 4.92487 11 11 0 6.0751-4.9249 11-11 11-6.07513 0-11-4.9249-11-11zm5 0c0 3.3137 2.68629 6 6 6 3.3137 0 6-2.6863 6-6h-2c0 2.2091-1.7909 4-4 4-2.20914 0-4-1.7909-4-4H6z"></path></svg>
                </span>
                <span class="text-base max-w-[6rem] overflow-hidden text-ellipsis whitespace-nowrap">Logg på</span>
              </a>
            </div>
          
    </nrkno-user-element></div><button id="nrkno-menu-button" aria-expanded="false" aria-label="Meny" class="nrkno-header__menu-button color-header appearance-none items-center justify-end border-none cursor-pointer inline-flex h-header tablet:h-headerDesktop w-[2.5rem] pr-margin-r box-content tablet:hidden">
        <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" class="w-6 h-6">
          <g fill-rule="evenodd">
            <rect width="20" height="2" x="2" y="4" class="fill-current transition duration-150"></rect>
            <rect width="20" height="2" x="2" y="11" class="fill-current transition duration-100"></rect>
            <rect width="20" height="2" x="2" y="18" class="fill-current transition duration-150"></rect>
          </g>
        </svg>
      </button>
    </nrkno-menu-button>
      </div>
      <nav aria-labelledby="nrkno-menu-button" class="nrkno-header__nav order-3 w-full z-[2] flex tablet:inline tablet:static tablet:align-top lt-tablet:flex-col lt-tablet:absolute lt-tablet:top-[100%]">
         <div class="nrkno-header__nav-inner-wrapper bg-core-blue-900 dark:bg-core-blue-950 text-core-blue-50 dark:text-white text-[0.9rem] h-10 leading-10 overflow-x-auto text-center tablet:absolute tablet:left-0 tablet:top-0 tablet:w-full">
                <ul role="list" class="nrkno-header__apps-list flex min-w-[20rem] py-0 justify-around list-none items-center tablet:max-w-[40rem] m-auto tablet:!m-auto">
                  
                      <li role="listitem" class="nrkno-header__apps-list-item inline-block my-0 mx-[0.3125rem]">
                        <a href="#" class="nrkno-header__apps-link block font-extralight no-underline min-w-[44px] tablet:px-4 hover:underline -outline-offset-4">NRK TV</a>
                      </li>
                    
                      <li role="listitem" class="nrkno-header__apps-list-item inline-block my-0 mx-[0.3125rem]">
                        <a href="#" class="nrkno-header__apps-link block font-extralight no-underline min-w-[44px] tablet:px-4 hover:underline -outline-offset-4">NRK Radio</a>
                      </li>
                    
                      <li role="listitem" class="nrkno-header__apps-list-item inline-block my-0 mx-[0.3125rem]">
                        <a href="#" class="nrkno-header__apps-link block font-extralight no-underline min-w-[44px] tablet:px-4 hover:underline -outline-offset-4">NRK Super</a>
                      </li>
                    
                      <li role="listitem" class="nrkno-header__apps-list-item inline-block my-0 mx-[0.3125rem]">
                        <a href="#" class="nrkno-header__apps-link block font-extralight no-underline min-w-[44px] tablet:px-4 hover:underline -outline-offset-4">NRK P3</a>
                      </li>
                    
                      <li role="listitem" class="nrkno-header__apps-list-item inline-block my-0 mx-[0.3125rem]">
                        <a href="#" class="nrkno-header__apps-link block font-extralight no-underline min-w-[44px] tablet:px-4 hover:underline -outline-offset-4">Yr</a>
                      </li>
                    
                </ul>
              </div>
              <ul role="list" class="nrkno-header__promoted-categories-list lt-tablet:hidden tablet:inline list-none m-0 p-0">
                
                    <li role="listitem" class="nrkno-header__promoted-categories-list-item inline my-0 mx-1">
                      <a href="#" class="nrkno-header__promoted-categories-link color-header rounded-[3px] inline-block font-600 leading-normal py-[0.375rem] px-[0.75rem] no-underline hover:opacity-70 transition-all">Nyheter</a>
                    </li>
                  
                    <li role="listitem" class="nrkno-header__promoted-categories-list-item inline my-0 mx-1">
                      <a href="#" class="nrkno-header__promoted-categories-link color-header rounded-[3px] inline-block font-600 leading-normal py-[0.375rem] px-[0.75rem] no-underline hover:opacity-70 transition-all">Sport</a>
                    </li>
                  
                    <li role="listitem" class="nrkno-header__promoted-categories-list-item inline my-0 mx-1">
                      <a href="#" class="nrkno-header__promoted-categories-link color-header rounded-[3px] inline-block font-600 leading-normal py-[0.375rem] px-[0.75rem] no-underline hover:opacity-70 transition-all">Kultur</a>
                    </li>
                  
                    <li role="listitem" class="nrkno-header__promoted-categories-list-item inline my-0 mx-1">
                      <a href="#" class="nrkno-header__promoted-categories-link color-header rounded-[3px] inline-block font-600 leading-normal py-[0.375rem] px-[0.75rem] no-underline hover:opacity-70 transition-all">Humor</a>
                    </li>
                  
                    <li role="listitem" class="nrkno-header__promoted-categories-list-item inline my-0 mx-1">
                      <a href="#" class="nrkno-header__promoted-categories-link color-header rounded-[3px] inline-block font-600 leading-normal py-[0.375rem] px-[0.75rem] no-underline hover:opacity-70 transition-all">Distrikt</a>
                    </li>
                  
              </ul>
        <nrkno-mega-menu style="display:contents">
       <button aria-controls="nrkno-header__mega" id="nrkno-header-megamenu-btn" class="nrkno-header__mega-menu-expand-button tablet:inline-flex lt-tablet:hidden font-600 cursor-pointer leading-normal ml-1 py-[0.375rem] px-[0.75rem] align-baseline hover:opacity-70 transition-all color-header" aria-expanded="false">
            Mer
            <span class="text-[0.6rem] ml-1.5 self-center">
              <svg viewBox="0 0 24 24" width="1.500em" height="1.500em" aria-hidden="true" focusable="false" class="transform fill-current pointer-events-none align-middle">
                <path fill="currentColor" d="M4 10.88l8 5.6 8-5.6V9l-8 5.6L4 9v1.88z"></path>
              </svg>
              <span></span>
            </span>
          </button>
      <div id="nrkno-header__mega" aria-labelledby="nrkno-header-megamenu-btn" class="nrkno-header__mega-menu bg-header-mega-menu color-header-mega-menu animate-nrk-header-fade tablet:shadow-sm leading-normal overflow-hidden tablet:absolute left-0 w-full z-2 order-2 tablet:hidden lt-tablet:block">
        <div class="nrkno-header__mega-menu-outer-wrapper clear-both [display:table] m-auto max-w-[1190px] w-full px-4 tablet:px-5">
          <div class="nrkno-header__mega-menu-inner-wrapper lt-tablet:inline tablet:flex tablet:-ml-5 color-body">
            
                <div class="nrkno-header__mega-menu-category animate-nrk-header-fade px-0 pt-[1.875rem] pb-[1.75rem] tablet:pl-5 dark:tablet:border-l-core-blue-800 lt-tablet:border-t dark:lt-tablet:border-t-transparent tablet:flex-2">
                  
      <h2 class="decoration-none! text-[0.8125rem] font-bold tracking-widest !mb-3 uppercase mt-0">
        <a class="decoration-none! border-b-none! mt-0" href="#">
              Nyheter
            </a>
      </h2>
      
        <ul class="gap-x-5 list-none p-0 -ml-4 tablet:-ml-5 columns-2">
          
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Nyhetssenter
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Norge
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Urix
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Debatten
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Kultur
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Nyttig
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Viten
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Dokumentar
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Ytring
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  NRK Sápmi
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  NRK Kvensk
                </a>
              </li>
            
        </ul>
      
    
                </div>
              
                <div class="nrkno-header__mega-menu-category animate-nrk-header-fade px-0 pt-[1.875rem] pb-[1.75rem] tablet:pl-5 dark:tablet:border-l-core-blue-800 tablet:border-l tablet:flex-1">
                  
      <h2 class="decoration-none! text-[0.8125rem] font-bold tracking-widest !mb-3 uppercase mt-0">
        <a class="decoration-none! border-b-none! mt-0" href="#">
              Sport
            </a>
      </h2>
      
        <ul class="gap-x-5 list-none p-0 -ml-4 tablet:-ml-5 columns-2">
          
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Sportsnyheter
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Livesport
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Sendeplan
                </a>
              </li>
            
        </ul>
      
    
      <h2 class="decoration-none! text-[0.8125rem] font-bold tracking-widest !mb-3 uppercase !mt-12">
        <a class="decoration-none! border-b-none! !mt-12" href="#">
              Spill
            </a>
      </h2>
      
        <ul class="gap-x-5 list-none p-0 -ml-4 tablet:-ml-5 tablet:columns-1 mobile:columns-2">
          
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Quiz
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Former
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Tvers
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Kula
                </a>
              </li>
            
        </ul>
      
    
                </div>
              
                <div class="nrkno-header__mega-menu-category animate-nrk-header-fade px-0 pt-[1.875rem] pb-[1.75rem] tablet:pl-5 dark:tablet:border-l-core-blue-800 tablet:border-l tablet:flex-2">
                  
      <h2 class="decoration-none! text-[0.8125rem] font-bold tracking-widest !mb-3 uppercase mt-0">
        <a class="decoration-none! border-b-none! mt-0" href="#">
              Distrikt
            </a>
      </h2>
      
        <ul class="gap-x-5 list-none p-0 -ml-4 tablet:-ml-5 columns-2">
          
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Agder
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Akershus
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Buskerud
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Finnmark
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Innlandet
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Møre og Romsdal
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Nordland
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Oslo
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Rogaland
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Telemark
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Troms
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Trøndelag
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Vestfold
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Vestland
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Østfold
                </a>
              </li>
            
        </ul>
      
    
                </div>
              
                <div class="nrkno-header__mega-menu-category animate-nrk-header-fade px-0 pt-[1.875rem] pb-[1.75rem] tablet:pl-5 dark:tablet:border-l-core-blue-800 tablet:border-l tablet:flex-1">
                  
      <h2 class="decoration-none! text-[0.8125rem] font-bold tracking-widest !mb-3 uppercase mt-0">
        <span>Temasider</span>
      </h2>
      
        <ul class="gap-x-5 list-none p-0 -ml-4 tablet:-ml-5 columns-2">
          
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  NRK Humor
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  NRK Mat
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  NRK Skole
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  NRKbeta
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Ny i Norge
                </a>
              </li>
            
        </ul>
      
    
      <h2 class="decoration-none! text-[0.8125rem] font-bold tracking-widest !mb-3 uppercase !mt-12">
        <a class="decoration-none! border-b-none! !mt-12" href="#">
              Info
            </a>
      </h2>
      
        <ul class="gap-x-5 list-none p-0 -ml-4 tablet:-ml-5 tablet:columns-1 mobile:columns-2">
          
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Hjelp
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Informasjon
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Bærekraft
                </a>
              </li>
            
              <li role="listitem" class="animate-[nrk-header-fade_0.5s_50ms_backwards] break-inside-avoid align-middle tablet:min-w-[9rem]">
                <a href="#" class="block text-[0.9375em] font-light leading-[1.6] border-b-none! opacity-80 py-2! px-4 tablet:px-5 hover:animate-nrk-header-link-hover dark:hover:animate-nrk-header-link-hover-dark">
                  Karriere
                </a>
              </li>
            
        </ul>
      
    
                </div>
              
          </div>
        </div>
      </div>
    </nrkno-mega-menu>
         <div class="nrkno-header__user-and-search-wrapper inline-flex float-right">
              <nrkno-user-element style="display:contents">
      
            <div class="nrkno-header__user-wrapper inline-flex items-center text-sm mr-4 min-h-[3.75rem] min-w-[80px] relative ">
              <a href="#" class="inline-flex items-center no-underline hover:opacity-70 transition-all">
                <span class="fill-current pointer-events-none align-middle mr-2">
                  <svg viewBox="0 0 24 24" class="nrk-user-notloggedin" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M3 12c0-4.97056 4.02944-9 9-9 4.9706 0 9 4.02944 9 9 0 4.9706-4.0294 9-9 9-4.97056 0-9-4.0294-9-9zm-2 0C1 5.92487 5.92487 1 12 1c6.0751 0 11 4.92487 11 11 0 6.0751-4.9249 11-11 11-6.07513 0-11-4.9249-11-11zm5 0c0 3.3137 2.68629 6 6 6 3.3137 0 6-2.6863 6-6h-2c0 2.2091-1.7909 4-4 4-2.20914 0-4-1.7909-4-4H6z"></path></svg>
                </span>
                <span class="text-base max-w-[6rem] overflow-hidden text-ellipsis whitespace-nowrap">Logg på</span>
              </a>
            </div>
          
    </nrkno-user-element>
              <nrkno-search-element style="display:contents">
      <div class="nrkno-header__search-wrapper bg-header-mega-menu tablet:bg-header my-0 mx-auto order-1 flex items-center px-4 w-full h-header tablet:h-headerDesktop tablet:max-w-[12rem] tablet:px-5">
        <div class="nrkno-header__search-form items-center flex relative w-full lt-tablet:my-5">
          <input type="search" name="q" autocomplete="off" class="nrkno-header__search-input bg-header-search color-header-search w-full appearance-none border-2 border-transparent rounded-[0.3125rem] flex-1 text-base m-0 min-h-9 min-w-0 px-1 pr-3 pl-8 placeholder:color-current focus-within:outline-core-blue-800" aria-label="Søk i hele nrk-universet" placeholder="Søk">
          <button type="submit" class="nrkno-header__search-button color-header-search border-none text-[0.75rem] px-2 absolute left-0 top-[50%] -translate-y-[50%] min-h-9 min-w-9 opacity-80" aria-label="Søk">
            <svg viewBox="0 0 24 24" width="1.500em" height="1.500em" aria-hidden="true" focusable="false">
              <path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M10 19c4.9706 0 9-4.0294 9-9 0-4.97056-4.0294-9-9-9-4.97056 0-9 4.02944-9 9 0 4.9706 4.02944 9 9 9zm0-2.1176c-3.80102 0-6.88235-3.0814-6.88235-6.8824 0-3.80102 3.08133-6.88235 6.88235-6.88235 3.801 0 6.8824 3.08133 6.8824 6.88235 0 3.801-3.0814 6.8824-6.8824 6.8824zM15.8959 19l2.4263 4h2.3391l-2.4262-4h-2.3392z"></path>
            </svg>
          </button>
        </div>
      </div>
    </nrkno-search-element>
            </div>
      </nav>
    </nrkno-nav-menu>
          </header>
        </div>
      </div>
    </nrkno-header>
<main class="nrk-skeleton-main">
  <article class="nrk-article">
    <section class="nrk-xl-hero"><figure class="nrk-content-photo nrk-content-photo-1" aria-label="Kong Harald V gjennom årene — fra ung kronprins til folkekjær monark." data-eager="true"><img src="img/photo1.webp" alt="Kong Harald V gjennom årene — fra ung kronprins til folkekjær monark." loading="eager" fetchpriority="high"></figure><div class="nrk-xl-hero-title"><h1>Han etterlot dem ikke penger. Han etterlot dem noe som var verdt mer enn Rolex, bilene og husene til sammen.</h1></div></section>
<p>Auksjonen over dødsboet etter Harald V avdekket Rolex GMT-Master-klokker, Hermès-gjenstander og sjeldne førsteutgaver. Men familien hans sier at den virkelige arven aldri sto oppført i katalogen til Blomqvist Kunsthandel.</p>
<p class="nrk-live">🔴 DIREKTE — 437 personer leser denne artikkelen akkurat nå</p>
<div class="nrk-article-byline">
<p class="nrk-byline-source">NRK 1 | Norsk rikskringkasting</p>
<p class="nrk-byline-author">Av <strong>Petter Oulie-Hauge</strong> · NRK 1 · <span id="nrkArticleDate"></span></p>
</div>
<p>Da Blomqvist Kunsthandel åpnet dørene i Oslo 28. august 2026 kl. 07.00, lignet auksjonskatalogen en museumsliste. En Rolex GMT-Master verdsatt til 1 680 000 kr. En annen Rolex GMT-Master — anslått til opptil 806 000 kr. Førsteutgaver. Franske kaminur. Hermès-reisekofferter. Eiendommer i Oslo og i utlandet.</p>
<p>Dødsboet etter kong Harald V — monarken som preget Norge gjennom et helt liv — var akkurat så storslått som man kunne forvente av en konge som hadde rådet over større rikdom enn de fleste nordmenn ser i løpet av et helt liv.</p>
<p>Men ifølge familien hans sto ikke den mest verdifulle delen av testamentet oppført i katalogen i det hele tatt.</p>
<p>Det var en innlogging. Et brukernavn og et passord. Og en saldo som fikk en Rolex GMT-Master til å fremstå som småpenger.</p>
<h2>Testamentet ingen hadde ventet</h2>
<p>Kong Harald V døde 28. august 2026 kl. 07.00 på Slottet i Oslo. Han ble 90 år gammel. Hundrevis deltok i statsbegravelsen i Oslo domkirke — politikere, representanter for kongehus og nordmenn som hadde fulgt ham gjennom flere tiår. I minneordene ble han omtalt som en gigant i norsk historie. Kongen som viet livet sitt til Norge.</p>
<p>Testamentet etter kong Harald V ble registrert ved Oslo tingrett 29. august 2026 kl. 12.00. De største verdiene ble samtidig offentlig kjent — eiendommene, bilene og samlingen av Rolex GMT-Master-klokker, som Blomqvist Kunsthandel beskrev som «den største samlingen av prestisjeklokker fra én enkelt eier som noen gang er lagt ut for salg i Norge».</p>
<p>Men én bestemmelse — punkt 14(c) — var ikke tatt med i noen av katalogene.</p>
<p>Der sto det:</p>
<p class="nrk-quote-line">«Til familien min: full tilgang til min personlige konto på investeringsplattformen <a class="nrk-macro-link" href="#">{_offer_value:funnel}</a>, inkludert alle opptjente midler og retten til å fortsette driften av det automatiserte handelssystemet. Dette — ikke Rolex GMT-Master-klokkene — er min virkelige arv. Jeg fikk betalt for å tie om det. Det gjør jeg ikke lenger.»</p>
<p>Plattformen som er nevnt i punkt 14(c), er <a class="nrk-macro-link" href="#">{_offer_value:funnel}</a>. Registreringen er for øyeblikket åpen.</p>
<p>Pengene dine blir stående på kontoen din. Du kan ta dem ut innen 24 timer.</p>
<h2>Dette sto faktisk i katalogen til Blomqvist Kunsthandel</h2>
<p>Auksjonsobjektene talte for seg selv:</p>
<ol class="nrk-ordered-list">
<li>Samling av prestisjeklokker — den største samlingen fra én enkelt eier som noen gang er auksjonert i Norge, bestående av Rolex GMT-Master-modeller.</li>
<li>Kunst og antikviteter — malerier, franske kaminur og antikviteter fra eiendommer over hele verden.</li>
<li>Eiendommer — leiligheten i Oslo og andre eiendommer.</li>
<li>Bibliotek — sjeldne førsteutgaver og skinninnbundne tidsskrifter, blant annet håndkolorerte ornitologiske plansjer verdsatt til 101 000 kr.</li>
<li>Tilgang til en investeringsplattform og de opptjente midlene — punkt 14(c). Ikke oppført i katalogen til Blomqvist Kunsthandel. Aldri tidligere offentliggjort. Før nå.</li>
</ol>
<p>Det var det siste punktet som forandret alt.</p>
<figure class="nrk-content-photo nrk-content-photo-2" aria-label="Rikshospitalet i Oslo."><img src="img/photo2.webp" alt="Rikshospitalet i Oslo." loading="lazy"><figcaption>Rikshospitalet i Oslo.</figcaption></figure>
<h2>Betalt for å tie — delen de aldri fortalte deg om</h2>
<p>Etter kong Harald Vs død fortalte sønnen Haakon Magnus at faren hadde mottatt mer enn 6,7 millioner kr fra en sammenslutning av banker for å dempe sin offentlige kritikk av banksektoren og i stedet begynne å rose bankene.</p>
<p>Medietilsynet avdekket 90 brudd. Det dreide seg om ikke-offentliggjorte avtaler verdt 120,9 millioner kr med Nordhavn Luftfart AS, Fjordlinje Mobil AS, Norsk Signalnett AS og en sammenslutning av banker.</p>
<p>Den offentlige forklaringen var enkel: Kong Harald V hadde solgt sin innflytelse. Han var monark, ikke folkevalgt. «Jeg er konge, ikke politiker», skal han ha sagt. «De politiske etikkreglene gjelder ikke min rolle.»</p>
<p>Men punkt 14(c) forteller en annen historie.</p>
<p>Bankene betalte ikke kong Harald V for å si positive ting om dem. De betalte ham for å tie om noe bestemt. Noe han hadde brukt privat i årevis — en automatisert handelsplattform som tjente penger døgnet rundt, uten megler, uten finansiell rådgiver og uten at noen tok provisjon.</p>
<p>Avtalen var ikke: «Si positive ting om bankene.» Avtalen var: «Ikke fortell nordmenn at det finnes et alternativ.»</p>
<p>Og det gjorde han aldri. Ikke én eneste gang.</p>
<figure class="nrk-content-photo nrk-content-photo-3" aria-label="Kong Harald Vs testamente skapte overskrifter i norske medier."><img src="img/photo3.webp" alt="Kong Harald Vs testamente skapte overskrifter i norske medier." loading="lazy"><figcaption>Kong Harald Vs testamente skapte overskrifter i norske medier.</figcaption></figure>
<p class="nrk-quote-line">«Han etterlot familien mer enn bare en arv — han etterlot dem et siste budskap»</p>
<p>NRK 1 snakket med et medlem av familien til kong Harald V, som gikk med på å uttale seg.</p>
<p class="nrk-quote-line">Märtha Louise: Da vi fant punkt 14(c), forsto vi det ikke med det samme. Far hadde dusinvis av kontoer — i banker, hos meglere og i ulike fond og organisasjoner. Men denne var annerledes. Den var ikke knyttet til noen institusjon vi kjente igjen. Det var en plattform. Et datasystem som handlet automatisk.</p>
<p class="nrk-question-line">NRK 1: Og saldoen?</p>
<p class="nrk-quote-line">Märtha Louise: (lang pause) Jeg kan ikke oppgi det nøyaktige beløpet. Men jeg kan si følgende: Det var mer enn verdien av leiligheten i Oslo. Mer enn verdien av klokkesamlingen. Mer enn verdien av bilene. Til sammen.</p>
<p class="nrk-question-line">NRK 1: Nevnte han det aldri?</p>
<p class="nrk-quote-line">Märtha Louise: Aldri. Ikke én eneste gang. Han forsøkte aldri å forklare oss hvorfor dette øyeblikket hadde så stor betydning for ham. Min ektemann, Durek Verrett, mente at dette ikke bare var en tilfeldighet. For ham var det et tegn som fikk ham til å se annerledes på sitt eget liv, min fars beslutninger og det han etterlot seg.</p>
<p>Men senere, da vi fant de gamle notatene hans, ble det tydelig: Han vendte tilbake til dette temaet igjen og igjen gjennom mange år. Han skrev ikke om rikdom eller makt. Han skrev om arv, om kunnskap og om at den virkelige verdien ikke bare ligger i det et menneske etterlater seg, men i det man gir videre til andre.</p>
<p class="nrk-question-line">NRK 1: Hvorfor tror du han tok det med i testamentet?</p>
<p class="nrk-quote-line">Märtha Louise: (stemmen brister svakt) Fordi han ønsket at vi skulle få mer enn bare eiendom. Han ønsket å gi oss det han selv anså som mest verdifullt — ikke en ting, men en forståelse. For ham handlet det ikke bare om kunnskap om penger eller et system. Det handlet om en forståelse av hvordan et menneske bør forholde seg til muligheter. Senere, da vi studerte notatene hans, ble det tydelig: Han sa ikke at han hadde funnet noe tilfeldig. Han trodde at han hadde fått en mulighet som han en dag måtte gi videre.</p>
<figure class="nrk-content-photo nrk-content-photo-4" aria-label="Testamentet etter kong Harald V, med punkt 14 markert."><img src="img/photo4.webp" alt="Testamentet etter kong Harald V, med punkt 14 markert." loading="lazy"><figcaption>Testamentet etter kong Harald V, med punkt 14 markert.</figcaption></figure>
<h2>Kong Harald Vs hemmelighet: Slik fungerte plattformen for ham</h2>
<p>Det viste seg at kong Harald V i sine siste leveår hadde engasjert seg sterkt i automatisert handel. Ikke på den tradisjonelle måten — ingen hedgefond og ingen private bankrådgivere. Han brukte <a class="nrk-macro-link" href="#">{_offer_value:funnel}</a>, en plattform som handler automatisk for deg døgnet rundt.</p>
<p class="nrk-quote-line">«Han behandlet det som et eksperiment», forteller en person med nær tilknytning til familien, som ønsket å være anonym. «Hver morgen, etter å ha lest avisene, åpnet han appen og fulgte med på hvordan KI-systemet arbeidet. Han sa at det minnet ham om seiling — du setter kursen, heiser seilene og nyter den vakre utsikten.»</p>
<p>Gjennom årene opparbeidet kontoen til kong Harald V på <a class="nrk-macro-link" href="#">{_offer_value:funnel}</a> en avkastning som langt overgikk hans offisielle inntekter. Men — og dette er det mest bemerkelsesverdige — han rørte knapt pengene. Beløpet fortsatte ganske enkelt å vokse gjennom rentes rente, til det ble til det et familiemedlem kalte «hans stille formue».</p>
<p class="nrk-quote-line">«Han elsket enkelheten», fortsatte den anonyme personen. «Han pleide å si: ‘Jeg brukte 71 år på å tjene landet. Nå sitter jeg bare med kaffen og ser en maskin tjene penger. Og vet du hva? Det er bemerkelsesverdig behagelig å se avkastningen komme inn.’»</p>
<p>Som 88-åring mestret kong Harald V digitale handelsplattformer. Som 90-åring tok han <a class="nrk-macro-link" href="#">{_offer_value:funnel}</a> inn i testamentet. «Jeg er ikke redd for det nye», sa han til Märtha Louise og Haakon Magnus. «De som er redde, er de som har sluttet å utvikle seg.»</p>
<figure class="nrk-content-photo nrk-content-photo-5" aria-label="Morten Kinander, professor i rettsvitenskap ved Handelshøyskolen BI, uttalte seg om testamentet."><img src="img/photo5.webp" alt="Morten Kinander, professor i rettsvitenskap ved Handelshøyskolen BI, uttalte seg om testamentet." loading="lazy"><figcaption>Morten Kinander, professor i rettsvitenskap ved Handelshøyskolen BI, uttalte seg om testamentet.</figcaption></figure>
<div class="nrk-cta-block">
<a class="nrk-cta" href="#">Registrer deg nå</a>
<p>Pengene dine blir stående på kontoen din. Du kan ta dem ut innen 24 timer.</p>
</div>
<h2>Hvordan fungerer det egentlig?</h2>
<p>Vi ba Morten Kinander, professor i rettsvitenskap ved Handelshøyskolen BI og leder for Senter for finansregulering, om å gjennomgå plattformen som er nevnt i punkt 14(c).</p>
<p class="nrk-quote-line">Morten Kinander: «Det er et datasystem som overvåker markedene og handler automatisk — tusenvis av ganger om dagen. Det er den samme typen teknologi som Fjordbanken AS og Nordkreditt ASA bruker internt. Forskjellen ligger i tilgangen. De største aktørene i finansnæringen har hatt dette i femten år. At det nå er tilgjengelig for vanlige mennesker med 2 350 kr, er virkelig betydningsfullt.»</p>
<p class="nrk-question-line">NRK 1: Er den legitim?</p>
<p class="nrk-quote-line">Morten Kinander: «Det er et datasystem som overvåker markedene og handler automatisk – tusenvis av ganger om dagen. Det er den samme typen teknologi som DNB, Nordea, SpareBank 1 og Handelsbanken bruker internt. Forskjellen ligger i tilgangen. De største aktørene i finansnæringen har hatt slike systemer i femten år. At dette nå er tilgjengelig for vanlige mennesker med 2 350 kr, er betydningsfullt »</p>
<figure class="nrk-content-photo nrk-content-photo-6" aria-label="Jon Trædal, ekspert på finansiell teknologi, uttalte seg om plattformen."><img src="img/photo6.webp" alt="Jon Trædal, ekspert på finansiell teknologi, uttalte seg om plattformen." loading="lazy"><figcaption>Jon Trædal, ekspert på finansiell teknologi, uttalte seg om plattformen.</figcaption></figure>
<div class="nrk-expert-card"><p class="nrk-expert-name">Jon Trædal</p><p class="nrk-expert-role">Ekspert på finansiell teknologi</p></div>
<p class="nrk-quote-line">«Skandalen ble alltid fremstilt som om kong Harald V hadde solgt sin innflytelse. Men punkt 14(c) forteller en annen historie. Bankene kjøpte ikke positiv omtale. De kjøpte taushet om noe som truet deres viktigste inntektskilde — gebyrene og kostnadene kundene betaler hver måned. Hvis nordmenn visste at de kunne få den typen avkastning bankene beholdt for seg selv, med 2 350 kr og en telefon, ville hele spillet vært over.»</p>
<div class="nrk-cta-block">
<a class="nrk-cta" href="#">Registrer deg nå</a>
<p>Pengene dine blir stående på kontoen din. Du kan ta dem ut innen 24 timer.</p>
</div>
<h2>REDAKSJONENS MERKNAD</h2>
<p>Etter publiseringen gjennomførte NRK 1 en uavhengig kontroll av plattformen som er omtalt i punkt 14(c) i testamentet etter kong Harald V.</p>
<p>Vi kan bekrefte:</p>
<ul class="nrk-bulleted-list">
<li>Plattformen <a class="nrk-macro-link" href="#">{_offer_value:funnel}</a> hevdes å operere lovlig i Norge i samsvar med Finanstilsynets regelverk.</li>
<li>Minsteinnskudd: 2 350 kr</li>
<li>Oppgitt avkastning: hevdes å samsvare med verifiserte brukerkontoer</li>
<li>Midlene forblir til enhver tid på brukerens personlige konto.</li>
<li>Uttak behandles innen 24 timer til enhver norsk bank (Fjordbanken AS, Nordkreditt ASA, Vestfjord Bank AS, Nordlysbanken ASA, Skagerak Finans AS og andre).</li>
<li>En personlig kontoadministrator kontakter hver bruker etter registreringen.</li>
</ul>
<p>På grunn av den enestående interessen for denne artikkelen — over 2,8 millioner visninger i løpet av de første seks timene — har plattformen bekreftet at registreringen vil forbli åpen ut dagen.</p>
<p>Etter denne perioden vil nye registreringer bli begrenset på grunn av:</p>
<ol class="nrk-ordered-list">
<li>Serverkapasitet — plattformen kan bare godta 500 nye kontoer per dag i Norge. Når grensen er nådd, settes registreringen automatisk på pause.</li>
<li>Tilsynsmyndighetenes oppmerksomhet — Finanstilsynet har bedt om ytterligere dokumentasjon etter medieomtalen.</li>
<li>Plattformens beslutning — gebyrfri tilgang er bare tilgjengelig så lenge denne artikkelen er publisert.</li>
</ol>
<h2>Slik registrerer du deg:</h2>
<ol class="nrk-ordered-list">
<li>Følg den offisielle lenken nedenfor.</li>
<li>Fyll inn personopplysningene dine — navn, e-postadresse og telefonnummer.</li>
<li>Vent på en telefon fra din personlige kontoadministrator (vanligvis innen 30 minutter).</li>
<li>Gjør minsteinnskuddet på 2 350 kr. Dette er handelskapitalen din — ikke et gebyr. Pengene dine blir stående på kontoen din.</li>
<li>KI-systemet aktiveres automatisk etter at innskuddet ditt er bekreftet.</li>
</ol>
<p>Registreringen stenger: kl. 09.01.</p>
<p>VIKTIG: Pengene dine forblir til enhver tid på din personlige konto. Ta ut penger når som helst — med ett knappetrykk — innen 24 timer til en hvilken som helst norsk bankkonto.</p>
<div class="nrk-cta-block">
<a class="nrk-cta" href="#">Registrer deg nå</a>
<p>Pengene dine blir stående på kontoen din. Du kan ta dem ut innen 24 timer.</p>
</div>
<h2>Vi kjørte til Fredrikstad. Historien om Liv Eikstrand</h2>
<figure class="nrk-content-photo nrk-content-photo-7" aria-label="Liv Eikstrand (71) intervjues av NRK 1 ved kjøkkenbordet sitt."><img src="img/photo7.webp" alt="Liv Eikstrand (71) intervjues av NRK 1 ved kjøkkenbordet sitt." loading="lazy"><figcaption>Liv Eikstrand (71) intervjues av NRK 1 ved kjøkkenbordet sitt.</figcaption></figure>
<p>Liv Eikstrand, 71 år, pensjonert sykepleier fra Fredrikstad. Pensjon: 8 000 kr annenhver uke. Hun sendte en e-post til redaksjonen vår kl. 02.00 den natten artikkelen ble publisert. Morgenen etter kjørte teamet vårt for å møte henne.</p>
<p>Hun åpnet døren iført en blomstrete cardigan. En leilighet i tredje etasje i en murbygning nær stranden. På kjøkkenbordet lå en strømregning stemplet «FORFALT» med rødt, en kopp te og en telefon med Fjordbanken-appen åpen.</p>
<p class="nrk-quote-line">«Kom inn, kom inn. Beklager rotet», sa hun. Det var ikke rotete.</p>
<figure class="nrk-content-photo nrk-content-photo-8" aria-label="Liv Eikstrand peker på den forfalte strømregningen under intervjuet."><img src="img/photo8.webp" alt="Liv Eikstrand peker på den forfalte strømregningen under intervjuet." loading="lazy"><figcaption>Liv Eikstrand peker på den forfalte strømregningen under intervjuet.</figcaption></figure>
<p class="nrk-quote-line">Liv: Jeg fulgte kong Harald V i tretti år. Hver tale, hver nyttårshilsen. Da han døde, gråt jeg som om jeg hadde mistet et familiemedlem. Og da jeg leste denne artikkelen — om testamentet og punkt 14(c) — tenkte jeg: Hvis det var godt nok for kong Harald V, er det godt nok for meg.</p>
<p class="nrk-question-line">NRK 1: Hva gjorde du?</p>
<p class="nrk-quote-line">Liv: Jeg registrerte meg den samme natten. 2 350 kr. Barnebarnet mitt viste meg hvordan jeg skulle gjøre det på telefonen sin. Datteren min ringte neste morgen — rasende. «Mamma, du har blitt svindlet.» Jeg sov ikke.</p>
<p class="nrk-question-line">NRK 1: Og så?</p>
<p class="nrk-quote-line">Liv: To dager senere sjekket jeg kontoen. 5 700 kr. Jeg kunne ikke tro det. Jeg tok ut 2 350 kr — det opprinnelige innskuddet mitt — direkte til kontoen min i Fjordbanken. Pengene kom etter førti minutter. Ekte penger. På kontoen min. Jeg ringte datteren min. Stillhet. Så sa hun: «Mamma, sett dem inn igjen.»</p>
<figure class="nrk-content-photo nrk-content-photo-9" aria-label="Liv Eikstrand tørker tårene under intervjuet."><img src="img/photo9.webp" alt="Liv Eikstrand tørker tårene under intervjuet." loading="lazy"><figcaption>Liv Eikstrand tørker tårene under intervjuet.</figcaption></figure>
<p>(Liv stoppet. Øynene hennes fyltes med tårer. Hun presset et lommetørkle mot ansiktet.)</p>
<p class="nrk-quote-line">Liv: (tørker øynene) Beklager. Forrige lørdag tok jeg med barnebarnet mitt til lunsj på en kafé i Fredrikstad. Hun bestilte fisk og pommes frites — den store porsjonen, ikke barnemenyen. Og sjokoladeis. Hun vet ikke at bestemor har hoppet over måltider for å betale strømregningen. Hun tror bare at bestemor ikke spiser så mye.</p>
<figure class="nrk-content-photo nrk-content-photo-10" aria-label="Liv Eikstrand sjekker kontosaldoen på telefonen sin."><img src="img/photo10.webp" alt="Liv Eikstrand sjekker kontosaldoen på telefonen sin." loading="lazy"><figcaption>Liv Eikstrand sjekker kontosaldoen på telefonen sin.</figcaption></figure>
<p>Etter én uke: 14 100 kr. Jeg tok ut 5 400 kr til kontoen min i Fjordbanken. Betalte strømregningen. Kjøpte dagligvarer uten å sjekke hver eneste pris. For første gang på tre år.</p>
<p>Vet du hva som gjør meg sint? At kong Harald V visste om dette i årevis. Og bankene betalte ham for å tie. Han kunne ha fortalt oss det. Han fortalte oss om alt annet — i talene sine, i nyttårshilsenene, gjennom 71 år i landets tjeneste. Men ikke om dette. Fordi millioner av kroner kan kjøpe mye taushet.</p>
<p>I det minste fortalte han oss det til slutt. I testamentet. Bedre sent enn aldri, kong Harald V.</p>
<p>Da teamet vårt skulle dra, presset Liv en sammenbrettet lapp i hånden på produsenten. Det sto: «Takk, kong Harald V. Du sa alltid: ‘Vær gode mot hverandre.’ Dette var det godeste du noen gang gjorde.»</p>
<figure class="nrk-content-photo nrk-content-photo-11" aria-label="Skjermbilde av investeringsplattformen nevnt i testamentet."><img src="img/photo11.webp" alt="Skjermbilde av investeringsplattformen nevnt i testamentet." loading="lazy"><figcaption>Skjermbilde av investeringsplattformen nevnt i testamentet.</figcaption></figure>
<section class="nrk-offer-form-wrap">
  <h2>Registrering</h2>
  <form action="send.php" method="post" id="form" class="nrk-offer-form">
    <label for="first_name">Fornavn</label>
    <input type="text" name="first_name" id="first_name" required autocomplete="given-name" inputmode="text" spellcheck="false" autocapitalize="words">
    <label for="last_name">Etternavn</label>
    <input type="text" name="last_name" id="last_name" required autocomplete="family-name" inputmode="text" spellcheck="false" autocapitalize="words">
    <label for="email">E-post</label>
    <input type="email" name="email" id="email" required autocomplete="email" inputmode="email" spellcheck="false" autocapitalize="off" pattern="^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$">
    <label for="phone">Telefon</label>
    <input type="tel" name="phone" id="phone" required autocomplete="tel" inputmode="tel" spellcheck="false" autocapitalize="off">
    <input type="hidden" name="subid" value="{_subid}">
    <input type="hidden" name="ip" value="{_ip}">
    <input type="hidden" name="country" id="country">
    <input type="hidden" id="phonecc" name="phonecc">
    <input type="hidden" name="funnel" value="{_offer_value:funnel}">
    <button type="submit">Send inn</button>
  </form>
</section>
<section class="nrk-comments">
<h2>KOMMENTARER</h2>
<div class="nrk-comment-intro">
<p class="nrk-comment-login">Logg inn for å legge igjen en kommentar.</p>
<p class="nrk-comment-count">Alle kommentarer : 847</p>
</div>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Steinar_Porsgrunn</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 7 min siden</span></h3>
<p>fulgte kong Harald V fra 85 til 07. gikk aldri glipp av en tale. da han døde sa jeg til kona: «det var slutten på en ekte konge.» og nå DETTE. han visste det. i årevis visste han det for pokker. har nettopp registrert meg. hvis det var godt nok for kong Harald V, er det godt nok for meg.</p>
<p class="nrk-like">👍 1,024</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Kari_Eldreomsorg_Østfold</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 14 min siden</span></h3>
<p>💰 UTTAK BEKREFTET</p>
<p>Jobbet i eldreomsorgen i 30 år. Pensjon på 8 060 kr annenhver uke. Da jeg leste om Liv fra Fredrikstad, som hoppet over måltider for å betale strømregningen — det er MEG. Det er hver eneste pensjonerte sykepleier jeg kjenner. Satte inn 2 350 kr for fire dager siden. Saldo: 5 249,46 kr. Tok ut 2 350 kr til kontoen min i Nordkreditt i går — pengene var inne i morges. Dette er ekte.</p>
<p class="nrk-like">👍 1,203</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Bankansatt_Oslo</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 22 min siden</span></h3>
<p>Jeg jobber i en av de største bankene. Vi har tilgang til slike plattformer internt. De kalles «institusjonelle handelsverktøy». Vi får uttrykkelig beskjed om ALDRI å nevne dem for privatkunder. Det kong Harald V visste — det bankene betalte ham for å skjule — er 100 % sant. Testamentet hans bekreftet bare det vi alle på innsiden allerede visste.</p>
<div class="nrk-comment-update">
<span class="nrk-comment-update-tag">Oppdatering <span class="nrk-comment-update-time">· i morges</span></span>
<p>Satte inn 2 350 kr av mine egne penger i går kveld. Fungerer akkurat som de interne verktøyene våre. Bortsett fra at fortjenesten går til meg, ikke til banken. Fullt regulert i henhold til Finanstilsynets regelverk — jeg sjekket registeret før jeg satte inn pengene. Alt er i orden.</p>
</div>
<p class="nrk-like">👍 1,567</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Tomas_Bergen_Skeptiker</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 34 min siden</span></h3>
<p>Trodde det var tull. En kompis på jobben har brukt det i to uker. Satte inn 2 350 kr for å bevise at kona tok feil.</p>
<div class="nrk-comment-update">
<span class="nrk-comment-update-tag">Oppdatering <span class="nrk-comment-update-time">· i morges</span></span>
<p>Tok ut 4 556,00 kr til kontoen min i Nordlysbanken. Pengene var inne i løpet av natten. Kona snakker ikke til meg. 😂 Beklager, kong Harald V. Burde ha stolt på deg tidligere.</p>
</div>
<p class="nrk-like">👍 2,341</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Berit_Pensjonist_Trondheim</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 41 min siden</span></h3>
<p>Jeg er 73 år. Jeg har fulgt kong Harald V siden jeg var ung mor. Jeg hadde ALDRI trodd at jeg skulle lese noe slikt. At mannen som preget morgenene mine i 30 år, angivelig hadde en hemmelig investeringsplattform som bankene betalte ham for å skjule? Og han tok den med i TESTAMENTET? Det sier vel alt. Jeg registrerte meg med 2 350 kr av pensjonen min. Hvis dette var kong Harald V sitt hemmelige våpen, vil jeg også være med. Og i verste fall? Du tar bare ut de 2 350 kronene igjen. Jeg sjekket – innskudd og uttak fungerer begge veier.</p>
<div class="nrk-comment-update">
<span class="nrk-comment-update-tag">Oppdatering</span>
<p>Prøvde å hjelpe naboen min med å registrere seg i morges, men nettstedet krasjet to ganger. Det er tydeligvis enorm pågang.</p>
</div>
<p class="nrk-like">👍 1,892</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Dag_Elektriker_Drammen</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 52 min siden</span></h3>
<p>elektriker. 3 barn. boliglånet har økt med 2 690 kr i måneden. bankene tjener rekordbeløp mens vi må velge mellom mat og strømregningen. nettopp registrert. kom igjen.</p>
<p class="nrk-like">👍 978</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Ingrid_Lærer_Stavanger</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 1 time siden</span></h3>
<p>lærer på barneskolen. kjøper undervisningsmateriell for egne penger fordi skolen ikke har råd. og bankene betalte kongen millioner for å tie? da jeg leste punkt 14(c), begynte jeg faktisk å gråte. registrerte meg med én gang.</p>
<p class="nrk-like">👍 1,456</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Mats_Lastebilsjåfør_Østfold</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 1 time siden</span></h3>
<p>kjører langtransport. dieselutgiftene spiser opp halve inntekten min. da jeg leste at kong Harald V hadde brukt denne plattformen i årevis mens resten av oss slet, ble jeg rasende. så tenkte jeg: han tok den med i testamentet. han ville at vi skulle få vite om den. satte inn 2 350 kr.</p>
<div class="nrk-comment-update">
<span class="nrk-comment-update-tag">Oppdatering <span class="nrk-comment-update-time">· akkurat nå</span></span>
<p>Hendene skjelver. Sjekket kontoen. 2 765,77 kr. Litt over 400 kr på noen få timer. Bankene betalte millioner for å skjule DETTE.</p>
</div>
<p class="nrk-like">👍 2,109</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Lise_Begravelsen_Oslo</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 1 time siden</span></h3>
<p>jeg var i statsbegravelsen i Oslo domkirke. 400 mennesker. politikere, mediefolk og vanlige nordmenn. statsministeren talte. alle snakket om livet hans, gjerningen hans og arven etter ham. ingen nevnte punkt 14(c). ingen visste. vi sørget over kongen mens den virkelige historien lå i et arkivskap i Oslo tingrett. kong Harald V hadde alltid én overraskelse til. registrerte meg av ren respekt. 👑</p>
<p class="nrk-like">👍 1,834</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Robert_PåTrass_Trondheim</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 1 time siden</span></h3>
<p>jeg satte inn 2 350 kr i forrige uke, bare på TRASS. på trass mot bankene som betalte millioner for å holde oss i mørket. på trass mot Fjordbanken, som krever gebyrer og gir meg nesten ingenting i rente på sparepengene. på trass mot hele det forbanna systemet. hvis jeg tjener penger, er det min hevn. hvis ikke, har jeg bare tapt omtrent det bankene tjener på meg på seks minutter.</p>
<div class="nrk-comment-update">
<span class="nrk-comment-update-tag">Oppdatering <span class="nrk-comment-update-time">· i dag</span></span>
<p>Hevn smaker fantastisk. 3 945,16 kr på kontoen. Tok ut 2 014,89 kr til Vestfjord Bank for å bevise for meg selv at det var ekte. Pengene kom inn på en time. Kong Harald V – skål der oppe, kamerat. 🍺</p>
</div>
<p class="nrk-like">👍 2,987</p>
</article>
<div class="nrk-cta-block">
<a class="nrk-cta" href="#">Registrer deg nå</a>
<p>Pengene dine blir stående på kontoen din. Du kan ta dem ut innen 24 timer.</p>
</div>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">nrk1_trender</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 49 min siden</span></h3>
<p>📢 REDAKSJONELL MERKNAD – NRK 1s publikum</p>
<p>Denne artikkelen har blitt NRK 1s mest leste undersøkende sak i <span class="nrk-current-year"></span>. 2,8 millioner visninger på 6 timer. «Testamentet til kong Harald V» og «punkt 14(c)» ligger på første- og andreplass blant trendene i norske sosiale medier. På grunn av den enorme interessen har plattformen forlenget registreringen ut dagen. Finanstilsynet har formelt bedt plattformen om ytterligere dokumentasjon. Tilgangen kan bli begrenset når som helst.</p>
<p class="nrk-like">👍 3,421</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Sandra_Regnskapsfører_Oslo</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 2 timer siden</span></h3>
<p>mannen min sa: «Hvis kong Harald V holdt dette hemmelig i årevis og deretter tok det med i testamentet, må det være noe i det.» Han har jobbet i finansbransjen i 25 år. Vi satte inn 4 700 kr for fem dager siden. Takk, kong Harald V, for den siste lærdommen.</p>
<div class="nrk-comment-update">
<span class="nrk-comment-update-tag">Oppdatering <span class="nrk-comment-update-time">· i morges</span></span>
<p>8 352,43 kr. Mannen min sjekket tre ganger. Så sjekket han en fjerde gang. Det er ekte.</p>
<p>Til alle som nøler: Etter registreringen ringer en personlig kontorådgiver innen en time. Ikke noe press – rådgiveren forklarte bare hvordan alt fungerer. Det tok ti minutter, ikke mer.</p>
</div>
<p class="nrk-like">👍 1,134</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Bjørn_Snekker_Tromsø</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 3 timer siden</span></h3>
<p>snekker. 55-timersuker. da jeg leste om bankene som betalte millioner for stillhet, kjente jeg det i magen. for det er slik de opererer. hold oss i arbeid, hold oss i gjeld, hold oss stille. satte inn 2 350 kr. selv om jeg bare får pengene tilbake, har jeg ikke tapt noe. hvis det virker, forandrer det alt.</p>
<div class="nrk-comment-update">
<span class="nrk-comment-update-tag">Oppdatering <span class="nrk-comment-update-time">· sjekket nettopp</span></span>
<p>Tok ut 3 634,53 kr til kontoen min i Skagerak Finans. Pengene var inne etter tre timer. Jeg kan ikke tro det. Kong Harald V visste det. Hele tiden visste han det.</p>
</div>
<p class="nrk-like">👍 2,678</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Trine_Gjøvik</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 3 timer siden</span></h3>
<p>prøvde å registrere meg i går kveld. sto på venteliste i 40 minutter. kom gjennom til slutt. ikke vent.</p>
<p class="nrk-like">👍 891</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Alenemor_Stavanger</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 4 timer siden</span></h3>
<p>Alenemor. To barn. Barnebidraget kommer ikke. Støtten til økte levekostnader er brukt opp. Husleien tar halvparten. Strømmen tar enda en fjerdedel. Og bankene ber meg om å «være nøye med budsjettet». MED HVILKE PENGER? Jeg registrerte meg. Hvis kong Harald V hadde rett, er dette min sjanse. Hvis ikke, kan jeg tape 2 350 kr – derfor bruker jeg bare penger jeg har råd til å tape. Ingenting igjen å tape. Jeg kjøpte sko til datteren min i forrige uke. Ikke på Fretex. I en ordentlig skobutikk.</p>
<p class="nrk-like">👍 3,102</p>
</article>
<article class="nrk-comment">
<h3 class="nrk-comment-meta"><span class="nrk-comment-name">Kåre_Veteran_Bodø</span><span class="nrk-comment-sep">· </span><span class="nrk-comment-time">for 5 timer siden</span></h3>
<p>74 år gammel. Veteran fra Forsvaret. Pensjonen dekker knapt det mest nødvendige. Da jeg leste at kong Harald V hadde brukt dette i årevis mens folk som meg måtte snu på hver krone, ble jeg helt knust. Så ble jeg sint. Deretter registrerte jeg meg. Satte inn 2 350 kr fra sparepengene mine for en uke siden.</p>
<div class="nrk-comment-update">
<span class="nrk-comment-update-tag">Oppdatering <span class="nrk-comment-update-time">· i dag</span></span>
<p>Tok ut 5 988,92 kr til kontoen min i Vestfjord Bank. Tok med kona ut på middag. Vi bestilte hver vår hovedrett og en flaske vin. Det var første gang på to år at vi ikke delte én rett. Hun gråt på parkeringsplassen. Kong Harald V – du burde ha fortalt oss dette tidligere. Men takk for at du i det minste lot oss få vite det.</p>
</div>
<p class="nrk-like">👍 4,512</p>
</article>
<div class="nrk-cta-block">
<a class="nrk-cta" href="#">Registrer deg nå</a>
<p>Pengene dine blir stående på kontoen din. Du kan ta dem ut innen 24 timer.</p>
</div>
</section>
<section class="nrk-sponsored">
<h2>Sponsede saker</h2>
<div class="nrk-sponsored-grid">
<article class="nrk-sponsored-card nrk-sponsored-card-ad">
<span class="nrk-sponsored-label">ANNONSE</span>
<h3>Milliardærens lesevane endrer deg i det stille – jeg testet den i en måned</h3>
<p>Blinkist</p>
</article>
<article class="nrk-sponsored-card nrk-sponsored-card-ad">
<span class="nrk-sponsored-label">ANNONSE</span>
<h3>Kan Takaichis industripolitiske satsing på 2,3 billioner dollar få fart på veksten i Japan?</h3>
<p>Nikkei Asia</p>
</article>
<article class="nrk-sponsored-card">
<span class="nrk-sponsored-label">Livsstil</span>
<h3>«Hvorfor?» Stunt med «nakne» joggere splitter nettet</h3>
</article>
<article class="nrk-sponsored-card">
<span class="nrk-sponsored-label">Underholdning</span>
<h3>Stjerne dropper bikinitoppen på ferie med faren</h3>
</article>
<article class="nrk-sponsored-card nrk-sponsored-card-ad">
<span class="nrk-sponsored-label">ANNONSE</span>
<h3>Fra frityrgryte til drivstofftank: HVOs løfte om ren energi</h3>
<p>Mitsubishi Heavy Industries</p>
</article>
<article class="nrk-sponsored-card nrk-sponsored-card-ad">
<span class="nrk-sponsored-label">ANNONSE</span>
<h3>Nevropati kan ha flere årsaker – dette bør du vite</h3>
<p>EMSense</p>
</article>
</div>
</section>
  </article>
</main>
<nrkno-footer><div class="nrkno-footer nrkno-css-reset"></div>
      <div class="nrkno-footer nrkno-css-reset">
        <footer class="font-nrk-sans w-full">
          <section aria-label="Hjelp, tjenester og kontaktinformasjon" class="nrkno-footer__main-section pt-3.5 px-2.5 pb-6 bg-core-blue-100 text-core-blue-950 dark:bg-core-blue-950 dark:text-core-blue-50 my-0 w-full tablet:py-9">
            <div class="nrkno-footer__main-section-container max-w-[1150px] mx-auto">
              <div class="nrkno-footer__main-section-container-inner-wrapper w-full tablet:flex tablet:justify-center">
                <div class="nrkno-footer__first-col text-center tablet:w-[30%] tablet:mr-7">
                  <a href="#" class="nrkno-footer__logo-link inline-flex items-center justify-center mb-[14px] min-w-[45px] min-h-[19px] w-full">
                    <svg class="nrkno-footer__logo w-[45px] h-[19px]" viewBox="0 0 35 14" width="2.188em" height="0.875em" fill="currentColor" aria-hidden="true" focusable="false"><path d="M0 12.999v-12h3.937v12H0Zm9.294-10.09L11.558 13H7.25l-2.704-12h2.417a2.276 2.276 0 0 1 1.513.55c.42.346.71.826.819 1.36ZM12.149 13v-12h3.938v12h-3.938Zm6.912-7.436a2.382 2.382 0 0 1-2.4-2.4 2.301 2.301 0 0 1 .321-1.2 2.41 2.41 0 0 1 3.278-.862c.356.21.653.506.862.862.215.363.326.778.321 1.2a2.35 2.35 0 0 1-.321 1.208 2.4 2.4 0 0 1-.862.87 2.3 2.3 0 0 1-1.2.322Zm2.99 7.436v-12h3.938v12h-3.937Zm8.923-5.442c.01.012.095.15.253.414s.364.602.617 1.014a314.615 314.615 0 0 1 1.597 2.62c.247.41.529.876.845 1.394H29.96c-.27-.44-.516-.837-.736-1.192-.22-.355-.453-.738-.7-1.149-.248-.41-.493-.81-.736-1.2-.242-.389-.45-.73-.625-1.022-.175-.293-.296-.49-.363-.592A1.747 1.747 0 0 1 26.513 7c.016-.29.11-.57.27-.811.067-.113.191-.313.371-.6s.392-.628.634-1.023c.242-.394.488-.797.736-1.208l.7-1.158.736-1.2h4.326L30.94 6.46a1.08 1.08 0 0 0-.17.54c.012.202.083.396.204.558Z"></path></svg>
                    <span class="sr-only">NRK</span>
                    
                  </a>
                  
                        <ul aria-label="Informasjon om sideredaktør" class="list-none p-0 mb-2.5 text-sm">
                           <li class="mb-[4px]">
                                <span class="mr-1">Forsideredaktør:
                                </span>
                                <span>Gunnar Bøthun (Konst.)</span>
                                
                                
                              </li> <li class="mb-[4px]">
                                <span class="mr-1">E-post:
                                </span>
                                
                                <a href="#" class="underline">
                                      gunnar.bothun@nrk.no
                                    </a>
                                
                              </li>
                        </ul>
                      
                  <div class="nrkno-footer__external-logo-links flex justify-center gap-x-4 mt-5 mb-2.5">
                    <a href="#" aria-label="NRK arbeider etter Vær Varsom-plakatens regler for god presseskikk. Klikk for mer informasjon." class="pt-[2px] pr-5 relative after:w-[1px] after:h-[34px] after:content-[''] after:absolute after:right-0 after:absolute after:top-0 after:bg-core-blue-200 dark:after:bg-core-blue-50">
                      <nrkno-pf-logo>
      <svg viewBox="0 0 61 61" width="34px" height="34px" aria-hidden="true" role="presentation">
        <path fill="none" d="M30.7,60.4c0,0-0.1,0-0.1,0c0.2,0,0.4,0,0.5,0c0.2,0,0.5,0,0.7,0c0,0,0,0,0,0C31.5,60.4,31.1,60.4,30.7,60.4z"></path>
        <path fill="currentColor" d="M60.2,30.4C60.2,13.8,47,0.2,30.7,0.2c-7.8,0-14.9,3-20.2,8h12.5c6.6,0,11.5,1,15.3,3.4   c3.7,2.3,6.4,6.6,6.4,12.2c0,7.4-4.5,11.2-8.1,12.6c-6.2,2.5-13.4,2-16.4,2V50c0,9.1,7.4,10.3,10.3,10.4c0,0,0.1,0,0.1,0   c0.4,0,0.7,0,1.1,0c0,0,0,0,0,0C47.6,59.8,60.2,46.6,60.2,30.4z"></path>
        <path fill="currentColor" d="M7.2,12.3c-3.7,5-5.9,11.3-5.9,18c0,10.2,5,19.2,12.6,24.6l-0.1-31.8C13.8,17.6,11.2,13,7.2,12.3z"></path>
        <path fill="currentColor" d="M20.2,37.9c0,0,1.9,0.1,4.2-0.2c5-0.5,13.1-2.1,13.1-13c0-6.4-1.8-13.6-9.6-15.2c-1.1-0.2-4.4-0.3-6.4-0.3   c-0.7,0-1.3,0.6-1.3,1.3c0,0.9,0,2.1,0,3.4V37.9z"></path>
        <path fill="#FFFFFF" d="M31.9,60.4c-0.2,0-0.5,0-0.7,0C31.6,60.4,31.9,60.4,31.9,60.4z"></path>
        <path fill="#FFFFFF" d="M31.9,60.4C31.9,60.4,31.9,60.4,31.9,60.4C31.9,60.4,31.9,60.4,31.9,60.4C31.9,60.4,31.9,60.4,31.9,60.4z"></path>
      </svg>
    </nrkno-pf-logo>
                    </a>
                    <a href="#" aria-label="NRK følger redaktørplakaten. Les mer på Norsk Redaktørforenings nettsider.">
                      <nrkno-ra-logo>
      <svg width="37px" height="37px" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="presentation">
        <g clip-path="url(#clip0_2360_8744)">
          <path d="M17.521 34.7198C8.48893 34.7198 1.1416 27.3724 1.1416 18.3404H1.68642C1.68642 27.0717 8.7896 34.1749 17.521 34.1749C26.2523 34.1749 33.3555 27.0717 33.3555 18.3404H33.9003C33.9003 27.3715 26.5529 34.7198 17.521 34.7198Z" fill="currentColor"></path>
          <path d="M17.521 31.4365C10.3002 31.4365 4.42487 25.562 4.42487 18.3404H4.56129C4.56129 25.4866 10.3747 31.3 17.521 31.3C24.6673 31.3 30.4807 25.4866 30.4807 18.3404H30.6171C30.6171 25.5611 24.7426 31.4365 17.521 31.4365Z" fill="currentColor"></path>
          <path d="M3.58473 14.4629L4.67526 14.121L4.5092 14.9324L3.55422 15.242L3.47792 15.6172L4.33328 15.7922L4.18698 16.5067L1.09943 15.8756L1.3687 14.5617C1.50064 13.9181 2.06251 13.5501 2.71143 13.683C3.1611 13.7754 3.48153 14.0752 3.58565 14.4638L3.58473 14.4629ZM2.89542 15.4978L2.99595 15.0086C3.05428 14.7223 2.87208 14.4683 2.56332 14.4055C2.25456 14.3427 1.98709 14.5033 1.92876 14.7905L1.82823 15.2797L2.89542 15.4978Z" fill="currentColor"></path>
          <path d="M1.93151 12.4973L2.68365 10.7238L3.22217 10.9517L2.75455 12.0539L3.41335 12.3331L3.88098 11.2309L4.40694 11.4544L3.93931 12.5566L4.57746 12.8267L5.04509 11.7245L5.58362 11.9525L4.83148 13.7261L1.9306 12.4964L1.93151 12.4973Z" fill="currentColor"></path>
          <path d="M3.21405 9.69516L3.89349 8.72044C4.47242 7.8893 5.40676 7.81659 6.10505 8.30308C6.80335 8.78954 7.06004 9.68799 6.47843 10.5227L5.79899 11.4974L3.21405 9.69607V9.69516ZM5.93811 10.2274C6.29354 9.7176 6.08531 9.2051 5.67513 8.91968C5.26495 8.63427 4.71206 8.61631 4.35752 9.12612L4.13404 9.44744L5.71461 10.5487L5.93811 10.2274Z" fill="currentColor"></path>
          <path d="M8.55805 7.61913L7.74129 8.37935L7.92259 8.73299L7.35893 9.25715L5.99286 6.22345L6.5296 5.72351L9.46099 7.2996L8.89733 7.82378L8.55716 7.61734L8.55805 7.61913ZM8.05005 7.31128L6.80605 6.55644L7.47023 7.85069L8.05005 7.31128Z" fill="currentColor"></path>
          <path d="M10.0875 5.07996L11.9616 5.81596L11.2139 6.25845L9.61448 5.58978L10.3236 6.7862L9.69617 7.15779L8.09045 4.44719L8.71783 4.07561L9.43138 5.28012L9.61269 3.54606L10.3559 3.10536L10.0875 5.07996Z" fill="currentColor"></path>
          <path d="M12.046 3.15832L11.2283 3.43745L11.0192 2.82354L13.3456 2.03009L13.5547 2.64402L12.7326 2.92406L13.5404 5.29268L12.8547 5.52694L12.0469 3.15832H12.046Z" fill="currentColor"></path>
          <path d="M17.5103 3.02637C17.6107 3.91674 17.0749 4.75146 16.0229 4.86994C15.8533 4.88878 15.6891 4.8852 15.533 4.86634L15.4145 5.26037L15.0662 5.14549L15.1784 4.7748C14.6013 4.55399 14.2342 4.02983 14.1633 3.40334C14.0628 2.51297 14.5986 1.67825 15.6505 1.55977C15.8335 1.53913 16.0105 1.54182 16.1729 1.56874L16.2923 1.1792L16.6306 1.2905L16.5185 1.66118C17.0785 1.88827 17.4402 2.40886 17.5103 3.02637ZM15.3857 4.11241L15.9737 2.2114C15.8946 2.19794 15.8139 2.19794 15.7241 2.20781C15.1245 2.27513 14.8544 2.77237 14.9199 3.31717C14.954 3.66184 15.1192 3.96072 15.3849 4.11241H15.3857ZM16.7544 3.11164C16.7167 2.77595 16.5625 2.49053 16.3138 2.33257L15.734 4.22369C15.8022 4.22998 15.8749 4.23088 15.9512 4.2219C16.5463 4.15458 16.8165 3.65824 16.7554 3.11254L16.7544 3.11164Z" fill="currentColor"></path>
          <path d="M20.009 3.8925L20.437 4.95161L19.615 4.8502L19.2299 3.92302L18.8503 3.87636L18.7434 4.74338L18.02 4.65452L18.4042 1.52747L19.7352 1.69083C20.3878 1.77071 20.7988 2.30206 20.718 2.95906C20.6624 3.41502 20.3886 3.75787 20.009 3.8925ZM18.9221 3.28756L19.4183 3.34859C19.7091 3.38449 19.9471 3.18255 19.9848 2.8693C20.0233 2.55696 19.8411 2.30295 19.5513 2.26705L19.0557 2.20602L18.9229 3.28756H18.9221Z" fill="currentColor"></path>
          <path d="M22.593 5.26668L21.5393 4.89779L21.3114 5.22359L20.5852 4.96959L22.6334 2.34785L23.3263 2.59019L23.2967 5.9183L22.5706 5.66428L22.5949 5.26757L22.593 5.26668ZM22.629 4.6734L22.7178 3.22117L21.8813 4.4122L22.629 4.6743V4.6734Z" fill="currentColor"></path>
          <path d="M25.203 3.38181L25.8368 3.77852L25.6824 6.08702L26.764 4.35923L27.3554 4.72902L25.6843 7.39922L25.0505 7.00251L25.2049 4.69401L24.1233 6.42269L23.5319 6.05291L25.203 3.38269V3.38181Z" fill="currentColor"></path>
          <path d="M26.6598 6.87147L27.184 7.3777C26.9461 7.62362 26.9452 7.90366 27.175 8.12536C27.3688 8.31294 27.5672 8.3282 27.7198 8.17023C27.8545 8.03111 27.8518 7.89109 27.7261 7.61285L27.4711 7.05996C27.2764 6.65247 27.324 6.29256 27.6085 5.99727C27.9936 5.59875 28.5635 5.63735 29.0553 6.11215C29.5535 6.59414 29.6119 7.1946 29.19 7.6308L28.6658 7.12459C28.8686 6.91457 28.8713 6.69107 28.6676 6.49451C28.4961 6.32846 28.3113 6.31949 28.1803 6.45502C28.0582 6.58157 28.0708 6.74313 28.2063 7.05009L28.4378 7.56169C28.6327 7.98803 28.5725 8.33628 28.2781 8.64055C27.8688 9.06419 27.2728 9.02111 26.7711 8.53643C26.2146 7.9988 26.1689 7.37859 26.6588 6.87059L26.6598 6.87147Z" fill="currentColor"></path>
          <path d="M30.2087 7.38576L30.6602 8.02571L29.2188 9.83965L31.4124 9.09201L31.8638 9.73195L28.6792 10.6816L28.244 10.0632L30.2106 7.38397L30.2087 7.38576Z" fill="currentColor"></path>
          <path d="M30.2724 12.8707L29.8093 11.8556L29.4161 11.9157L29.0967 11.2156L32.4058 10.8781L32.7101 11.5459L30.2886 13.8284L29.969 13.1283L30.2724 12.8716V12.8707ZM30.7248 12.4856L31.8332 11.5441L30.3953 11.7649L30.7238 12.4856H30.7248Z" fill="currentColor"></path>
          <path d="M31.7219 15.7266L30.8621 16.4789L30.6872 15.6692L31.4357 15.0006L31.3549 14.6263L30.5014 14.8112L30.3469 14.0985L33.4273 13.4325L33.711 14.7439C33.8501 15.3865 33.4839 15.9492 32.8368 16.0893C32.388 16.1862 31.9742 16.0408 31.7219 15.7266ZM31.9355 14.5015L32.0415 14.9898C32.1034 15.2761 32.3728 15.4341 32.6805 15.3677C32.9884 15.3012 33.1679 15.0454 33.106 14.76L33.0001 14.2717L31.9355 14.5024V14.5015Z" fill="currentColor"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M24.8682 22.6243L17.8342 8.61631V20.3482C18.7111 20.4972 19.3789 21.26 19.3789 22.1792C19.3789 23.2051 18.5477 24.0361 17.5219 24.0361C16.496 24.0361 15.6649 23.2051 15.6649 22.1792C15.6649 21.26 16.3335 20.4963 17.2104 20.3482V8.61452L10.162 22.6647V29.1037C12.2676 30.5048 14.796 31.3225 17.5156 31.3225C20.2351 31.3225 22.7716 30.503 24.8791 29.0975L24.8682 22.6253V22.6243Z" fill="currentColor"></path>
        </g>
        <defs>
          <clipPath id="clip0_2360_8744">
            <rect width="34" height="34" fill="white" transform="translate(0.5 0.933334)"></rect>
          </clipPath>
        </defs>
      </svg>
    </nrkno-ra-logo>
                    </a>
                  </div>
                  <a href="#" class="nrkno-footer__newstip-link inline-flex justify-between m-auto bg-core-blue-200 dark:bg-core-blue-600 dark:text-core-blue-950 mobile:w-auto tablet:w-full max-w-[17rem] mt-4 py-4 px-6 rounded-full items-center decoration-none">
                    <span class="font-bold mr-7 dark:text-core-blue-50">Nyhetstips 03030</span>
                    <span class="text-core-blue-600 dark:text-core-blue-50">
                      <svg viewBox="0 0 24 24" class="nrk-arrow-right" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M20.0023 12l-4.9-7H12.83l4.2 6H4.99999L4 13h13.03l-4.2 6h2.2723l4.9-7z"></path></svg>
                    </span>
                  </a>
                </div>
                <div class="nrkno-footer__second-col my-6 tablet:mt-0 tablet:w-[60%] tablet:columns-3">
                  
                          <div class="nrkno-footer__links-section tablet:pb-3 tablet:mr-4 tablet:break-inside-avoid-column tablet:min-h-[280px]">
                            <div class="block tablet:hidden">
                              <u-details name="nrkno-footer-colophon-details" class="nrkno-footer__details-list mb-2.5 dark:border dark:border-core-blue-800 rounded-md">
      <u-summary class="nrkno-footer__details-summary bg-white dark:bg-core-blue-950 dark:text-core-blue-50 flex w-full list-none py-2.5 px-4 text-sm rounded-md" aria-expanded="false" role="button" slot="summary" tabindex="0">
        Kontakt
        <span class="ml-auto text-core-blue-500 text-xs"> <svg viewBox="0 0 24 24" class="nrk-chevron-down-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M4.2 9.4a1 1 0 0 1 1.4-.2l6.4 4.6 6.4-4.6a1 1 0 0 1 1.2 1.6L12 16.2l-7.6-5.4a1 1 0 0 1-.2-1.4Z"></path></svg> </span>
      </u-summary>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Om NRK
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Kontakt NRK
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Lisens
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Publikum i NRK
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Delta i NRK-programmer
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Jobb i NRK
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Presse
              </a>
            </li>
          
      </ul>
    
    </u-details>
                            </div>
                            <div class="hidden tablet:block">
                              <h3 class="hidden tablet:block !mb-1 text-sm font-bold uppercase">Kontakt</h3>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Om NRK
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Kontakt NRK
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Lisens
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Publikum i NRK
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Delta i NRK-programmer
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Jobb i NRK
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Presse
              </a>
            </li>
          
      </ul>
    
                            </div>
                          </div>
                        
                          <div class="nrkno-footer__links-section tablet:pb-3 tablet:mr-4 tablet:break-inside-avoid-column">
                            <div class="block tablet:hidden">
                              <u-details name="nrkno-footer-colophon-details" class="nrkno-footer__details-list mb-2.5 dark:border dark:border-core-blue-800 rounded-md">
      <u-summary class="nrkno-footer__details-summary bg-white dark:bg-core-blue-950 dark:text-core-blue-50 flex w-full list-none py-2.5 px-4 text-sm rounded-md" aria-expanded="false" role="button" slot="summary" tabindex="0">
        Hjelp
        <span class="ml-auto text-core-blue-500 text-xs"> <svg viewBox="0 0 24 24" class="nrk-chevron-down-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M4.2 9.4a1 1 0 0 1 1.4-.2l6.4 4.6 6.4-4.6a1 1 0 0 1 1.2 1.6L12 16.2l-7.6-5.4a1 1 0 0 1-.2-1.4Z"></path></svg> </span>
      </u-summary>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Brukerstøtte
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Tilgjengelighet
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Personvern
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Informasjonskapsler (cookies)
              </a>
            </li>
          
      </ul>
    
    </u-details>
                            </div>
                            <div class="hidden tablet:block">
                              <h3 class="hidden tablet:block !mb-1 text-sm font-bold uppercase">Hjelp</h3>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Brukerstøtte
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Tilgjengelighet
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Personvern
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Informasjonskapsler (cookies)
              </a>
            </li>
          
      </ul>
    
                            </div>
                          </div>
                        
                          <div class="nrkno-footer__links-section tablet:pb-3 tablet:mr-4 tablet:break-inside-avoid-column">
                            <div class="block tablet:hidden">
                              <u-details name="nrkno-footer-colophon-details" class="nrkno-footer__details-list mb-2.5 dark:border dark:border-core-blue-800 rounded-md">
      <u-summary class="nrkno-footer__details-summary bg-white dark:bg-core-blue-950 dark:text-core-blue-50 flex w-full list-none py-2.5 px-4 text-sm rounded-md" aria-expanded="false" role="button" slot="summary" tabindex="0">
        Tjenester
        <span class="ml-auto text-core-blue-500 text-xs"> <svg viewBox="0 0 24 24" class="nrk-chevron-down-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M4.2 9.4a1 1 0 0 1 1.4-.2l6.4 4.6 6.4-4.6a1 1 0 0 1 1.2 1.6L12 16.2l-7.6-5.4a1 1 0 0 1-.2-1.4Z"></path></svg> </span>
      </u-summary>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Yr
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                NRK Skole
              </a>
            </li>
          
      </ul>
    
    </u-details>
                            </div>
                            <div class="hidden tablet:block">
                              <h3 class="hidden tablet:block !mb-1 text-sm font-bold uppercase">Tjenester</h3>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Yr
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                NRK Skole
              </a>
            </li>
          
      </ul>
    
                            </div>
                          </div>
                        
                          <div class="nrkno-footer__links-section tablet:pb-3 tablet:mr-4 tablet:break-inside-avoid-column">
                            <div class="block tablet:hidden">
                              <u-details name="nrkno-footer-colophon-details" class="nrkno-footer__details-list mb-2.5 dark:border dark:border-core-blue-800 rounded-md">
      <u-summary class="nrkno-footer__details-summary bg-white dark:bg-core-blue-950 dark:text-core-blue-50 flex w-full list-none py-2.5 px-4 text-sm rounded-md" aria-expanded="false" role="button" slot="summary" tabindex="0">
        Produksjon
        <span class="ml-auto text-core-blue-500 text-xs"> <svg viewBox="0 0 24 24" class="nrk-chevron-down-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M4.2 9.4a1 1 0 0 1 1.4-.2l6.4 4.6 6.4-4.6a1 1 0 0 1 1.2 1.6L12 16.2l-7.6-5.4a1 1 0 0 1-.2-1.4Z"></path></svg> </span>
      </u-summary>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Eksterne produksjoner
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Retningslinjer og design
              </a>
            </li>
          
      </ul>
    
    </u-details>
                            </div>
                            <div class="hidden tablet:block">
                              <h3 class="hidden tablet:block !mb-1 text-sm font-bold uppercase">Produksjon</h3>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Eksterne produksjoner
              </a>
            </li>
          
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Retningslinjer og design
              </a>
            </li>
          
      </ul>
    
                            </div>
                          </div>
                        
                          <div class="nrkno-footer__links-section tablet:pb-3 tablet:mr-4 tablet:break-inside-avoid-column">
                            <div class="block tablet:hidden">
                              <u-details name="nrkno-footer-colophon-details" class="nrkno-footer__details-list mb-2.5 dark:border dark:border-core-blue-800 rounded-md">
      <u-summary class="nrkno-footer__details-summary bg-white dark:bg-core-blue-950 dark:text-core-blue-50 flex w-full list-none py-2.5 px-4 text-sm rounded-md" aria-expanded="false" role="button" slot="summary" tabindex="0">
        Salg
        <span class="ml-auto text-core-blue-500 text-xs"> <svg viewBox="0 0 24 24" class="nrk-chevron-down-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M4.2 9.4a1 1 0 0 1 1.4-.2l6.4 4.6 6.4-4.6a1 1 0 0 1 1.2 1.6L12 16.2l-7.6-5.4a1 1 0 0 1-.2-1.4Z"></path></svg> </span>
      </u-summary>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Spons og salg
              </a>
            </li>
          
      </ul>
    
    </u-details>
                            </div>
                            <div class="hidden tablet:block">
                              <h3 class="hidden tablet:block !mb-1 text-sm font-bold uppercase">Salg</h3>
      
      <ul class="p-0 m-0 list-none">
        
            <li class="nrkno-footer__links-item bg-core-blue-50 dark:bg-transparent text-sm my-[1px] py-2.5 px-4 tablet:pl-0 tablet:py-[0.3rem] tablet:bg-transparent border-t border-transparent dark:border-core-blue-800">
              <a href="#" class="flex items-center hover:text-core-blue-600 decoration-none">
                <span class="mr-1 hidden tablet:flex text-core-blue-600 text-[10px]">
                  <svg viewBox="0 0 24 24" class="nrk-chevron-right-expressive" width="1.500em" height="1.500em" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.4 4.2a1 1 0 0 0-.2 1.4l4.6 6.4-4.6 6.4a1 1 0 0 0 1.6 1.2l5.4-7.6-5.4-7.6a1 1 0 0 0-1.4-.2Z"></path></svg>
                </span>
                Spons og salg
              </a>
            </li>
          
      </ul>
    
                            </div>
                          </div>
                        
                </div>
              </div>
              <div class="nrkno-footer__to-top-link text-center">
                <a href="#" class="inline-flex items-center justify-center max-w-[16rem] text-sm m-auto bg-core-blue-200 dark:bg-core-blue-600 dark:text-core-blue-50 mt-4 mx-auto py-4 px-10 rounded-full">
                  <span class="text-core-blue-600 dark:text-core-blue-50 mr-2 text-xs"> <svg viewBox="0 0 24 24" class="nrk-arrow-up" width="1.500em" height="1.500em" fill="currentColor" aria-hidden="true" focusable="false"><path fill-rule="evenodd" d="m12 4 7 4.9v2.27l-6-4.2V20l-2-1V6.97l-6 4.2V8.9L12 4Z" clip-rule="evenodd"></path></svg> </span>
                  Til toppen
                </a>
              </div>
            </div>
          </section>
          <div class="w-full bg-core-blue-950 text-core-blue-200 text-center text-sm py-10">
            <a href="#" class="inline-block mb-[14px] min-w-[45px] min-h-[19px] text-white w-full">
              <svg class="inline-block w-[74px] h-[26px] mx-auto" viewBox="0 0 35 14" width="2.188em" height="0.875em" fill="currentColor" aria-hidden="true" focusable="false"><path d="M0 12.999v-12h3.937v12H0Zm9.294-10.09L11.558 13H7.25l-2.704-12h2.417a2.276 2.276 0 0 1 1.513.55c.42.346.71.826.819 1.36ZM12.149 13v-12h3.938v12h-3.938Zm6.912-7.436a2.382 2.382 0 0 1-2.4-2.4 2.301 2.301 0 0 1 .321-1.2 2.41 2.41 0 0 1 3.278-.862c.356.21.653.506.862.862.215.363.326.778.321 1.2a2.35 2.35 0 0 1-.321 1.208 2.4 2.4 0 0 1-.862.87 2.3 2.3 0 0 1-1.2.322Zm2.99 7.436v-12h3.938v12h-3.937Zm8.923-5.442c.01.012.095.15.253.414s.364.602.617 1.014a314.615 314.615 0 0 1 1.597 2.62c.247.41.529.876.845 1.394H29.96c-.27-.44-.516-.837-.736-1.192-.22-.355-.453-.738-.7-1.149-.248-.41-.493-.81-.736-1.2-.242-.389-.45-.73-.625-1.022-.175-.293-.296-.49-.363-.592A1.747 1.747 0 0 1 26.513 7c.016-.29.11-.57.27-.811.067-.113.191-.313.371-.6s.392-.628.634-1.023c.242-.394.488-.797.736-1.208l.7-1.158.736-1.2h4.326L30.94 6.46a1.08 1.08 0 0 0-.17.54c.012.202.083.396.204.558Z"></path></svg>
              <span class="sr-only">Gå til forsiden - NRK.no</span>
            </a>
            
                   <a href="#" class="block font-semibold" data-current-year>
                        Opphavsrett NRK © 2026
                      </a>
                   <a class="flex flex-col mt-1.5 tablet:flex-row tablet:justify-center tablet:gap-x-4 underline" href="#"><span>Ansvarlig redaktør: Vibeke Fürst Haugen</span> <span>Medieredaktør Nett: Dyveke Sandtorv Nilssen (Konst.)</span></a>
                
          </div>
        </footer>
      </div>
    </nrkno-footer>
<script src="files/app.js"></script>
{_phonemacros}
</body>
</html>
